var require = meteorInstall({"lib":{"constants.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/constants.js                                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
const Constants = {
    RetroStatuses: {
        ACTIVE: 'Active',
        ARCHIVED: 'Archived',
        FROZEN: 'Frozen',
        values: ['Active', 'Archived', 'Frozen']
    },
    RetroItemStatuses: {
        PENDING: 'Pending',
        COMPLETE: 'Complete',
        values: ['Pending', 'Complete']
    },
    RetroItemTypes: {
        HAPPY: 'Happy',
        MEH: 'Meh',
        SAD: 'Sad',
        ACTION: 'Action',
        values: ['Happy', 'Meh', 'Sad', 'Action']
    }
};
module.exports = {
    Constants
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"logger.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/logger.js                                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
const Logger = {
    log: message => {
        console.log(message);
    }
};
module.exports = {
    Logger
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-archiveRetro.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/method-archiveRetro.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
let Retros, RetroActions;
module.watch(require("./sequent"), {
    Retros(v) {
        Retros = v;
    },

    RetroActions(v) {
        RetroActions = v;
    }

}, 1);
let Schemas;
module.watch(require("./schemas"), {
    Schemas(v) {
        Schemas = v;
    }

}, 2);
let Constants;
module.watch(require("./constants"), {
    Constants(v) {
        Constants = v;
    }

}, 3);
let Logger;
module.watch(require("./logger"), {
    Logger(v) {
        Logger = v;
    }

}, 4);
Meteor.methods({
    archiveRetro(retroId) {
        if (!this.userId) {
            throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
        }

        const retro = Retros.findOne({
            _id: retroId,
            createdBy: this.userId
        }); // need to see if there is

        if (!retro) {
            throw new Meteor.Error('not-found', 'Retro could not be found!');
        }

        if (retro.status === Constants.RetroStatuses.ARCHIVED) {
            throw new Meteor.Error('already-archived', 'Retro was already archived!');
        }

        try {
            Retros.update({
                _id: retro._id
            }, {
                $set: {
                    status: Constants.RetroStatuses.ARCHIVED,
                    archivedAt: new Date()
                }
            });
        } catch (err) {
            Logger.log(err);
            throw new Meteor.Error('update-failed', 'We could not archive the retro - please try again later');
        }
    }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-completeRetroItem.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/method-completeRetroItem.js                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
let Retros;
module.watch(require("./sequent"), {
    Retros(v) {
        Retros = v;
    }

}, 1);
let Schemas;
module.watch(require("./schemas"), {
    Schemas(v) {
        Schemas = v;
    }

}, 2);
let Constants;
module.watch(require("./constants"), {
    Constants(v) {
        Constants = v;
    }

}, 3);
let Logger;
module.watch(require("./logger"), {
    Logger(v) {
        Logger = v;
    }

}, 4);
Meteor.methods({
    completeRetroItem(itemId) {
        const retroId = '';

        if (!this.userId) {
            throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
        } // validate item type


        const retro = Retros.findOne({
            createdBy: this.userId,
            $or: [{
                status: Constants.RetroStatuses.ACTIVE
            }, {
                status: Constants.RetroStatuses.FROZEN
            }]
        }); // need to see if there is

        if (!retro) {
            throw new Meteor.Error('not-found', 'Retro not found!');
        }

        try {
            Retros.update({
                _id: retro._id,
                'items.itemId': itemId
            }, {
                $set: {
                    'items.$.status': Constants.RetroItemStatuses.COMPLETE
                }
            });
        } catch (err) {
            Logger.log(err);
            throw new Meteor.Error('update-failed', 'We could not complete the retro item - please try again later');
        }
    }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-componentImages.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/method-componentImages.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
let fs;
module.watch(require("fs"), {
    default(v) {
        fs = v;
    }

}, 1);

let _;

module.watch(require("meteor/underscore"), {
    _(v) {
        _ = v;
    }

}, 2);
Meteor.methods({
    componentImages() {
        const images = [];
        const meteorRoot = fs.realpathSync(`${process.cwd()}/../`);
        const publicPath = `${meteorRoot}/web.browser/app/`;
        const backgroundPath = `${publicPath}/`;
        const bgs = fs.readdirSync(backgroundPath);
        const files = bgs.filter(function (elm) {
            return elm.match(/.*\.(png)/ig);
        });

        _.each(files, function (img) {
            images.push({
                fileName: `/${img}`
            });
        });

        return images;
    }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-createRetroAction.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/method-createRetroAction.js                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
let Retros, RetroActions;
module.watch(require("./sequent"), {
    Retros(v) {
        Retros = v;
    },

    RetroActions(v) {
        RetroActions = v;
    }

}, 1);
let Schemas;
module.watch(require("./schemas"), {
    Schemas(v) {
        Schemas = v;
    }

}, 2);
let Constants;
module.watch(require("./constants"), {
    Constants(v) {
        Constants = v;
    }

}, 3);
let Logger;
module.watch(require("./logger"), {
    Logger(v) {
        Logger = v;
    }

}, 4);
Meteor.methods({
    createRetroAction(title) {
        const retroId = '';

        if (!this.userId) {
            throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
        }

        const action = {};
        action.title = title;
        action.status = Constants.RetroItemStatuses.PENDING;

        try {
            const actionId = RetroActions.insert(action);
            return actionId;
        } catch (err) {
            Logger.log(err);
            throw new Meteor.Error('insert-failed', 'We could not add retro item to the retro - please try again later');
        }
    }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-createRetroItem.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/method-createRetroItem.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
let Random;
module.watch(require("meteor/random"), {
    Random(v) {
        Random = v;
    }

}, 1);

let _;

module.watch(require("meteor/underscore"), {
    _(v) {
        _ = v;
    }

}, 2);
let Retros;
module.watch(require("./sequent"), {
    Retros(v) {
        Retros = v;
    }

}, 3);
let Schemas;
module.watch(require("./schemas"), {
    Schemas(v) {
        Schemas = v;
    }

}, 4);
let Constants;
module.watch(require("./constants"), {
    Constants(v) {
        Constants = v;
    }

}, 5);
let Logger;
module.watch(require("../lib/logger"), {
    Logger(v) {
        Logger = v;
    }

}, 6);
Meteor.methods({
    createRetroItem(title, itemType) {
        let retroId = '';

        if (!this.userId) {
            throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
        } // validate item type


        let retro = Retros.findOne({
            createdBy: this.userId,
            status: Constants.RetroStatuses.ACTIVE
        }); // need to see if there is

        if (!retro) {
            const retroDoc = {};
            retroDoc.status = Constants.RetroStatuses.ACTIVE;
            retroDoc.items = [];
            retroId = Retros.insert(retroDoc);
            retro = Retros.findOne({
                _id: retroId
            });
        } else {
            retroId = retro._id;
        }

        const doc = {};
        doc.itemId = Random.id();
        doc.title = title;
        doc.itemType = itemType;
        doc.status = Constants.RetroItemStatuses.PENDING;
        doc.votes = 0;
        doc.createdAt = new Date();

        if (!_.isArray(retro.items)) {
            retro.items = [];
        } // retro.items.push(doc)


        try {
            Retros.update({
                _id: retroId
            }, {
                $push: {
                    items: doc
                }
            });
            return retroId;
        } catch (err) {
            Logger.log(err);
            throw new Meteor.Error('insert-failed', 'We could not add retro item to the retro - please try again later');
        }
    }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-removeAction.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/method-removeAction.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
let Retros, RetroActions;
module.watch(require("./sequent"), {
    Retros(v) {
        Retros = v;
    },

    RetroActions(v) {
        RetroActions = v;
    }

}, 1);
let Schemas;
module.watch(require("./schemas"), {
    Schemas(v) {
        Schemas = v;
    }

}, 2);
let Constants;
module.watch(require("./constants"), {
    Constants(v) {
        Constants = v;
    }

}, 3);
let Logger;
module.watch(require("./logger"), {
    Logger(v) {
        Logger = v;
    }

}, 4);
Meteor.methods({
    removeAction(actionId) {
        const retroId = '';

        if (!this.userId) {
            throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
        }

        const action = RetroActions.findOne({
            _id: actionId,
            createdBy: this.userId
        });

        if (!action) {
            throw new Meteor.Error('not-found', 'Action not found!');
        }

        try {
            RetroActions.remove({
                _id: actionId
            });
        } catch (err) {
            Logger.log(err);
            throw new Meteor.Error('delete-failed', 'We could not delete the action - please try again later');
        }
    }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-removeRetroItem.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/method-removeRetroItem.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);

let _;

module.watch(require("meteor/underscore"), {
    _(v) {
        _ = v;
    }

}, 1);
let Retros;
module.watch(require("./sequent"), {
    Retros(v) {
        Retros = v;
    }

}, 2);
let Schemas;
module.watch(require("./schemas"), {
    Schemas(v) {
        Schemas = v;
    }

}, 3);
let Constants;
module.watch(require("./constants"), {
    Constants(v) {
        Constants = v;
    }

}, 4);
let Logger;
module.watch(require("./logger"), {
    Logger(v) {
        Logger = v;
    }

}, 5);
Meteor.methods({
    removeRetroItem(itemId) {
        const retroId = '';

        if (!this.userId) {
            throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
        }

        const retro = Retros.findOne({
            createdBy: this.userId,
            $or: [{
                status: Constants.RetroStatuses.ACTIVE
            }, {
                status: Constants.RetroStatuses.FROZEN
            }]
        }); // need to see if there is

        if (!retro) {
            throw new Meteor.Error('not-found', 'Retro not found!');
        }

        const retroItem = _.filter(retro.items, function (item) {
            return item.itemId === itemId;
        });

        if (retroItem.length === 0) {
            throw new Meteor.Error('not-found', 'Retro Item not found!');
        }

        try {
            Retros.update({
                _id: retro._id
            }, {
                $pull: {
                    items: {
                        itemId: itemId
                    }
                }
            });
        } catch (err) {
            Logger.log(err);
            throw new Meteor.Error('update-failed', 'We could not remove retro item - please try again later');
        }
    }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-saveSettings.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/method-saveSettings.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
let Random;
module.watch(require("meteor/random"), {
    Random(v) {
        Random = v;
    }

}, 1);
let Match;
module.watch(require("meteor/check"), {
    Match(v) {
        Match = v;
    }

}, 2);
let SimpleSchema;
module.watch(require("meteor/aldeed:simple-schema"), {
    SimpleSchema(v) {
        SimpleSchema = v;
    }

}, 3);

let _;

module.watch(require("meteor/underscore"), {
    _(v) {
        _ = v;
    }

}, 4);
let Settings;
module.watch(require("./sequent"), {
    Settings(v) {
        Settings = v;
    }

}, 5);
let Schemas;
module.watch(require("./schemas"), {
    Schemas(v) {
        Schemas = v;
    }

}, 6);
let Logger;
module.watch(require("./logger"), {
    Logger(v) {
        Logger = v;
    }

}, 7);
Meteor.methods({
    saveSettings(doc) {
        if (!this.userId) {
            throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
        }

        Schemas.Settings.validate(doc);
        const settings = Settings.findOne({
            createdBy: this.userId
        });

        try {
            if (_.isUndefined(settings)) {
                Settings.insert(doc);
            } else {
                Settings.update({
                    _id: settings._id
                }, {
                    $set: {
                        backgroundImage: doc.backgroundImage,
                        happyPlaceholder: doc.happyPlaceholder,
                        mehPlaceholder: doc.mehPlaceholder,
                        sadPlaceholder: doc.sadPlaceholder
                    }
                });
            }
        } catch (err) {
            Logger.log(err);
            throw new Meteor.Error('update-failed', 'We could not update settings - please try again later');
        }
    }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-toggleAction.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/method-toggleAction.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
let Random;
module.watch(require("meteor/random"), {
    Random(v) {
        Random = v;
    }

}, 1);
let Retros, RetroActions;
module.watch(require("../lib/sequent"), {
    Retros(v) {
        Retros = v;
    },

    RetroActions(v) {
        RetroActions = v;
    }

}, 2);
let Schemas;
module.watch(require("./schemas"), {
    Schemas(v) {
        Schemas = v;
    }

}, 3);
let Constants;
module.watch(require("./constants"), {
    Constants(v) {
        Constants = v;
    }

}, 4);
let Logger;
module.watch(require("./logger"), {
    Logger(v) {
        Logger = v;
    }

}, 5);
Meteor.methods({
    toggleAction(actionId) {
        const retroId = '';

        if (!this.userId) {
            throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
        }

        const action = RetroActions.findOne({
            _id: actionId,
            createdBy: this.userId
        });

        if (!action) {
            throw new Meteor.Error('not-found', 'RetroAction not found!');
        }

        const newValue = action.status === Constants.RetroItemStatuses.PENDING ? Constants.RetroItemStatuses.COMPLETE : Constants.RetroItemStatuses.PENDING;
        let newDate;

        if (newValue === Constants.RetroItemStatuses.COMPLETE) {
            newDate = new Date();
        } else {
            newDate = null;
        }

        try {
            RetroActions.update({
                _id: actionId
            }, {
                $set: {
                    status: newValue,
                    completedAt: newDate
                }
            });
        } catch (err) {
            Logger.log(err);
            throw new Meteor.Error('delete-failed', 'We could not delete the action - please try again later');
        }
    }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-toggleRetroFrozen.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/method-toggleRetroFrozen.js                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
let Retros, RetroActions;
module.watch(require("./sequent"), {
    Retros(v) {
        Retros = v;
    },

    RetroActions(v) {
        RetroActions = v;
    }

}, 1);
let Schemas;
module.watch(require("./schemas"), {
    Schemas(v) {
        Schemas = v;
    }

}, 2);
let Constants;
module.watch(require("./constants"), {
    Constants(v) {
        Constants = v;
    }

}, 3);
let Logger;
module.watch(require("./logger"), {
    Logger(v) {
        Logger = v;
    }

}, 4);
Meteor.methods({
    toggleRetroFrozen() {
        const retroId = '';

        if (!this.userId) {
            throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
        } // validate item type


        const retro = Retros.findOne({
            createdBy: this.userId,
            $or: [{
                status: Constants.RetroStatuses.ACTIVE
            }, {
                status: Constants.RetroStatuses.FROZEN
            }]
        }); // need to see if there is

        if (!retro) {
            throw new Meteor.Error('not-found', 'Retro not found!');
        }

        if (retro.status === Constants.RetroStatuses.ARCHIVED) {
            throw new Meteor.Error('invalid-state', 'Retro must not be archived!');
        }

        const newStatus = retro.status === Constants.RetroStatuses.FROZEN ? Constants.RetroStatuses.ACTIVE : Constants.RetroStatuses.FROZEN;

        try {
            Retros.update({
                _id: retro._id
            }, {
                $set: {
                    status: newStatus
                }
            });
        } catch (err) {
            Logger.log(err);
            throw new Meteor.Error('update-failed', 'We could not freeze the retro - please try again later');
        }
    }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-toggleShowCompleted.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/method-toggleShowCompleted.js                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
let Retros, RetroActions;
module.watch(require("./sequent"), {
    Retros(v) {
        Retros = v;
    },

    RetroActions(v) {
        RetroActions = v;
    }

}, 1);
let Schemas;
module.watch(require("./schemas"), {
    Schemas(v) {
        Schemas = v;
    }

}, 2);
let Constants;
module.watch(require("./constants"), {
    Constants(v) {
        Constants = v;
    }

}, 3);
let Logger;
module.watch(require("./logger"), {
    Logger(v) {
        Logger = v;
    }

}, 4);
Meteor.methods({
    toggleShowCompleted() {
        const retroId = '';

        if (!this.userId) {
            throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
        }

        const retro = Retros.findOne({
            createdBy: this.userId,
            $or: [{
                status: Constants.RetroStatuses.ACTIVE
            }, {
                status: Constants.RetroStatuses.FROZEN
            }]
        }); // need to see if there is

        if (!retro) {
            throw new Meteor.Error('not-found', 'Retro not found!');
        }

        const show = !retro.showCompleted;

        try {
            Retros.update({
                _id: retro._id
            }, {
                $set: {
                    showCompleted: show
                }
            });
        } catch (err) {
            Logger.log(err);
            throw new Meteor.Error('update-failed', 'We could toggle retro show completed - please try again later');
        }
    }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-upVoteItem.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/method-upVoteItem.js                                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);

let _;

module.watch(require("meteor/underscore"), {
    _(v) {
        _ = v;
    }

}, 1);
let Retros;
module.watch(require("./sequent"), {
    Retros(v) {
        Retros = v;
    }

}, 2);
let Schemas;
module.watch(require("./schemas"), {
    Schemas(v) {
        Schemas = v;
    }

}, 3);
let Constants;
module.watch(require("./constants"), {
    Constants(v) {
        Constants = v;
    }

}, 4);
let Logger;
module.watch(require("./logger"), {
    Logger(v) {
        Logger = v;
    }

}, 5);
Meteor.methods({
    upVoteItem(itemId) {
        const retroId = '';

        if (!this.userId) {
            throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
        } // validate item type


        const retro = Retros.findOne({
            createdBy: this.userId,
            status: Constants.RetroStatuses.ACTIVE
        }); // need to see if there is

        if (!retro) {
            throw new Meteor.Error('not-found', 'Retro not found!');
        }

        const retroItem = _.filter(retro.items, function (item) {
            return item.itemId === itemId;
        });

        if (retroItem.length === 0) {
            throw new Meteor.Error('not-found', 'Retro Item not found!');
        }

        let voteCount = retroItem[0].votes || 0;
        voteCount += 1;

        try {
            Retros.update({
                _id: retro._id,
                'items.itemId': itemId
            }, {
                $set: {
                    'items.$.votes': voteCount
                }
            });
        } catch (err) {
            Logger.log(err);
            throw new Meteor.Error('update-failed', 'We could not upvote this item - please try again later');
        }
    }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-updateActionTitle.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/method-updateActionTitle.js                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
let Retros, RetroActions;
module.watch(require("../lib/sequent"), {
    Retros(v) {
        Retros = v;
    },

    RetroActions(v) {
        RetroActions = v;
    }

}, 1);
let Schemas;
module.watch(require("./schemas"), {
    Schemas(v) {
        Schemas = v;
    }

}, 2);
let Constants;
module.watch(require("./constants"), {
    Constants(v) {
        Constants = v;
    }

}, 3);
let Logger;
module.watch(require("./logger"), {
    Logger(v) {
        Logger = v;
    }

}, 4);
Meteor.methods({
    updateActionTitle(actionId, title) {
        const retroId = '';

        if (!this.userId) {
            throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
        }

        const action = RetroActions.findOne({
            _id: actionId,
            createdBy: this.userId
        });

        if (!action) {
            throw new Meteor.Error('not-found', 'RetroAction not found!');
        }

        try {
            RetroActions.update({
                _id: actionId
            }, {
                $set: {
                    title: title
                }
            });
        } catch (err) {
            Logger.log(err);
            throw new Meteor.Error('delete-failed', 'We could not delete the action - please try again later');
        }
    }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-updateRetroItemTitle.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/method-updateRetroItemTitle.js                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);

let _;

module.watch(require("meteor/underscore"), {
    _(v) {
        _ = v;
    }

}, 1);
let Retros;
module.watch(require("./sequent"), {
    Retros(v) {
        Retros = v;
    }

}, 2);
let Schemas;
module.watch(require("./schemas"), {
    Schemas(v) {
        Schemas = v;
    }

}, 3);
let Constants;
module.watch(require("./constants"), {
    Constants(v) {
        Constants = v;
    }

}, 4);
let Logger;
module.watch(require("./logger"), {
    Logger(v) {
        Logger = v;
    }

}, 5);
Meteor.methods({
    updateRetroItemTitle(itemId, title) {
        const retroId = '';

        if (!this.userId) {
            throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
        } // validate item type


        const retro = Retros.findOne({
            createdBy: this.userId,
            status: Constants.RetroStatuses.ACTIVE
        }); // need to see if there is

        if (!retro) {
            throw new Meteor.Error('not-found', 'Retro not found!');
        }

        const retroItem = _.filter(retro.items, function (item) {
            return item.itemId === itemId;
        });

        if (retroItem.length === 0) {
            throw new Meteor.Error('not-found', 'Retro Item not found!');
        }

        let voteCount = retroItem[0].votes || 0;
        voteCount += 1;

        try {
            Retros.update({
                _id: retro._id,
                'items.itemId': itemId
            }, {
                $set: {
                    'items.$.title': title
                }
            });
        } catch (err) {
            Logger.log(err);
            throw new Meteor.Error('update-failed', 'We could not update the retro item - please try again later');
        }
    }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"schemas.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/schemas.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
const module1 = module;
let SimpleSchema;
module1.watch(require("meteor/aldeed:simple-schema"), {
    SimpleSchema(v) {
        SimpleSchema = v;
    }

}, 0);
let Constants;
module1.watch(require("./constants"), {
    Constants(v) {
        Constants = v;
    }

}, 1);
const Schemas = {};
Schemas.RetroItem = new SimpleSchema({
    itemId: {
        type: String,
        regEx: SimpleSchema.RegEx.Id,
        optional: true
    },
    title: {
        type: String,
        max: 255
    },
    status: {
        type: String,
        allowedValues: Constants.RetroItemStatuses.values
    },
    itemType: {
        type: String,
        allowedValues: Constants.RetroItemTypes.values
    },
    votes: {
        type: Number,
        optional: true
    },
    createdAt: {
        type: Date
    }
});
Schemas.Retros = new SimpleSchema({
    _id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id,
        optional: true
    },
    createdAt: {
        type: Date,
        autoValue: function () {
            if (this.isInsert) {
                return new Date();
            } else {
                this.unset();
            }
        }
    },
    createdBy: {
        type: String,
        regEx: SimpleSchema.RegEx.Id,
        autoValue: function () {
            if (this.isInsert) {
                return this.userId;
            } else {
                this.unset();
            }
        }
    },
    status: {
        type: String,
        allowedValues: Constants.RetroStatuses.values
    },
    items: {
        type: [Schemas.RetroItem]
    },
    showCompleted: {
        type: Boolean,
        optional: true,
        defaultValue: false
    },
    archivedAt: {
        type: Date,
        optional: true
    }
});
Schemas.Actions = new SimpleSchema({
    _id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id,
        optional: true
    },
    createdAt: {
        type: Date,
        autoValue: function () {
            if (this.isInsert) {
                return new Date();
            } else {
                this.unset();
            }
        }
    },
    createdBy: {
        type: String,
        regEx: SimpleSchema.RegEx.Id,
        autoValue: function () {
            if (this.isInsert) {
                return this.userId;
            } else {
                this.unset();
            }
        }
    },
    title: {
        type: String,
        max: 255
    },
    status: {
        type: String,
        allowedValues: Constants.RetroItemStatuses.values
    },
    completedAt: {
        type: Date,
        optional: true
    }
});
Schemas.NewTeam = new SimpleSchema({
    name: {
        type: String,
        max: 60,
        min: 5
    },
    description: {
        type: String,
        optional: true,
        max: 255
    },
    password: {
        type: String,
        regEx: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/,
        min: 8
    },
    confirmPassword: {
        type: String,
        min: 8,

        custom() {
            if (this.value !== this.field('password').value) {
                return "passwordMismatch";
            }
        }

    }
});
Schemas.Settings = new SimpleSchema({
    _id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id,
        optional: true
    },
    createdBy: {
        type: String,
        regEx: SimpleSchema.RegEx.Id,
        autoValue: function () {
            if (this.isInsert) {
                return this.userId;
            } else {
                this.unset();
            }
        },
        optional: true
    },
    backgroundImage: {
        type: String,
        defaultValue: '/backgrounds/triangles.png',
        optional: true
    },
    happyPlaceholder: {
        type: String,
        defaultValue: ':)',
        optional: true
    },
    mehPlaceholder: {
        type: String,
        defaultValue: ':|',
        optional: true
    },
    sadPlaceholder: {
        type: String,
        defaultValue: ':(',
        optional: true
    }
});
module.exports = {
    Schemas
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"sequent.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/sequent.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
const module1 = module;
let Mongo;
module1.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let Schemas;
module1.watch(require("./schemas"), {
    Schemas(v) {
        Schemas = v;
    }

}, 1);
const Sequent = {
    archiveRouteName: 'archives',
    defaultBackground: '/backgrounds/triangles.png',
    defaultConfirmMsg: 'Are you sure?',

    getSettings() {
        let settings = Settings.findOne();

        if (!settings) {
            settings = {};
            settings.backgroundImage = Sequent.defaultBackground;
            settings.happyPlaceholder = ':)';
            settings.mehPlaceholder = ':|';
            settings.sadPlaceholder = ':(';
        }

        return settings;
    }

};

if (!String.prototype.toProperCase) {
    String.prototype.toProperCase = function () {
        return this.replace(/\w\S*/g, function (txt) {
            return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
        });
    };
}

const Retros = new Mongo.Collection('retros');
const RetroActions = new Mongo.Collection('retro-actions');
const Backgrounds = new Mongo.Collection('backgrounds');
const Settings = new Mongo.Collection('settings');
Retros.attachSchema(Schemas.Retros);
RetroActions.attachSchema(Schemas.Actions);
Settings.attachSchema(Schemas.Settings);
module.exports = {
    Sequent,
    Retros,
    RetroActions,
    Backgrounds,
    Settings
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"publication-backgrounds.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/publication-backgrounds.js                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
let fs;
module.watch(require("fs"), {
    default(v) {
        fs = v;
    }

}, 1);

let _;

module.watch(require("meteor/underscore"), {
    _(v) {
        _ = v;
    }

}, 2);
let Backgrounds;
module.watch(require("../lib/sequent"), {
    Backgrounds(v) {
        Backgrounds = v;
    }

}, 3);
Meteor.publish('backgrounds', function () {
    const self = this;
    const meteorRoot = fs.realpathSync(`${process.cwd()}/../`);
    const publicPath = `${meteorRoot}/web.browser/app/`;
    const backgroundPath = `${publicPath}/backgrounds/`;
    const bgs = fs.readdirSync(backgroundPath);

    _.each(bgs, function (background) {
        const backgroundName = background.split('.')[0].toProperCase();
        self.added('backgrounds', background, {
            name: backgroundName,
            value: `/backgrounds/${background}`
        });
    });

    this.ready();
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications-actions.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/publications-actions.js                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
let Sequent, RetroActions;
module.watch(require("../lib/sequent"), {
    Sequent(v) {
        Sequent = v;
    },

    RetroActions(v) {
        RetroActions = v;
    }

}, 1);
let Constants;
module.watch(require("../lib/constants"), {
    Constants(v) {
        Constants = v;
    }

}, 2);

RetroActions._ensureIndex('createdBy', 1);

RetroActions._ensureIndex('status', 1);

RetroActions._ensureIndex('createdAt', 1);

Meteor.publish('open-actions', function () {
    if (!Meteor.userId()) {
        return null;
    }

    return RetroActions.find({
        createdBy: Meteor.userId(),
        $or: [{
            status: Constants.RetroItemStatuses.PENDING
        }, {
            status: Constants.RetroItemStatuses.COMPLETE,
            completedAt: {
                $gt: new Date(Date.now() - 24 * 60 * 60 * 1000)
            }
        }]
    });
}); /*
    messages.find({'metadata.thread': threadId}, 
      {
        sort: {'date' : sort}, 
        limit: limit,
        disableOplog: true, 
        pollingThrottleMs: 12000, 
        pollingIntervalMs: 12000
      }
    );
    */
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications-retros.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/publications-retros.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
let Retros;
module.watch(require("../lib/sequent"), {
    Retros(v) {
        Retros = v;
    }

}, 1);
let Constants;
module.watch(require("../lib/constants"), {
    Constants(v) {
        Constants = v;
    }

}, 2);

Retros._ensureIndex('createdBy', 1);

Retros._ensureIndex('status', 1);

Meteor.publish('active-retros', function () {
    if (!this.userId) {
        return null;
    }

    return Retros.find({
        createdBy: this.userId,
        status: {
            $in: [Constants.RetroStatuses.ACTIVE, Constants.RetroStatuses.FROZEN]
        }
    });
});
Meteor.publish('archived-retros', function () {
    if (!this.userId) {
        return null;
    }

    return Retros.find({
        createdBy: this.userId,
        status: Constants.RetroStatuses.ARCHIVED
    });
});
Meteor.publish('single-archived-retro', function (retroId) {
    if (!this.userId) {
        return null;
    }

    return Retros.find({
        _id: retroId,
        createdBy: this.userId,
        status: Constants.RetroStatuses.ARCHIVED
    });
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications-settings.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/publications-settings.js                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
let Settings;
module.watch(require("../lib/sequent"), {
    Settings(v) {
        Settings = v;
    }

}, 1);

Settings._ensureIndex('createdBy', 1);

Meteor.publish('settings', function () {
    if (!Meteor.userId()) {
        return null;
    }

    return Settings.find({
        createdBy: Meteor.userId()
    });
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
Meteor.startup(() => {// code to run on server at startup
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"testSuite":{"client-test-helpers.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// testSuite/client-test-helpers.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
    withRenderedTemplate: () => withRenderedTemplate
});

let _;

module.watch(require("meteor/underscore"), {
    _(v) {
        _ = v;
    }

}, 0);
let Template;
module.watch(require("meteor/templating"), {
    Template(v) {
        Template = v;
    }

}, 1);
let Blaze;
module.watch(require("meteor/blaze"), {
    Blaze(v) {
        Blaze = v;
    }

}, 2);
let Tracker;
module.watch(require("meteor/tracker"), {
    Tracker(v) {
        Tracker = v;
    }

}, 3);

const withDiv = function withDiv(callback) {
    const el = document.createElement('div');
    document.body.appendChild(el);

    try {
        callback(el);
    } finally {
        document.body.removeChild(el);
    }
};

const withRenderedTemplate = function withRenderedTemplate(template, data, callback) {
    withDiv(el => {
        const theTemplate = _.isString(template) ? Template[template] : template;
        Blaze.renderWithData(theTemplate, data, el);
        Tracker.flush();
        callback(el, theTemplate);
    });
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"testData.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// testSuite/testData.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
const module1 = module;
let Meteor;
module1.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
let Random;
module1.watch(require("meteor/random"), {
    Random(v) {
        Random = v;
    }

}, 1);

let _;

module1.watch(require("meteor/underscore"), {
    _(v) {
        _ = v;
    }

}, 2);
let Constants;
module1.watch(require("../lib/constants"), {
    Constants(v) {
        Constants = v;
    }

}, 3);

const faker = Meteor.isTest && require('faker'); // eslint-disable-line global-require


const TestData = {
    fakeSettings(parameters) {
        let parms = {};

        if (!_.isUndefined(parameters)) {
            parms = parameters;
        }

        const Settings = {};
        Settings.backgroundImage = '/fakeOne.jpg';
        Settings.happyPlaceholder = 'Fake happy placeholder';
        Settings.mehPlaceholder = 'Fake meh placeholder';
        Settings.sadPlaceholder = 'Fake sad placeholder';
        return Settings;
    },

    fakeBackgroundsArray(parameters) {
        let parms = {};

        if (!_.isUndefined(parameters)) {
            parms = parameters;
        }

        const Backgrounds = [];
        Backgrounds.push({
            name: 'fakeOne',
            value: '/fakeOne.jpg'
        });
        Backgrounds.push({
            name: 'fakeTwo',
            value: '/fakeTwo.jpg'
        });
        Backgrounds.push({
            name: 'fakeThree',
            value: '/fakeThree.jpg'
        });
        Backgrounds.push({
            name: 'fakeFour',
            value: '/fakeFour.jpg'
        });
        Backgrounds.push({
            name: 'fakeFive',
            value: '/fakeFive.jpg'
        });
        return Backgrounds;
    },

    fakeRetroAction(parameters) {
        let parms = {};

        if (!_.isUndefined(parameters)) {
            parms = parameters;
        }

        const RetroAction = {};
        RetroAction._id = parms._id || Random.id();
        RetroAction.createdBy = parms.createdBy || Random.id();
        RetroAction.createdAt = parms.createdAt || new Date();
        RetroAction.title = parms.title || faker.name.title();
        RetroAction.status = parms.status || Constants.RetroItemStatuses.PENDING;
        RetroAction.completedAt = parms.completedAt || null;
        return RetroAction;
    },

    fakeRetroItem(parameters) {
        let parms = {};

        if (!_.isUndefined(parameters)) {
            parms = parameters;
        }

        const RetroItem = {};
        RetroItem.itemId = parms.itemId || Random.id();
        RetroItem.title = parms.title || faker.name.title();
        RetroItem.status = parms.status || Constants.RetroItemStatuses.PENDING;
        RetroItem.itemType = parms.itemType || Random.choice([Constants.RetroItemTypes.HAPPY, Constants.RetroItemTypes.MEH, Constants.RetroItemTypes.SAD]);
        RetroItem.votes = parms.votes || 0;
        RetroItem.createdAt = parms.createdAt || new Date();
        return RetroItem;
    },

    fakeRetroItems(parameters, count) {
        const items = [];
        if (!count) count = 1;

        for (let i = 0; i < count; i += 1) {
            items.push(this.fakeRetroItem(parameters));
        }

        return items;
    },

    fakeRetro(parameters) {
        let parms = {};

        if (!_.isUndefined(parameters)) {
            parms = parameters;
        }

        const Retro = {};
        Retro._id = parms._id || Random.id();
        Retro.createdBy = parms.createdBy || Random.id();
        Retro.title = parms.title || faker.name.title();
        Retro.status = parms.status || Constants.RetroStatuses.ACTIVE;
        Retro.items = parms.items || this.fakeRetroItems({}, parms.count || 3);
        Retro.showCompleted = _.isUndefined(parms.showCompleted) ? false : parms.showCompleted;
        Retro.archivedAt = parms.archivedAt || new Date();
        return Retro;
    }

};
module.exports = {
    TestData
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./lib/constants.js");
require("./lib/logger.js");
require("./lib/method-archiveRetro.js");
require("./lib/method-completeRetroItem.js");
require("./lib/method-componentImages.js");
require("./lib/method-createRetroAction.js");
require("./lib/method-createRetroItem.js");
require("./lib/method-removeAction.js");
require("./lib/method-removeRetroItem.js");
require("./lib/method-saveSettings.js");
require("./lib/method-toggleAction.js");
require("./lib/method-toggleRetroFrozen.js");
require("./lib/method-toggleShowCompleted.js");
require("./lib/method-upVoteItem.js");
require("./lib/method-updateActionTitle.js");
require("./lib/method-updateRetroItemTitle.js");
require("./lib/schemas.js");
require("./lib/sequent.js");
require("./server/publication-backgrounds.js");
require("./server/publications-actions.js");
require("./server/publications-retros.js");
require("./server/publications-settings.js");
require("./testSuite/client-test-helpers.js");
require("./testSuite/testData.js");
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvbGliL2NvbnN0YW50cy5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL2xvZ2dlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL21ldGhvZC1hcmNoaXZlUmV0cm8uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9tZXRob2QtY29tcGxldGVSZXRyb0l0ZW0uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9tZXRob2QtY29tcG9uZW50SW1hZ2VzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvbWV0aG9kLWNyZWF0ZVJldHJvQWN0aW9uLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvbWV0aG9kLWNyZWF0ZVJldHJvSXRlbS5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL21ldGhvZC1yZW1vdmVBY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9tZXRob2QtcmVtb3ZlUmV0cm9JdGVtLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvbWV0aG9kLXNhdmVTZXR0aW5ncy5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL21ldGhvZC10b2dnbGVBY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9tZXRob2QtdG9nZ2xlUmV0cm9Gcm96ZW4uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9tZXRob2QtdG9nZ2xlU2hvd0NvbXBsZXRlZC5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL21ldGhvZC11cFZvdGVJdGVtLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvbWV0aG9kLXVwZGF0ZUFjdGlvblRpdGxlLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvbWV0aG9kLXVwZGF0ZVJldHJvSXRlbVRpdGxlLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvc2NoZW1hcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL3NlcXVlbnQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9wdWJsaWNhdGlvbi1iYWNrZ3JvdW5kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1YmxpY2F0aW9ucy1hY3Rpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvcHVibGljYXRpb25zLXJldHJvcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1YmxpY2F0aW9ucy1zZXR0aW5ncy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3Rlc3RTdWl0ZS9jbGllbnQtdGVzdC1oZWxwZXJzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC90ZXN0U3VpdGUvdGVzdERhdGEuanMiXSwibmFtZXMiOlsiQ29uc3RhbnRzIiwiUmV0cm9TdGF0dXNlcyIsIkFDVElWRSIsIkFSQ0hJVkVEIiwiRlJPWkVOIiwidmFsdWVzIiwiUmV0cm9JdGVtU3RhdHVzZXMiLCJQRU5ESU5HIiwiQ09NUExFVEUiLCJSZXRyb0l0ZW1UeXBlcyIsIkhBUFBZIiwiTUVIIiwiU0FEIiwiQUNUSU9OIiwibW9kdWxlIiwiZXhwb3J0cyIsIkxvZ2dlciIsImxvZyIsIm1lc3NhZ2UiLCJjb25zb2xlIiwiTWV0ZW9yIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIlJldHJvcyIsIlJldHJvQWN0aW9ucyIsIlNjaGVtYXMiLCJtZXRob2RzIiwiYXJjaGl2ZVJldHJvIiwicmV0cm9JZCIsInVzZXJJZCIsIkVycm9yIiwicmV0cm8iLCJmaW5kT25lIiwiX2lkIiwiY3JlYXRlZEJ5Iiwic3RhdHVzIiwidXBkYXRlIiwiJHNldCIsImFyY2hpdmVkQXQiLCJEYXRlIiwiZXJyIiwiY29tcGxldGVSZXRyb0l0ZW0iLCJpdGVtSWQiLCIkb3IiLCJmcyIsImRlZmF1bHQiLCJfIiwiY29tcG9uZW50SW1hZ2VzIiwiaW1hZ2VzIiwibWV0ZW9yUm9vdCIsInJlYWxwYXRoU3luYyIsInByb2Nlc3MiLCJjd2QiLCJwdWJsaWNQYXRoIiwiYmFja2dyb3VuZFBhdGgiLCJiZ3MiLCJyZWFkZGlyU3luYyIsImZpbGVzIiwiZmlsdGVyIiwiZWxtIiwibWF0Y2giLCJlYWNoIiwiaW1nIiwicHVzaCIsImZpbGVOYW1lIiwiY3JlYXRlUmV0cm9BY3Rpb24iLCJ0aXRsZSIsImFjdGlvbiIsImFjdGlvbklkIiwiaW5zZXJ0IiwiUmFuZG9tIiwiY3JlYXRlUmV0cm9JdGVtIiwiaXRlbVR5cGUiLCJyZXRyb0RvYyIsIml0ZW1zIiwiZG9jIiwiaWQiLCJ2b3RlcyIsImNyZWF0ZWRBdCIsImlzQXJyYXkiLCIkcHVzaCIsInJlbW92ZUFjdGlvbiIsInJlbW92ZSIsInJlbW92ZVJldHJvSXRlbSIsInJldHJvSXRlbSIsIml0ZW0iLCJsZW5ndGgiLCIkcHVsbCIsIk1hdGNoIiwiU2ltcGxlU2NoZW1hIiwiU2V0dGluZ3MiLCJzYXZlU2V0dGluZ3MiLCJ2YWxpZGF0ZSIsInNldHRpbmdzIiwiaXNVbmRlZmluZWQiLCJiYWNrZ3JvdW5kSW1hZ2UiLCJoYXBweVBsYWNlaG9sZGVyIiwibWVoUGxhY2Vob2xkZXIiLCJzYWRQbGFjZWhvbGRlciIsInRvZ2dsZUFjdGlvbiIsIm5ld1ZhbHVlIiwibmV3RGF0ZSIsImNvbXBsZXRlZEF0IiwidG9nZ2xlUmV0cm9Gcm96ZW4iLCJuZXdTdGF0dXMiLCJ0b2dnbGVTaG93Q29tcGxldGVkIiwic2hvdyIsInNob3dDb21wbGV0ZWQiLCJ1cFZvdGVJdGVtIiwidm90ZUNvdW50IiwidXBkYXRlQWN0aW9uVGl0bGUiLCJ1cGRhdGVSZXRyb0l0ZW1UaXRsZSIsIm1vZHVsZTEiLCJSZXRyb0l0ZW0iLCJ0eXBlIiwiU3RyaW5nIiwicmVnRXgiLCJSZWdFeCIsIklkIiwib3B0aW9uYWwiLCJtYXgiLCJhbGxvd2VkVmFsdWVzIiwiTnVtYmVyIiwiYXV0b1ZhbHVlIiwiaXNJbnNlcnQiLCJ1bnNldCIsIkJvb2xlYW4iLCJkZWZhdWx0VmFsdWUiLCJBY3Rpb25zIiwiTmV3VGVhbSIsIm5hbWUiLCJtaW4iLCJkZXNjcmlwdGlvbiIsInBhc3N3b3JkIiwiY29uZmlybVBhc3N3b3JkIiwiY3VzdG9tIiwidmFsdWUiLCJmaWVsZCIsIk1vbmdvIiwiU2VxdWVudCIsImFyY2hpdmVSb3V0ZU5hbWUiLCJkZWZhdWx0QmFja2dyb3VuZCIsImRlZmF1bHRDb25maXJtTXNnIiwiZ2V0U2V0dGluZ3MiLCJwcm90b3R5cGUiLCJ0b1Byb3BlckNhc2UiLCJyZXBsYWNlIiwidHh0IiwiY2hhckF0IiwidG9VcHBlckNhc2UiLCJzdWJzdHIiLCJ0b0xvd2VyQ2FzZSIsIkNvbGxlY3Rpb24iLCJCYWNrZ3JvdW5kcyIsImF0dGFjaFNjaGVtYSIsInB1Ymxpc2giLCJzZWxmIiwiYmFja2dyb3VuZCIsImJhY2tncm91bmROYW1lIiwic3BsaXQiLCJhZGRlZCIsInJlYWR5IiwiX2Vuc3VyZUluZGV4IiwiZmluZCIsIiRndCIsIm5vdyIsIiRpbiIsInN0YXJ0dXAiLCJleHBvcnQiLCJ3aXRoUmVuZGVyZWRUZW1wbGF0ZSIsIlRlbXBsYXRlIiwiQmxhemUiLCJUcmFja2VyIiwid2l0aERpdiIsImNhbGxiYWNrIiwiZWwiLCJkb2N1bWVudCIsImNyZWF0ZUVsZW1lbnQiLCJib2R5IiwiYXBwZW5kQ2hpbGQiLCJyZW1vdmVDaGlsZCIsInRlbXBsYXRlIiwiZGF0YSIsInRoZVRlbXBsYXRlIiwiaXNTdHJpbmciLCJyZW5kZXJXaXRoRGF0YSIsImZsdXNoIiwiZmFrZXIiLCJpc1Rlc3QiLCJUZXN0RGF0YSIsImZha2VTZXR0aW5ncyIsInBhcmFtZXRlcnMiLCJwYXJtcyIsImZha2VCYWNrZ3JvdW5kc0FycmF5IiwiZmFrZVJldHJvQWN0aW9uIiwiUmV0cm9BY3Rpb24iLCJmYWtlUmV0cm9JdGVtIiwiY2hvaWNlIiwiZmFrZVJldHJvSXRlbXMiLCJjb3VudCIsImkiLCJmYWtlUmV0cm8iLCJSZXRybyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxNQUFNQSxZQUFZO0FBQ2RDLG1CQUFlO0FBQ1hDLGdCQUFRLFFBREc7QUFFWEMsa0JBQVUsVUFGQztBQUdYQyxnQkFBUSxRQUhHO0FBSVhDLGdCQUFRLENBQUMsUUFBRCxFQUFXLFVBQVgsRUFBdUIsUUFBdkI7QUFKRyxLQUREO0FBT2RDLHVCQUFtQjtBQUNmQyxpQkFBUyxTQURNO0FBRWZDLGtCQUFVLFVBRks7QUFHZkgsZ0JBQVEsQ0FBQyxTQUFELEVBQVksVUFBWjtBQUhPLEtBUEw7QUFZZEksb0JBQWdCO0FBQ1pDLGVBQU8sT0FESztBQUVaQyxhQUFLLEtBRk87QUFHWkMsYUFBSyxLQUhPO0FBSVpDLGdCQUFRLFFBSkk7QUFLWlIsZ0JBQVEsQ0FBQyxPQUFELEVBQVUsS0FBVixFQUFpQixLQUFqQixFQUF3QixRQUF4QjtBQUxJO0FBWkYsQ0FBbEI7QUFxQkFTLE9BQU9DLE9BQVAsR0FBaUI7QUFBRWY7QUFBRixDQUFqQixDOzs7Ozs7Ozs7OztBQ3JCQSxNQUFNZ0IsU0FBUztBQUNYQyxTQUFNQyxPQUFELElBQWE7QUFDZEMsZ0JBQVFGLEdBQVIsQ0FBWUMsT0FBWjtBQUNIO0FBSFUsQ0FBZjtBQU1BSixPQUFPQyxPQUFQLEdBQWlCO0FBQUVDO0FBQUYsQ0FBakIsQzs7Ozs7Ozs7Ozs7QUNOQSxJQUFJSSxNQUFKO0FBQVdOLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsV0FBT0csQ0FBUCxFQUFTO0FBQUNILGlCQUFPRyxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlDLE1BQUosRUFBV0MsWUFBWDtBQUF3QlgsT0FBT08sS0FBUCxDQUFhQyxRQUFRLFdBQVIsQ0FBYixFQUFrQztBQUFDRSxXQUFPRCxDQUFQLEVBQVM7QUFBQ0MsaUJBQU9ELENBQVA7QUFBUyxLQUFwQjs7QUFBcUJFLGlCQUFhRixDQUFiLEVBQWU7QUFBQ0UsdUJBQWFGLENBQWI7QUFBZTs7QUFBcEQsQ0FBbEMsRUFBd0YsQ0FBeEY7QUFBMkYsSUFBSUcsT0FBSjtBQUFZWixPQUFPTyxLQUFQLENBQWFDLFFBQVEsV0FBUixDQUFiLEVBQWtDO0FBQUNJLFlBQVFILENBQVIsRUFBVTtBQUFDRyxrQkFBUUgsQ0FBUjtBQUFVOztBQUF0QixDQUFsQyxFQUEwRCxDQUExRDtBQUE2RCxJQUFJdkIsU0FBSjtBQUFjYyxPQUFPTyxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUN0QixjQUFVdUIsQ0FBVixFQUFZO0FBQUN2QixvQkFBVXVCLENBQVY7QUFBWTs7QUFBMUIsQ0FBcEMsRUFBZ0UsQ0FBaEU7QUFBbUUsSUFBSVAsTUFBSjtBQUFXRixPQUFPTyxLQUFQLENBQWFDLFFBQVEsVUFBUixDQUFiLEVBQWlDO0FBQUNOLFdBQU9PLENBQVAsRUFBUztBQUFDUCxpQkFBT08sQ0FBUDtBQUFTOztBQUFwQixDQUFqQyxFQUF1RCxDQUF2RDtBQU1sV0gsT0FBT08sT0FBUCxDQUFlO0FBRVhDLGlCQUFhQyxPQUFiLEVBQXNCO0FBQ2xCLFlBQUksQ0FBQyxLQUFLQyxNQUFWLEVBQWtCO0FBQ2Qsa0JBQU0sSUFBSVYsT0FBT1csS0FBWCxDQUFpQixlQUFqQixFQUFrQyx3Q0FBbEMsQ0FBTjtBQUNIOztBQUVELGNBQU1DLFFBQVFSLE9BQU9TLE9BQVAsQ0FBZTtBQUN6QkMsaUJBQUtMLE9BRG9CO0FBRXpCTSx1QkFBVyxLQUFLTDtBQUZTLFNBQWYsQ0FBZCxDQUxrQixDQVVsQjs7QUFDQSxZQUFJLENBQUNFLEtBQUwsRUFBWTtBQUNSLGtCQUFNLElBQUlaLE9BQU9XLEtBQVgsQ0FBaUIsV0FBakIsRUFBOEIsMkJBQTlCLENBQU47QUFDSDs7QUFFRCxZQUFJQyxNQUFNSSxNQUFOLEtBQWlCcEMsVUFBVUMsYUFBVixDQUF3QkUsUUFBN0MsRUFBdUQ7QUFDbkQsa0JBQU0sSUFBSWlCLE9BQU9XLEtBQVgsQ0FBaUIsa0JBQWpCLEVBQXFDLDZCQUFyQyxDQUFOO0FBQ0g7O0FBRUQsWUFBSTtBQUNBUCxtQkFBT2EsTUFBUCxDQUNJO0FBQUVILHFCQUFLRixNQUFNRTtBQUFiLGFBREosRUFFSTtBQUNJSSxzQkFDQTtBQUNJRiw0QkFBUXBDLFVBQVVDLGFBQVYsQ0FBd0JFLFFBRHBDO0FBRUlvQyxnQ0FBWSxJQUFJQyxJQUFKO0FBRmhCO0FBRkosYUFGSjtBQVVILFNBWEQsQ0FXRSxPQUFPQyxHQUFQLEVBQVk7QUFDVnpCLG1CQUFPQyxHQUFQLENBQVd3QixHQUFYO0FBQ0Esa0JBQU0sSUFBSXJCLE9BQU9XLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0MseURBQWxDLENBQU47QUFDSDtBQUNKOztBQXBDVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDTkEsSUFBSVgsTUFBSjtBQUFXTixPQUFPTyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNGLFdBQU9HLENBQVAsRUFBUztBQUFDSCxpQkFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJQyxNQUFKO0FBQVdWLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxXQUFSLENBQWIsRUFBa0M7QUFBQ0UsV0FBT0QsQ0FBUCxFQUFTO0FBQUNDLGlCQUFPRCxDQUFQO0FBQVM7O0FBQXBCLENBQWxDLEVBQXdELENBQXhEO0FBQTJELElBQUlHLE9BQUo7QUFBWVosT0FBT08sS0FBUCxDQUFhQyxRQUFRLFdBQVIsQ0FBYixFQUFrQztBQUFDSSxZQUFRSCxDQUFSLEVBQVU7QUFBQ0csa0JBQVFILENBQVI7QUFBVTs7QUFBdEIsQ0FBbEMsRUFBMEQsQ0FBMUQ7QUFBNkQsSUFBSXZCLFNBQUo7QUFBY2MsT0FBT08sS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFQUFvQztBQUFDdEIsY0FBVXVCLENBQVYsRUFBWTtBQUFDdkIsb0JBQVV1QixDQUFWO0FBQVk7O0FBQTFCLENBQXBDLEVBQWdFLENBQWhFO0FBQW1FLElBQUlQLE1BQUo7QUFBV0YsT0FBT08sS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDTixXQUFPTyxDQUFQLEVBQVM7QUFBQ1AsaUJBQU9PLENBQVA7QUFBUzs7QUFBcEIsQ0FBakMsRUFBdUQsQ0FBdkQ7QUFNclRILE9BQU9PLE9BQVAsQ0FBZTtBQUVYZSxzQkFBa0JDLE1BQWxCLEVBQTBCO0FBQ3RCLGNBQU1kLFVBQVUsRUFBaEI7O0FBRUEsWUFBSSxDQUFDLEtBQUtDLE1BQVYsRUFBa0I7QUFDZCxrQkFBTSxJQUFJVixPQUFPVyxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHdDQUFsQyxDQUFOO0FBQ0gsU0FMcUIsQ0FPdEI7OztBQUVBLGNBQU1DLFFBQVFSLE9BQU9TLE9BQVAsQ0FBZTtBQUN6QkUsdUJBQVcsS0FBS0wsTUFEUztBQUV6QmMsaUJBQUssQ0FDRDtBQUFFUix3QkFBUXBDLFVBQVVDLGFBQVYsQ0FBd0JDO0FBQWxDLGFBREMsRUFFRDtBQUFFa0Msd0JBQVFwQyxVQUFVQyxhQUFWLENBQXdCRztBQUFsQyxhQUZDO0FBRm9CLFNBQWYsQ0FBZCxDQVRzQixDQWlCdEI7O0FBQ0EsWUFBSSxDQUFDNEIsS0FBTCxFQUFZO0FBQ1Isa0JBQU0sSUFBSVosT0FBT1csS0FBWCxDQUFpQixXQUFqQixFQUE4QixrQkFBOUIsQ0FBTjtBQUNIOztBQUdELFlBQUk7QUFDQVAsbUJBQU9hLE1BQVAsQ0FDSTtBQUNJSCxxQkFBS0YsTUFBTUUsR0FEZjtBQUVJLGdDQUFnQlM7QUFGcEIsYUFESixFQUtJO0FBQ0lMLHNCQUFNO0FBQ0Ysc0NBQWtCdEMsVUFBVU0saUJBQVYsQ0FBNEJFO0FBRDVDO0FBRFYsYUFMSjtBQVdILFNBWkQsQ0FZRSxPQUFPaUMsR0FBUCxFQUFZO0FBQ1Z6QixtQkFBT0MsR0FBUCxDQUFXd0IsR0FBWDtBQUNBLGtCQUFNLElBQUlyQixPQUFPVyxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLCtEQUFsQyxDQUFOO0FBQ0g7QUFDSjs7QUF6Q1UsQ0FBZixFOzs7Ozs7Ozs7OztBQ05BLElBQUlYLE1BQUo7QUFBV04sT0FBT08sS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixXQUFPRyxDQUFQLEVBQVM7QUFBQ0gsaUJBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSXNCLEVBQUo7QUFBTy9CLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxJQUFSLENBQWIsRUFBMkI7QUFBQ3dCLFlBQVF2QixDQUFSLEVBQVU7QUFBQ3NCLGFBQUd0QixDQUFIO0FBQUs7O0FBQWpCLENBQTNCLEVBQThDLENBQTlDOztBQUFpRCxJQUFJd0IsQ0FBSjs7QUFBTWpDLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxtQkFBUixDQUFiLEVBQTBDO0FBQUN5QixNQUFFeEIsQ0FBRixFQUFJO0FBQUN3QixZQUFFeEIsQ0FBRjtBQUFJOztBQUFWLENBQTFDLEVBQXNELENBQXREO0FBSXhJSCxPQUFPTyxPQUFQLENBQWU7QUFDWHFCLHNCQUFrQjtBQUNkLGNBQU1DLFNBQVMsRUFBZjtBQUVBLGNBQU1DLGFBQWFMLEdBQUdNLFlBQUgsQ0FBaUIsR0FBRUMsUUFBUUMsR0FBUixFQUFjLE1BQWpDLENBQW5CO0FBQ0EsY0FBTUMsYUFBYyxHQUFFSixVQUFXLG1CQUFqQztBQUNBLGNBQU1LLGlCQUFrQixHQUFFRCxVQUFXLEdBQXJDO0FBQ0EsY0FBTUUsTUFBTVgsR0FBR1ksV0FBSCxDQUFlRixjQUFmLENBQVo7QUFDQSxjQUFNRyxRQUFRRixJQUFJRyxNQUFKLENBQVcsVUFBVUMsR0FBVixFQUFlO0FBQUUsbUJBQU9BLElBQUlDLEtBQUosQ0FBVSxhQUFWLENBQVA7QUFBa0MsU0FBOUQsQ0FBZDs7QUFFQWQsVUFBRWUsSUFBRixDQUFPSixLQUFQLEVBQWMsVUFBVUssR0FBVixFQUFlO0FBQ3pCZCxtQkFBT2UsSUFBUCxDQUFZO0FBQUVDLDBCQUFXLElBQUdGLEdBQUk7QUFBcEIsYUFBWjtBQUNILFNBRkQ7O0FBSUEsZUFBT2QsTUFBUDtBQUNIOztBQWZVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNKQSxJQUFJN0IsTUFBSjtBQUFXTixPQUFPTyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNGLFdBQU9HLENBQVAsRUFBUztBQUFDSCxpQkFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJQyxNQUFKLEVBQVdDLFlBQVg7QUFBd0JYLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxXQUFSLENBQWIsRUFBa0M7QUFBQ0UsV0FBT0QsQ0FBUCxFQUFTO0FBQUNDLGlCQUFPRCxDQUFQO0FBQVMsS0FBcEI7O0FBQXFCRSxpQkFBYUYsQ0FBYixFQUFlO0FBQUNFLHVCQUFhRixDQUFiO0FBQWU7O0FBQXBELENBQWxDLEVBQXdGLENBQXhGO0FBQTJGLElBQUlHLE9BQUo7QUFBWVosT0FBT08sS0FBUCxDQUFhQyxRQUFRLFdBQVIsQ0FBYixFQUFrQztBQUFDSSxZQUFRSCxDQUFSLEVBQVU7QUFBQ0csa0JBQVFILENBQVI7QUFBVTs7QUFBdEIsQ0FBbEMsRUFBMEQsQ0FBMUQ7QUFBNkQsSUFBSXZCLFNBQUo7QUFBY2MsT0FBT08sS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFQUFvQztBQUFDdEIsY0FBVXVCLENBQVYsRUFBWTtBQUFDdkIsb0JBQVV1QixDQUFWO0FBQVk7O0FBQTFCLENBQXBDLEVBQWdFLENBQWhFO0FBQW1FLElBQUlQLE1BQUo7QUFBV0YsT0FBT08sS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDTixXQUFPTyxDQUFQLEVBQVM7QUFBQ1AsaUJBQU9PLENBQVA7QUFBUzs7QUFBcEIsQ0FBakMsRUFBdUQsQ0FBdkQ7QUFNbFdILE9BQU9PLE9BQVAsQ0FBZTtBQUVYdUMsc0JBQWtCQyxLQUFsQixFQUF5QjtBQUNyQixjQUFNdEMsVUFBVSxFQUFoQjs7QUFFQSxZQUFJLENBQUMsS0FBS0MsTUFBVixFQUFrQjtBQUNkLGtCQUFNLElBQUlWLE9BQU9XLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0Msd0NBQWxDLENBQU47QUFDSDs7QUFFRCxjQUFNcUMsU0FBUyxFQUFmO0FBQ0FBLGVBQU9ELEtBQVAsR0FBZUEsS0FBZjtBQUNBQyxlQUFPaEMsTUFBUCxHQUFnQnBDLFVBQVVNLGlCQUFWLENBQTRCQyxPQUE1Qzs7QUFFQSxZQUFJO0FBQ0Esa0JBQU04RCxXQUFXNUMsYUFBYTZDLE1BQWIsQ0FBb0JGLE1BQXBCLENBQWpCO0FBQ0EsbUJBQU9DLFFBQVA7QUFDSCxTQUhELENBR0UsT0FBTzVCLEdBQVAsRUFBWTtBQUNWekIsbUJBQU9DLEdBQVAsQ0FBV3dCLEdBQVg7QUFDQSxrQkFBTSxJQUFJckIsT0FBT1csS0FBWCxDQUFpQixlQUFqQixFQUFrQyxtRUFBbEMsQ0FBTjtBQUNIO0FBQ0o7O0FBcEJVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNOQSxJQUFJWCxNQUFKO0FBQVdOLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsV0FBT0csQ0FBUCxFQUFTO0FBQUNILGlCQUFPRyxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlnRCxNQUFKO0FBQVd6RCxPQUFPTyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNpRCxXQUFPaEQsQ0FBUCxFQUFTO0FBQUNnRCxpQkFBT2hELENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7O0FBQStELElBQUl3QixDQUFKOztBQUFNakMsT0FBT08sS0FBUCxDQUFhQyxRQUFRLG1CQUFSLENBQWIsRUFBMEM7QUFBQ3lCLE1BQUV4QixDQUFGLEVBQUk7QUFBQ3dCLFlBQUV4QixDQUFGO0FBQUk7O0FBQVYsQ0FBMUMsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSUMsTUFBSjtBQUFXVixPQUFPTyxLQUFQLENBQWFDLFFBQVEsV0FBUixDQUFiLEVBQWtDO0FBQUNFLFdBQU9ELENBQVAsRUFBUztBQUFDQyxpQkFBT0QsQ0FBUDtBQUFTOztBQUFwQixDQUFsQyxFQUF3RCxDQUF4RDtBQUEyRCxJQUFJRyxPQUFKO0FBQVlaLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxXQUFSLENBQWIsRUFBa0M7QUFBQ0ksWUFBUUgsQ0FBUixFQUFVO0FBQUNHLGtCQUFRSCxDQUFSO0FBQVU7O0FBQXRCLENBQWxDLEVBQTBELENBQTFEO0FBQTZELElBQUl2QixTQUFKO0FBQWNjLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRUFBb0M7QUFBQ3RCLGNBQVV1QixDQUFWLEVBQVk7QUFBQ3ZCLG9CQUFVdUIsQ0FBVjtBQUFZOztBQUExQixDQUFwQyxFQUFnRSxDQUFoRTtBQUFtRSxJQUFJUCxNQUFKO0FBQVdGLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ04sV0FBT08sQ0FBUCxFQUFTO0FBQUNQLGlCQUFPTyxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBUTliSCxPQUFPTyxPQUFQLENBQWU7QUFFWDZDLG9CQUFnQkwsS0FBaEIsRUFBdUJNLFFBQXZCLEVBQWlDO0FBQzdCLFlBQUk1QyxVQUFVLEVBQWQ7O0FBRUEsWUFBSSxDQUFDLEtBQUtDLE1BQVYsRUFBa0I7QUFDZCxrQkFBTSxJQUFJVixPQUFPVyxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHdDQUFsQyxDQUFOO0FBQ0gsU0FMNEIsQ0FPN0I7OztBQUVBLFlBQUlDLFFBQVFSLE9BQU9TLE9BQVAsQ0FBZTtBQUN2QkUsdUJBQVcsS0FBS0wsTUFETztBQUV2Qk0sb0JBQVFwQyxVQUFVQyxhQUFWLENBQXdCQztBQUZULFNBQWYsQ0FBWixDQVQ2QixDQWM3Qjs7QUFDQSxZQUFJLENBQUM4QixLQUFMLEVBQVk7QUFDUixrQkFBTTBDLFdBQVcsRUFBakI7QUFDQUEscUJBQVN0QyxNQUFULEdBQWtCcEMsVUFBVUMsYUFBVixDQUF3QkMsTUFBMUM7QUFDQXdFLHFCQUFTQyxLQUFULEdBQWlCLEVBQWpCO0FBRUE5QyxzQkFBVUwsT0FBTzhDLE1BQVAsQ0FBY0ksUUFBZCxDQUFWO0FBRUExQyxvQkFBUVIsT0FBT1MsT0FBUCxDQUFlO0FBQUVDLHFCQUFLTDtBQUFQLGFBQWYsQ0FBUjtBQUNILFNBUkQsTUFRTztBQUNIQSxzQkFBVUcsTUFBTUUsR0FBaEI7QUFDSDs7QUFFRCxjQUFNMEMsTUFBTSxFQUFaO0FBQ0FBLFlBQUlqQyxNQUFKLEdBQWE0QixPQUFPTSxFQUFQLEVBQWI7QUFDQUQsWUFBSVQsS0FBSixHQUFZQSxLQUFaO0FBQ0FTLFlBQUlILFFBQUosR0FBZUEsUUFBZjtBQUNBRyxZQUFJeEMsTUFBSixHQUFhcEMsVUFBVU0saUJBQVYsQ0FBNEJDLE9BQXpDO0FBQ0FxRSxZQUFJRSxLQUFKLEdBQVksQ0FBWjtBQUNBRixZQUFJRyxTQUFKLEdBQWdCLElBQUl2QyxJQUFKLEVBQWhCOztBQUVBLFlBQUksQ0FBQ08sRUFBRWlDLE9BQUYsQ0FBVWhELE1BQU0yQyxLQUFoQixDQUFMLEVBQTZCO0FBQ3pCM0Msa0JBQU0yQyxLQUFOLEdBQWMsRUFBZDtBQUNILFNBckM0QixDQXVDN0I7OztBQUVBLFlBQUk7QUFDQW5ELG1CQUFPYSxNQUFQLENBQ0k7QUFBRUgscUJBQUtMO0FBQVAsYUFESixFQUVJO0FBQ0lvRCx1QkFBTztBQUNITiwyQkFBT0M7QUFESjtBQURYLGFBRko7QUFRQSxtQkFBTy9DLE9BQVA7QUFDSCxTQVZELENBVUUsT0FBT1ksR0FBUCxFQUFZO0FBQ1Z6QixtQkFBT0MsR0FBUCxDQUFXd0IsR0FBWDtBQUNBLGtCQUFNLElBQUlyQixPQUFPVyxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLG1FQUFsQyxDQUFOO0FBQ0g7QUFDSjs7QUF6RFUsQ0FBZixFOzs7Ozs7Ozs7OztBQ1JBLElBQUlYLE1BQUo7QUFBV04sT0FBT08sS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixXQUFPRyxDQUFQLEVBQVM7QUFBQ0gsaUJBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUMsTUFBSixFQUFXQyxZQUFYO0FBQXdCWCxPQUFPTyxLQUFQLENBQWFDLFFBQVEsV0FBUixDQUFiLEVBQWtDO0FBQUNFLFdBQU9ELENBQVAsRUFBUztBQUFDQyxpQkFBT0QsQ0FBUDtBQUFTLEtBQXBCOztBQUFxQkUsaUJBQWFGLENBQWIsRUFBZTtBQUFDRSx1QkFBYUYsQ0FBYjtBQUFlOztBQUFwRCxDQUFsQyxFQUF3RixDQUF4RjtBQUEyRixJQUFJRyxPQUFKO0FBQVlaLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxXQUFSLENBQWIsRUFBa0M7QUFBQ0ksWUFBUUgsQ0FBUixFQUFVO0FBQUNHLGtCQUFRSCxDQUFSO0FBQVU7O0FBQXRCLENBQWxDLEVBQTBELENBQTFEO0FBQTZELElBQUl2QixTQUFKO0FBQWNjLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRUFBb0M7QUFBQ3RCLGNBQVV1QixDQUFWLEVBQVk7QUFBQ3ZCLG9CQUFVdUIsQ0FBVjtBQUFZOztBQUExQixDQUFwQyxFQUFnRSxDQUFoRTtBQUFtRSxJQUFJUCxNQUFKO0FBQVdGLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxVQUFSLENBQWIsRUFBaUM7QUFBQ04sV0FBT08sQ0FBUCxFQUFTO0FBQUNQLGlCQUFPTyxDQUFQO0FBQVM7O0FBQXBCLENBQWpDLEVBQXVELENBQXZEO0FBTWxXSCxPQUFPTyxPQUFQLENBQWU7QUFFWHVELGlCQUFhYixRQUFiLEVBQXVCO0FBQ25CLGNBQU14QyxVQUFVLEVBQWhCOztBQUVBLFlBQUksQ0FBQyxLQUFLQyxNQUFWLEVBQWtCO0FBQ2Qsa0JBQU0sSUFBSVYsT0FBT1csS0FBWCxDQUFpQixlQUFqQixFQUFrQyx3Q0FBbEMsQ0FBTjtBQUNIOztBQUVELGNBQU1xQyxTQUFTM0MsYUFBYVEsT0FBYixDQUFxQjtBQUFFQyxpQkFBS21DLFFBQVA7QUFBaUJsQyx1QkFBVyxLQUFLTDtBQUFqQyxTQUFyQixDQUFmOztBQUVBLFlBQUksQ0FBQ3NDLE1BQUwsRUFBYTtBQUNULGtCQUFNLElBQUloRCxPQUFPVyxLQUFYLENBQWlCLFdBQWpCLEVBQThCLG1CQUE5QixDQUFOO0FBQ0g7O0FBQ0QsWUFBSTtBQUNBTix5QkFBYTBELE1BQWIsQ0FBb0I7QUFBRWpELHFCQUFLbUM7QUFBUCxhQUFwQjtBQUNILFNBRkQsQ0FFRSxPQUFPNUIsR0FBUCxFQUFZO0FBQ1Z6QixtQkFBT0MsR0FBUCxDQUFXd0IsR0FBWDtBQUNBLGtCQUFNLElBQUlyQixPQUFPVyxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHlEQUFsQyxDQUFOO0FBQ0g7QUFDSjs7QUFwQlUsQ0FBZixFOzs7Ozs7Ozs7OztBQ05BLElBQUlYLE1BQUo7QUFBV04sT0FBT08sS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixXQUFPRyxDQUFQLEVBQVM7QUFBQ0gsaUJBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7O0FBQStELElBQUl3QixDQUFKOztBQUFNakMsT0FBT08sS0FBUCxDQUFhQyxRQUFRLG1CQUFSLENBQWIsRUFBMEM7QUFBQ3lCLE1BQUV4QixDQUFGLEVBQUk7QUFBQ3dCLFlBQUV4QixDQUFGO0FBQUk7O0FBQVYsQ0FBMUMsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSUMsTUFBSjtBQUFXVixPQUFPTyxLQUFQLENBQWFDLFFBQVEsV0FBUixDQUFiLEVBQWtDO0FBQUNFLFdBQU9ELENBQVAsRUFBUztBQUFDQyxpQkFBT0QsQ0FBUDtBQUFTOztBQUFwQixDQUFsQyxFQUF3RCxDQUF4RDtBQUEyRCxJQUFJRyxPQUFKO0FBQVlaLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxXQUFSLENBQWIsRUFBa0M7QUFBQ0ksWUFBUUgsQ0FBUixFQUFVO0FBQUNHLGtCQUFRSCxDQUFSO0FBQVU7O0FBQXRCLENBQWxDLEVBQTBELENBQTFEO0FBQTZELElBQUl2QixTQUFKO0FBQWNjLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRUFBb0M7QUFBQ3RCLGNBQVV1QixDQUFWLEVBQVk7QUFBQ3ZCLG9CQUFVdUIsQ0FBVjtBQUFZOztBQUExQixDQUFwQyxFQUFnRSxDQUFoRTtBQUFtRSxJQUFJUCxNQUFKO0FBQVdGLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxVQUFSLENBQWIsRUFBaUM7QUFBQ04sV0FBT08sQ0FBUCxFQUFTO0FBQUNQLGlCQUFPTyxDQUFQO0FBQVM7O0FBQXBCLENBQWpDLEVBQXVELENBQXZEO0FBT3BYSCxPQUFPTyxPQUFQLENBQWU7QUFFWHlELG9CQUFnQnpDLE1BQWhCLEVBQXdCO0FBQ3BCLGNBQU1kLFVBQVUsRUFBaEI7O0FBRUEsWUFBSSxDQUFDLEtBQUtDLE1BQVYsRUFBa0I7QUFDZCxrQkFBTSxJQUFJVixPQUFPVyxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHdDQUFsQyxDQUFOO0FBQ0g7O0FBRUQsY0FBTUMsUUFBUVIsT0FBT1MsT0FBUCxDQUFlO0FBQ3pCRSx1QkFBVyxLQUFLTCxNQURTO0FBRXpCYyxpQkFBSyxDQUNEO0FBQUVSLHdCQUFRcEMsVUFBVUMsYUFBVixDQUF3QkM7QUFBbEMsYUFEQyxFQUVEO0FBQUVrQyx3QkFBUXBDLFVBQVVDLGFBQVYsQ0FBd0JHO0FBQWxDLGFBRkM7QUFGb0IsU0FBZixDQUFkLENBUG9CLENBZXBCOztBQUNBLFlBQUksQ0FBQzRCLEtBQUwsRUFBWTtBQUNSLGtCQUFNLElBQUlaLE9BQU9XLEtBQVgsQ0FBaUIsV0FBakIsRUFBOEIsa0JBQTlCLENBQU47QUFDSDs7QUFFRCxjQUFNc0QsWUFBWXRDLEVBQUVZLE1BQUYsQ0FBUzNCLE1BQU0yQyxLQUFmLEVBQXNCLFVBQVVXLElBQVYsRUFBZ0I7QUFDcEQsbUJBQU9BLEtBQUszQyxNQUFMLEtBQWdCQSxNQUF2QjtBQUNILFNBRmlCLENBQWxCOztBQUlBLFlBQUkwQyxVQUFVRSxNQUFWLEtBQXFCLENBQXpCLEVBQTRCO0FBQ3hCLGtCQUFNLElBQUluRSxPQUFPVyxLQUFYLENBQWlCLFdBQWpCLEVBQThCLHVCQUE5QixDQUFOO0FBQ0g7O0FBRUQsWUFBSTtBQUNBUCxtQkFBT2EsTUFBUCxDQUNJO0FBQ0lILHFCQUFLRixNQUFNRTtBQURmLGFBREosRUFJSTtBQUNJc0QsdUJBQU87QUFDSGIsMkJBQU87QUFBRWhDLGdDQUFRQTtBQUFWO0FBREo7QUFEWCxhQUpKO0FBVUgsU0FYRCxDQVdFLE9BQU9GLEdBQVAsRUFBWTtBQUNWekIsbUJBQU9DLEdBQVAsQ0FBV3dCLEdBQVg7QUFDQSxrQkFBTSxJQUFJckIsT0FBT1csS0FBWCxDQUFpQixlQUFqQixFQUFrQyx5REFBbEMsQ0FBTjtBQUNIO0FBQ0o7O0FBN0NVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNQQSxJQUFJWCxNQUFKO0FBQVdOLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsV0FBT0csQ0FBUCxFQUFTO0FBQUNILGlCQUFPRyxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlnRCxNQUFKO0FBQVd6RCxPQUFPTyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNpRCxXQUFPaEQsQ0FBUCxFQUFTO0FBQUNnRCxpQkFBT2hELENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSWtFLEtBQUo7QUFBVTNFLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ21FLFVBQU1sRSxDQUFOLEVBQVE7QUFBQ2tFLGdCQUFNbEUsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJbUUsWUFBSjtBQUFpQjVFLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNvRSxpQkFBYW5FLENBQWIsRUFBZTtBQUFDbUUsdUJBQWFuRSxDQUFiO0FBQWU7O0FBQWhDLENBQXBELEVBQXNGLENBQXRGOztBQUF5RixJQUFJd0IsQ0FBSjs7QUFBTWpDLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxtQkFBUixDQUFiLEVBQTBDO0FBQUN5QixNQUFFeEIsQ0FBRixFQUFJO0FBQUN3QixZQUFFeEIsQ0FBRjtBQUFJOztBQUFWLENBQTFDLEVBQXNELENBQXREO0FBQXlELElBQUlvRSxRQUFKO0FBQWE3RSxPQUFPTyxLQUFQLENBQWFDLFFBQVEsV0FBUixDQUFiLEVBQWtDO0FBQUNxRSxhQUFTcEUsQ0FBVCxFQUFXO0FBQUNvRSxtQkFBU3BFLENBQVQ7QUFBVzs7QUFBeEIsQ0FBbEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUcsT0FBSjtBQUFZWixPQUFPTyxLQUFQLENBQWFDLFFBQVEsV0FBUixDQUFiLEVBQWtDO0FBQUNJLFlBQVFILENBQVIsRUFBVTtBQUFDRyxrQkFBUUgsQ0FBUjtBQUFVOztBQUF0QixDQUFsQyxFQUEwRCxDQUExRDtBQUE2RCxJQUFJUCxNQUFKO0FBQVdGLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxVQUFSLENBQWIsRUFBaUM7QUFBQ04sV0FBT08sQ0FBUCxFQUFTO0FBQUNQLGlCQUFPTyxDQUFQO0FBQVM7O0FBQXBCLENBQWpDLEVBQXVELENBQXZEO0FBU25pQkgsT0FBT08sT0FBUCxDQUFlO0FBRVhpRSxpQkFBYWhCLEdBQWIsRUFBa0I7QUFDZCxZQUFJLENBQUMsS0FBSzlDLE1BQVYsRUFBa0I7QUFDZCxrQkFBTSxJQUFJVixPQUFPVyxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHdDQUFsQyxDQUFOO0FBQ0g7O0FBRURMLGdCQUFRaUUsUUFBUixDQUFpQkUsUUFBakIsQ0FBMEJqQixHQUExQjtBQUVBLGNBQU1rQixXQUFXSCxTQUFTMUQsT0FBVCxDQUFpQjtBQUFFRSx1QkFBVyxLQUFLTDtBQUFsQixTQUFqQixDQUFqQjs7QUFFQSxZQUFJO0FBQ0EsZ0JBQUlpQixFQUFFZ0QsV0FBRixDQUFjRCxRQUFkLENBQUosRUFBNkI7QUFDekJILHlCQUFTckIsTUFBVCxDQUFnQk0sR0FBaEI7QUFDSCxhQUZELE1BRU87QUFDSGUseUJBQVN0RCxNQUFULENBQ0k7QUFBRUgseUJBQUs0RCxTQUFTNUQ7QUFBaEIsaUJBREosRUFFSTtBQUNJSSwwQkFBTTtBQUNGMEQseUNBQWlCcEIsSUFBSW9CLGVBRG5CO0FBRUZDLDBDQUFrQnJCLElBQUlxQixnQkFGcEI7QUFHRkMsd0NBQWdCdEIsSUFBSXNCLGNBSGxCO0FBSUZDLHdDQUFnQnZCLElBQUl1QjtBQUpsQjtBQURWLGlCQUZKO0FBV0g7QUFDSixTQWhCRCxDQWdCRSxPQUFPMUQsR0FBUCxFQUFZO0FBQ1Z6QixtQkFBT0MsR0FBUCxDQUFXd0IsR0FBWDtBQUNBLGtCQUFNLElBQUlyQixPQUFPVyxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHVEQUFsQyxDQUFOO0FBQ0g7QUFDSjs7QUEvQlUsQ0FBZixFOzs7Ozs7Ozs7OztBQ1RBLElBQUlYLE1BQUo7QUFBV04sT0FBT08sS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixXQUFPRyxDQUFQLEVBQVM7QUFBQ0gsaUJBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSWdELE1BQUo7QUFBV3pELE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2lELFdBQU9oRCxDQUFQLEVBQVM7QUFBQ2dELGlCQUFPaEQsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJQyxNQUFKLEVBQVdDLFlBQVg7QUFBd0JYLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxnQkFBUixDQUFiLEVBQXVDO0FBQUNFLFdBQU9ELENBQVAsRUFBUztBQUFDQyxpQkFBT0QsQ0FBUDtBQUFTLEtBQXBCOztBQUFxQkUsaUJBQWFGLENBQWIsRUFBZTtBQUFDRSx1QkFBYUYsQ0FBYjtBQUFlOztBQUFwRCxDQUF2QyxFQUE2RixDQUE3RjtBQUFnRyxJQUFJRyxPQUFKO0FBQVlaLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxXQUFSLENBQWIsRUFBa0M7QUFBQ0ksWUFBUUgsQ0FBUixFQUFVO0FBQUNHLGtCQUFRSCxDQUFSO0FBQVU7O0FBQXRCLENBQWxDLEVBQTBELENBQTFEO0FBQTZELElBQUl2QixTQUFKO0FBQWNjLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRUFBb0M7QUFBQ3RCLGNBQVV1QixDQUFWLEVBQVk7QUFBQ3ZCLG9CQUFVdUIsQ0FBVjtBQUFZOztBQUExQixDQUFwQyxFQUFnRSxDQUFoRTtBQUFtRSxJQUFJUCxNQUFKO0FBQVdGLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxVQUFSLENBQWIsRUFBaUM7QUFBQ04sV0FBT08sQ0FBUCxFQUFTO0FBQUNQLGlCQUFPTyxDQUFQO0FBQVM7O0FBQXBCLENBQWpDLEVBQXVELENBQXZEO0FBT2piSCxPQUFPTyxPQUFQLENBQWU7QUFFWHlFLGlCQUFhL0IsUUFBYixFQUF1QjtBQUNuQixjQUFNeEMsVUFBVSxFQUFoQjs7QUFFQSxZQUFJLENBQUMsS0FBS0MsTUFBVixFQUFrQjtBQUNkLGtCQUFNLElBQUlWLE9BQU9XLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0Msd0NBQWxDLENBQU47QUFDSDs7QUFFRCxjQUFNcUMsU0FBUzNDLGFBQWFRLE9BQWIsQ0FBcUI7QUFBRUMsaUJBQUttQyxRQUFQO0FBQWlCbEMsdUJBQVcsS0FBS0w7QUFBakMsU0FBckIsQ0FBZjs7QUFFQSxZQUFJLENBQUNzQyxNQUFMLEVBQWE7QUFDVCxrQkFBTSxJQUFJaEQsT0FBT1csS0FBWCxDQUFpQixXQUFqQixFQUE4Qix3QkFBOUIsQ0FBTjtBQUNIOztBQUVELGNBQU1zRSxXQUFXakMsT0FBT2hDLE1BQVAsS0FBa0JwQyxVQUFVTSxpQkFBVixDQUE0QkMsT0FBOUMsR0FBd0RQLFVBQVVNLGlCQUFWLENBQTRCRSxRQUFwRixHQUErRlIsVUFBVU0saUJBQVYsQ0FBNEJDLE9BQTVJO0FBRUEsWUFBSStGLE9BQUo7O0FBRUEsWUFBSUQsYUFBYXJHLFVBQVVNLGlCQUFWLENBQTRCRSxRQUE3QyxFQUF1RDtBQUNuRDhGLHNCQUFVLElBQUk5RCxJQUFKLEVBQVY7QUFDSCxTQUZELE1BRU87QUFDSDhELHNCQUFVLElBQVY7QUFDSDs7QUFHRCxZQUFJO0FBQ0E3RSx5QkFBYVksTUFBYixDQUNJO0FBQUVILHFCQUFLbUM7QUFBUCxhQURKLEVBRUk7QUFDSS9CLHNCQUNBO0FBQ0lGLDRCQUFRaUUsUUFEWjtBQUVJRSxpQ0FBYUQ7QUFGakI7QUFGSixhQUZKO0FBVUgsU0FYRCxDQVdFLE9BQU83RCxHQUFQLEVBQVk7QUFDVnpCLG1CQUFPQyxHQUFQLENBQVd3QixHQUFYO0FBQ0Esa0JBQU0sSUFBSXJCLE9BQU9XLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0MseURBQWxDLENBQU47QUFDSDtBQUNKOztBQXpDVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDUEEsSUFBSVgsTUFBSjtBQUFXTixPQUFPTyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNGLFdBQU9HLENBQVAsRUFBUztBQUFDSCxpQkFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJQyxNQUFKLEVBQVdDLFlBQVg7QUFBd0JYLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxXQUFSLENBQWIsRUFBa0M7QUFBQ0UsV0FBT0QsQ0FBUCxFQUFTO0FBQUNDLGlCQUFPRCxDQUFQO0FBQVMsS0FBcEI7O0FBQXFCRSxpQkFBYUYsQ0FBYixFQUFlO0FBQUNFLHVCQUFhRixDQUFiO0FBQWU7O0FBQXBELENBQWxDLEVBQXdGLENBQXhGO0FBQTJGLElBQUlHLE9BQUo7QUFBWVosT0FBT08sS0FBUCxDQUFhQyxRQUFRLFdBQVIsQ0FBYixFQUFrQztBQUFDSSxZQUFRSCxDQUFSLEVBQVU7QUFBQ0csa0JBQVFILENBQVI7QUFBVTs7QUFBdEIsQ0FBbEMsRUFBMEQsQ0FBMUQ7QUFBNkQsSUFBSXZCLFNBQUo7QUFBY2MsT0FBT08sS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFQUFvQztBQUFDdEIsY0FBVXVCLENBQVYsRUFBWTtBQUFDdkIsb0JBQVV1QixDQUFWO0FBQVk7O0FBQTFCLENBQXBDLEVBQWdFLENBQWhFO0FBQW1FLElBQUlQLE1BQUo7QUFBV0YsT0FBT08sS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDTixXQUFPTyxDQUFQLEVBQVM7QUFBQ1AsaUJBQU9PLENBQVA7QUFBUzs7QUFBcEIsQ0FBakMsRUFBdUQsQ0FBdkQ7QUFNbFdILE9BQU9PLE9BQVAsQ0FBZTtBQUVYNkUsd0JBQW9CO0FBQ2hCLGNBQU0zRSxVQUFVLEVBQWhCOztBQUVBLFlBQUksQ0FBQyxLQUFLQyxNQUFWLEVBQWtCO0FBQ2Qsa0JBQU0sSUFBSVYsT0FBT1csS0FBWCxDQUFpQixlQUFqQixFQUFrQyx3Q0FBbEMsQ0FBTjtBQUNILFNBTGUsQ0FPaEI7OztBQUVBLGNBQU1DLFFBQVFSLE9BQU9TLE9BQVAsQ0FBZTtBQUN6QkUsdUJBQVcsS0FBS0wsTUFEUztBQUV6QmMsaUJBQ0EsQ0FDSTtBQUFFUix3QkFBUXBDLFVBQVVDLGFBQVYsQ0FBd0JDO0FBQWxDLGFBREosRUFFSTtBQUFFa0Msd0JBQVFwQyxVQUFVQyxhQUFWLENBQXdCRztBQUFsQyxhQUZKO0FBSHlCLFNBQWYsQ0FBZCxDQVRnQixDQWtCaEI7O0FBQ0EsWUFBSSxDQUFDNEIsS0FBTCxFQUFZO0FBQ1Isa0JBQU0sSUFBSVosT0FBT1csS0FBWCxDQUFpQixXQUFqQixFQUE4QixrQkFBOUIsQ0FBTjtBQUNIOztBQUVELFlBQUlDLE1BQU1JLE1BQU4sS0FBaUJwQyxVQUFVQyxhQUFWLENBQXdCRSxRQUE3QyxFQUF1RDtBQUNuRCxrQkFBTSxJQUFJaUIsT0FBT1csS0FBWCxDQUFpQixlQUFqQixFQUFrQyw2QkFBbEMsQ0FBTjtBQUNIOztBQUVELGNBQU0wRSxZQUFZekUsTUFBTUksTUFBTixLQUFpQnBDLFVBQVVDLGFBQVYsQ0FBd0JHLE1BQXpDLEdBQWtESixVQUFVQyxhQUFWLENBQXdCQyxNQUExRSxHQUFtRkYsVUFBVUMsYUFBVixDQUF3QkcsTUFBN0g7O0FBRUEsWUFBSTtBQUNBb0IsbUJBQU9hLE1BQVAsQ0FDSTtBQUFFSCxxQkFBS0YsTUFBTUU7QUFBYixhQURKLEVBRUk7QUFDSUksc0JBQ0E7QUFBRUYsNEJBQVFxRTtBQUFWO0FBRkosYUFGSjtBQU9ILFNBUkQsQ0FRRSxPQUFPaEUsR0FBUCxFQUFZO0FBQ1Z6QixtQkFBT0MsR0FBUCxDQUFXd0IsR0FBWDtBQUNBLGtCQUFNLElBQUlyQixPQUFPVyxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHdEQUFsQyxDQUFOO0FBQ0g7QUFDSjs7QUEzQ1UsQ0FBZixFOzs7Ozs7Ozs7OztBQ05BLElBQUlYLE1BQUo7QUFBV04sT0FBT08sS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixXQUFPRyxDQUFQLEVBQVM7QUFBQ0gsaUJBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUMsTUFBSixFQUFXQyxZQUFYO0FBQXdCWCxPQUFPTyxLQUFQLENBQWFDLFFBQVEsV0FBUixDQUFiLEVBQWtDO0FBQUNFLFdBQU9ELENBQVAsRUFBUztBQUFDQyxpQkFBT0QsQ0FBUDtBQUFTLEtBQXBCOztBQUFxQkUsaUJBQWFGLENBQWIsRUFBZTtBQUFDRSx1QkFBYUYsQ0FBYjtBQUFlOztBQUFwRCxDQUFsQyxFQUF3RixDQUF4RjtBQUEyRixJQUFJRyxPQUFKO0FBQVlaLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxXQUFSLENBQWIsRUFBa0M7QUFBQ0ksWUFBUUgsQ0FBUixFQUFVO0FBQUNHLGtCQUFRSCxDQUFSO0FBQVU7O0FBQXRCLENBQWxDLEVBQTBELENBQTFEO0FBQTZELElBQUl2QixTQUFKO0FBQWNjLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRUFBb0M7QUFBQ3RCLGNBQVV1QixDQUFWLEVBQVk7QUFBQ3ZCLG9CQUFVdUIsQ0FBVjtBQUFZOztBQUExQixDQUFwQyxFQUFnRSxDQUFoRTtBQUFtRSxJQUFJUCxNQUFKO0FBQVdGLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxVQUFSLENBQWIsRUFBaUM7QUFBQ04sV0FBT08sQ0FBUCxFQUFTO0FBQUNQLGlCQUFPTyxDQUFQO0FBQVM7O0FBQXBCLENBQWpDLEVBQXVELENBQXZEO0FBTWxXSCxPQUFPTyxPQUFQLENBQWU7QUFFWCtFLDBCQUFzQjtBQUNsQixjQUFNN0UsVUFBVSxFQUFoQjs7QUFFQSxZQUFJLENBQUMsS0FBS0MsTUFBVixFQUFrQjtBQUNkLGtCQUFNLElBQUlWLE9BQU9XLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0Msd0NBQWxDLENBQU47QUFDSDs7QUFFRCxjQUFNQyxRQUFRUixPQUFPUyxPQUFQLENBQWU7QUFDekJFLHVCQUFXLEtBQUtMLE1BRFM7QUFFekJjLGlCQUNBLENBQ0k7QUFBRVIsd0JBQVFwQyxVQUFVQyxhQUFWLENBQXdCQztBQUFsQyxhQURKLEVBRUk7QUFBRWtDLHdCQUFRcEMsVUFBVUMsYUFBVixDQUF3Qkc7QUFBbEMsYUFGSjtBQUh5QixTQUFmLENBQWQsQ0FQa0IsQ0FnQmxCOztBQUNBLFlBQUksQ0FBQzRCLEtBQUwsRUFBWTtBQUNSLGtCQUFNLElBQUlaLE9BQU9XLEtBQVgsQ0FBaUIsV0FBakIsRUFBOEIsa0JBQTlCLENBQU47QUFDSDs7QUFFRCxjQUFNNEUsT0FBTyxDQUFDM0UsTUFBTTRFLGFBQXBCOztBQUVBLFlBQUk7QUFDQXBGLG1CQUFPYSxNQUFQLENBQ0k7QUFDSUgscUJBQUtGLE1BQU1FO0FBRGYsYUFESixFQUlJO0FBQ0lJLHNCQUNBO0FBQ0lzRSxtQ0FBZUQ7QUFEbkI7QUFGSixhQUpKO0FBV0gsU0FaRCxDQVlFLE9BQU9sRSxHQUFQLEVBQVk7QUFDVnpCLG1CQUFPQyxHQUFQLENBQVd3QixHQUFYO0FBQ0Esa0JBQU0sSUFBSXJCLE9BQU9XLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0MsK0RBQWxDLENBQU47QUFDSDtBQUNKOztBQXpDVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDTkEsSUFBSVgsTUFBSjtBQUFXTixPQUFPTyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNGLFdBQU9HLENBQVAsRUFBUztBQUFDSCxpQkFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDs7QUFBK0QsSUFBSXdCLENBQUo7O0FBQU1qQyxPQUFPTyxLQUFQLENBQWFDLFFBQVEsbUJBQVIsQ0FBYixFQUEwQztBQUFDeUIsTUFBRXhCLENBQUYsRUFBSTtBQUFDd0IsWUFBRXhCLENBQUY7QUFBSTs7QUFBVixDQUExQyxFQUFzRCxDQUF0RDtBQUF5RCxJQUFJQyxNQUFKO0FBQVdWLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxXQUFSLENBQWIsRUFBa0M7QUFBQ0UsV0FBT0QsQ0FBUCxFQUFTO0FBQUNDLGlCQUFPRCxDQUFQO0FBQVM7O0FBQXBCLENBQWxDLEVBQXdELENBQXhEO0FBQTJELElBQUlHLE9BQUo7QUFBWVosT0FBT08sS0FBUCxDQUFhQyxRQUFRLFdBQVIsQ0FBYixFQUFrQztBQUFDSSxZQUFRSCxDQUFSLEVBQVU7QUFBQ0csa0JBQVFILENBQVI7QUFBVTs7QUFBdEIsQ0FBbEMsRUFBMEQsQ0FBMUQ7QUFBNkQsSUFBSXZCLFNBQUo7QUFBY2MsT0FBT08sS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFQUFvQztBQUFDdEIsY0FBVXVCLENBQVYsRUFBWTtBQUFDdkIsb0JBQVV1QixDQUFWO0FBQVk7O0FBQTFCLENBQXBDLEVBQWdFLENBQWhFO0FBQW1FLElBQUlQLE1BQUo7QUFBV0YsT0FBT08sS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDTixXQUFPTyxDQUFQLEVBQVM7QUFBQ1AsaUJBQU9PLENBQVA7QUFBUzs7QUFBcEIsQ0FBakMsRUFBdUQsQ0FBdkQ7QUFPcFhILE9BQU9PLE9BQVAsQ0FBZTtBQUVYa0YsZUFBV2xFLE1BQVgsRUFBbUI7QUFDZixjQUFNZCxVQUFVLEVBQWhCOztBQUVBLFlBQUksQ0FBQyxLQUFLQyxNQUFWLEVBQWtCO0FBQ2Qsa0JBQU0sSUFBSVYsT0FBT1csS0FBWCxDQUFpQixlQUFqQixFQUFrQyx3Q0FBbEMsQ0FBTjtBQUNILFNBTGMsQ0FPZjs7O0FBRUEsY0FBTUMsUUFBUVIsT0FBT1MsT0FBUCxDQUFlO0FBQ3pCRSx1QkFBVyxLQUFLTCxNQURTO0FBRXpCTSxvQkFBUXBDLFVBQVVDLGFBQVYsQ0FBd0JDO0FBRlAsU0FBZixDQUFkLENBVGUsQ0FjZjs7QUFDQSxZQUFJLENBQUM4QixLQUFMLEVBQVk7QUFDUixrQkFBTSxJQUFJWixPQUFPVyxLQUFYLENBQWlCLFdBQWpCLEVBQThCLGtCQUE5QixDQUFOO0FBQ0g7O0FBRUQsY0FBTXNELFlBQVl0QyxFQUFFWSxNQUFGLENBQVMzQixNQUFNMkMsS0FBZixFQUFzQixVQUFVVyxJQUFWLEVBQWdCO0FBQ3BELG1CQUFPQSxLQUFLM0MsTUFBTCxLQUFnQkEsTUFBdkI7QUFDSCxTQUZpQixDQUFsQjs7QUFJQSxZQUFJMEMsVUFBVUUsTUFBVixLQUFxQixDQUF6QixFQUE0QjtBQUN4QixrQkFBTSxJQUFJbkUsT0FBT1csS0FBWCxDQUFpQixXQUFqQixFQUE4Qix1QkFBOUIsQ0FBTjtBQUNIOztBQUVELFlBQUkrRSxZQUFZekIsVUFBVSxDQUFWLEVBQWFQLEtBQWIsSUFBc0IsQ0FBdEM7QUFFQWdDLHFCQUFhLENBQWI7O0FBRUEsWUFBSTtBQUNBdEYsbUJBQU9hLE1BQVAsQ0FDSTtBQUNJSCxxQkFBS0YsTUFBTUUsR0FEZjtBQUVJLGdDQUFnQlM7QUFGcEIsYUFESixFQUtJO0FBQ0lMLHNCQUFNO0FBQ0YscUNBQWlCd0U7QUFEZjtBQURWLGFBTEo7QUFXSCxTQVpELENBWUUsT0FBT3JFLEdBQVAsRUFBWTtBQUNWekIsbUJBQU9DLEdBQVAsQ0FBV3dCLEdBQVg7QUFDQSxrQkFBTSxJQUFJckIsT0FBT1csS0FBWCxDQUFpQixlQUFqQixFQUFrQyx3REFBbEMsQ0FBTjtBQUNIO0FBQ0o7O0FBakRVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNQQSxJQUFJWCxNQUFKO0FBQVdOLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsV0FBT0csQ0FBUCxFQUFTO0FBQUNILGlCQUFPRyxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlDLE1BQUosRUFBV0MsWUFBWDtBQUF3QlgsT0FBT08sS0FBUCxDQUFhQyxRQUFRLGdCQUFSLENBQWIsRUFBdUM7QUFBQ0UsV0FBT0QsQ0FBUCxFQUFTO0FBQUNDLGlCQUFPRCxDQUFQO0FBQVMsS0FBcEI7O0FBQXFCRSxpQkFBYUYsQ0FBYixFQUFlO0FBQUNFLHVCQUFhRixDQUFiO0FBQWU7O0FBQXBELENBQXZDLEVBQTZGLENBQTdGO0FBQWdHLElBQUlHLE9BQUo7QUFBWVosT0FBT08sS0FBUCxDQUFhQyxRQUFRLFdBQVIsQ0FBYixFQUFrQztBQUFDSSxZQUFRSCxDQUFSLEVBQVU7QUFBQ0csa0JBQVFILENBQVI7QUFBVTs7QUFBdEIsQ0FBbEMsRUFBMEQsQ0FBMUQ7QUFBNkQsSUFBSXZCLFNBQUo7QUFBY2MsT0FBT08sS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFQUFvQztBQUFDdEIsY0FBVXVCLENBQVYsRUFBWTtBQUFDdkIsb0JBQVV1QixDQUFWO0FBQVk7O0FBQTFCLENBQXBDLEVBQWdFLENBQWhFO0FBQW1FLElBQUlQLE1BQUo7QUFBV0YsT0FBT08sS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDTixXQUFPTyxDQUFQLEVBQVM7QUFBQ1AsaUJBQU9PLENBQVA7QUFBUzs7QUFBcEIsQ0FBakMsRUFBdUQsQ0FBdkQ7QUFNdldILE9BQU9PLE9BQVAsQ0FBZTtBQUVYb0Ysc0JBQWtCMUMsUUFBbEIsRUFBNEJGLEtBQTVCLEVBQW1DO0FBQy9CLGNBQU10QyxVQUFVLEVBQWhCOztBQUVBLFlBQUksQ0FBQyxLQUFLQyxNQUFWLEVBQWtCO0FBQ2Qsa0JBQU0sSUFBSVYsT0FBT1csS0FBWCxDQUFpQixlQUFqQixFQUFrQyx3Q0FBbEMsQ0FBTjtBQUNIOztBQUVELGNBQU1xQyxTQUFTM0MsYUFBYVEsT0FBYixDQUFxQjtBQUFFQyxpQkFBS21DLFFBQVA7QUFBaUJsQyx1QkFBVyxLQUFLTDtBQUFqQyxTQUFyQixDQUFmOztBQUVBLFlBQUksQ0FBQ3NDLE1BQUwsRUFBYTtBQUNULGtCQUFNLElBQUloRCxPQUFPVyxLQUFYLENBQWlCLFdBQWpCLEVBQThCLHdCQUE5QixDQUFOO0FBQ0g7O0FBRUQsWUFBSTtBQUNBTix5QkFBYVksTUFBYixDQUNJO0FBQUVILHFCQUFLbUM7QUFBUCxhQURKLEVBRUk7QUFDSS9CLHNCQUNBO0FBQ0k2QiwyQkFBT0E7QUFEWDtBQUZKLGFBRko7QUFTSCxTQVZELENBVUUsT0FBTzFCLEdBQVAsRUFBWTtBQUNWekIsbUJBQU9DLEdBQVAsQ0FBV3dCLEdBQVg7QUFDQSxrQkFBTSxJQUFJckIsT0FBT1csS0FBWCxDQUFpQixlQUFqQixFQUFrQyx5REFBbEMsQ0FBTjtBQUNIO0FBQ0o7O0FBN0JVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNOQSxJQUFJWCxNQUFKO0FBQVdOLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsV0FBT0csQ0FBUCxFQUFTO0FBQUNILGlCQUFPRyxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEOztBQUErRCxJQUFJd0IsQ0FBSjs7QUFBTWpDLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxtQkFBUixDQUFiLEVBQTBDO0FBQUN5QixNQUFFeEIsQ0FBRixFQUFJO0FBQUN3QixZQUFFeEIsQ0FBRjtBQUFJOztBQUFWLENBQTFDLEVBQXNELENBQXREO0FBQXlELElBQUlDLE1BQUo7QUFBV1YsT0FBT08sS0FBUCxDQUFhQyxRQUFRLFdBQVIsQ0FBYixFQUFrQztBQUFDRSxXQUFPRCxDQUFQLEVBQVM7QUFBQ0MsaUJBQU9ELENBQVA7QUFBUzs7QUFBcEIsQ0FBbEMsRUFBd0QsQ0FBeEQ7QUFBMkQsSUFBSUcsT0FBSjtBQUFZWixPQUFPTyxLQUFQLENBQWFDLFFBQVEsV0FBUixDQUFiLEVBQWtDO0FBQUNJLFlBQVFILENBQVIsRUFBVTtBQUFDRyxrQkFBUUgsQ0FBUjtBQUFVOztBQUF0QixDQUFsQyxFQUEwRCxDQUExRDtBQUE2RCxJQUFJdkIsU0FBSjtBQUFjYyxPQUFPTyxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUN0QixjQUFVdUIsQ0FBVixFQUFZO0FBQUN2QixvQkFBVXVCLENBQVY7QUFBWTs7QUFBMUIsQ0FBcEMsRUFBZ0UsQ0FBaEU7QUFBbUUsSUFBSVAsTUFBSjtBQUFXRixPQUFPTyxLQUFQLENBQWFDLFFBQVEsVUFBUixDQUFiLEVBQWlDO0FBQUNOLFdBQU9PLENBQVAsRUFBUztBQUFDUCxpQkFBT08sQ0FBUDtBQUFTOztBQUFwQixDQUFqQyxFQUF1RCxDQUF2RDtBQU9wWEgsT0FBT08sT0FBUCxDQUFlO0FBRVhxRix5QkFBcUJyRSxNQUFyQixFQUE2QndCLEtBQTdCLEVBQW9DO0FBQ2hDLGNBQU10QyxVQUFVLEVBQWhCOztBQUVBLFlBQUksQ0FBQyxLQUFLQyxNQUFWLEVBQWtCO0FBQ2Qsa0JBQU0sSUFBSVYsT0FBT1csS0FBWCxDQUFpQixlQUFqQixFQUFrQyx3Q0FBbEMsQ0FBTjtBQUNILFNBTCtCLENBT2hDOzs7QUFFQSxjQUFNQyxRQUFRUixPQUFPUyxPQUFQLENBQWU7QUFDekJFLHVCQUFXLEtBQUtMLE1BRFM7QUFFekJNLG9CQUFRcEMsVUFBVUMsYUFBVixDQUF3QkM7QUFGUCxTQUFmLENBQWQsQ0FUZ0MsQ0FjaEM7O0FBQ0EsWUFBSSxDQUFDOEIsS0FBTCxFQUFZO0FBQ1Isa0JBQU0sSUFBSVosT0FBT1csS0FBWCxDQUFpQixXQUFqQixFQUE4QixrQkFBOUIsQ0FBTjtBQUNIOztBQUVELGNBQU1zRCxZQUFZdEMsRUFBRVksTUFBRixDQUFTM0IsTUFBTTJDLEtBQWYsRUFBc0IsVUFBVVcsSUFBVixFQUFnQjtBQUNwRCxtQkFBT0EsS0FBSzNDLE1BQUwsS0FBZ0JBLE1BQXZCO0FBQ0gsU0FGaUIsQ0FBbEI7O0FBSUEsWUFBSTBDLFVBQVVFLE1BQVYsS0FBcUIsQ0FBekIsRUFBNEI7QUFDeEIsa0JBQU0sSUFBSW5FLE9BQU9XLEtBQVgsQ0FBaUIsV0FBakIsRUFBOEIsdUJBQTlCLENBQU47QUFDSDs7QUFFRCxZQUFJK0UsWUFBWXpCLFVBQVUsQ0FBVixFQUFhUCxLQUFiLElBQXNCLENBQXRDO0FBRUFnQyxxQkFBYSxDQUFiOztBQUVBLFlBQUk7QUFDQXRGLG1CQUFPYSxNQUFQLENBQ0k7QUFDSUgscUJBQUtGLE1BQU1FLEdBRGY7QUFFSSxnQ0FBZ0JTO0FBRnBCLGFBREosRUFLSTtBQUNJTCxzQkFBTTtBQUNGLHFDQUFpQjZCO0FBRGY7QUFEVixhQUxKO0FBV0gsU0FaRCxDQVlFLE9BQU8xQixHQUFQLEVBQVk7QUFDVnpCLG1CQUFPQyxHQUFQLENBQVd3QixHQUFYO0FBQ0Esa0JBQU0sSUFBSXJCLE9BQU9XLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0MsNkRBQWxDLENBQU47QUFDSDtBQUNKOztBQWpEVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDUEEsTUFBTWtGLFVBQVFuRyxNQUFkO0FBQXFCLElBQUk0RSxZQUFKO0FBQWlCdUIsUUFBUTVGLEtBQVIsQ0FBY0MsUUFBUSw2QkFBUixDQUFkLEVBQXFEO0FBQUNvRSxpQkFBYW5FLENBQWIsRUFBZTtBQUFDbUUsdUJBQWFuRSxDQUFiO0FBQWU7O0FBQWhDLENBQXJELEVBQXVGLENBQXZGO0FBQTBGLElBQUl2QixTQUFKO0FBQWNpSCxRQUFRNUYsS0FBUixDQUFjQyxRQUFRLGFBQVIsQ0FBZCxFQUFxQztBQUFDdEIsY0FBVXVCLENBQVYsRUFBWTtBQUFDdkIsb0JBQVV1QixDQUFWO0FBQVk7O0FBQTFCLENBQXJDLEVBQWlFLENBQWpFO0FBSTlJLE1BQU1HLFVBQVUsRUFBaEI7QUFFQUEsUUFBUXdGLFNBQVIsR0FBb0IsSUFBSXhCLFlBQUosQ0FBaUI7QUFFakMvQyxZQUFRO0FBQ0p3RSxjQUFNQyxNQURGO0FBRUpDLGVBQU8zQixhQUFhNEIsS0FBYixDQUFtQkMsRUFGdEI7QUFHSkMsa0JBQVU7QUFITixLQUZ5QjtBQU9qQ3JELFdBQU87QUFDSGdELGNBQU1DLE1BREg7QUFFSEssYUFBSztBQUZGLEtBUDBCO0FBV2pDckYsWUFBUTtBQUNKK0UsY0FBTUMsTUFERjtBQUVKTSx1QkFBZTFILFVBQVVNLGlCQUFWLENBQTRCRDtBQUZ2QyxLQVh5QjtBQWVqQ29FLGNBQVU7QUFDTjBDLGNBQU1DLE1BREE7QUFFTk0sdUJBQWUxSCxVQUFVUyxjQUFWLENBQXlCSjtBQUZsQyxLQWZ1QjtBQW1CakN5RSxXQUFPO0FBQ0hxQyxjQUFNUSxNQURIO0FBRUhILGtCQUFVO0FBRlAsS0FuQjBCO0FBdUJqQ3pDLGVBQVc7QUFDUG9DLGNBQU0zRTtBQURDO0FBdkJzQixDQUFqQixDQUFwQjtBQTZCQWQsUUFBUUYsTUFBUixHQUFpQixJQUFJa0UsWUFBSixDQUFpQjtBQUU5QnhELFNBQUs7QUFDRGlGLGNBQU1DLE1BREw7QUFFREMsZUFBTzNCLGFBQWE0QixLQUFiLENBQW1CQyxFQUZ6QjtBQUdEQyxrQkFBVTtBQUhULEtBRnlCO0FBTzlCekMsZUFBVztBQUNQb0MsY0FBTTNFLElBREM7QUFFUG9GLG1CQUFXLFlBQVc7QUFDbEIsZ0JBQUssS0FBS0MsUUFBVixFQUFxQjtBQUNqQix1QkFBTyxJQUFJckYsSUFBSixFQUFQO0FBQ0gsYUFGRCxNQUdLO0FBQ0QscUJBQUtzRixLQUFMO0FBQ0g7QUFDSjtBQVRNLEtBUG1CO0FBa0I5QjNGLGVBQVc7QUFDUGdGLGNBQU1DLE1BREM7QUFFUEMsZUFBTzNCLGFBQWE0QixLQUFiLENBQW1CQyxFQUZuQjtBQUdQSyxtQkFBVyxZQUFXO0FBQ2xCLGdCQUFLLEtBQUtDLFFBQVYsRUFBcUI7QUFDakIsdUJBQU8sS0FBSy9GLE1BQVo7QUFDSCxhQUZELE1BRU87QUFDSCxxQkFBS2dHLEtBQUw7QUFDSDtBQUNKO0FBVE0sS0FsQm1CO0FBNkI5QjFGLFlBQVE7QUFDSitFLGNBQU1DLE1BREY7QUFFSk0sdUJBQWUxSCxVQUFVQyxhQUFWLENBQXdCSTtBQUZuQyxLQTdCc0I7QUFpQzlCc0UsV0FBTztBQUNId0MsY0FBTSxDQUFDekYsUUFBUXdGLFNBQVQ7QUFESCxLQWpDdUI7QUFvQzlCTixtQkFBZTtBQUNYTyxjQUFNWSxPQURLO0FBRVhQLGtCQUFVLElBRkM7QUFHWFEsc0JBQWM7QUFISCxLQXBDZTtBQXlDOUJ6RixnQkFBWTtBQUNSNEUsY0FBTTNFLElBREU7QUFFUmdGLGtCQUFVO0FBRkY7QUF6Q2tCLENBQWpCLENBQWpCO0FBK0NBOUYsUUFBUXVHLE9BQVIsR0FBa0IsSUFBSXZDLFlBQUosQ0FBaUI7QUFDL0J4RCxTQUFLO0FBQ0RpRixjQUFNQyxNQURMO0FBRURDLGVBQU8zQixhQUFhNEIsS0FBYixDQUFtQkMsRUFGekI7QUFHREMsa0JBQVU7QUFIVCxLQUQwQjtBQU0vQnpDLGVBQVc7QUFDUG9DLGNBQU0zRSxJQURDO0FBRVBvRixtQkFBVyxZQUFXO0FBQ2xCLGdCQUFLLEtBQUtDLFFBQVYsRUFBcUI7QUFDakIsdUJBQU8sSUFBSXJGLElBQUosRUFBUDtBQUNILGFBRkQsTUFHSztBQUNELHFCQUFLc0YsS0FBTDtBQUNIO0FBQ0o7QUFUTSxLQU5vQjtBQWlCL0IzRixlQUFXO0FBQ1BnRixjQUFNQyxNQURDO0FBRVBDLGVBQU8zQixhQUFhNEIsS0FBYixDQUFtQkMsRUFGbkI7QUFHUEssbUJBQVcsWUFBVztBQUNsQixnQkFBSyxLQUFLQyxRQUFWLEVBQXFCO0FBQ2pCLHVCQUFPLEtBQUsvRixNQUFaO0FBQ0gsYUFGRCxNQUVPO0FBQ0gscUJBQUtnRyxLQUFMO0FBQ0g7QUFDSjtBQVRNLEtBakJvQjtBQTRCL0IzRCxXQUFPO0FBQ0hnRCxjQUFNQyxNQURIO0FBRUhLLGFBQUs7QUFGRixLQTVCd0I7QUFnQy9CckYsWUFBUTtBQUNKK0UsY0FBTUMsTUFERjtBQUVKTSx1QkFBZTFILFVBQVVNLGlCQUFWLENBQTRCRDtBQUZ2QyxLQWhDdUI7QUFvQy9Ca0csaUJBQWE7QUFDVFksY0FBTTNFLElBREc7QUFFVGdGLGtCQUFVO0FBRkQ7QUFwQ2tCLENBQWpCLENBQWxCO0FBMENBOUYsUUFBUXdHLE9BQVIsR0FBa0IsSUFBSXhDLFlBQUosQ0FBaUI7QUFDL0J5QyxVQUFNO0FBQ0ZoQixjQUFNQyxNQURKO0FBRUZLLGFBQUssRUFGSDtBQUdGVyxhQUFLO0FBSEgsS0FEeUI7QUFNL0JDLGlCQUFhO0FBQ1RsQixjQUFNQyxNQURHO0FBRVRJLGtCQUFVLElBRkQ7QUFHVEMsYUFBSztBQUhJLEtBTmtCO0FBVy9CYSxjQUFVO0FBQ05uQixjQUFNQyxNQURBO0FBRU5DLGVBQU8sZ0RBRkQ7QUFHTmUsYUFBSztBQUhDLEtBWHFCO0FBZ0IvQkcscUJBQWlCO0FBQ2JwQixjQUFNQyxNQURPO0FBRWJnQixhQUFLLENBRlE7O0FBR2JJLGlCQUFTO0FBQ0wsZ0JBQUksS0FBS0MsS0FBTCxLQUFlLEtBQUtDLEtBQUwsQ0FBVyxVQUFYLEVBQXVCRCxLQUExQyxFQUFpRDtBQUM3Qyx1QkFBTyxrQkFBUDtBQUNIO0FBQ0o7O0FBUFk7QUFoQmMsQ0FBakIsQ0FBbEI7QUEyQkEvRyxRQUFRaUUsUUFBUixHQUFtQixJQUFJRCxZQUFKLENBQWlCO0FBQ2hDeEQsU0FBSztBQUNEaUYsY0FBTUMsTUFETDtBQUVEQyxlQUFPM0IsYUFBYTRCLEtBQWIsQ0FBbUJDLEVBRnpCO0FBR0RDLGtCQUFVO0FBSFQsS0FEMkI7QUFNaENyRixlQUFXO0FBQ1BnRixjQUFNQyxNQURDO0FBRVBDLGVBQU8zQixhQUFhNEIsS0FBYixDQUFtQkMsRUFGbkI7QUFHUEssbUJBQVcsWUFBVztBQUNsQixnQkFBSyxLQUFLQyxRQUFWLEVBQXFCO0FBQ2pCLHVCQUFPLEtBQUsvRixNQUFaO0FBQ0gsYUFGRCxNQUVPO0FBQ0gscUJBQUtnRyxLQUFMO0FBQ0g7QUFDSixTQVRNO0FBVVBOLGtCQUFVO0FBVkgsS0FOcUI7QUFrQmhDeEIscUJBQWlCO0FBQ2JtQixjQUFNQyxNQURPO0FBRWJZLHNCQUFjLDRCQUZEO0FBR2JSLGtCQUFVO0FBSEcsS0FsQmU7QUF1QmhDdkIsc0JBQWtCO0FBQ2RrQixjQUFNQyxNQURRO0FBRWRZLHNCQUFjLElBRkE7QUFHZFIsa0JBQVU7QUFISSxLQXZCYztBQTRCaEN0QixvQkFBZ0I7QUFDWmlCLGNBQU1DLE1BRE07QUFFWlksc0JBQWMsSUFGRjtBQUdaUixrQkFBVTtBQUhFLEtBNUJnQjtBQWlDaENyQixvQkFBZ0I7QUFDWmdCLGNBQU1DLE1BRE07QUFFWlksc0JBQWMsSUFGRjtBQUdaUixrQkFBVTtBQUhFO0FBakNnQixDQUFqQixDQUFuQjtBQXlDQTFHLE9BQU9DLE9BQVAsR0FBaUI7QUFBRVc7QUFBRixDQUFqQixDOzs7Ozs7Ozs7OztBQ2hNQSxNQUFNdUYsVUFBUW5HLE1BQWQ7QUFBcUIsSUFBSTZILEtBQUo7QUFBVTFCLFFBQVE1RixLQUFSLENBQWNDLFFBQVEsY0FBUixDQUFkLEVBQXNDO0FBQUNxSCxVQUFNcEgsQ0FBTixFQUFRO0FBQUNvSCxnQkFBTXBILENBQU47QUFBUTs7QUFBbEIsQ0FBdEMsRUFBMEQsQ0FBMUQ7QUFBNkQsSUFBSUcsT0FBSjtBQUFZdUYsUUFBUTVGLEtBQVIsQ0FBY0MsUUFBUSxXQUFSLENBQWQsRUFBbUM7QUFBQ0ksWUFBUUgsQ0FBUixFQUFVO0FBQUNHLGtCQUFRSCxDQUFSO0FBQVU7O0FBQXRCLENBQW5DLEVBQTJELENBQTNEO0FBR3hHLE1BQU1xSCxVQUFVO0FBQ1pDLHNCQUFrQixVQUROO0FBRVpDLHVCQUFtQiw0QkFGUDtBQUdaQyx1QkFBbUIsZUFIUDs7QUFLWkMsa0JBQWE7QUFFVCxZQUFJbEQsV0FBV0gsU0FBUzFELE9BQVQsRUFBZjs7QUFFQSxZQUFJLENBQUM2RCxRQUFMLEVBQWM7QUFDVkEsdUJBQVcsRUFBWDtBQUNBQSxxQkFBU0UsZUFBVCxHQUEyQjRDLFFBQVFFLGlCQUFuQztBQUNBaEQscUJBQVNHLGdCQUFULEdBQTRCLElBQTVCO0FBQ0FILHFCQUFTSSxjQUFULEdBQTBCLElBQTFCO0FBQ0FKLHFCQUFTSyxjQUFULEdBQTBCLElBQTFCO0FBQ0g7O0FBRUQsZUFBT0wsUUFBUDtBQUNIOztBQWxCVyxDQUFoQjs7QUFxQkEsSUFBSSxDQUFDc0IsT0FBTzZCLFNBQVAsQ0FBaUJDLFlBQXRCLEVBQW9DO0FBQ2hDOUIsV0FBTzZCLFNBQVAsQ0FBaUJDLFlBQWpCLEdBQWdDLFlBQVk7QUFDeEMsZUFBTyxLQUFLQyxPQUFMLENBQWEsUUFBYixFQUF1QixVQUFTQyxHQUFULEVBQWE7QUFBQyxtQkFBT0EsSUFBSUMsTUFBSixDQUFXLENBQVgsRUFBY0MsV0FBZCxLQUE4QkYsSUFBSUcsTUFBSixDQUFXLENBQVgsRUFBY0MsV0FBZCxFQUFyQztBQUFrRSxTQUF2RyxDQUFQO0FBQ0gsS0FGRDtBQUdIOztBQUVELE1BQU1oSSxTQUFTLElBQUltSCxNQUFNYyxVQUFWLENBQXFCLFFBQXJCLENBQWY7QUFDQSxNQUFNaEksZUFBZSxJQUFJa0gsTUFBTWMsVUFBVixDQUFxQixlQUFyQixDQUFyQjtBQUNBLE1BQU1DLGNBQWMsSUFBSWYsTUFBTWMsVUFBVixDQUFxQixhQUFyQixDQUFwQjtBQUNBLE1BQU05RCxXQUFXLElBQUlnRCxNQUFNYyxVQUFWLENBQXFCLFVBQXJCLENBQWpCO0FBRUFqSSxPQUFPbUksWUFBUCxDQUFvQmpJLFFBQVFGLE1BQTVCO0FBQ0FDLGFBQWFrSSxZQUFiLENBQTBCakksUUFBUXVHLE9BQWxDO0FBQ0F0QyxTQUFTZ0UsWUFBVCxDQUFzQmpJLFFBQVFpRSxRQUE5QjtBQUVBN0UsT0FBT0MsT0FBUCxHQUFpQjtBQUFFNkgsV0FBRjtBQUFXcEgsVUFBWDtBQUFtQkMsZ0JBQW5CO0FBQWlDaUksZUFBakM7QUFBOEMvRDtBQUE5QyxDQUFqQixDOzs7Ozs7Ozs7OztBQ3ZDQSxJQUFJdkUsTUFBSjtBQUFXTixPQUFPTyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNGLFdBQU9HLENBQVAsRUFBUztBQUFDSCxpQkFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJc0IsRUFBSjtBQUFPL0IsT0FBT08sS0FBUCxDQUFhQyxRQUFRLElBQVIsQ0FBYixFQUEyQjtBQUFDd0IsWUFBUXZCLENBQVIsRUFBVTtBQUFDc0IsYUFBR3RCLENBQUg7QUFBSzs7QUFBakIsQ0FBM0IsRUFBOEMsQ0FBOUM7O0FBQWlELElBQUl3QixDQUFKOztBQUFNakMsT0FBT08sS0FBUCxDQUFhQyxRQUFRLG1CQUFSLENBQWIsRUFBMEM7QUFBQ3lCLE1BQUV4QixDQUFGLEVBQUk7QUFBQ3dCLFlBQUV4QixDQUFGO0FBQUk7O0FBQVYsQ0FBMUMsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSW1JLFdBQUo7QUFBZ0I1SSxPQUFPTyxLQUFQLENBQWFDLFFBQVEsZ0JBQVIsQ0FBYixFQUF1QztBQUFDb0ksZ0JBQVluSSxDQUFaLEVBQWM7QUFBQ21JLHNCQUFZbkksQ0FBWjtBQUFjOztBQUE5QixDQUF2QyxFQUF1RSxDQUF2RTtBQUtqTkgsT0FBT3dJLE9BQVAsQ0FBZSxhQUFmLEVBQThCLFlBQVk7QUFDdEMsVUFBTUMsT0FBTyxJQUFiO0FBQ0EsVUFBTTNHLGFBQWFMLEdBQUdNLFlBQUgsQ0FBaUIsR0FBRUMsUUFBUUMsR0FBUixFQUFjLE1BQWpDLENBQW5CO0FBQ0EsVUFBTUMsYUFBYyxHQUFFSixVQUFXLG1CQUFqQztBQUNBLFVBQU1LLGlCQUFrQixHQUFFRCxVQUFXLGVBQXJDO0FBQ0EsVUFBTUUsTUFBTVgsR0FBR1ksV0FBSCxDQUFlRixjQUFmLENBQVo7O0FBQ0FSLE1BQUVlLElBQUYsQ0FBT04sR0FBUCxFQUFZLFVBQVVzRyxVQUFWLEVBQXNCO0FBQzlCLGNBQU1DLGlCQUFpQkQsV0FBV0UsS0FBWCxDQUFpQixHQUFqQixFQUFzQixDQUF0QixFQUF5QmQsWUFBekIsRUFBdkI7QUFDQVcsYUFBS0ksS0FBTCxDQUFXLGFBQVgsRUFBMEJILFVBQTFCLEVBQXNDO0FBQUUzQixrQkFBTTRCLGNBQVI7QUFBd0J0QixtQkFBUSxnQkFBZXFCLFVBQVc7QUFBMUQsU0FBdEM7QUFDSCxLQUhEOztBQUlBLFNBQUtJLEtBQUw7QUFDSCxDQVhELEU7Ozs7Ozs7Ozs7O0FDTEEsSUFBSTlJLE1BQUo7QUFBV04sT0FBT08sS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixXQUFPRyxDQUFQLEVBQVM7QUFBQ0gsaUJBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSXFILE9BQUosRUFBWW5ILFlBQVo7QUFBeUJYLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxnQkFBUixDQUFiLEVBQXVDO0FBQUNzSCxZQUFRckgsQ0FBUixFQUFVO0FBQUNxSCxrQkFBUXJILENBQVI7QUFBVSxLQUF0Qjs7QUFBdUJFLGlCQUFhRixDQUFiLEVBQWU7QUFBQ0UsdUJBQWFGLENBQWI7QUFBZTs7QUFBdEQsQ0FBdkMsRUFBK0YsQ0FBL0Y7QUFBa0csSUFBSXZCLFNBQUo7QUFBY2MsT0FBT08sS0FBUCxDQUFhQyxRQUFRLGtCQUFSLENBQWIsRUFBeUM7QUFBQ3RCLGNBQVV1QixDQUFWLEVBQVk7QUFBQ3ZCLG9CQUFVdUIsQ0FBVjtBQUFZOztBQUExQixDQUF6QyxFQUFxRSxDQUFyRTs7QUFJbk5FLGFBQWEwSSxZQUFiLENBQTBCLFdBQTFCLEVBQXVDLENBQXZDOztBQUNBMUksYUFBYTBJLFlBQWIsQ0FBMEIsUUFBMUIsRUFBb0MsQ0FBcEM7O0FBQ0ExSSxhQUFhMEksWUFBYixDQUEwQixXQUExQixFQUF1QyxDQUF2Qzs7QUFHQS9JLE9BQU93SSxPQUFQLENBQWUsY0FBZixFQUErQixZQUFXO0FBRXRDLFFBQUcsQ0FBQ3hJLE9BQU9VLE1BQVAsRUFBSixFQUFxQjtBQUNqQixlQUFPLElBQVA7QUFDSDs7QUFFRCxXQUFPTCxhQUFhMkksSUFBYixDQUNQO0FBQ0lqSSxtQkFBV2YsT0FBT1UsTUFBUCxFQURmO0FBRUljLGFBQUssQ0FDRDtBQUFFUixvQkFBUXBDLFVBQVVNLGlCQUFWLENBQTRCQztBQUF0QyxTQURDLEVBRUQ7QUFDRTZCLG9CQUFRcEMsVUFBVU0saUJBQVYsQ0FBNEJFLFFBRHRDO0FBRUUrRix5QkFBYTtBQUFFOEQscUJBQUssSUFBSTdILElBQUosQ0FBU0EsS0FBSzhILEdBQUwsS0FBYSxLQUFHLEVBQUgsR0FBTSxFQUFOLEdBQVcsSUFBakM7QUFBUDtBQUZmLFNBRkM7QUFGVCxLQURPLENBQVA7QUFZSCxDQWxCRCxFLENBb0JBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3QkEsSUFBSWxKLE1BQUo7QUFBV04sT0FBT08sS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixXQUFPRyxDQUFQLEVBQVM7QUFBQ0gsaUJBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUMsTUFBSjtBQUFXVixPQUFPTyxLQUFQLENBQWFDLFFBQVEsZ0JBQVIsQ0FBYixFQUF1QztBQUFDRSxXQUFPRCxDQUFQLEVBQVM7QUFBQ0MsaUJBQU9ELENBQVA7QUFBUzs7QUFBcEIsQ0FBdkMsRUFBNkQsQ0FBN0Q7QUFBZ0UsSUFBSXZCLFNBQUo7QUFBY2MsT0FBT08sS0FBUCxDQUFhQyxRQUFRLGtCQUFSLENBQWIsRUFBeUM7QUFBQ3RCLGNBQVV1QixDQUFWLEVBQVk7QUFBQ3ZCLG9CQUFVdUIsQ0FBVjtBQUFZOztBQUExQixDQUF6QyxFQUFxRSxDQUFyRTs7QUFJbktDLE9BQU8ySSxZQUFQLENBQW9CLFdBQXBCLEVBQWlDLENBQWpDOztBQUNBM0ksT0FBTzJJLFlBQVAsQ0FBb0IsUUFBcEIsRUFBOEIsQ0FBOUI7O0FBRUEvSSxPQUFPd0ksT0FBUCxDQUFlLGVBQWYsRUFBZ0MsWUFBVztBQUV2QyxRQUFHLENBQUMsS0FBSzlILE1BQVQsRUFBaUI7QUFDYixlQUFPLElBQVA7QUFDSDs7QUFFRCxXQUFPTixPQUFPNEksSUFBUCxDQUFZO0FBQ2ZqSSxtQkFBVyxLQUFLTCxNQUREO0FBRWZNLGdCQUFRO0FBQ0ptSSxpQkFBSyxDQUFFdkssVUFBVUMsYUFBVixDQUF3QkMsTUFBMUIsRUFBa0NGLFVBQVVDLGFBQVYsQ0FBd0JHLE1BQTFEO0FBREQ7QUFGTyxLQUFaLENBQVA7QUFPSCxDQWJEO0FBZUFnQixPQUFPd0ksT0FBUCxDQUFlLGlCQUFmLEVBQWtDLFlBQVc7QUFFekMsUUFBRyxDQUFDLEtBQUs5SCxNQUFULEVBQWlCO0FBQ2IsZUFBTyxJQUFQO0FBQ0g7O0FBRUQsV0FBT04sT0FBTzRJLElBQVAsQ0FBWTtBQUFFakksbUJBQVcsS0FBS0wsTUFBbEI7QUFBMEJNLGdCQUFRcEMsVUFBVUMsYUFBVixDQUF3QkU7QUFBMUQsS0FBWixDQUFQO0FBRUgsQ0FSRDtBQVVBaUIsT0FBT3dJLE9BQVAsQ0FBZSx1QkFBZixFQUF3QyxVQUFTL0gsT0FBVCxFQUFrQjtBQUV0RCxRQUFHLENBQUMsS0FBS0MsTUFBVCxFQUFpQjtBQUNiLGVBQU8sSUFBUDtBQUNIOztBQUVELFdBQU9OLE9BQU80SSxJQUFQLENBQVk7QUFBRWxJLGFBQUtMLE9BQVA7QUFBZ0JNLG1CQUFXLEtBQUtMLE1BQWhDO0FBQXdDTSxnQkFBUXBDLFVBQVVDLGFBQVYsQ0FBd0JFO0FBQXhFLEtBQVosQ0FBUDtBQUVILENBUkQsRTs7Ozs7Ozs7Ozs7QUNoQ0EsSUFBSWlCLE1BQUo7QUFBV04sT0FBT08sS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixXQUFPRyxDQUFQLEVBQVM7QUFBQ0gsaUJBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSW9FLFFBQUo7QUFBYTdFLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxnQkFBUixDQUFiLEVBQXVDO0FBQUNxRSxhQUFTcEUsQ0FBVCxFQUFXO0FBQUNvRSxtQkFBU3BFLENBQVQ7QUFBVzs7QUFBeEIsQ0FBdkMsRUFBaUUsQ0FBakU7O0FBR3ZGb0UsU0FBU3dFLFlBQVQsQ0FBc0IsV0FBdEIsRUFBbUMsQ0FBbkM7O0FBRUEvSSxPQUFPd0ksT0FBUCxDQUFlLFVBQWYsRUFBMkIsWUFBVztBQUVsQyxRQUFHLENBQUN4SSxPQUFPVSxNQUFQLEVBQUosRUFBcUI7QUFDakIsZUFBTyxJQUFQO0FBQ0g7O0FBRUQsV0FBTzZELFNBQVN5RSxJQUFULENBQWM7QUFBRWpJLG1CQUFXZixPQUFPVSxNQUFQO0FBQWIsS0FBZCxDQUFQO0FBRUgsQ0FSRCxFOzs7Ozs7Ozs7OztBQ0xBLElBQUlWLE1BQUo7QUFBV04sT0FBT08sS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixTQUFPRyxDQUFQLEVBQVM7QUFBQ0gsYUFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUVYSCxPQUFPb0osT0FBUCxDQUFlLE1BQU0sQ0FDbkI7QUFDRCxDQUZELEU7Ozs7Ozs7Ozs7O0FDRkExSixPQUFPMkosTUFBUCxDQUFjO0FBQUNDLDBCQUFxQixNQUFJQTtBQUExQixDQUFkOztBQUErRCxJQUFJM0gsQ0FBSjs7QUFBTWpDLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxtQkFBUixDQUFiLEVBQTBDO0FBQUN5QixNQUFFeEIsQ0FBRixFQUFJO0FBQUN3QixZQUFFeEIsQ0FBRjtBQUFJOztBQUFWLENBQTFDLEVBQXNELENBQXREO0FBQXlELElBQUlvSixRQUFKO0FBQWE3SixPQUFPTyxLQUFQLENBQWFDLFFBQVEsbUJBQVIsQ0FBYixFQUEwQztBQUFDcUosYUFBU3BKLENBQVQsRUFBVztBQUFDb0osbUJBQVNwSixDQUFUO0FBQVc7O0FBQXhCLENBQTFDLEVBQW9FLENBQXBFO0FBQXVFLElBQUlxSixLQUFKO0FBQVU5SixPQUFPTyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNzSixVQUFNckosQ0FBTixFQUFRO0FBQUNxSixnQkFBTXJKLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSXNKLE9BQUo7QUFBWS9KLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxnQkFBUixDQUFiLEVBQXVDO0FBQUN1SixZQUFRdEosQ0FBUixFQUFVO0FBQUNzSixrQkFBUXRKLENBQVI7QUFBVTs7QUFBdEIsQ0FBdkMsRUFBK0QsQ0FBL0Q7O0FBS3BTLE1BQU11SixVQUFVLFNBQVNBLE9BQVQsQ0FBaUJDLFFBQWpCLEVBQTJCO0FBQ3ZDLFVBQU1DLEtBQUtDLFNBQVNDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBWDtBQUNBRCxhQUFTRSxJQUFULENBQWNDLFdBQWQsQ0FBMEJKLEVBQTFCOztBQUVBLFFBQUk7QUFDQUQsaUJBQVNDLEVBQVQ7QUFDSCxLQUZELFNBRVU7QUFDTkMsaUJBQVNFLElBQVQsQ0FBY0UsV0FBZCxDQUEwQkwsRUFBMUI7QUFDSDtBQUNKLENBVEQ7O0FBV08sTUFBTU4sdUJBQXVCLFNBQVNBLG9CQUFULENBQThCWSxRQUE5QixFQUF3Q0MsSUFBeEMsRUFBOENSLFFBQTlDLEVBQXdEO0FBQ3hGRCxZQUFTRSxFQUFELElBQVE7QUFDWixjQUFNUSxjQUFjekksRUFBRTBJLFFBQUYsQ0FBV0gsUUFBWCxJQUF1QlgsU0FBU1csUUFBVCxDQUF2QixHQUE0Q0EsUUFBaEU7QUFDQVYsY0FBTWMsY0FBTixDQUFxQkYsV0FBckIsRUFBa0NELElBQWxDLEVBQXdDUCxFQUF4QztBQUNBSCxnQkFBUWMsS0FBUjtBQUNBWixpQkFBU0MsRUFBVCxFQUFhUSxXQUFiO0FBQ0gsS0FMRDtBQU1ILENBUE0sQzs7Ozs7Ozs7Ozs7QUNoQlAsTUFBTXZFLFVBQVFuRyxNQUFkO0FBQXFCLElBQUlNLE1BQUo7QUFBVzZGLFFBQVE1RixLQUFSLENBQWNDLFFBQVEsZUFBUixDQUFkLEVBQXVDO0FBQUNGLFdBQU9HLENBQVAsRUFBUztBQUFDSCxpQkFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF2QyxFQUE2RCxDQUE3RDtBQUFnRSxJQUFJZ0QsTUFBSjtBQUFXMEMsUUFBUTVGLEtBQVIsQ0FBY0MsUUFBUSxlQUFSLENBQWQsRUFBdUM7QUFBQ2lELFdBQU9oRCxDQUFQLEVBQVM7QUFBQ2dELGlCQUFPaEQsQ0FBUDtBQUFTOztBQUFwQixDQUF2QyxFQUE2RCxDQUE3RDs7QUFBZ0UsSUFBSXdCLENBQUo7O0FBQU1rRSxRQUFRNUYsS0FBUixDQUFjQyxRQUFRLG1CQUFSLENBQWQsRUFBMkM7QUFBQ3lCLE1BQUV4QixDQUFGLEVBQUk7QUFBQ3dCLFlBQUV4QixDQUFGO0FBQUk7O0FBQVYsQ0FBM0MsRUFBdUQsQ0FBdkQ7QUFBMEQsSUFBSXZCLFNBQUo7QUFBY2lILFFBQVE1RixLQUFSLENBQWNDLFFBQVEsa0JBQVIsQ0FBZCxFQUEwQztBQUFDdEIsY0FBVXVCLENBQVYsRUFBWTtBQUFDdkIsb0JBQVV1QixDQUFWO0FBQVk7O0FBQTFCLENBQTFDLEVBQXNFLENBQXRFOztBQU96UCxNQUFNcUssUUFBUXhLLE9BQU95SyxNQUFQLElBQWlCdkssUUFBUSxPQUFSLENBQS9CLEMsQ0FBZ0Q7OztBQUVoRCxNQUFNd0ssV0FBVztBQUViQyxpQkFBYUMsVUFBYixFQUF5QjtBQUNyQixZQUFJQyxRQUFRLEVBQVo7O0FBRUEsWUFBSSxDQUFDbEosRUFBRWdELFdBQUYsQ0FBY2lHLFVBQWQsQ0FBTCxFQUFnQztBQUM1QkMsb0JBQVFELFVBQVI7QUFDSDs7QUFFRCxjQUFNckcsV0FBVyxFQUFqQjtBQUNBQSxpQkFBU0ssZUFBVCxHQUEyQixjQUEzQjtBQUNBTCxpQkFBU00sZ0JBQVQsR0FBNEIsd0JBQTVCO0FBQ0FOLGlCQUFTTyxjQUFULEdBQTBCLHNCQUExQjtBQUNBUCxpQkFBU1EsY0FBVCxHQUEwQixzQkFBMUI7QUFFQSxlQUFPUixRQUFQO0FBQ0gsS0FoQlk7O0FBaUJidUcseUJBQXFCRixVQUFyQixFQUFpQztBQUM3QixZQUFJQyxRQUFRLEVBQVo7O0FBRUEsWUFBSSxDQUFDbEosRUFBRWdELFdBQUYsQ0FBY2lHLFVBQWQsQ0FBTCxFQUFnQztBQUM1QkMsb0JBQVFELFVBQVI7QUFDSDs7QUFFRCxjQUFNdEMsY0FBYyxFQUFwQjtBQUVBQSxvQkFBWTFGLElBQVosQ0FBaUI7QUFBRW1FLGtCQUFNLFNBQVI7QUFBbUJNLG1CQUFPO0FBQTFCLFNBQWpCO0FBQ0FpQixvQkFBWTFGLElBQVosQ0FBaUI7QUFBRW1FLGtCQUFNLFNBQVI7QUFBbUJNLG1CQUFPO0FBQTFCLFNBQWpCO0FBQ0FpQixvQkFBWTFGLElBQVosQ0FBaUI7QUFBRW1FLGtCQUFNLFdBQVI7QUFBcUJNLG1CQUFPO0FBQTVCLFNBQWpCO0FBQ0FpQixvQkFBWTFGLElBQVosQ0FBaUI7QUFBRW1FLGtCQUFNLFVBQVI7QUFBb0JNLG1CQUFPO0FBQTNCLFNBQWpCO0FBQ0FpQixvQkFBWTFGLElBQVosQ0FBaUI7QUFBRW1FLGtCQUFNLFVBQVI7QUFBb0JNLG1CQUFPO0FBQTNCLFNBQWpCO0FBRUEsZUFBT2lCLFdBQVA7QUFDSCxLQWpDWTs7QUFtQ2J5QyxvQkFBZ0JILFVBQWhCLEVBQTRCO0FBQ3hCLFlBQUlDLFFBQVEsRUFBWjs7QUFFQSxZQUFJLENBQUNsSixFQUFFZ0QsV0FBRixDQUFjaUcsVUFBZCxDQUFMLEVBQWdDO0FBQzVCQyxvQkFBUUQsVUFBUjtBQUNIOztBQUVELGNBQU1JLGNBQWMsRUFBcEI7QUFFQUEsb0JBQVlsSyxHQUFaLEdBQWtCK0osTUFBTS9KLEdBQU4sSUFBYXFDLE9BQU9NLEVBQVAsRUFBL0I7QUFDQXVILG9CQUFZakssU0FBWixHQUF3QjhKLE1BQU05SixTQUFOLElBQW1Cb0MsT0FBT00sRUFBUCxFQUEzQztBQUNBdUgsb0JBQVlySCxTQUFaLEdBQXdCa0gsTUFBTWxILFNBQU4sSUFBbUIsSUFBSXZDLElBQUosRUFBM0M7QUFDQTRKLG9CQUFZakksS0FBWixHQUFvQjhILE1BQU05SCxLQUFOLElBQWV5SCxNQUFNekQsSUFBTixDQUFXaEUsS0FBWCxFQUFuQztBQUNBaUksb0JBQVloSyxNQUFaLEdBQXFCNkosTUFBTTdKLE1BQU4sSUFBZ0JwQyxVQUFVTSxpQkFBVixDQUE0QkMsT0FBakU7QUFDQTZMLG9CQUFZN0YsV0FBWixHQUEwQjBGLE1BQU0xRixXQUFOLElBQXFCLElBQS9DO0FBRUEsZUFBTzZGLFdBQVA7QUFDSCxLQXBEWTs7QUFzRGJDLGtCQUFjTCxVQUFkLEVBQTBCO0FBQ3RCLFlBQUlDLFFBQVEsRUFBWjs7QUFFQSxZQUFJLENBQUNsSixFQUFFZ0QsV0FBRixDQUFjaUcsVUFBZCxDQUFMLEVBQWdDO0FBQzVCQyxvQkFBUUQsVUFBUjtBQUNIOztBQUVELGNBQU05RSxZQUFZLEVBQWxCO0FBRUFBLGtCQUFVdkUsTUFBVixHQUFtQnNKLE1BQU10SixNQUFOLElBQWdCNEIsT0FBT00sRUFBUCxFQUFuQztBQUNBcUMsa0JBQVUvQyxLQUFWLEdBQWtCOEgsTUFBTTlILEtBQU4sSUFBZXlILE1BQU16RCxJQUFOLENBQVdoRSxLQUFYLEVBQWpDO0FBQ0ErQyxrQkFBVTlFLE1BQVYsR0FBbUI2SixNQUFNN0osTUFBTixJQUFnQnBDLFVBQVVNLGlCQUFWLENBQTRCQyxPQUEvRDtBQUNBMkcsa0JBQVV6QyxRQUFWLEdBQXFCd0gsTUFBTXhILFFBQU4sSUFBa0JGLE9BQU8rSCxNQUFQLENBQWMsQ0FBQ3RNLFVBQVVTLGNBQVYsQ0FBeUJDLEtBQTFCLEVBQWlDVixVQUFVUyxjQUFWLENBQXlCRSxHQUExRCxFQUErRFgsVUFBVVMsY0FBVixDQUF5QkcsR0FBeEYsQ0FBZCxDQUF2QztBQUNBc0csa0JBQVVwQyxLQUFWLEdBQWtCbUgsTUFBTW5ILEtBQU4sSUFBZSxDQUFqQztBQUNBb0Msa0JBQVVuQyxTQUFWLEdBQXNCa0gsTUFBTWxILFNBQU4sSUFBbUIsSUFBSXZDLElBQUosRUFBekM7QUFFQSxlQUFPMEUsU0FBUDtBQUNILEtBdkVZOztBQXlFYnFGLG1CQUFlUCxVQUFmLEVBQTJCUSxLQUEzQixFQUFrQztBQUM5QixjQUFNN0gsUUFBUSxFQUFkO0FBRUEsWUFBSSxDQUFDNkgsS0FBTCxFQUFZQSxRQUFRLENBQVI7O0FBRVosYUFBSyxJQUFJQyxJQUFJLENBQWIsRUFBZ0JBLElBQUlELEtBQXBCLEVBQTJCQyxLQUFLLENBQWhDLEVBQW1DO0FBQy9COUgsa0JBQU1YLElBQU4sQ0FBVyxLQUFLcUksYUFBTCxDQUFtQkwsVUFBbkIsQ0FBWDtBQUNIOztBQUVELGVBQU9ySCxLQUFQO0FBQ0gsS0FuRlk7O0FBcUZiK0gsY0FBVVYsVUFBVixFQUFzQjtBQUNsQixZQUFJQyxRQUFRLEVBQVo7O0FBRUEsWUFBSSxDQUFDbEosRUFBRWdELFdBQUYsQ0FBY2lHLFVBQWQsQ0FBTCxFQUFnQztBQUM1QkMsb0JBQVFELFVBQVI7QUFDSDs7QUFFRCxjQUFNVyxRQUFRLEVBQWQ7QUFFQUEsY0FBTXpLLEdBQU4sR0FBWStKLE1BQU0vSixHQUFOLElBQWFxQyxPQUFPTSxFQUFQLEVBQXpCO0FBQ0E4SCxjQUFNeEssU0FBTixHQUFrQjhKLE1BQU05SixTQUFOLElBQW1Cb0MsT0FBT00sRUFBUCxFQUFyQztBQUNBOEgsY0FBTXhJLEtBQU4sR0FBYzhILE1BQU05SCxLQUFOLElBQWV5SCxNQUFNekQsSUFBTixDQUFXaEUsS0FBWCxFQUE3QjtBQUNBd0ksY0FBTXZLLE1BQU4sR0FBZTZKLE1BQU03SixNQUFOLElBQWdCcEMsVUFBVUMsYUFBVixDQUF3QkMsTUFBdkQ7QUFDQXlNLGNBQU1oSSxLQUFOLEdBQWNzSCxNQUFNdEgsS0FBTixJQUFlLEtBQUs0SCxjQUFMLENBQW9CLEVBQXBCLEVBQXdCTixNQUFNTyxLQUFOLElBQWUsQ0FBdkMsQ0FBN0I7QUFDQUcsY0FBTS9GLGFBQU4sR0FBc0I3RCxFQUFFZ0QsV0FBRixDQUFja0csTUFBTXJGLGFBQXBCLElBQXFDLEtBQXJDLEdBQTZDcUYsTUFBTXJGLGFBQXpFO0FBQ0ErRixjQUFNcEssVUFBTixHQUFtQjBKLE1BQU0xSixVQUFOLElBQW9CLElBQUlDLElBQUosRUFBdkM7QUFFQSxlQUFPbUssS0FBUDtBQUNIOztBQXZHWSxDQUFqQjtBQTBHQTdMLE9BQU9DLE9BQVAsR0FBaUI7QUFBRStLO0FBQUYsQ0FBakIsQyIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgQ29uc3RhbnRzID0ge1xuICAgIFJldHJvU3RhdHVzZXM6IHtcbiAgICAgICAgQUNUSVZFOiAnQWN0aXZlJyxcbiAgICAgICAgQVJDSElWRUQ6ICdBcmNoaXZlZCcsXG4gICAgICAgIEZST1pFTjogJ0Zyb3plbicsXG4gICAgICAgIHZhbHVlczogWydBY3RpdmUnLCAnQXJjaGl2ZWQnLCAnRnJvemVuJ11cbiAgICB9LFxuICAgIFJldHJvSXRlbVN0YXR1c2VzOiB7XG4gICAgICAgIFBFTkRJTkc6ICdQZW5kaW5nJyxcbiAgICAgICAgQ09NUExFVEU6ICdDb21wbGV0ZScsXG4gICAgICAgIHZhbHVlczogWydQZW5kaW5nJywgJ0NvbXBsZXRlJ11cbiAgICB9LFxuICAgIFJldHJvSXRlbVR5cGVzOiB7XG4gICAgICAgIEhBUFBZOiAnSGFwcHknLFxuICAgICAgICBNRUg6ICdNZWgnLFxuICAgICAgICBTQUQ6ICdTYWQnLFxuICAgICAgICBBQ1RJT046ICdBY3Rpb24nLFxuICAgICAgICB2YWx1ZXM6IFsnSGFwcHknLCAnTWVoJywgJ1NhZCcsICdBY3Rpb24nXVxuICAgIH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSB7IENvbnN0YW50cyB9IiwiY29uc3QgTG9nZ2VyID0ge1xuICAgIGxvZzogKG1lc3NhZ2UpID0+IHtcbiAgICAgICAgY29uc29sZS5sb2cobWVzc2FnZSlcbiAgICB9XG59XG5cbm1vZHVsZS5leHBvcnRzID0geyBMb2dnZXIgfVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IFJldHJvcywgUmV0cm9BY3Rpb25zIH0gZnJvbSAnLi9zZXF1ZW50J1xuaW1wb3J0IHsgU2NoZW1hcyB9IGZyb20gJy4vc2NoZW1hcydcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4vY29uc3RhbnRzJ1xuaW1wb3J0IHsgTG9nZ2VyIH0gZnJvbSAnLi9sb2dnZXInXG5cbk1ldGVvci5tZXRob2RzKHtcblxuICAgIGFyY2hpdmVSZXRybyhyZXRyb0lkKSB7XG4gICAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1sb2dnZWQtaW4nLCAnWW91IG11c3QgYmUgbG9nZ2VkIGludG8gYSByZXRybyBib2FyZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcmV0cm8gPSBSZXRyb3MuZmluZE9uZSh7XG4gICAgICAgICAgICBfaWQ6IHJldHJvSWQsXG4gICAgICAgICAgICBjcmVhdGVkQnk6IHRoaXMudXNlcklkXG4gICAgICAgIH0pXG5cbiAgICAgICAgLy8gbmVlZCB0byBzZWUgaWYgdGhlcmUgaXNcbiAgICAgICAgaWYgKCFyZXRybykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWZvdW5kJywgJ1JldHJvIGNvdWxkIG5vdCBiZSBmb3VuZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHJldHJvLnN0YXR1cyA9PT0gQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuQVJDSElWRUQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ2FscmVhZHktYXJjaGl2ZWQnLCAnUmV0cm8gd2FzIGFscmVhZHkgYXJjaGl2ZWQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBSZXRyb3MudXBkYXRlKFxuICAgICAgICAgICAgICAgIHsgX2lkOiByZXRyby5faWQgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICRzZXQ6XG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czogQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuQVJDSElWRUQsXG4gICAgICAgICAgICAgICAgICAgICAgICBhcmNoaXZlZEF0OiBuZXcgRGF0ZSgpXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgTG9nZ2VyLmxvZyhlcnIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCd1cGRhdGUtZmFpbGVkJywgJ1dlIGNvdWxkIG5vdCBhcmNoaXZlIHRoZSByZXRybyAtIHBsZWFzZSB0cnkgYWdhaW4gbGF0ZXInKVxuICAgICAgICB9XG4gICAgfVxuXG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IFJldHJvcyB9IGZyb20gJy4vc2VxdWVudCdcbmltcG9ydCB7IFNjaGVtYXMgfSBmcm9tICcuL3NjaGVtYXMnXG5pbXBvcnQgeyBDb25zdGFudHMgfSBmcm9tICcuL2NvbnN0YW50cydcbmltcG9ydCB7IExvZ2dlciB9IGZyb20gJy4vbG9nZ2VyJ1xuXG5NZXRlb3IubWV0aG9kcyh7XG5cbiAgICBjb21wbGV0ZVJldHJvSXRlbShpdGVtSWQpIHtcbiAgICAgICAgY29uc3QgcmV0cm9JZCA9ICcnXG5cbiAgICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWxvZ2dlZC1pbicsICdZb3UgbXVzdCBiZSBsb2dnZWQgaW50byBhIHJldHJvIGJvYXJkIScpXG4gICAgICAgIH1cblxuICAgICAgICAvLyB2YWxpZGF0ZSBpdGVtIHR5cGVcblxuICAgICAgICBjb25zdCByZXRybyA9IFJldHJvcy5maW5kT25lKHtcbiAgICAgICAgICAgIGNyZWF0ZWRCeTogdGhpcy51c2VySWQsXG4gICAgICAgICAgICAkb3I6IFtcbiAgICAgICAgICAgICAgICB7IHN0YXR1czogQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuQUNUSVZFIH0sXG4gICAgICAgICAgICAgICAgeyBzdGF0dXM6IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkZST1pFTiB9XG4gICAgICAgICAgICBdXG4gICAgICAgIH0pXG5cbiAgICAgICAgLy8gbmVlZCB0byBzZWUgaWYgdGhlcmUgaXNcbiAgICAgICAgaWYgKCFyZXRybykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWZvdW5kJywgJ1JldHJvIG5vdCBmb3VuZCEnKVxuICAgICAgICB9XG5cblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgUmV0cm9zLnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIF9pZDogcmV0cm8uX2lkLFxuICAgICAgICAgICAgICAgICAgICAnaXRlbXMuaXRlbUlkJzogaXRlbUlkXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICdpdGVtcy4kLnN0YXR1cyc6IENvbnN0YW50cy5SZXRyb0l0ZW1TdGF0dXNlcy5DT01QTEVURVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKVxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIExvZ2dlci5sb2coZXJyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcigndXBkYXRlLWZhaWxlZCcsICdXZSBjb3VsZCBub3QgY29tcGxldGUgdGhlIHJldHJvIGl0ZW0gLSBwbGVhc2UgdHJ5IGFnYWluIGxhdGVyJylcbiAgICAgICAgfVxuICAgIH1cblxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgZnMgZnJvbSAnZnMnXG5pbXBvcnQgeyBfIH0gZnJvbSAnbWV0ZW9yL3VuZGVyc2NvcmUnXG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICBjb21wb25lbnRJbWFnZXMoKSB7XG4gICAgICAgIGNvbnN0IGltYWdlcyA9IFtdXG5cbiAgICAgICAgY29uc3QgbWV0ZW9yUm9vdCA9IGZzLnJlYWxwYXRoU3luYyhgJHtwcm9jZXNzLmN3ZCgpfS8uLi9gKTtcbiAgICAgICAgY29uc3QgcHVibGljUGF0aCA9IGAke21ldGVvclJvb3R9L3dlYi5icm93c2VyL2FwcC9gO1xuICAgICAgICBjb25zdCBiYWNrZ3JvdW5kUGF0aCA9IGAke3B1YmxpY1BhdGh9L2A7XG4gICAgICAgIGNvbnN0IGJncyA9IGZzLnJlYWRkaXJTeW5jKGJhY2tncm91bmRQYXRoKTtcbiAgICAgICAgY29uc3QgZmlsZXMgPSBiZ3MuZmlsdGVyKGZ1bmN0aW9uIChlbG0pIHsgcmV0dXJuIGVsbS5tYXRjaCgvLipcXC4ocG5nKS9pZyk7IH0pXG5cbiAgICAgICAgXy5lYWNoKGZpbGVzLCBmdW5jdGlvbiAoaW1nKSB7XG4gICAgICAgICAgICBpbWFnZXMucHVzaCh7IGZpbGVOYW1lOiBgLyR7aW1nfWAgfSlcbiAgICAgICAgfSlcblxuICAgICAgICByZXR1cm4gaW1hZ2VzXG4gICAgfVxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBSZXRyb3MsIFJldHJvQWN0aW9ucyB9IGZyb20gJy4vc2VxdWVudCdcbmltcG9ydCB7IFNjaGVtYXMgfSBmcm9tICcuL3NjaGVtYXMnXG5pbXBvcnQgeyBDb25zdGFudHMgfSBmcm9tICcuL2NvbnN0YW50cydcbmltcG9ydCB7IExvZ2dlciB9IGZyb20gJy4vbG9nZ2VyJ1xuXG5NZXRlb3IubWV0aG9kcyh7XG5cbiAgICBjcmVhdGVSZXRyb0FjdGlvbih0aXRsZSkge1xuICAgICAgICBjb25zdCByZXRyb0lkID0gJydcblxuICAgICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtbG9nZ2VkLWluJywgJ1lvdSBtdXN0IGJlIGxvZ2dlZCBpbnRvIGEgcmV0cm8gYm9hcmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGFjdGlvbiA9IHt9XG4gICAgICAgIGFjdGlvbi50aXRsZSA9IHRpdGxlXG4gICAgICAgIGFjdGlvbi5zdGF0dXMgPSBDb25zdGFudHMuUmV0cm9JdGVtU3RhdHVzZXMuUEVORElOR1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBhY3Rpb25JZCA9IFJldHJvQWN0aW9ucy5pbnNlcnQoYWN0aW9uKVxuICAgICAgICAgICAgcmV0dXJuIGFjdGlvbklkXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgTG9nZ2VyLmxvZyhlcnIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdpbnNlcnQtZmFpbGVkJywgJ1dlIGNvdWxkIG5vdCBhZGQgcmV0cm8gaXRlbSB0byB0aGUgcmV0cm8gLSBwbGVhc2UgdHJ5IGFnYWluIGxhdGVyJylcbiAgICAgICAgfVxuICAgIH1cblxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBSYW5kb20gfSBmcm9tICdtZXRlb3IvcmFuZG9tJ1xuaW1wb3J0IHsgXyB9IGZyb20gJ21ldGVvci91bmRlcnNjb3JlJ1xuaW1wb3J0IHsgUmV0cm9zIH0gZnJvbSAnLi9zZXF1ZW50J1xuaW1wb3J0IHsgU2NoZW1hcyB9IGZyb20gJy4vc2NoZW1hcydcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4vY29uc3RhbnRzJ1xuaW1wb3J0IHsgTG9nZ2VyIH0gZnJvbSAnLi4vbGliL2xvZ2dlcidcblxuTWV0ZW9yLm1ldGhvZHMoe1xuXG4gICAgY3JlYXRlUmV0cm9JdGVtKHRpdGxlLCBpdGVtVHlwZSkge1xuICAgICAgICBsZXQgcmV0cm9JZCA9ICcnXG5cbiAgICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWxvZ2dlZC1pbicsICdZb3UgbXVzdCBiZSBsb2dnZWQgaW50byBhIHJldHJvIGJvYXJkIScpXG4gICAgICAgIH1cblxuICAgICAgICAvLyB2YWxpZGF0ZSBpdGVtIHR5cGVcblxuICAgICAgICBsZXQgcmV0cm8gPSBSZXRyb3MuZmluZE9uZSh7XG4gICAgICAgICAgICBjcmVhdGVkQnk6IHRoaXMudXNlcklkLFxuICAgICAgICAgICAgc3RhdHVzOiBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5BQ1RJVkVcbiAgICAgICAgfSlcblxuICAgICAgICAvLyBuZWVkIHRvIHNlZSBpZiB0aGVyZSBpc1xuICAgICAgICBpZiAoIXJldHJvKSB7XG4gICAgICAgICAgICBjb25zdCByZXRyb0RvYyA9IHt9XG4gICAgICAgICAgICByZXRyb0RvYy5zdGF0dXMgPSBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5BQ1RJVkVcbiAgICAgICAgICAgIHJldHJvRG9jLml0ZW1zID0gW11cblxuICAgICAgICAgICAgcmV0cm9JZCA9IFJldHJvcy5pbnNlcnQocmV0cm9Eb2MpXG5cbiAgICAgICAgICAgIHJldHJvID0gUmV0cm9zLmZpbmRPbmUoeyBfaWQ6IHJldHJvSWQgfSlcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHJvSWQgPSByZXRyby5faWRcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGRvYyA9IHt9XG4gICAgICAgIGRvYy5pdGVtSWQgPSBSYW5kb20uaWQoKVxuICAgICAgICBkb2MudGl0bGUgPSB0aXRsZVxuICAgICAgICBkb2MuaXRlbVR5cGUgPSBpdGVtVHlwZVxuICAgICAgICBkb2Muc3RhdHVzID0gQ29uc3RhbnRzLlJldHJvSXRlbVN0YXR1c2VzLlBFTkRJTkdcbiAgICAgICAgZG9jLnZvdGVzID0gMFxuICAgICAgICBkb2MuY3JlYXRlZEF0ID0gbmV3IERhdGUoKVxuXG4gICAgICAgIGlmICghXy5pc0FycmF5KHJldHJvLml0ZW1zKSkge1xuICAgICAgICAgICAgcmV0cm8uaXRlbXMgPSBbXVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gcmV0cm8uaXRlbXMucHVzaChkb2MpXG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIFJldHJvcy51cGRhdGUoXG4gICAgICAgICAgICAgICAgeyBfaWQ6IHJldHJvSWQgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICRwdXNoOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpdGVtczogZG9jXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApXG4gICAgICAgICAgICByZXR1cm4gcmV0cm9JZFxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIExvZ2dlci5sb2coZXJyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignaW5zZXJ0LWZhaWxlZCcsICdXZSBjb3VsZCBub3QgYWRkIHJldHJvIGl0ZW0gdG8gdGhlIHJldHJvIC0gcGxlYXNlIHRyeSBhZ2FpbiBsYXRlcicpXG4gICAgICAgIH1cbiAgICB9XG5cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgUmV0cm9zLCBSZXRyb0FjdGlvbnMgfSBmcm9tICcuL3NlcXVlbnQnXG5pbXBvcnQgeyBTY2hlbWFzIH0gZnJvbSAnLi9zY2hlbWFzJ1xuaW1wb3J0IHsgQ29uc3RhbnRzIH0gZnJvbSAnLi9jb25zdGFudHMnXG5pbXBvcnQgeyBMb2dnZXIgfSBmcm9tICcuL2xvZ2dlcidcblxuTWV0ZW9yLm1ldGhvZHMoe1xuXG4gICAgcmVtb3ZlQWN0aW9uKGFjdGlvbklkKSB7XG4gICAgICAgIGNvbnN0IHJldHJvSWQgPSAnJ1xuXG4gICAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1sb2dnZWQtaW4nLCAnWW91IG11c3QgYmUgbG9nZ2VkIGludG8gYSByZXRybyBib2FyZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgYWN0aW9uID0gUmV0cm9BY3Rpb25zLmZpbmRPbmUoeyBfaWQ6IGFjdGlvbklkLCBjcmVhdGVkQnk6IHRoaXMudXNlcklkIH0pXG5cbiAgICAgICAgaWYgKCFhY3Rpb24pIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1mb3VuZCcsICdBY3Rpb24gbm90IGZvdW5kIScpXG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIFJldHJvQWN0aW9ucy5yZW1vdmUoeyBfaWQ6IGFjdGlvbklkIH0pXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgTG9nZ2VyLmxvZyhlcnIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdkZWxldGUtZmFpbGVkJywgJ1dlIGNvdWxkIG5vdCBkZWxldGUgdGhlIGFjdGlvbiAtIHBsZWFzZSB0cnkgYWdhaW4gbGF0ZXInKVxuICAgICAgICB9XG4gICAgfVxuXG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IF8gfSBmcm9tICdtZXRlb3IvdW5kZXJzY29yZSdcbmltcG9ydCB7IFJldHJvcyB9IGZyb20gJy4vc2VxdWVudCdcbmltcG9ydCB7IFNjaGVtYXMgfSBmcm9tICcuL3NjaGVtYXMnXG5pbXBvcnQgeyBDb25zdGFudHMgfSBmcm9tICcuL2NvbnN0YW50cydcbmltcG9ydCB7IExvZ2dlciB9IGZyb20gJy4vbG9nZ2VyJ1xuXG5NZXRlb3IubWV0aG9kcyh7XG5cbiAgICByZW1vdmVSZXRyb0l0ZW0oaXRlbUlkKSB7XG4gICAgICAgIGNvbnN0IHJldHJvSWQgPSAnJ1xuXG4gICAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1sb2dnZWQtaW4nLCAnWW91IG11c3QgYmUgbG9nZ2VkIGludG8gYSByZXRybyBib2FyZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcmV0cm8gPSBSZXRyb3MuZmluZE9uZSh7XG4gICAgICAgICAgICBjcmVhdGVkQnk6IHRoaXMudXNlcklkLFxuICAgICAgICAgICAgJG9yOiBbXG4gICAgICAgICAgICAgICAgeyBzdGF0dXM6IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkFDVElWRSB9LFxuICAgICAgICAgICAgICAgIHsgc3RhdHVzOiBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5GUk9aRU4gfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgIH0pXG5cbiAgICAgICAgLy8gbmVlZCB0byBzZWUgaWYgdGhlcmUgaXNcbiAgICAgICAgaWYgKCFyZXRybykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWZvdW5kJywgJ1JldHJvIG5vdCBmb3VuZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcmV0cm9JdGVtID0gXy5maWx0ZXIocmV0cm8uaXRlbXMsIGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgICAgICByZXR1cm4gaXRlbS5pdGVtSWQgPT09IGl0ZW1JZFxuICAgICAgICB9KVxuXG4gICAgICAgIGlmIChyZXRyb0l0ZW0ubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtZm91bmQnLCAnUmV0cm8gSXRlbSBub3QgZm91bmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBSZXRyb3MudXBkYXRlKFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgX2lkOiByZXRyby5faWQsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICRwdWxsOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpdGVtczogeyBpdGVtSWQ6IGl0ZW1JZCB9LFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICApXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgTG9nZ2VyLmxvZyhlcnIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCd1cGRhdGUtZmFpbGVkJywgJ1dlIGNvdWxkIG5vdCByZW1vdmUgcmV0cm8gaXRlbSAtIHBsZWFzZSB0cnkgYWdhaW4gbGF0ZXInKVxuICAgICAgICB9XG4gICAgfSxcblxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBSYW5kb20gfSBmcm9tICdtZXRlb3IvcmFuZG9tJ1xuaW1wb3J0IHsgTWF0Y2ggfSBmcm9tICdtZXRlb3IvY2hlY2snXG5pbXBvcnQgeyBTaW1wbGVTY2hlbWEgfSBmcm9tICdtZXRlb3IvYWxkZWVkOnNpbXBsZS1zY2hlbWEnXG5pbXBvcnQgeyBfIH0gZnJvbSAnbWV0ZW9yL3VuZGVyc2NvcmUnXG5pbXBvcnQgeyBTZXR0aW5ncyB9IGZyb20gJy4vc2VxdWVudCdcbmltcG9ydCB7IFNjaGVtYXMgfSBmcm9tICcuL3NjaGVtYXMnXG5pbXBvcnQgeyBMb2dnZXIgfSBmcm9tICcuL2xvZ2dlcidcblxuTWV0ZW9yLm1ldGhvZHMoe1xuXG4gICAgc2F2ZVNldHRpbmdzKGRvYykge1xuICAgICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtbG9nZ2VkLWluJywgJ1lvdSBtdXN0IGJlIGxvZ2dlZCBpbnRvIGEgcmV0cm8gYm9hcmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIFNjaGVtYXMuU2V0dGluZ3MudmFsaWRhdGUoZG9jKVxuXG4gICAgICAgIGNvbnN0IHNldHRpbmdzID0gU2V0dGluZ3MuZmluZE9uZSh7IGNyZWF0ZWRCeTogdGhpcy51c2VySWQgfSlcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgaWYgKF8uaXNVbmRlZmluZWQoc2V0dGluZ3MpKSB7XG4gICAgICAgICAgICAgICAgU2V0dGluZ3MuaW5zZXJ0KGRvYylcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgU2V0dGluZ3MudXBkYXRlKFxuICAgICAgICAgICAgICAgICAgICB7IF9pZDogc2V0dGluZ3MuX2lkIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kSW1hZ2U6IGRvYy5iYWNrZ3JvdW5kSW1hZ2UsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFwcHlQbGFjZWhvbGRlcjogZG9jLmhhcHB5UGxhY2Vob2xkZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVoUGxhY2Vob2xkZXI6IGRvYy5tZWhQbGFjZWhvbGRlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzYWRQbGFjZWhvbGRlcjogZG9jLnNhZFBsYWNlaG9sZGVyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgTG9nZ2VyLmxvZyhlcnIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCd1cGRhdGUtZmFpbGVkJywgJ1dlIGNvdWxkIG5vdCB1cGRhdGUgc2V0dGluZ3MgLSBwbGVhc2UgdHJ5IGFnYWluIGxhdGVyJylcbiAgICAgICAgfVxuICAgIH1cblxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBSYW5kb20gfSBmcm9tICdtZXRlb3IvcmFuZG9tJ1xuaW1wb3J0IHsgUmV0cm9zLCBSZXRyb0FjdGlvbnMgfSBmcm9tICcuLi9saWIvc2VxdWVudCdcbmltcG9ydCB7IFNjaGVtYXMgfSBmcm9tICcuL3NjaGVtYXMnXG5pbXBvcnQgeyBDb25zdGFudHMgfSBmcm9tICcuL2NvbnN0YW50cydcbmltcG9ydCB7IExvZ2dlciB9IGZyb20gJy4vbG9nZ2VyJ1xuXG5NZXRlb3IubWV0aG9kcyh7XG5cbiAgICB0b2dnbGVBY3Rpb24oYWN0aW9uSWQpIHtcbiAgICAgICAgY29uc3QgcmV0cm9JZCA9ICcnXG5cbiAgICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWxvZ2dlZC1pbicsICdZb3UgbXVzdCBiZSBsb2dnZWQgaW50byBhIHJldHJvIGJvYXJkIScpXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBhY3Rpb24gPSBSZXRyb0FjdGlvbnMuZmluZE9uZSh7IF9pZDogYWN0aW9uSWQsIGNyZWF0ZWRCeTogdGhpcy51c2VySWQgfSlcblxuICAgICAgICBpZiAoIWFjdGlvbikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWZvdW5kJywgJ1JldHJvQWN0aW9uIG5vdCBmb3VuZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgbmV3VmFsdWUgPSBhY3Rpb24uc3RhdHVzID09PSBDb25zdGFudHMuUmV0cm9JdGVtU3RhdHVzZXMuUEVORElORyA/IENvbnN0YW50cy5SZXRyb0l0ZW1TdGF0dXNlcy5DT01QTEVURSA6IENvbnN0YW50cy5SZXRyb0l0ZW1TdGF0dXNlcy5QRU5ESU5HXG5cbiAgICAgICAgbGV0IG5ld0RhdGVcblxuICAgICAgICBpZiAobmV3VmFsdWUgPT09IENvbnN0YW50cy5SZXRyb0l0ZW1TdGF0dXNlcy5DT01QTEVURSkge1xuICAgICAgICAgICAgbmV3RGF0ZSA9IG5ldyBEYXRlKClcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG5ld0RhdGUgPSBudWxsXG4gICAgICAgIH1cblxuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBSZXRyb0FjdGlvbnMudXBkYXRlKFxuICAgICAgICAgICAgICAgIHsgX2lkOiBhY3Rpb25JZCB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgJHNldDpcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBuZXdWYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbXBsZXRlZEF0OiBuZXdEYXRlXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgTG9nZ2VyLmxvZyhlcnIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdkZWxldGUtZmFpbGVkJywgJ1dlIGNvdWxkIG5vdCBkZWxldGUgdGhlIGFjdGlvbiAtIHBsZWFzZSB0cnkgYWdhaW4gbGF0ZXInKVxuICAgICAgICB9XG4gICAgfVxuXG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IFJldHJvcywgUmV0cm9BY3Rpb25zIH0gZnJvbSAnLi9zZXF1ZW50J1xuaW1wb3J0IHsgU2NoZW1hcyB9IGZyb20gJy4vc2NoZW1hcydcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4vY29uc3RhbnRzJ1xuaW1wb3J0IHsgTG9nZ2VyIH0gZnJvbSAnLi9sb2dnZXInXG5cbk1ldGVvci5tZXRob2RzKHtcblxuICAgIHRvZ2dsZVJldHJvRnJvemVuKCkge1xuICAgICAgICBjb25zdCByZXRyb0lkID0gJydcblxuICAgICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtbG9nZ2VkLWluJywgJ1lvdSBtdXN0IGJlIGxvZ2dlZCBpbnRvIGEgcmV0cm8gYm9hcmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHZhbGlkYXRlIGl0ZW0gdHlwZVxuXG4gICAgICAgIGNvbnN0IHJldHJvID0gUmV0cm9zLmZpbmRPbmUoe1xuICAgICAgICAgICAgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCxcbiAgICAgICAgICAgICRvcjpcbiAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICB7IHN0YXR1czogQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuQUNUSVZFIH0sXG4gICAgICAgICAgICAgICAgeyBzdGF0dXM6IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkZST1pFTiB9XG4gICAgICAgICAgICBdXG4gICAgICAgIH0pXG5cbiAgICAgICAgLy8gbmVlZCB0byBzZWUgaWYgdGhlcmUgaXNcbiAgICAgICAgaWYgKCFyZXRybykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWZvdW5kJywgJ1JldHJvIG5vdCBmb3VuZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHJldHJvLnN0YXR1cyA9PT0gQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuQVJDSElWRUQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ2ludmFsaWQtc3RhdGUnLCAnUmV0cm8gbXVzdCBub3QgYmUgYXJjaGl2ZWQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IG5ld1N0YXR1cyA9IHJldHJvLnN0YXR1cyA9PT0gQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuRlJPWkVOID8gQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuQUNUSVZFIDogQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuRlJPWkVOXG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIFJldHJvcy51cGRhdGUoXG4gICAgICAgICAgICAgICAgeyBfaWQ6IHJldHJvLl9pZCB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgJHNldDpcbiAgICAgICAgICAgICAgICAgICAgeyBzdGF0dXM6IG5ld1N0YXR1cyB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKVxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIExvZ2dlci5sb2coZXJyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcigndXBkYXRlLWZhaWxlZCcsICdXZSBjb3VsZCBub3QgZnJlZXplIHRoZSByZXRybyAtIHBsZWFzZSB0cnkgYWdhaW4gbGF0ZXInKVxuICAgICAgICB9XG4gICAgfVxuXG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IFJldHJvcywgUmV0cm9BY3Rpb25zIH0gZnJvbSAnLi9zZXF1ZW50J1xuaW1wb3J0IHsgU2NoZW1hcyB9IGZyb20gJy4vc2NoZW1hcydcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4vY29uc3RhbnRzJ1xuaW1wb3J0IHsgTG9nZ2VyIH0gZnJvbSAnLi9sb2dnZXInXG5cbk1ldGVvci5tZXRob2RzKHtcblxuICAgIHRvZ2dsZVNob3dDb21wbGV0ZWQoKSB7XG4gICAgICAgIGNvbnN0IHJldHJvSWQgPSAnJ1xuXG4gICAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1sb2dnZWQtaW4nLCAnWW91IG11c3QgYmUgbG9nZ2VkIGludG8gYSByZXRybyBib2FyZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcmV0cm8gPSBSZXRyb3MuZmluZE9uZSh7XG4gICAgICAgICAgICBjcmVhdGVkQnk6IHRoaXMudXNlcklkLFxuICAgICAgICAgICAgJG9yOlxuICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgIHsgc3RhdHVzOiBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5BQ1RJVkUgfSxcbiAgICAgICAgICAgICAgICB7IHN0YXR1czogQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuRlJPWkVOIH1cbiAgICAgICAgICAgIF1cbiAgICAgICAgfSlcblxuICAgICAgICAvLyBuZWVkIHRvIHNlZSBpZiB0aGVyZSBpc1xuICAgICAgICBpZiAoIXJldHJvKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtZm91bmQnLCAnUmV0cm8gbm90IGZvdW5kIScpXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBzaG93ID0gIXJldHJvLnNob3dDb21wbGV0ZWRcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgUmV0cm9zLnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIF9pZDogcmV0cm8uX2lkXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICRzZXQ6XG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3dDb21wbGV0ZWQ6IHNob3dcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIClcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBMb2dnZXIubG9nKGVycilcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ3VwZGF0ZS1mYWlsZWQnLCAnV2UgY291bGQgdG9nZ2xlIHJldHJvIHNob3cgY29tcGxldGVkIC0gcGxlYXNlIHRyeSBhZ2FpbiBsYXRlcicpXG4gICAgICAgIH1cbiAgICB9XG5cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgXyB9IGZyb20gJ21ldGVvci91bmRlcnNjb3JlJ1xuaW1wb3J0IHsgUmV0cm9zIH0gZnJvbSAnLi9zZXF1ZW50J1xuaW1wb3J0IHsgU2NoZW1hcyB9IGZyb20gJy4vc2NoZW1hcydcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4vY29uc3RhbnRzJ1xuaW1wb3J0IHsgTG9nZ2VyIH0gZnJvbSAnLi9sb2dnZXInXG5cbk1ldGVvci5tZXRob2RzKHtcblxuICAgIHVwVm90ZUl0ZW0oaXRlbUlkKSB7XG4gICAgICAgIGNvbnN0IHJldHJvSWQgPSAnJ1xuXG4gICAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1sb2dnZWQtaW4nLCAnWW91IG11c3QgYmUgbG9nZ2VkIGludG8gYSByZXRybyBib2FyZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gdmFsaWRhdGUgaXRlbSB0eXBlXG5cbiAgICAgICAgY29uc3QgcmV0cm8gPSBSZXRyb3MuZmluZE9uZSh7XG4gICAgICAgICAgICBjcmVhdGVkQnk6IHRoaXMudXNlcklkLFxuICAgICAgICAgICAgc3RhdHVzOiBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5BQ1RJVkVcbiAgICAgICAgfSlcblxuICAgICAgICAvLyBuZWVkIHRvIHNlZSBpZiB0aGVyZSBpc1xuICAgICAgICBpZiAoIXJldHJvKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtZm91bmQnLCAnUmV0cm8gbm90IGZvdW5kIScpXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCByZXRyb0l0ZW0gPSBfLmZpbHRlcihyZXRyby5pdGVtcywgZnVuY3Rpb24gKGl0ZW0pIHtcbiAgICAgICAgICAgIHJldHVybiBpdGVtLml0ZW1JZCA9PT0gaXRlbUlkXG4gICAgICAgIH0pXG5cbiAgICAgICAgaWYgKHJldHJvSXRlbS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1mb3VuZCcsICdSZXRybyBJdGVtIG5vdCBmb3VuZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgbGV0IHZvdGVDb3VudCA9IHJldHJvSXRlbVswXS52b3RlcyB8fCAwXG5cbiAgICAgICAgdm90ZUNvdW50ICs9IDFcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgUmV0cm9zLnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIF9pZDogcmV0cm8uX2lkLFxuICAgICAgICAgICAgICAgICAgICAnaXRlbXMuaXRlbUlkJzogaXRlbUlkXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICdpdGVtcy4kLnZvdGVzJzogdm90ZUNvdW50XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgTG9nZ2VyLmxvZyhlcnIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCd1cGRhdGUtZmFpbGVkJywgJ1dlIGNvdWxkIG5vdCB1cHZvdGUgdGhpcyBpdGVtIC0gcGxlYXNlIHRyeSBhZ2FpbiBsYXRlcicpXG4gICAgICAgIH1cbiAgICB9XG5cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgUmV0cm9zLCBSZXRyb0FjdGlvbnMgfSBmcm9tICcuLi9saWIvc2VxdWVudCdcbmltcG9ydCB7IFNjaGVtYXMgfSBmcm9tICcuL3NjaGVtYXMnXG5pbXBvcnQgeyBDb25zdGFudHMgfSBmcm9tICcuL2NvbnN0YW50cydcbmltcG9ydCB7IExvZ2dlciB9IGZyb20gJy4vbG9nZ2VyJ1xuXG5NZXRlb3IubWV0aG9kcyh7XG5cbiAgICB1cGRhdGVBY3Rpb25UaXRsZShhY3Rpb25JZCwgdGl0bGUpIHtcbiAgICAgICAgY29uc3QgcmV0cm9JZCA9ICcnXG5cbiAgICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWxvZ2dlZC1pbicsICdZb3UgbXVzdCBiZSBsb2dnZWQgaW50byBhIHJldHJvIGJvYXJkIScpXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBhY3Rpb24gPSBSZXRyb0FjdGlvbnMuZmluZE9uZSh7IF9pZDogYWN0aW9uSWQsIGNyZWF0ZWRCeTogdGhpcy51c2VySWQgfSlcblxuICAgICAgICBpZiAoIWFjdGlvbikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWZvdW5kJywgJ1JldHJvQWN0aW9uIG5vdCBmb3VuZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIFJldHJvQWN0aW9ucy51cGRhdGUoXG4gICAgICAgICAgICAgICAgeyBfaWQ6IGFjdGlvbklkIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAkc2V0OlxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogdGl0bGVcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIClcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBMb2dnZXIubG9nKGVycilcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ2RlbGV0ZS1mYWlsZWQnLCAnV2UgY291bGQgbm90IGRlbGV0ZSB0aGUgYWN0aW9uIC0gcGxlYXNlIHRyeSBhZ2FpbiBsYXRlcicpXG4gICAgICAgIH1cbiAgICB9XG5cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgXyB9IGZyb20gJ21ldGVvci91bmRlcnNjb3JlJ1xuaW1wb3J0IHsgUmV0cm9zIH0gZnJvbSAnLi9zZXF1ZW50J1xuaW1wb3J0IHsgU2NoZW1hcyB9IGZyb20gJy4vc2NoZW1hcydcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4vY29uc3RhbnRzJ1xuaW1wb3J0IHsgTG9nZ2VyIH0gZnJvbSAnLi9sb2dnZXInXG5cbk1ldGVvci5tZXRob2RzKHtcblxuICAgIHVwZGF0ZVJldHJvSXRlbVRpdGxlKGl0ZW1JZCwgdGl0bGUpIHtcbiAgICAgICAgY29uc3QgcmV0cm9JZCA9ICcnXG5cbiAgICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWxvZ2dlZC1pbicsICdZb3UgbXVzdCBiZSBsb2dnZWQgaW50byBhIHJldHJvIGJvYXJkIScpXG4gICAgICAgIH1cblxuICAgICAgICAvLyB2YWxpZGF0ZSBpdGVtIHR5cGVcblxuICAgICAgICBjb25zdCByZXRybyA9IFJldHJvcy5maW5kT25lKHtcbiAgICAgICAgICAgIGNyZWF0ZWRCeTogdGhpcy51c2VySWQsXG4gICAgICAgICAgICBzdGF0dXM6IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkFDVElWRVxuICAgICAgICB9KVxuXG4gICAgICAgIC8vIG5lZWQgdG8gc2VlIGlmIHRoZXJlIGlzXG4gICAgICAgIGlmICghcmV0cm8pIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1mb3VuZCcsICdSZXRybyBub3QgZm91bmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHJldHJvSXRlbSA9IF8uZmlsdGVyKHJldHJvLml0ZW1zLCBmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgICAgICAgcmV0dXJuIGl0ZW0uaXRlbUlkID09PSBpdGVtSWRcbiAgICAgICAgfSlcblxuICAgICAgICBpZiAocmV0cm9JdGVtLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWZvdW5kJywgJ1JldHJvIEl0ZW0gbm90IGZvdW5kIScpXG4gICAgICAgIH1cblxuICAgICAgICBsZXQgdm90ZUNvdW50ID0gcmV0cm9JdGVtWzBdLnZvdGVzIHx8IDBcblxuICAgICAgICB2b3RlQ291bnQgKz0gMVxuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBSZXRyb3MudXBkYXRlKFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgX2lkOiByZXRyby5faWQsXG4gICAgICAgICAgICAgICAgICAgICdpdGVtcy5pdGVtSWQnOiBpdGVtSWRcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgJHNldDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgJ2l0ZW1zLiQudGl0bGUnOiB0aXRsZVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKVxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIExvZ2dlci5sb2coZXJyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcigndXBkYXRlLWZhaWxlZCcsICdXZSBjb3VsZCBub3QgdXBkYXRlIHRoZSByZXRybyBpdGVtIC0gcGxlYXNlIHRyeSBhZ2FpbiBsYXRlcicpXG4gICAgICAgIH1cbiAgICB9XG5cbn0pXG4iLCJcbmltcG9ydCB7IFNpbXBsZVNjaGVtYSB9IGZyb20gJ21ldGVvci9hbGRlZWQ6c2ltcGxlLXNjaGVtYSdcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4vY29uc3RhbnRzJ1xuXG5jb25zdCBTY2hlbWFzID0ge31cblxuU2NoZW1hcy5SZXRyb0l0ZW0gPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICBcbiAgICBpdGVtSWQ6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICByZWdFeDogU2ltcGxlU2NoZW1hLlJlZ0V4LklkLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0sXG4gICAgdGl0bGU6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBtYXg6IDI1NVxuICAgIH0sXG4gICAgc3RhdHVzOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgYWxsb3dlZFZhbHVlczogQ29uc3RhbnRzLlJldHJvSXRlbVN0YXR1c2VzLnZhbHVlc1xuICAgIH0sXG4gICAgaXRlbVR5cGU6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBDb25zdGFudHMuUmV0cm9JdGVtVHlwZXMudmFsdWVzXG4gICAgfSxcbiAgICB2b3Rlczoge1xuICAgICAgICB0eXBlOiBOdW1iZXIsXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSxcbiAgICBjcmVhdGVkQXQ6IHtcbiAgICAgICAgdHlwZTogRGF0ZVxuICAgIH1cbiAgICBcbn0pXG5cblNjaGVtYXMuUmV0cm9zID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgXG4gICAgX2lkOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgcmVnRXg6IFNpbXBsZVNjaGVtYS5SZWdFeC5JZCxcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9LFxuICAgIGNyZWF0ZWRBdDoge1xuICAgICAgICB0eXBlOiBEYXRlLCAgIFxuICAgICAgICBhdXRvVmFsdWU6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgaWYgKCB0aGlzLmlzSW5zZXJ0ICkge1xuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgRGF0ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMudW5zZXQoKVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcbiAgICBjcmVhdGVkQnk6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICByZWdFeDogU2ltcGxlU2NoZW1hLlJlZ0V4LklkLFxuICAgICAgICBhdXRvVmFsdWU6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgaWYgKCB0aGlzLmlzSW5zZXJ0ICkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnVzZXJJZDtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy51bnNldCgpXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LFxuICAgIHN0YXR1czoge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLnZhbHVlc1xuICAgIH0sXG4gICAgaXRlbXM6IHtcbiAgICAgICAgdHlwZTogW1NjaGVtYXMuUmV0cm9JdGVtXVxuICAgIH0sXG4gICAgc2hvd0NvbXBsZXRlZDoge1xuICAgICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcbiAgICAgICAgZGVmYXVsdFZhbHVlOiBmYWxzZVxuICAgIH0sXG4gICAgYXJjaGl2ZWRBdDoge1xuICAgICAgICB0eXBlOiBEYXRlLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH1cbn0pXG5cblNjaGVtYXMuQWN0aW9ucyA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgIF9pZDoge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIHJlZ0V4OiBTaW1wbGVTY2hlbWEuUmVnRXguSWQsXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSxcbiAgICBjcmVhdGVkQXQ6IHtcbiAgICAgICAgdHlwZTogRGF0ZSwgICBcbiAgICAgICAgYXV0b1ZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIGlmICggdGhpcy5pc0luc2VydCApIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gbmV3IERhdGU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aGlzLnVuc2V0KClcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sXG4gICAgY3JlYXRlZEJ5OiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgcmVnRXg6IFNpbXBsZVNjaGVtYS5SZWdFeC5JZCxcbiAgICAgICAgYXV0b1ZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIGlmICggdGhpcy5pc0luc2VydCApIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy51c2VySWQ7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMudW5zZXQoKVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcbiAgICB0aXRsZToge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIG1heDogMjU1XG4gICAgfSxcbiAgICBzdGF0dXM6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBDb25zdGFudHMuUmV0cm9JdGVtU3RhdHVzZXMudmFsdWVzXG4gICAgfSxcbiAgICBjb21wbGV0ZWRBdDoge1xuICAgICAgICB0eXBlOiBEYXRlLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH1cbn0pXG5cblNjaGVtYXMuTmV3VGVhbSA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgIG5hbWU6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBtYXg6IDYwLFxuICAgICAgICBtaW46IDVcbiAgICB9LFxuICAgIGRlc2NyaXB0aW9uOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgb3B0aW9uYWw6IHRydWUsXG4gICAgICAgIG1heDogMjU1XG4gICAgfSxcbiAgICBwYXNzd29yZDoge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIHJlZ0V4OiAvXig/PS4qW2Etel0pKD89LipbQS1aXSkoPz0uKlxcZClbYS16QS1aXFxkXXs4LH0kLyxcbiAgICAgICAgbWluOiA4LFxuICAgIH0sXG4gICAgY29uZmlybVBhc3N3b3JkOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgbWluOiA4LFxuICAgICAgICBjdXN0b20oKSB7XG4gICAgICAgICAgICBpZiAodGhpcy52YWx1ZSAhPT0gdGhpcy5maWVsZCgncGFzc3dvcmQnKS52YWx1ZSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBcInBhc3N3b3JkTWlzbWF0Y2hcIjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn0pXG5cblNjaGVtYXMuU2V0dGluZ3MgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICBfaWQ6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICByZWdFeDogU2ltcGxlU2NoZW1hLlJlZ0V4LklkLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0sXG4gICAgY3JlYXRlZEJ5OiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgcmVnRXg6IFNpbXBsZVNjaGVtYS5SZWdFeC5JZCxcbiAgICAgICAgYXV0b1ZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIGlmICggdGhpcy5pc0luc2VydCApIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy51c2VySWQ7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMudW5zZXQoKVxuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0sXG4gICAgYmFja2dyb3VuZEltYWdlOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgZGVmYXVsdFZhbHVlOiAnL2JhY2tncm91bmRzL3RyaWFuZ2xlcy5wbmcnLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0sXG4gICAgaGFwcHlQbGFjZWhvbGRlcjoge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIGRlZmF1bHRWYWx1ZTogJzopJyxcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9LFxuICAgIG1laFBsYWNlaG9sZGVyOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgZGVmYXVsdFZhbHVlOiAnOnwnLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0sXG4gICAgc2FkUGxhY2Vob2xkZXI6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBkZWZhdWx0VmFsdWU6ICc6KCcsXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfVxuXG59KVxuXG5tb2R1bGUuZXhwb3J0cyA9IHsgU2NoZW1hcyB9XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbydcbmltcG9ydCB7IFNjaGVtYXMgfSBmcm9tICcuL3NjaGVtYXMnXG5cbmNvbnN0IFNlcXVlbnQgPSB7XG4gICAgYXJjaGl2ZVJvdXRlTmFtZTogJ2FyY2hpdmVzJyxcbiAgICBkZWZhdWx0QmFja2dyb3VuZDogJy9iYWNrZ3JvdW5kcy90cmlhbmdsZXMucG5nJyxcbiAgICBkZWZhdWx0Q29uZmlybU1zZzogJ0FyZSB5b3Ugc3VyZT8nLFxuXG4gICAgZ2V0U2V0dGluZ3MoKXtcblxuICAgICAgICBsZXQgc2V0dGluZ3MgPSBTZXR0aW5ncy5maW5kT25lKClcbiAgICBcbiAgICAgICAgaWYgKCFzZXR0aW5ncyl7XG4gICAgICAgICAgICBzZXR0aW5ncyA9IHt9XG4gICAgICAgICAgICBzZXR0aW5ncy5iYWNrZ3JvdW5kSW1hZ2UgPSBTZXF1ZW50LmRlZmF1bHRCYWNrZ3JvdW5kXG4gICAgICAgICAgICBzZXR0aW5ncy5oYXBweVBsYWNlaG9sZGVyID0gJzopJ1xuICAgICAgICAgICAgc2V0dGluZ3MubWVoUGxhY2Vob2xkZXIgPSAnOnwnXG4gICAgICAgICAgICBzZXR0aW5ncy5zYWRQbGFjZWhvbGRlciA9ICc6KCdcbiAgICAgICAgfSBcbiAgICBcbiAgICAgICAgcmV0dXJuIHNldHRpbmdzXG4gICAgfVxufVxuXG5pZiAoIVN0cmluZy5wcm90b3R5cGUudG9Qcm9wZXJDYXNlKSB7XG4gICAgU3RyaW5nLnByb3RvdHlwZS50b1Byb3BlckNhc2UgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJlcGxhY2UoL1xcd1xcUyovZywgZnVuY3Rpb24odHh0KXtyZXR1cm4gdHh0LmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgdHh0LnN1YnN0cigxKS50b0xvd2VyQ2FzZSgpO30pO1xuICAgIH07XG59XG5cbmNvbnN0IFJldHJvcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdyZXRyb3MnKVxuY29uc3QgUmV0cm9BY3Rpb25zID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3JldHJvLWFjdGlvbnMnKVxuY29uc3QgQmFja2dyb3VuZHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignYmFja2dyb3VuZHMnKVxuY29uc3QgU2V0dGluZ3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignc2V0dGluZ3MnKVxuXG5SZXRyb3MuYXR0YWNoU2NoZW1hKFNjaGVtYXMuUmV0cm9zKVxuUmV0cm9BY3Rpb25zLmF0dGFjaFNjaGVtYShTY2hlbWFzLkFjdGlvbnMpXG5TZXR0aW5ncy5hdHRhY2hTY2hlbWEoU2NoZW1hcy5TZXR0aW5ncylcblxubW9kdWxlLmV4cG9ydHMgPSB7IFNlcXVlbnQsIFJldHJvcywgUmV0cm9BY3Rpb25zLCBCYWNrZ3JvdW5kcywgU2V0dGluZ3MgfVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCB7IF8gfSBmcm9tICdtZXRlb3IvdW5kZXJzY29yZSdcbmltcG9ydCB7IEJhY2tncm91bmRzIH0gZnJvbSAnLi4vbGliL3NlcXVlbnQnXG5cbk1ldGVvci5wdWJsaXNoKCdiYWNrZ3JvdW5kcycsIGZ1bmN0aW9uICgpIHtcbiAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICBjb25zdCBtZXRlb3JSb290ID0gZnMucmVhbHBhdGhTeW5jKGAke3Byb2Nlc3MuY3dkKCl9Ly4uL2ApO1xuICAgIGNvbnN0IHB1YmxpY1BhdGggPSBgJHttZXRlb3JSb290fS93ZWIuYnJvd3Nlci9hcHAvYDtcbiAgICBjb25zdCBiYWNrZ3JvdW5kUGF0aCA9IGAke3B1YmxpY1BhdGh9L2JhY2tncm91bmRzL2A7XG4gICAgY29uc3QgYmdzID0gZnMucmVhZGRpclN5bmMoYmFja2dyb3VuZFBhdGgpO1xuICAgIF8uZWFjaChiZ3MsIGZ1bmN0aW9uIChiYWNrZ3JvdW5kKSB7XG4gICAgICAgIGNvbnN0IGJhY2tncm91bmROYW1lID0gYmFja2dyb3VuZC5zcGxpdCgnLicpWzBdLnRvUHJvcGVyQ2FzZSgpXG4gICAgICAgIHNlbGYuYWRkZWQoJ2JhY2tncm91bmRzJywgYmFja2dyb3VuZCwgeyBuYW1lOiBiYWNrZ3JvdW5kTmFtZSwgdmFsdWU6IGAvYmFja2dyb3VuZHMvJHtiYWNrZ3JvdW5kfWAgfSk7XG4gICAgfSlcbiAgICB0aGlzLnJlYWR5KCk7XG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBTZXF1ZW50LCBSZXRyb0FjdGlvbnMgfSBmcm9tICcuLi9saWIvc2VxdWVudCdcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4uL2xpYi9jb25zdGFudHMnXG5cblJldHJvQWN0aW9ucy5fZW5zdXJlSW5kZXgoJ2NyZWF0ZWRCeScsIDEpXG5SZXRyb0FjdGlvbnMuX2Vuc3VyZUluZGV4KCdzdGF0dXMnLCAxKVxuUmV0cm9BY3Rpb25zLl9lbnN1cmVJbmRleCgnY3JlYXRlZEF0JywgMSlcblxuXG5NZXRlb3IucHVibGlzaCgnb3Blbi1hY3Rpb25zJywgZnVuY3Rpb24oKSB7XG4gICAgXG4gICAgaWYoIU1ldGVvci51c2VySWQoKSkge1xuICAgICAgICByZXR1cm4gbnVsbFxuICAgIH1cbiAgICBcbiAgICByZXR1cm4gUmV0cm9BY3Rpb25zLmZpbmQoXG4gICAgeyBcbiAgICAgICAgY3JlYXRlZEJ5OiBNZXRlb3IudXNlcklkKCksIFxuICAgICAgICAkb3I6IFsgXG4gICAgICAgICAgICB7IHN0YXR1czogQ29uc3RhbnRzLlJldHJvSXRlbVN0YXR1c2VzLlBFTkRJTkcgfSwgXG4gICAgICAgICAgICB7IFxuICAgICAgICAgICAgICBzdGF0dXM6IENvbnN0YW50cy5SZXRyb0l0ZW1TdGF0dXNlcy5DT01QTEVURSwgXG4gICAgICAgICAgICAgIGNvbXBsZXRlZEF0OiB7ICRndDogbmV3IERhdGUoRGF0ZS5ub3coKSAtIDI0KjYwKjYwICogMTAwMCl9XG4gICAgICAgICAgICB9XG4gICAgICAgIF0gXG4gICAgfSlcbiAgICBcbn0pO1xuXG4vKlxubWVzc2FnZXMuZmluZCh7J21ldGFkYXRhLnRocmVhZCc6IHRocmVhZElkfSwgXG4gIHtcbiAgICBzb3J0OiB7J2RhdGUnIDogc29ydH0sIFxuICAgIGxpbWl0OiBsaW1pdCxcbiAgICBkaXNhYmxlT3Bsb2c6IHRydWUsIFxuICAgIHBvbGxpbmdUaHJvdHRsZU1zOiAxMjAwMCwgXG4gICAgcG9sbGluZ0ludGVydmFsTXM6IDEyMDAwXG4gIH1cbik7XG4qLyIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBSZXRyb3MgfSBmcm9tICcuLi9saWIvc2VxdWVudCdcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4uL2xpYi9jb25zdGFudHMnXG5cblJldHJvcy5fZW5zdXJlSW5kZXgoJ2NyZWF0ZWRCeScsIDEpXG5SZXRyb3MuX2Vuc3VyZUluZGV4KCdzdGF0dXMnLCAxKVxuXG5NZXRlb3IucHVibGlzaCgnYWN0aXZlLXJldHJvcycsIGZ1bmN0aW9uKCkge1xuICAgIFxuICAgIGlmKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICByZXR1cm4gbnVsbFxuICAgIH1cbiAgICBcbiAgICByZXR1cm4gUmV0cm9zLmZpbmQoeyBcbiAgICAgICAgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCwgXG4gICAgICAgIHN0YXR1czogeyBcbiAgICAgICAgICAgICRpbjogWyBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5BQ1RJVkUsIENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkZST1pFTiBdXG4gICAgICAgIH1cbiAgICB9KVxuICAgIFxufSk7XG5cbk1ldGVvci5wdWJsaXNoKCdhcmNoaXZlZC1yZXRyb3MnLCBmdW5jdGlvbigpIHtcbiAgICBcbiAgICBpZighdGhpcy51c2VySWQpIHtcbiAgICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG5cbiAgICByZXR1cm4gUmV0cm9zLmZpbmQoeyBjcmVhdGVkQnk6IHRoaXMudXNlcklkLCBzdGF0dXM6IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkFSQ0hJVkVEfSlcbiBcbn0pO1xuXG5NZXRlb3IucHVibGlzaCgnc2luZ2xlLWFyY2hpdmVkLXJldHJvJywgZnVuY3Rpb24ocmV0cm9JZCkge1xuICAgIFxuICAgIGlmKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICByZXR1cm4gbnVsbFxuICAgIH1cblxuICAgIHJldHVybiBSZXRyb3MuZmluZCh7IF9pZDogcmV0cm9JZCwgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCwgc3RhdHVzOiBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5BUkNISVZFRH0pXG4gXG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBTZXR0aW5ncyB9IGZyb20gJy4uL2xpYi9zZXF1ZW50J1xuXG5TZXR0aW5ncy5fZW5zdXJlSW5kZXgoJ2NyZWF0ZWRCeScsIDEpXG5cbk1ldGVvci5wdWJsaXNoKCdzZXR0aW5ncycsIGZ1bmN0aW9uKCkge1xuICAgIFxuICAgIGlmKCFNZXRlb3IudXNlcklkKCkpIHtcbiAgICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG4gICAgXG4gICAgcmV0dXJuIFNldHRpbmdzLmZpbmQoeyBjcmVhdGVkQnk6IE1ldGVvci51c2VySWQoKSB9KVxuICAgIFxufSk7XG4gIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5cbk1ldGVvci5zdGFydHVwKCgpID0+IHtcbiAgLy8gY29kZSB0byBydW4gb24gc2VydmVyIGF0IHN0YXJ0dXBcbn0pO1xuIiwiaW1wb3J0IHsgXyB9IGZyb20gJ21ldGVvci91bmRlcnNjb3JlJztcbmltcG9ydCB7IFRlbXBsYXRlIH0gZnJvbSAnbWV0ZW9yL3RlbXBsYXRpbmcnO1xuaW1wb3J0IHsgQmxhemUgfSBmcm9tICdtZXRlb3IvYmxhemUnO1xuaW1wb3J0IHsgVHJhY2tlciB9IGZyb20gJ21ldGVvci90cmFja2VyJztcblxuY29uc3Qgd2l0aERpdiA9IGZ1bmN0aW9uIHdpdGhEaXYoY2FsbGJhY2spIHtcbiAgICBjb25zdCBlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZWwpO1xuICAgIFxuICAgIHRyeSB7XG4gICAgICAgIGNhbGxiYWNrKGVsKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGVsKTtcbiAgICB9XG59O1xuXG5leHBvcnQgY29uc3Qgd2l0aFJlbmRlcmVkVGVtcGxhdGUgPSBmdW5jdGlvbiB3aXRoUmVuZGVyZWRUZW1wbGF0ZSh0ZW1wbGF0ZSwgZGF0YSwgY2FsbGJhY2spIHtcbiAgICB3aXRoRGl2KChlbCkgPT4ge1xuICAgICAgICBjb25zdCB0aGVUZW1wbGF0ZSA9IF8uaXNTdHJpbmcodGVtcGxhdGUpID8gVGVtcGxhdGVbdGVtcGxhdGVdIDogdGVtcGxhdGU7XG4gICAgICAgIEJsYXplLnJlbmRlcldpdGhEYXRhKHRoZVRlbXBsYXRlLCBkYXRhLCBlbCk7XG4gICAgICAgIFRyYWNrZXIuZmx1c2goKTtcbiAgICAgICAgY2FsbGJhY2soZWwsIHRoZVRlbXBsYXRlKTtcbiAgICB9KTtcbn07IiwiLyogZ2xvYmFsIG1vbWVudCAqL1xuXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgUmFuZG9tIH0gZnJvbSAnbWV0ZW9yL3JhbmRvbSdcbmltcG9ydCB7IF8gfSBmcm9tICdtZXRlb3IvdW5kZXJzY29yZSdcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4uL2xpYi9jb25zdGFudHMnXG5cbmNvbnN0IGZha2VyID0gTWV0ZW9yLmlzVGVzdCAmJiByZXF1aXJlKCdmYWtlcicpIC8vIGVzbGludC1kaXNhYmxlLWxpbmUgZ2xvYmFsLXJlcXVpcmVcblxuY29uc3QgVGVzdERhdGEgPSB7XG5cbiAgICBmYWtlU2V0dGluZ3MocGFyYW1ldGVycykge1xuICAgICAgICBsZXQgcGFybXMgPSB7fVxuXG4gICAgICAgIGlmICghXy5pc1VuZGVmaW5lZChwYXJhbWV0ZXJzKSkge1xuICAgICAgICAgICAgcGFybXMgPSBwYXJhbWV0ZXJzO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgU2V0dGluZ3MgPSB7fVxuICAgICAgICBTZXR0aW5ncy5iYWNrZ3JvdW5kSW1hZ2UgPSAnL2Zha2VPbmUuanBnJ1xuICAgICAgICBTZXR0aW5ncy5oYXBweVBsYWNlaG9sZGVyID0gJ0Zha2UgaGFwcHkgcGxhY2Vob2xkZXInXG4gICAgICAgIFNldHRpbmdzLm1laFBsYWNlaG9sZGVyID0gJ0Zha2UgbWVoIHBsYWNlaG9sZGVyJ1xuICAgICAgICBTZXR0aW5ncy5zYWRQbGFjZWhvbGRlciA9ICdGYWtlIHNhZCBwbGFjZWhvbGRlcidcblxuICAgICAgICByZXR1cm4gU2V0dGluZ3NcbiAgICB9LFxuICAgIGZha2VCYWNrZ3JvdW5kc0FycmF5KHBhcmFtZXRlcnMpIHtcbiAgICAgICAgbGV0IHBhcm1zID0ge31cblxuICAgICAgICBpZiAoIV8uaXNVbmRlZmluZWQocGFyYW1ldGVycykpIHtcbiAgICAgICAgICAgIHBhcm1zID0gcGFyYW1ldGVycztcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IEJhY2tncm91bmRzID0gW11cblxuICAgICAgICBCYWNrZ3JvdW5kcy5wdXNoKHsgbmFtZTogJ2Zha2VPbmUnLCB2YWx1ZTogJy9mYWtlT25lLmpwZycgfSlcbiAgICAgICAgQmFja2dyb3VuZHMucHVzaCh7IG5hbWU6ICdmYWtlVHdvJywgdmFsdWU6ICcvZmFrZVR3by5qcGcnIH0pXG4gICAgICAgIEJhY2tncm91bmRzLnB1c2goeyBuYW1lOiAnZmFrZVRocmVlJywgdmFsdWU6ICcvZmFrZVRocmVlLmpwZycgfSlcbiAgICAgICAgQmFja2dyb3VuZHMucHVzaCh7IG5hbWU6ICdmYWtlRm91cicsIHZhbHVlOiAnL2Zha2VGb3VyLmpwZycgfSlcbiAgICAgICAgQmFja2dyb3VuZHMucHVzaCh7IG5hbWU6ICdmYWtlRml2ZScsIHZhbHVlOiAnL2Zha2VGaXZlLmpwZycgfSlcblxuICAgICAgICByZXR1cm4gQmFja2dyb3VuZHNcbiAgICB9LFxuXG4gICAgZmFrZVJldHJvQWN0aW9uKHBhcmFtZXRlcnMpIHtcbiAgICAgICAgbGV0IHBhcm1zID0ge31cblxuICAgICAgICBpZiAoIV8uaXNVbmRlZmluZWQocGFyYW1ldGVycykpIHtcbiAgICAgICAgICAgIHBhcm1zID0gcGFyYW1ldGVycztcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IFJldHJvQWN0aW9uID0ge31cblxuICAgICAgICBSZXRyb0FjdGlvbi5faWQgPSBwYXJtcy5faWQgfHwgUmFuZG9tLmlkKClcbiAgICAgICAgUmV0cm9BY3Rpb24uY3JlYXRlZEJ5ID0gcGFybXMuY3JlYXRlZEJ5IHx8IFJhbmRvbS5pZCgpXG4gICAgICAgIFJldHJvQWN0aW9uLmNyZWF0ZWRBdCA9IHBhcm1zLmNyZWF0ZWRBdCB8fCBuZXcgRGF0ZSgpXG4gICAgICAgIFJldHJvQWN0aW9uLnRpdGxlID0gcGFybXMudGl0bGUgfHwgZmFrZXIubmFtZS50aXRsZSgpXG4gICAgICAgIFJldHJvQWN0aW9uLnN0YXR1cyA9IHBhcm1zLnN0YXR1cyB8fCBDb25zdGFudHMuUmV0cm9JdGVtU3RhdHVzZXMuUEVORElOR1xuICAgICAgICBSZXRyb0FjdGlvbi5jb21wbGV0ZWRBdCA9IHBhcm1zLmNvbXBsZXRlZEF0IHx8IG51bGxcblxuICAgICAgICByZXR1cm4gUmV0cm9BY3Rpb25cbiAgICB9LFxuXG4gICAgZmFrZVJldHJvSXRlbShwYXJhbWV0ZXJzKSB7XG4gICAgICAgIGxldCBwYXJtcyA9IHt9XG5cbiAgICAgICAgaWYgKCFfLmlzVW5kZWZpbmVkKHBhcmFtZXRlcnMpKSB7XG4gICAgICAgICAgICBwYXJtcyA9IHBhcmFtZXRlcnM7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBSZXRyb0l0ZW0gPSB7fVxuXG4gICAgICAgIFJldHJvSXRlbS5pdGVtSWQgPSBwYXJtcy5pdGVtSWQgfHwgUmFuZG9tLmlkKClcbiAgICAgICAgUmV0cm9JdGVtLnRpdGxlID0gcGFybXMudGl0bGUgfHwgZmFrZXIubmFtZS50aXRsZSgpXG4gICAgICAgIFJldHJvSXRlbS5zdGF0dXMgPSBwYXJtcy5zdGF0dXMgfHwgQ29uc3RhbnRzLlJldHJvSXRlbVN0YXR1c2VzLlBFTkRJTkdcbiAgICAgICAgUmV0cm9JdGVtLml0ZW1UeXBlID0gcGFybXMuaXRlbVR5cGUgfHwgUmFuZG9tLmNob2ljZShbQ29uc3RhbnRzLlJldHJvSXRlbVR5cGVzLkhBUFBZLCBDb25zdGFudHMuUmV0cm9JdGVtVHlwZXMuTUVILCBDb25zdGFudHMuUmV0cm9JdGVtVHlwZXMuU0FEXSlcbiAgICAgICAgUmV0cm9JdGVtLnZvdGVzID0gcGFybXMudm90ZXMgfHwgMFxuICAgICAgICBSZXRyb0l0ZW0uY3JlYXRlZEF0ID0gcGFybXMuY3JlYXRlZEF0IHx8IG5ldyBEYXRlKClcblxuICAgICAgICByZXR1cm4gUmV0cm9JdGVtXG4gICAgfSxcblxuICAgIGZha2VSZXRyb0l0ZW1zKHBhcmFtZXRlcnMsIGNvdW50KSB7XG4gICAgICAgIGNvbnN0IGl0ZW1zID0gW11cblxuICAgICAgICBpZiAoIWNvdW50KSBjb3VudCA9IDFcblxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNvdW50OyBpICs9IDEpIHtcbiAgICAgICAgICAgIGl0ZW1zLnB1c2godGhpcy5mYWtlUmV0cm9JdGVtKHBhcmFtZXRlcnMpKVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGl0ZW1zXG4gICAgfSxcblxuICAgIGZha2VSZXRybyhwYXJhbWV0ZXJzKSB7XG4gICAgICAgIGxldCBwYXJtcyA9IHt9XG5cbiAgICAgICAgaWYgKCFfLmlzVW5kZWZpbmVkKHBhcmFtZXRlcnMpKSB7XG4gICAgICAgICAgICBwYXJtcyA9IHBhcmFtZXRlcnM7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBSZXRybyA9IHt9XG5cbiAgICAgICAgUmV0cm8uX2lkID0gcGFybXMuX2lkIHx8IFJhbmRvbS5pZCgpXG4gICAgICAgIFJldHJvLmNyZWF0ZWRCeSA9IHBhcm1zLmNyZWF0ZWRCeSB8fCBSYW5kb20uaWQoKVxuICAgICAgICBSZXRyby50aXRsZSA9IHBhcm1zLnRpdGxlIHx8IGZha2VyLm5hbWUudGl0bGUoKVxuICAgICAgICBSZXRyby5zdGF0dXMgPSBwYXJtcy5zdGF0dXMgfHwgQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuQUNUSVZFXG4gICAgICAgIFJldHJvLml0ZW1zID0gcGFybXMuaXRlbXMgfHwgdGhpcy5mYWtlUmV0cm9JdGVtcyh7fSwgcGFybXMuY291bnQgfHwgMylcbiAgICAgICAgUmV0cm8uc2hvd0NvbXBsZXRlZCA9IF8uaXNVbmRlZmluZWQocGFybXMuc2hvd0NvbXBsZXRlZCkgPyBmYWxzZSA6IHBhcm1zLnNob3dDb21wbGV0ZWRcbiAgICAgICAgUmV0cm8uYXJjaGl2ZWRBdCA9IHBhcm1zLmFyY2hpdmVkQXQgfHwgbmV3IERhdGUoKVxuXG4gICAgICAgIHJldHVybiBSZXRyb1xuICAgIH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSB7IFRlc3REYXRhIH1cbiJdfQ==
