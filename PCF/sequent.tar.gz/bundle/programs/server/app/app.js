var require = meteorInstall({"lib":{"constants.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/constants.js                                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
!function (module1) {
  const Constants = {
    RetroStatuses: {
      ACTIVE: 'Active',
      ARCHIVED: 'Archived',
      FROZEN: 'Frozen',
      values: ['Active', 'Archived', 'Frozen']
    },
    RetroItemStatuses: {
      PENDING: 'Pending',
      COMPLETE: 'Complete',
      values: ['Pending', 'Complete']
    },
    RetroItemTypes: {
      HAPPY: 'Happy',
      MEH: 'Meh',
      SAD: 'Sad',
      ACTION: 'Action',
      values: ['Happy', 'Meh', 'Sad', 'Action']
    }
  };
  module.exports = {
    Constants
  };
}.call(this, module);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"logger.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/logger.js                                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
!function (module1) {
  const Logger = {
    log: message => {
      console.log(message);
    }
  };
  module.exports = {
    Logger
  };
}.call(this, module);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-completeRetroItem.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/method-completeRetroItem.js                                                                                  //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Retros;
module.link("./sequent", {
  Retros(v) {
    Retros = v;
  }

}, 1);
let Schemas;
module.link("./schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 2);
let Constants;
module.link("./constants", {
  Constants(v) {
    Constants = v;
  }

}, 3);
let Logger;
module.link("./logger", {
  Logger(v) {
    Logger = v;
  }

}, 4);
Meteor.methods({
  completeRetroItem(itemId) {
    const retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    } // validate item type


    const retro = Retros.findOne({
      createdBy: this.userId,
      $or: [{
        status: Constants.RetroStatuses.ACTIVE
      }, {
        status: Constants.RetroStatuses.FROZEN
      }]
    }); // need to see if there is

    if (!retro) {
      throw new Meteor.Error('not-found', 'Retro not found!');
    }

    try {
      Retros.update({
        _id: retro._id,
        'items.itemId': itemId
      }, {
        $set: {
          'items.$.status': Constants.RetroItemStatuses.COMPLETE
        }
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('update-failed', 'We could not complete the retro item - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-removeAction.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/method-removeAction.js                                                                                       //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Retros, RetroActions;
module.link("./sequent", {
  Retros(v) {
    Retros = v;
  },

  RetroActions(v) {
    RetroActions = v;
  }

}, 1);
let Schemas;
module.link("./schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 2);
let Constants;
module.link("./constants", {
  Constants(v) {
    Constants = v;
  }

}, 3);
let Logger;
module.link("./logger", {
  Logger(v) {
    Logger = v;
  }

}, 4);
Meteor.methods({
  removeAction(actionId) {
    const retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    const action = RetroActions.findOne({
      _id: actionId,
      createdBy: this.userId
    });

    if (!action) {
      throw new Meteor.Error('not-found', 'Action not found!');
    }

    try {
      RetroActions.remove({
        _id: actionId
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('delete-failed', 'We could not delete the action - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-removeRetroItem.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/method-removeRetroItem.js                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 1);
let Retros;
module.link("./sequent", {
  Retros(v) {
    Retros = v;
  }

}, 2);
let Schemas;
module.link("./schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 3);
let Constants;
module.link("./constants", {
  Constants(v) {
    Constants = v;
  }

}, 4);
let Logger;
module.link("./logger", {
  Logger(v) {
    Logger = v;
  }

}, 5);
Meteor.methods({
  removeRetroItem(itemId) {
    const retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    const retro = Retros.findOne({
      createdBy: this.userId,
      $or: [{
        status: Constants.RetroStatuses.ACTIVE
      }, {
        status: Constants.RetroStatuses.FROZEN
      }]
    }); // need to see if there is

    if (!retro) {
      throw new Meteor.Error('not-found', 'Retro not found!');
    }

    const retroItem = _.filter(retro.items, function (item) {
      return item.itemId === itemId;
    });

    if (retroItem.length === 0) {
      throw new Meteor.Error('not-found', 'Retro Item not found!');
    }

    try {
      Retros.update({
        _id: retro._id
      }, {
        $pull: {
          items: {
            itemId: itemId
          }
        }
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('update-failed', 'We could not remove retro item - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-toggleAction.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/method-toggleAction.js                                                                                       //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Random;
module.link("meteor/random", {
  Random(v) {
    Random = v;
  }

}, 1);
let Retros, RetroActions;
module.link("../lib/sequent", {
  Retros(v) {
    Retros = v;
  },

  RetroActions(v) {
    RetroActions = v;
  }

}, 2);
let Schemas;
module.link("./schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 3);
let Constants;
module.link("./constants", {
  Constants(v) {
    Constants = v;
  }

}, 4);
let Logger;
module.link("./logger", {
  Logger(v) {
    Logger = v;
  }

}, 5);
Meteor.methods({
  toggleAction(actionId) {
    const retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    const action = RetroActions.findOne({
      _id: actionId,
      createdBy: this.userId
    });

    if (!action) {
      throw new Meteor.Error('not-found', 'RetroAction not found!');
    }

    const newValue = action.status === Constants.RetroItemStatuses.PENDING ? Constants.RetroItemStatuses.COMPLETE : Constants.RetroItemStatuses.PENDING;
    let newDate;

    if (newValue === Constants.RetroItemStatuses.COMPLETE) {
      newDate = new Date();
    } else {
      newDate = null;
    }

    try {
      RetroActions.update({
        _id: actionId
      }, {
        $set: {
          status: newValue,
          completedAt: newDate
        }
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('delete-failed', 'We could not delete the action - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-toggleRetroFrozen.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/method-toggleRetroFrozen.js                                                                                  //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Retros, RetroActions;
module.link("./sequent", {
  Retros(v) {
    Retros = v;
  },

  RetroActions(v) {
    RetroActions = v;
  }

}, 1);
let Schemas;
module.link("./schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 2);
let Constants;
module.link("./constants", {
  Constants(v) {
    Constants = v;
  }

}, 3);
let Logger;
module.link("./logger", {
  Logger(v) {
    Logger = v;
  }

}, 4);
Meteor.methods({
  toggleRetroFrozen() {
    const retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    } // validate item type


    const retro = Retros.findOne({
      createdBy: this.userId,
      $or: [{
        status: Constants.RetroStatuses.ACTIVE
      }, {
        status: Constants.RetroStatuses.FROZEN
      }]
    }); // need to see if there is

    if (!retro) {
      throw new Meteor.Error('not-found', 'Retro not found!');
    }

    if (retro.status === Constants.RetroStatuses.ARCHIVED) {
      throw new Meteor.Error('invalid-state', 'Retro must not be archived!');
    }

    const newStatus = retro.status === Constants.RetroStatuses.FROZEN ? Constants.RetroStatuses.ACTIVE : Constants.RetroStatuses.FROZEN;

    try {
      Retros.update({
        _id: retro._id
      }, {
        $set: {
          status: newStatus
        }
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('update-failed', 'We could not freeze the retro - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-toggleShowCompleted.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/method-toggleShowCompleted.js                                                                                //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Retros, RetroActions;
module.link("./sequent", {
  Retros(v) {
    Retros = v;
  },

  RetroActions(v) {
    RetroActions = v;
  }

}, 1);
let Schemas;
module.link("./schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 2);
let Constants;
module.link("./constants", {
  Constants(v) {
    Constants = v;
  }

}, 3);
let Logger;
module.link("./logger", {
  Logger(v) {
    Logger = v;
  }

}, 4);
Meteor.methods({
  toggleShowCompleted() {
    const retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    const retro = Retros.findOne({
      createdBy: this.userId,
      $or: [{
        status: Constants.RetroStatuses.ACTIVE
      }, {
        status: Constants.RetroStatuses.FROZEN
      }]
    }); // need to see if there is

    if (!retro) {
      throw new Meteor.Error('not-found', 'Retro not found!');
    }

    const show = !retro.showCompleted;

    try {
      Retros.update({
        _id: retro._id
      }, {
        $set: {
          showCompleted: show
        }
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('update-failed', 'We could toggle retro show completed - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-upVoteItem.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/method-upVoteItem.js                                                                                         //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 1);
let Retros;
module.link("./sequent", {
  Retros(v) {
    Retros = v;
  }

}, 2);
let Schemas;
module.link("./schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 3);
let Constants;
module.link("./constants", {
  Constants(v) {
    Constants = v;
  }

}, 4);
let Logger;
module.link("./logger", {
  Logger(v) {
    Logger = v;
  }

}, 5);
Meteor.methods({
  upVoteItem(itemId) {
    const retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    } // validate item type


    const retro = Retros.findOne({
      createdBy: this.userId,
      status: Constants.RetroStatuses.ACTIVE
    }); // need to see if there is

    if (!retro) {
      throw new Meteor.Error('not-found', 'Retro not found!');
    }

    const retroItem = _.filter(retro.items, function (item) {
      return item.itemId === itemId;
    });

    if (retroItem.length === 0) {
      throw new Meteor.Error('not-found', 'Retro Item not found!');
    }

    let voteCount = retroItem[0].votes || 0;
    voteCount += 1;

    try {
      Retros.update({
        _id: retro._id,
        'items.itemId': itemId
      }, {
        $set: {
          'items.$.votes': voteCount
        }
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('update-failed', 'We could not upvote this item - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"schemas.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/schemas.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
!function (module1) {
  let SimpleSchema;
  module1.link("meteor/aldeed:simple-schema", {
    SimpleSchema(v) {
      SimpleSchema = v;
    }

  }, 0);
  let Constants;
  module1.link("./constants", {
    Constants(v) {
      Constants = v;
    }

  }, 1);
  const Schemas = {};
  Schemas.RetroItem = new SimpleSchema({
    itemId: {
      type: String,
      regEx: SimpleSchema.RegEx.Id,
      optional: true
    },
    title: {
      type: String,
      max: 255
    },
    status: {
      type: String,
      allowedValues: Constants.RetroItemStatuses.values
    },
    itemType: {
      type: String,
      allowedValues: Constants.RetroItemTypes.values
    },
    votes: {
      type: Number,
      optional: true
    },
    createdAt: {
      type: Date
    }
  });
  Schemas.Retros = new SimpleSchema({
    _id: {
      type: String,
      regEx: SimpleSchema.RegEx.Id,
      optional: true
    },
    createdAt: {
      type: Date,
      autoValue: function () {
        if (this.isInsert) {
          return new Date();
        }

        this.unset();
      }
    },
    createdBy: {
      type: String,
      regEx: SimpleSchema.RegEx.Id,
      autoValue: function () {
        if (this.isInsert) {
          return this.userId;
        }

        this.unset();
      }
    },
    status: {
      type: String,
      allowedValues: Constants.RetroStatuses.values
    },
    items: {
      type: [Schemas.RetroItem]
    },
    showCompleted: {
      type: Boolean,
      optional: true,
      defaultValue: false
    },
    archivedAt: {
      type: Date,
      optional: true
    },
    happyPlaceholder: {
      type: String,
      optional: true
    },
    mehPlaceholder: {
      type: String,
      optional: true
    },
    sadPlaceholder: {
      type: String,
      optional: true
    },
    archiveName: {
      type: String,
      optional: true
    }
  });
  Schemas.Actions = new SimpleSchema({
    _id: {
      type: String,
      regEx: SimpleSchema.RegEx.Id,
      optional: true
    },
    createdAt: {
      type: Date,
      autoValue: function () {
        if (this.isInsert) {
          return new Date();
        }

        this.unset();
      }
    },
    createdBy: {
      type: String,
      regEx: SimpleSchema.RegEx.Id,
      autoValue: function () {
        if (this.isInsert) {
          return this.userId;
        }

        this.unset();
      }
    },
    title: {
      type: String,
      max: 255
    },
    status: {
      type: String,
      allowedValues: Constants.RetroItemStatuses.values
    },
    completedAt: {
      type: Date,
      optional: true
    }
  });
  Schemas.NewTeam = new SimpleSchema({
    name: {
      type: String,
      max: 60,
      min: 5
    },
    description: {
      type: String,
      optional: true,
      max: 255
    },
    password: {
      type: String,
      regEx: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/,
      min: 8
    },
    confirmPassword: {
      type: String,
      min: 8,

      custom() {
        if (this.value !== this.field('password').value) {
          return 'passwordMismatch';
        }
      }

    }
  });
  Schemas.Settings = new SimpleSchema({
    _id: {
      type: String,
      regEx: SimpleSchema.RegEx.Id,
      optional: true
    },
    createdBy: {
      type: String,
      regEx: SimpleSchema.RegEx.Id,
      autoValue: function () {
        if (this.isInsert) {
          return this.userId;
        }

        this.unset();
      },
      optional: true
    },
    backgroundImage: {
      type: String,
      defaultValue: '/backgrounds/triangles.png',
      optional: true
    },
    happyPlaceholder: {
      type: String,
      defaultValue: ':)',
      optional: true
    },
    mehPlaceholder: {
      type: String,
      defaultValue: ':|',
      optional: true
    },
    sadPlaceholder: {
      type: String,
      defaultValue: ':(',
      optional: true
    }
  });
  module.exports = {
    Schemas
  };
}.call(this, module);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"sequent.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/sequent.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
!function (module1) {
  let Mongo;
  module1.link("meteor/mongo", {
    Mongo(v) {
      Mongo = v;
    }

  }, 0);
  let Schemas;
  module1.link("./schemas", {
    Schemas(v) {
      Schemas = v;
    }

  }, 1);

  if (!String.prototype.toProperCase) {
    String.prototype.toProperCase = function () {
      return this.replace(/\w\S*/g, function (txt) {
        return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
      });
    };
  }

  const Retros = new Mongo.Collection('retros');
  const RetroActions = new Mongo.Collection('retro-actions');
  const Backgrounds = new Mongo.Collection('backgrounds');
  const Settings = new Mongo.Collection('settings');
  Retros.attachSchema(Schemas.Retros);
  RetroActions.attachSchema(Schemas.Actions);
  Settings.attachSchema(Schemas.Settings);
  const Sequent = {
    archiveRouteName: 'archives',
    defaultBackground: '/backgrounds/triangles.png',
    defaultConfirmMsg: 'Are you sure?',
    ToastTimeOut: 3000,
    EMAIL_TARGET: 'emailTarget',

    pageSize() {
      return 25;
    },

    getSettings() {
      let settings = Settings.findOne();

      if (!settings) {
        settings = {};
        settings.backgroundImage = Sequent.defaultBackground;
        settings.happyPlaceholder = ':)';
        settings.mehPlaceholder = ':|';
        settings.sadPlaceholder = ':(';
      }

      return settings;
    }

  };
  module.exports = {
    Sequent,
    Retros,
    RetroActions,
    Backgrounds,
    Settings
  };
}.call(this, module);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"cleanInput.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/cleanInput.js                                                                                             //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let sanitizeHtml;
module.link("sanitize-html", {
  default(v) {
    sanitizeHtml = v;
  }

}, 0);

const cleanInput = function (input) {
  let defaultVal = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
  const value = sanitizeHtml(input, {
    allowedTags: []
  });
  return value || defaultVal;
};

module.exportDefault(cleanInput);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-archiveRetro.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/method-archiveRetro.js                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let moment;
module.link("moment", {
  default(v) {
    moment = v;
  }

}, 1);
let Settings, Retros;
module.link("../lib/sequent", {
  Settings(v) {
    Settings = v;
  },

  Retros(v) {
    Retros = v;
  }

}, 2);
let Schemas;
module.link("../lib/schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 3);
let Constants;
module.link("../lib/constants", {
  Constants(v) {
    Constants = v;
  }

}, 4);
let Logger;
module.link("../lib/logger", {
  Logger(v) {
    Logger = v;
  }

}, 5);
let cleanInput;
module.link("./cleanInput", {
  default(v) {
    cleanInput = v;
  }

}, 6);

const inputName = (name, dateVal) => {
  const newName = cleanInput(name);
  if (!newName) return "".concat(dateVal);
  if (newName === '') return "".concat(dateVal);
  return newName;
};

Meteor.methods({
  archiveRetro(retroId, name) {
    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    const retro = Retros.findOne({
      _id: retroId,
      createdBy: this.userId
    });

    if (!retro) {
      throw new Meteor.Error('not-found', 'Retro could not be found!');
    }

    if (retro.status === Constants.RetroStatuses.ARCHIVED) {
      throw new Meteor.Error('already-archived', 'Retro was already archived!');
    }

    const archivedAt = new Date();
    const dateVal = moment(archivedAt).format('MM-DD-YYYY - LT');
    const archiveName = inputName(name, dateVal);

    if (archiveName !== name && name !== '') {
      throw new Meteor.Error('invalid-name', 'Invalid Archive name. HTML tags not allowed!');
    }

    let settings = Settings.findOne({
      createdBy: this.userId
    });

    if (!settings) {
      settings = {
        happyPlaceholder: ':)',
        mehPlaceholder: ':|',
        sadPlaceholder: ':('
      };
    }

    try {
      Retros.update({
        _id: retro._id
      }, {
        $set: {
          status: Constants.RetroStatuses.ARCHIVED,
          archivedAt,
          archiveName,
          happyPlaceholder: settings.happyPlaceholder,
          mehPlaceholder: settings.mehPlaceholder,
          sadPlaceholder: settings.sadPlaceholder
        }
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('update-failed', 'We could not archive the retro - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-componentImages.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/method-componentImages.js                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let fs;
module.link("fs", {
  default(v) {
    fs = v;
  }

}, 1);

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 2);
Meteor.methods({
  componentImages() {
    const images = [];
    const meteorRoot = fs.realpathSync("".concat(process.cwd(), "/../"));
    const publicPath = "".concat(meteorRoot, "/web.browser/app/");
    const backgroundPath = "".concat(publicPath, "/");
    const bgs = fs.readdirSync(backgroundPath);
    const files = bgs.filter(function (elm) {
      return elm.match(/.*\.(png)/ig);
    });

    _.each(files, function (img) {
      images.push({
        fileName: "/".concat(img)
      });
    });

    return images;
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-createRetroAction.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/method-createRetroAction.js                                                                               //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Retros, RetroActions;
module.link("../lib/sequent", {
  Retros(v) {
    Retros = v;
  },

  RetroActions(v) {
    RetroActions = v;
  }

}, 1);
let Schemas;
module.link("../lib/schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 2);
let Constants;
module.link("../lib/constants", {
  Constants(v) {
    Constants = v;
  }

}, 3);
let Logger;
module.link("../lib/logger", {
  Logger(v) {
    Logger = v;
  }

}, 4);
let cleanInput;
module.link("./cleanInput", {
  default(v) {
    cleanInput = v;
  }

}, 5);
Meteor.methods({
  createRetroAction(title) {
    const retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    const action = {};
    action.title = cleanInput(title);
    action.status = Constants.RetroItemStatuses.PENDING;

    if (action.title === '') {
      throw new Meteor.Error('title-required', 'Invalid action item! HTML Tags not allowed.');
    }

    try {
      const actionId = RetroActions.insert(action);
      return actionId;
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('insert-failed', 'We could not add retro item to the retro - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-createRetroItem.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/method-createRetroItem.js                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Random;
module.link("meteor/random", {
  Random(v) {
    Random = v;
  }

}, 1);

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 2);
let Retros;
module.link("../lib/sequent", {
  Retros(v) {
    Retros = v;
  }

}, 3);
let Schemas;
module.link("../lib/schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 4);
let Constants;
module.link("../lib/constants", {
  Constants(v) {
    Constants = v;
  }

}, 5);
let Logger;
module.link("../lib/logger", {
  Logger(v) {
    Logger = v;
  }

}, 6);
let cleanInput;
module.link("./cleanInput", {
  default(v) {
    cleanInput = v;
  }

}, 7);
Meteor.methods({
  createRetroItem(title, itemType) {
    let retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    const newTitle = cleanInput(title);

    if (newTitle === '') {
      throw new Meteor.Error('title-required', 'Invalid retro item! HTML Tags not allowed.');
    } // if there are no active retros for this user create one


    let retro = Retros.findOne({
      createdBy: this.userId,
      status: Constants.RetroStatuses.ACTIVE
    });

    if (!retro) {
      const retroDoc = {};
      retroDoc.status = Constants.RetroStatuses.ACTIVE;
      retroDoc.items = [];
      retroId = Retros.insert(retroDoc);
      retro = Retros.findOne({
        _id: retroId
      });
    } else {
      retroId = retro._id;
    }

    const doc = {};
    doc.itemId = Random.id();
    doc.title = newTitle;
    doc.itemType = itemType;
    doc.status = Constants.RetroItemStatuses.PENDING;
    doc.votes = 0;
    doc.createdAt = new Date();

    if (!_.isArray(retro.items)) {
      retro.items = [];
    } // retro.items.push(doc)


    try {
      Retros.update({
        _id: retroId
      }, {
        $push: {
          items: doc
        }
      });
      return retroId;
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('insert-failed', 'We could not add retro item to the retro - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-saveSettings.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/method-saveSettings.js                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Random;
module.link("meteor/random", {
  Random(v) {
    Random = v;
  }

}, 1);
let Match;
module.link("meteor/check", {
  Match(v) {
    Match = v;
  }

}, 2);
let SimpleSchema;
module.link("meteor/aldeed:simple-schema", {
  SimpleSchema(v) {
    SimpleSchema = v;
  }

}, 3);

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 4);
let Settings;
module.link("../lib/sequent", {
  Settings(v) {
    Settings = v;
  }

}, 5);
let Schemas;
module.link("../lib/schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 6);
let Logger;
module.link("../lib/logger", {
  Logger(v) {
    Logger = v;
  }

}, 7);
let cleanInput;
module.link("./cleanInput", {
  default(v) {
    cleanInput = v;
  }

}, 8);
Meteor.methods({
  saveSettings(doc) {
    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    Schemas.Settings.validate(doc);
    const settings = Settings.findOne({
      createdBy: this.userId
    });
    const happy = cleanInput(doc.happyPlaceholder, ':)');
    const meh = cleanInput(doc.mehPlaceholder, ':|');
    const sad = cleanInput(doc.sadPlaceholder, ':(');

    if (happy !== doc.happyPlaceholder || meh !== doc.mehPlaceholder || sad !== doc.sadPlaceholder) {
      throw new Meteor.Error('invalid-prompt', 'Invalid prompt! HTML Tags not allowed.');
    }

    try {
      if (_.isUndefined(settings)) {
        Settings.insert(doc);
      } else {
        Settings.update({
          _id: settings._id
        }, {
          $set: {
            backgroundImage: doc.backgroundImage,
            happyPlaceholder: happy,
            mehPlaceholder: meh,
            sadPlaceholder: sad
          }
        });
      }
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('update-failed', 'We could not update settings - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-sendActionsByEmail.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/method-sendActionsByEmail.js                                                                              //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 1);
let Retros, RetroActions;
module.link("../lib/sequent", {
  Retros(v) {
    Retros = v;
  },

  RetroActions(v) {
    RetroActions = v;
  }

}, 2);
let Constants;
module.link("../lib/constants", {
  Constants(v) {
    Constants = v;
  }

}, 3);
let ServerUtils;
module.link("./serverUtils", {
  ServerUtils(v) {
    ServerUtils = v;
  }

}, 4);
let cleanInput;
module.link("./cleanInput", {
  default(v) {
    cleanInput = v;
  }

}, 5);
Meteor.methods({
  sendActionsByEmail(currentRetro, targetEmail) {
    // console.log('hi there')
    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged in to perform this action!');
    } // const retro = Retros.findOne({ _id: currentRetro })
    // if (!retro) {
    //     throw new Meteor.Error('not-found', 'Retro not found!')
    // }
    // if (retro.createdBy !== this.userId) {
    //     throw new Meteor.Error('not-the-owner', 'You are not the owner of this retro!')
    // }


    const emailToUse = targetEmail || '';

    if (emailToUse === '') {
      throw new Meteor.Error('email-address-required', 'An email address is required!');
    }

    const newEmail = cleanInput(emailToUse);

    if (newEmail === '') {
      throw new Meteor.Error('contains-html', 'Invalid email address!');
    } // console.log('email', newEmail)


    const actions = RetroActions.find({
      createdBy: this.userId,
      $or: [{
        status: Constants.RetroItemStatuses.PENDING
      }, {
        status: Constants.RetroItemStatuses.COMPLETE,
        completedAt: {
          $gt: new Date(Date.now() - 24 * 60 * 60 * 1000)
        }
      }]
    }).fetch();

    if (actions.length === 0) {
      throw new Meteor.Error('no-actions', 'There are no active or recently completed actions to send!');
    }

    const data = {};
    const user = Meteor.users.findOne(this.userId);
    data.retroName = user.username.toProperCase();
    data.currentYear = new Date().getFullYear(); // turn into html list

    let items = '<tr><th>Action Item</th><th class="text-center" style="width: 25%;">Status</th></tr>';
    data.retroItems = _.sortBy(actions, 'status').forEach(item => {
      const isComplete = item.status === Constants.RetroItemStatuses.COMPLETE ? 'Complete' : 'Active';
      const itemStyle = item.status === Constants.RetroItemStatuses.COMPLETE ? 'color: #999; padding: 4px 4px 4px 0px; vertical-align: top;' : 'padding: 4px 4px 4px 0px; vertical-align: top;';
      items += "<tr></tr><td style=\"".concat(itemStyle, "\">").concat(item.title, "</td><td style=\"").concat(itemStyle, "\">").concat(isComplete, "</td></tr>");
    });
    data.retroItems = items;
    const from = process.env.FROM_EMAIL_ADDRESS || 'sequent@6thcents.com';
    ServerUtils.sendHtmlEmail(newEmail, from, "".concat(user.username.toProperCase(), " Action Items"), 'actionItems', data);
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-updateActionTitle.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/method-updateActionTitle.js                                                                               //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Retros, RetroActions;
module.link("../lib/sequent", {
  Retros(v) {
    Retros = v;
  },

  RetroActions(v) {
    RetroActions = v;
  }

}, 1);
let Schemas;
module.link("../lib/schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 2);
let Constants;
module.link("../lib/constants", {
  Constants(v) {
    Constants = v;
  }

}, 3);
let Logger;
module.link("../lib/logger", {
  Logger(v) {
    Logger = v;
  }

}, 4);
let cleanInput;
module.link("./cleanInput", {
  default(v) {
    cleanInput = v;
  }

}, 5);
Meteor.methods({
  updateActionTitle(actionId, title) {
    const retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    const action = RetroActions.findOne({
      _id: actionId,
      createdBy: this.userId
    });

    if (!action) {
      throw new Meteor.Error('not-found', 'RetroAction not found!');
    }

    const newTitle = cleanInput(title);

    if (newTitle !== title) {
      throw new Meteor.Error('invalid-title', 'Invalid action! HTML tags not allowed.');
    }

    try {
      RetroActions.update({
        _id: actionId
      }, {
        $set: {
          title: newTitle
        }
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('delete-failed', 'We could not delete the action - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-updateRetroItemTitle.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/method-updateRetroItemTitle.js                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 1);
let Retros;
module.link("../lib/sequent", {
  Retros(v) {
    Retros = v;
  }

}, 2);
let Schemas;
module.link("../lib/schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 3);
let Constants;
module.link("../lib/constants", {
  Constants(v) {
    Constants = v;
  }

}, 4);
let Logger;
module.link("../lib/logger", {
  Logger(v) {
    Logger = v;
  }

}, 5);
let cleanInput;
module.link("./cleanInput", {
  default(v) {
    cleanInput = v;
  }

}, 6);
Meteor.methods({
  updateRetroItemTitle(itemId, title) {
    const retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    const retro = Retros.findOne({
      createdBy: this.userId,
      $or: [{
        status: Constants.RetroStatuses.ACTIVE
      }, {
        status: Constants.RetroStatuses.FROZEN
      }]
    }); // need to see if there is

    if (!retro) {
      throw new Meteor.Error('not-found', 'Retro not found!');
    }

    const retroItem = _.filter(retro.items, function (item) {
      return item.itemId === itemId;
    });

    if (retroItem.length === 0) {
      throw new Meteor.Error('not-found', 'Retro Item not found!');
    }

    let voteCount = retroItem[0].votes || 0;
    voteCount += 1;
    const newTitle = cleanInput(title);

    if (newTitle === '') {
      throw new Meteor.Error('invalid-title', 'Invalid Retro Item. HTML tags not allowed.');
    }

    try {
      Retros.update({
        _id: retro._id,
        'items.itemId': itemId
      }, {
        $set: {
          'items.$.title': newTitle
        }
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('update-failed', 'We could not update the retro item - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publication-backgrounds.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/publication-backgrounds.js                                                                                //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let fs;
module.link("fs", {
  default(v) {
    fs = v;
  }

}, 1);

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 2);
let Backgrounds;
module.link("../lib/sequent", {
  Backgrounds(v) {
    Backgrounds = v;
  }

}, 3);
Meteor.publish('backgrounds', function () {
  const self = this;
  const meteorRoot = fs.realpathSync("".concat(process.cwd(), "/../"));
  const publicPath = "".concat(meteorRoot, "/web.browser/app/");
  const backgroundPath = "".concat(publicPath, "/backgrounds/");
  const bgs = fs.readdirSync(backgroundPath);

  _.each(bgs, function (background) {
    const backgroundName = background.split('.')[0].toProperCase();
    self.added('backgrounds', background, {
      name: backgroundName,
      value: "/backgrounds/".concat(background)
    });
  });

  this.ready();
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications-actions.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/publications-actions.js                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Match;
module.link("meteor/check", {
  Match(v) {
    Match = v;
  }

}, 1);
let Sequent, RetroActions;
module.link("../lib/sequent", {
  Sequent(v) {
    Sequent = v;
  },

  RetroActions(v) {
    RetroActions = v;
  }

}, 2);
let Constants;
module.link("../lib/constants", {
  Constants(v) {
    Constants = v;
  }

}, 3);

RetroActions._ensureIndex('createdBy', 1);

RetroActions._ensureIndex('status', 1);

RetroActions._ensureIndex('createdAt', 1);

Meteor.publish('open-actions', function () {
  if (!this.userId) {
    this.stop();
    return null;
  }

  return RetroActions.find({
    createdBy: this.userId,
    status: Constants.RetroItemStatuses.PENDING
  });
});
Meteor.publish('all-actions', function (search) {
  if (!this.userId) {
    return null;
  }

  if (!Match.test(search, {
    limit: Number,
    showAll: Boolean
  })) {
    return null;
  }

  const query = {
    createdBy: this.userId
  };

  if (!search.showAll) {
    query.status = Constants.RetroItemStatuses.PENDING;
  }

  return RetroActions.find(query, {
    sort: {
      completedAt: 1
    },
    limit: search.limit
  });
});
/*
messages.find({'metadata.thread': threadId},
  {
    sort: {'date' : sort},
    limit: limit,
    disableOplog: true,
    pollingThrottleMs: 12000,
    pollingIntervalMs: 12000
  }
);
*/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications-retros.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/publications-retros.js                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Retros;
module.link("../lib/sequent", {
  Retros(v) {
    Retros = v;
  }

}, 1);
let Constants;
module.link("../lib/constants", {
  Constants(v) {
    Constants = v;
  }

}, 2);

Retros._ensureIndex('createdBy', 1);

Retros._ensureIndex('status', 1);

Meteor.publish('active-retros', function () {
  if (!this.userId) {
    return null;
  }

  return Retros.find({
    createdBy: this.userId,
    status: {
      $in: [Constants.RetroStatuses.ACTIVE, Constants.RetroStatuses.FROZEN]
    }
  });
});
Meteor.publish('archived-retros', function () {
  if (!this.userId) {
    return null;
  }

  return Retros.find({
    createdBy: this.userId,
    status: Constants.RetroStatuses.ARCHIVED
  });
});
Meteor.publish('single-archived-retro', function (retroId) {
  if (!this.userId) {
    return null;
  }

  return Retros.find({
    _id: retroId,
    createdBy: this.userId,
    status: Constants.RetroStatuses.ARCHIVED
  });
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications-settings.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/publications-settings.js                                                                                  //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Settings;
module.link("../lib/sequent", {
  Settings(v) {
    Settings = v;
  }

}, 1);

Settings._ensureIndex('createdBy', 1);

Meteor.publish('settings', function () {
  if (!Meteor.userId()) {
    return null;
  }

  return Settings.find({
    createdBy: Meteor.userId()
  });
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"serverUtils.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/serverUtils.js                                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
!function (module1) {
  let Meteor;
  module1.link("meteor/meteor", {
    Meteor(v) {
      Meteor = v;
    }

  }, 0);
  let SSR;
  module1.link("meteor/meteorhacks:ssr", {
    SSR(v) {
      SSR = v;
    }

  }, 1);
  let Email;
  module1.link("meteor/email", {
    Email(v) {
      Email = v;
    }

  }, 2);
  let check;
  module1.link("meteor/check", {
    default(v) {
      check = v;
    }

  }, 3);
  let Constants;
  module1.link("../lib/constants", {
    Constants(v) {
      Constants = v;
    }

  }, 4);

  if (!String.prototype.toProperCase) {
    String.prototype.toProperCase = function () {
      return this.replace(/\w\S*/g, function (txt) {
        return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
      });
    };
  }

  SSR.compileTemplate('actionItems', Assets.getText('emailTemplates/actionItems.html'));
  Template.actionItems.helpers({
    isComplete: function () {
      return this.status === Constants.RetroItemStatuses.COMPLETE;
    }
  });
  const ServerUtils = {};

  ServerUtils.sendEmail = (to, from, subject, text) => {
    check([to, from, subject, text], [String]);
    Meteor.defer(function () {
      Email.send({
        to: to,
        from: from || 'noreply@6thcents.com',
        subject: subject,
        text: text
      });
    });
  };

  ServerUtils.sendHtmlEmail = (to, from, subject, templateName, data) => {
    var body = SSR.render(templateName, data);
    Meteor.defer(function () {
      Email.send({
        to: to,
        from: from || 'sequent@6thcents.com',
        subject: subject,
        html: body
      });
    });
  };

  module.exports = {
    ServerUtils
  };
}.call(this, module);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/main.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
Meteor.startup(() => {// code to run on server at startup
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"testSuite":{"client-test-helpers.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// testSuite/client-test-helpers.js                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  withRenderedTemplate: () => withRenderedTemplate
});

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 0);
let Template;
module.link("meteor/templating", {
  Template(v) {
    Template = v;
  }

}, 1);
let Blaze;
module.link("meteor/blaze", {
  Blaze(v) {
    Blaze = v;
  }

}, 2);
let Tracker;
module.link("meteor/tracker", {
  Tracker(v) {
    Tracker = v;
  }

}, 3);

const withDiv = function withDiv(callback) {
  const el = document.createElement('div');
  document.body.appendChild(el);

  try {
    callback(el);
  } finally {
    document.body.removeChild(el);
  }
};

const withRenderedTemplate = function withRenderedTemplate(template, data, callback) {
  withDiv(el => {
    const theTemplate = _.isString(template) ? Template[template] : template;
    Blaze.renderWithData(theTemplate, data, el);
    Tracker.flush();
    callback(el, theTemplate);
  });
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"testData.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// testSuite/testData.js                                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
!function (module1) {
  let Random;
  module1.link("meteor/random", {
    Random(v) {
      Random = v;
    }

  }, 0);

  let _;

  module1.link("meteor/underscore", {
    _(v) {
      _ = v;
    }

  }, 1);
  let Constants;
  module1.link("../lib/constants", {
    Constants(v) {
      Constants = v;
    }

  }, 2);
  const TestData = {
    fakeSettings(parameters) {
      let parms = {};

      if (!_.isUndefined(parameters)) {
        parms = parameters;
      }

      const Settings = {};
      Settings.backgroundImage = '/fakeOne.jpg';
      Settings.happyPlaceholder = 'Fake happy placeholder';
      Settings.mehPlaceholder = 'Fake meh placeholder';
      Settings.sadPlaceholder = 'Fake sad placeholder';
      return Settings;
    },

    fakeBackgroundsArray(parameters) {
      let parms = {};

      if (!_.isUndefined(parameters)) {
        parms = parameters;
      }

      const Backgrounds = [];
      Backgrounds.push({
        name: 'fakeOne',
        value: '/fakeOne.jpg'
      });
      Backgrounds.push({
        name: 'fakeTwo',
        value: '/fakeTwo.jpg'
      });
      Backgrounds.push({
        name: 'fakeThree',
        value: '/fakeThree.jpg'
      });
      Backgrounds.push({
        name: 'fakeFour',
        value: '/fakeFour.jpg'
      });
      Backgrounds.push({
        name: 'fakeFive',
        value: '/fakeFive.jpg'
      });
      return Backgrounds;
    },

    fakeRetroAction(parameters) {
      let parms = {};

      if (!_.isUndefined(parameters)) {
        parms = parameters;
      }

      const RetroAction = {};
      RetroAction._id = parms._id || Random.id();
      RetroAction.createdBy = parms.createdBy || Random.id();
      RetroAction.createdAt = parms.createdAt || new Date();
      RetroAction.title = parms.title || 'fake title';
      RetroAction.status = parms.status || Constants.RetroItemStatuses.PENDING;
      RetroAction.completedAt = parms.completedAt || null;
      return RetroAction;
    },

    fakeRetroItem(parameters) {
      let parms = {};

      if (!_.isUndefined(parameters)) {
        parms = parameters;
      }

      const RetroItem = {};
      RetroItem.itemId = parms.itemId || Random.id();
      RetroItem.title = parms.title || 'fake title';
      RetroItem.status = parms.status || Constants.RetroItemStatuses.PENDING;
      RetroItem.itemType = parms.itemType || Random.choice([Constants.RetroItemTypes.HAPPY, Constants.RetroItemTypes.MEH, Constants.RetroItemTypes.SAD]);
      RetroItem.votes = parms.votes || 0;
      RetroItem.createdAt = parms.createdAt || new Date();
      return RetroItem;
    },

    fakeRetroItems(parameters, count) {
      const items = [];
      if (!count) count = 1;

      for (let i = 0; i < count; i += 1) {
        items.push(this.fakeRetroItem(parameters)); //  eslint-disable-line
      }

      return items;
    },

    fakeRetro(parameters) {
      let parms = {};

      if (!_.isUndefined(parameters)) {
        parms = parameters;
      }

      const Retro = {};
      Retro._id = parms._id || Random.id();
      Retro.createdAt = new Date();
      Retro.createdBy = parms.createdBy || Random.id();
      Retro.title = parms.title || 'fake title';
      Retro.status = parms.status || Constants.RetroStatuses.ACTIVE;
      Retro.items = parms.items || this.fakeRetroItems({}, parms.count || 3);
      Retro.showCompleted = _.isUndefined(parms.showCompleted) ? false : parms.showCompleted;
      Retro.archivedAt = parms.archivedAt || new Date();
      Retro.happyPlaceholder = 'Fake happy placeholder';
      Retro.mehPlaceholder = 'Fake meh placeholder';
      Retro.sadPlaceholder = 'Fake sad placeholder';

      if (parms.archiveName) {
        Retro.archiveName = parms.archiveName;
      }

      return Retro;
    }

  };
  module.exports = {
    TestData
  };
}.call(this, module);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".mjs"
  ]
});

require("/lib/constants.js");
require("/lib/logger.js");
require("/lib/method-completeRetroItem.js");
require("/lib/method-removeAction.js");
require("/lib/method-removeRetroItem.js");
require("/lib/method-toggleAction.js");
require("/lib/method-toggleRetroFrozen.js");
require("/lib/method-toggleShowCompleted.js");
require("/lib/method-upVoteItem.js");
require("/lib/schemas.js");
require("/lib/sequent.js");
require("/server/cleanInput.js");
require("/server/method-archiveRetro.js");
require("/server/method-componentImages.js");
require("/server/method-createRetroAction.js");
require("/server/method-createRetroItem.js");
require("/server/method-saveSettings.js");
require("/server/method-sendActionsByEmail.js");
require("/server/method-updateActionTitle.js");
require("/server/method-updateRetroItemTitle.js");
require("/server/publication-backgrounds.js");
require("/server/publications-actions.js");
require("/server/publications-retros.js");
require("/server/publications-settings.js");
require("/server/serverUtils.js");
require("/testSuite/client-test-helpers.js");
require("/testSuite/testData.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvbGliL2NvbnN0YW50cy5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL2xvZ2dlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL21ldGhvZC1jb21wbGV0ZVJldHJvSXRlbS5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL21ldGhvZC1yZW1vdmVBY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9tZXRob2QtcmVtb3ZlUmV0cm9JdGVtLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvbWV0aG9kLXRvZ2dsZUFjdGlvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL21ldGhvZC10b2dnbGVSZXRyb0Zyb3plbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL21ldGhvZC10b2dnbGVTaG93Q29tcGxldGVkLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvbWV0aG9kLXVwVm90ZUl0ZW0uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9zY2hlbWFzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvc2VxdWVudC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2NsZWFuSW5wdXQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tZXRob2QtYXJjaGl2ZVJldHJvLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWV0aG9kLWNvbXBvbmVudEltYWdlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21ldGhvZC1jcmVhdGVSZXRyb0FjdGlvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21ldGhvZC1jcmVhdGVSZXRyb0l0ZW0uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tZXRob2Qtc2F2ZVNldHRpbmdzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWV0aG9kLXNlbmRBY3Rpb25zQnlFbWFpbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21ldGhvZC11cGRhdGVBY3Rpb25UaXRsZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21ldGhvZC11cGRhdGVSZXRyb0l0ZW1UaXRsZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1YmxpY2F0aW9uLWJhY2tncm91bmRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvcHVibGljYXRpb25zLWFjdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9wdWJsaWNhdGlvbnMtcmV0cm9zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvcHVibGljYXRpb25zLXNldHRpbmdzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvc2VydmVyVXRpbHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC90ZXN0U3VpdGUvY2xpZW50LXRlc3QtaGVscGVycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvdGVzdFN1aXRlL3Rlc3REYXRhLmpzIl0sIm5hbWVzIjpbIkNvbnN0YW50cyIsIlJldHJvU3RhdHVzZXMiLCJBQ1RJVkUiLCJBUkNISVZFRCIsIkZST1pFTiIsInZhbHVlcyIsIlJldHJvSXRlbVN0YXR1c2VzIiwiUEVORElORyIsIkNPTVBMRVRFIiwiUmV0cm9JdGVtVHlwZXMiLCJIQVBQWSIsIk1FSCIsIlNBRCIsIkFDVElPTiIsIm1vZHVsZSIsImV4cG9ydHMiLCJMb2dnZXIiLCJsb2ciLCJtZXNzYWdlIiwiY29uc29sZSIsIk1ldGVvciIsImxpbmsiLCJ2IiwiUmV0cm9zIiwiU2NoZW1hcyIsIm1ldGhvZHMiLCJjb21wbGV0ZVJldHJvSXRlbSIsIml0ZW1JZCIsInJldHJvSWQiLCJ1c2VySWQiLCJFcnJvciIsInJldHJvIiwiZmluZE9uZSIsImNyZWF0ZWRCeSIsIiRvciIsInN0YXR1cyIsInVwZGF0ZSIsIl9pZCIsIiRzZXQiLCJlcnIiLCJSZXRyb0FjdGlvbnMiLCJyZW1vdmVBY3Rpb24iLCJhY3Rpb25JZCIsImFjdGlvbiIsInJlbW92ZSIsIl8iLCJyZW1vdmVSZXRyb0l0ZW0iLCJyZXRyb0l0ZW0iLCJmaWx0ZXIiLCJpdGVtcyIsIml0ZW0iLCJsZW5ndGgiLCIkcHVsbCIsIlJhbmRvbSIsInRvZ2dsZUFjdGlvbiIsIm5ld1ZhbHVlIiwibmV3RGF0ZSIsIkRhdGUiLCJjb21wbGV0ZWRBdCIsInRvZ2dsZVJldHJvRnJvemVuIiwibmV3U3RhdHVzIiwidG9nZ2xlU2hvd0NvbXBsZXRlZCIsInNob3ciLCJzaG93Q29tcGxldGVkIiwidXBWb3RlSXRlbSIsInZvdGVDb3VudCIsInZvdGVzIiwiU2ltcGxlU2NoZW1hIiwibW9kdWxlMSIsIlJldHJvSXRlbSIsInR5cGUiLCJTdHJpbmciLCJyZWdFeCIsIlJlZ0V4IiwiSWQiLCJvcHRpb25hbCIsInRpdGxlIiwibWF4IiwiYWxsb3dlZFZhbHVlcyIsIml0ZW1UeXBlIiwiTnVtYmVyIiwiY3JlYXRlZEF0IiwiYXV0b1ZhbHVlIiwiaXNJbnNlcnQiLCJ1bnNldCIsIkJvb2xlYW4iLCJkZWZhdWx0VmFsdWUiLCJhcmNoaXZlZEF0IiwiaGFwcHlQbGFjZWhvbGRlciIsIm1laFBsYWNlaG9sZGVyIiwic2FkUGxhY2Vob2xkZXIiLCJhcmNoaXZlTmFtZSIsIkFjdGlvbnMiLCJOZXdUZWFtIiwibmFtZSIsIm1pbiIsImRlc2NyaXB0aW9uIiwicGFzc3dvcmQiLCJjb25maXJtUGFzc3dvcmQiLCJjdXN0b20iLCJ2YWx1ZSIsImZpZWxkIiwiU2V0dGluZ3MiLCJiYWNrZ3JvdW5kSW1hZ2UiLCJNb25nbyIsInByb3RvdHlwZSIsInRvUHJvcGVyQ2FzZSIsInJlcGxhY2UiLCJ0eHQiLCJjaGFyQXQiLCJ0b1VwcGVyQ2FzZSIsInN1YnN0ciIsInRvTG93ZXJDYXNlIiwiQ29sbGVjdGlvbiIsIkJhY2tncm91bmRzIiwiYXR0YWNoU2NoZW1hIiwiU2VxdWVudCIsImFyY2hpdmVSb3V0ZU5hbWUiLCJkZWZhdWx0QmFja2dyb3VuZCIsImRlZmF1bHRDb25maXJtTXNnIiwiVG9hc3RUaW1lT3V0IiwiRU1BSUxfVEFSR0VUIiwicGFnZVNpemUiLCJnZXRTZXR0aW5ncyIsInNldHRpbmdzIiwic2FuaXRpemVIdG1sIiwiZGVmYXVsdCIsImNsZWFuSW5wdXQiLCJpbnB1dCIsImRlZmF1bHRWYWwiLCJhbGxvd2VkVGFncyIsImV4cG9ydERlZmF1bHQiLCJtb21lbnQiLCJpbnB1dE5hbWUiLCJkYXRlVmFsIiwibmV3TmFtZSIsImFyY2hpdmVSZXRybyIsImZvcm1hdCIsImZzIiwiY29tcG9uZW50SW1hZ2VzIiwiaW1hZ2VzIiwibWV0ZW9yUm9vdCIsInJlYWxwYXRoU3luYyIsInByb2Nlc3MiLCJjd2QiLCJwdWJsaWNQYXRoIiwiYmFja2dyb3VuZFBhdGgiLCJiZ3MiLCJyZWFkZGlyU3luYyIsImZpbGVzIiwiZWxtIiwibWF0Y2giLCJlYWNoIiwiaW1nIiwicHVzaCIsImZpbGVOYW1lIiwiY3JlYXRlUmV0cm9BY3Rpb24iLCJpbnNlcnQiLCJjcmVhdGVSZXRyb0l0ZW0iLCJuZXdUaXRsZSIsInJldHJvRG9jIiwiZG9jIiwiaWQiLCJpc0FycmF5IiwiJHB1c2giLCJNYXRjaCIsInNhdmVTZXR0aW5ncyIsInZhbGlkYXRlIiwiaGFwcHkiLCJtZWgiLCJzYWQiLCJpc1VuZGVmaW5lZCIsIlNlcnZlclV0aWxzIiwic2VuZEFjdGlvbnNCeUVtYWlsIiwiY3VycmVudFJldHJvIiwidGFyZ2V0RW1haWwiLCJlbWFpbFRvVXNlIiwibmV3RW1haWwiLCJhY3Rpb25zIiwiZmluZCIsIiRndCIsIm5vdyIsImZldGNoIiwiZGF0YSIsInVzZXIiLCJ1c2VycyIsInJldHJvTmFtZSIsInVzZXJuYW1lIiwiY3VycmVudFllYXIiLCJnZXRGdWxsWWVhciIsInJldHJvSXRlbXMiLCJzb3J0QnkiLCJmb3JFYWNoIiwiaXNDb21wbGV0ZSIsIml0ZW1TdHlsZSIsImZyb20iLCJlbnYiLCJGUk9NX0VNQUlMX0FERFJFU1MiLCJzZW5kSHRtbEVtYWlsIiwidXBkYXRlQWN0aW9uVGl0bGUiLCJ1cGRhdGVSZXRyb0l0ZW1UaXRsZSIsInB1Ymxpc2giLCJzZWxmIiwiYmFja2dyb3VuZCIsImJhY2tncm91bmROYW1lIiwic3BsaXQiLCJhZGRlZCIsInJlYWR5IiwiX2Vuc3VyZUluZGV4Iiwic3RvcCIsInNlYXJjaCIsInRlc3QiLCJsaW1pdCIsInNob3dBbGwiLCJxdWVyeSIsInNvcnQiLCIkaW4iLCJTU1IiLCJFbWFpbCIsImNoZWNrIiwiY29tcGlsZVRlbXBsYXRlIiwiQXNzZXRzIiwiZ2V0VGV4dCIsIlRlbXBsYXRlIiwiYWN0aW9uSXRlbXMiLCJoZWxwZXJzIiwic2VuZEVtYWlsIiwidG8iLCJzdWJqZWN0IiwidGV4dCIsImRlZmVyIiwic2VuZCIsInRlbXBsYXRlTmFtZSIsImJvZHkiLCJyZW5kZXIiLCJodG1sIiwic3RhcnR1cCIsImV4cG9ydCIsIndpdGhSZW5kZXJlZFRlbXBsYXRlIiwiQmxhemUiLCJUcmFja2VyIiwid2l0aERpdiIsImNhbGxiYWNrIiwiZWwiLCJkb2N1bWVudCIsImNyZWF0ZUVsZW1lbnQiLCJhcHBlbmRDaGlsZCIsInJlbW92ZUNoaWxkIiwidGVtcGxhdGUiLCJ0aGVUZW1wbGF0ZSIsImlzU3RyaW5nIiwicmVuZGVyV2l0aERhdGEiLCJmbHVzaCIsIlRlc3REYXRhIiwiZmFrZVNldHRpbmdzIiwicGFyYW1ldGVycyIsInBhcm1zIiwiZmFrZUJhY2tncm91bmRzQXJyYXkiLCJmYWtlUmV0cm9BY3Rpb24iLCJSZXRyb0FjdGlvbiIsImZha2VSZXRyb0l0ZW0iLCJjaG9pY2UiLCJmYWtlUmV0cm9JdGVtcyIsImNvdW50IiwiaSIsImZha2VSZXRybyIsIlJldHJvIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxRQUFNQSxTQUFTLEdBQUc7QUFDZEMsaUJBQWEsRUFBRTtBQUNYQyxZQUFNLEVBQUUsUUFERztBQUVYQyxjQUFRLEVBQUUsVUFGQztBQUdYQyxZQUFNLEVBQUUsUUFIRztBQUlYQyxZQUFNLEVBQUUsQ0FBQyxRQUFELEVBQVcsVUFBWCxFQUF1QixRQUF2QjtBQUpHLEtBREQ7QUFPZEMscUJBQWlCLEVBQUU7QUFDZkMsYUFBTyxFQUFFLFNBRE07QUFFZkMsY0FBUSxFQUFFLFVBRks7QUFHZkgsWUFBTSxFQUFFLENBQUMsU0FBRCxFQUFZLFVBQVo7QUFITyxLQVBMO0FBWWRJLGtCQUFjLEVBQUU7QUFDWkMsV0FBSyxFQUFFLE9BREs7QUFFWkMsU0FBRyxFQUFFLEtBRk87QUFHWkMsU0FBRyxFQUFFLEtBSE87QUFJWkMsWUFBTSxFQUFFLFFBSkk7QUFLWlIsWUFBTSxFQUFFLENBQUMsT0FBRCxFQUFVLEtBQVYsRUFBaUIsS0FBakIsRUFBd0IsUUFBeEI7QUFMSTtBQVpGLEdBQWxCO0FBcUJBUyxRQUFNLENBQUNDLE9BQVAsR0FBaUI7QUFBRWY7QUFBRixHQUFqQjs7Ozs7Ozs7Ozs7OztBQ3JCQSxRQUFNZ0IsTUFBTSxHQUFHO0FBQ1hDLE9BQUcsRUFBR0MsT0FBRCxJQUFhO0FBQ2RDLGFBQU8sQ0FBQ0YsR0FBUixDQUFZQyxPQUFaO0FBQ0g7QUFIVSxHQUFmO0FBTUFKLFFBQU0sQ0FBQ0MsT0FBUCxHQUFpQjtBQUFFQztBQUFGLEdBQWpCOzs7Ozs7Ozs7Ozs7QUNOQSxJQUFJSSxNQUFKO0FBQVdOLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLE1BQUo7QUFBV1QsTUFBTSxDQUFDTyxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDRSxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUzs7QUFBcEIsQ0FBeEIsRUFBOEMsQ0FBOUM7QUFBaUQsSUFBSUUsT0FBSjtBQUFZVixNQUFNLENBQUNPLElBQVAsQ0FBWSxXQUFaLEVBQXdCO0FBQUNHLFNBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLFdBQU8sR0FBQ0YsQ0FBUjtBQUFVOztBQUF0QixDQUF4QixFQUFnRCxDQUFoRDtBQUFtRCxJQUFJdEIsU0FBSjtBQUFjYyxNQUFNLENBQUNPLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNyQixXQUFTLENBQUNzQixDQUFELEVBQUc7QUFBQ3RCLGFBQVMsR0FBQ3NCLENBQVY7QUFBWTs7QUFBMUIsQ0FBMUIsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSU4sTUFBSjtBQUFXRixNQUFNLENBQUNPLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUNMLFFBQU0sQ0FBQ00sQ0FBRCxFQUFHO0FBQUNOLFVBQU0sR0FBQ00sQ0FBUDtBQUFTOztBQUFwQixDQUF2QixFQUE2QyxDQUE3QztBQU03UUYsTUFBTSxDQUFDSyxPQUFQLENBQWU7QUFFWEMsbUJBQWlCLENBQUNDLE1BQUQsRUFBUztBQUN0QixVQUFNQyxPQUFPLEdBQUcsRUFBaEI7O0FBRUEsUUFBSSxDQUFDLEtBQUtDLE1BQVYsRUFBa0I7QUFDZCxZQUFNLElBQUlULE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQyx3Q0FBbEMsQ0FBTjtBQUNILEtBTHFCLENBT3RCOzs7QUFFQSxVQUFNQyxLQUFLLEdBQUdSLE1BQU0sQ0FBQ1MsT0FBUCxDQUFlO0FBQ3pCQyxlQUFTLEVBQUUsS0FBS0osTUFEUztBQUV6QkssU0FBRyxFQUFFLENBQ0Q7QUFBRUMsY0FBTSxFQUFFbkMsU0FBUyxDQUFDQyxhQUFWLENBQXdCQztBQUFsQyxPQURDLEVBRUQ7QUFBRWlDLGNBQU0sRUFBRW5DLFNBQVMsQ0FBQ0MsYUFBVixDQUF3Qkc7QUFBbEMsT0FGQztBQUZvQixLQUFmLENBQWQsQ0FUc0IsQ0FpQnRCOztBQUNBLFFBQUksQ0FBQzJCLEtBQUwsRUFBWTtBQUNSLFlBQU0sSUFBSVgsTUFBTSxDQUFDVSxLQUFYLENBQWlCLFdBQWpCLEVBQThCLGtCQUE5QixDQUFOO0FBQ0g7O0FBR0QsUUFBSTtBQUNBUCxZQUFNLENBQUNhLE1BQVAsQ0FDSTtBQUNJQyxXQUFHLEVBQUVOLEtBQUssQ0FBQ00sR0FEZjtBQUVJLHdCQUFnQlY7QUFGcEIsT0FESixFQUtJO0FBQ0lXLFlBQUksRUFBRTtBQUNGLDRCQUFrQnRDLFNBQVMsQ0FBQ00saUJBQVYsQ0FBNEJFO0FBRDVDO0FBRFYsT0FMSjtBQVdILEtBWkQsQ0FZRSxPQUFPK0IsR0FBUCxFQUFZO0FBQ1Z2QixZQUFNLENBQUNDLEdBQVAsQ0FBV3NCLEdBQVg7QUFDQSxZQUFNLElBQUluQixNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0MsK0RBQWxDLENBQU47QUFDSDtBQUNKOztBQXpDVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDTkEsSUFBSVYsTUFBSjtBQUFXTixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxNQUFKLEVBQVdpQixZQUFYO0FBQXdCMUIsTUFBTSxDQUFDTyxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDRSxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUyxHQUFwQjs7QUFBcUJrQixjQUFZLENBQUNsQixDQUFELEVBQUc7QUFBQ2tCLGdCQUFZLEdBQUNsQixDQUFiO0FBQWU7O0FBQXBELENBQXhCLEVBQThFLENBQTlFO0FBQWlGLElBQUlFLE9BQUo7QUFBWVYsTUFBTSxDQUFDTyxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDRyxTQUFPLENBQUNGLENBQUQsRUFBRztBQUFDRSxXQUFPLEdBQUNGLENBQVI7QUFBVTs7QUFBdEIsQ0FBeEIsRUFBZ0QsQ0FBaEQ7QUFBbUQsSUFBSXRCLFNBQUo7QUFBY2MsTUFBTSxDQUFDTyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDckIsV0FBUyxDQUFDc0IsQ0FBRCxFQUFHO0FBQUN0QixhQUFTLEdBQUNzQixDQUFWO0FBQVk7O0FBQTFCLENBQTFCLEVBQXNELENBQXREO0FBQXlELElBQUlOLE1BQUo7QUFBV0YsTUFBTSxDQUFDTyxJQUFQLENBQVksVUFBWixFQUF1QjtBQUFDTCxRQUFNLENBQUNNLENBQUQsRUFBRztBQUFDTixVQUFNLEdBQUNNLENBQVA7QUFBUzs7QUFBcEIsQ0FBdkIsRUFBNkMsQ0FBN0M7QUFNMVRGLE1BQU0sQ0FBQ0ssT0FBUCxDQUFlO0FBRVhnQixjQUFZLENBQUNDLFFBQUQsRUFBVztBQUNuQixVQUFNZCxPQUFPLEdBQUcsRUFBaEI7O0FBRUEsUUFBSSxDQUFDLEtBQUtDLE1BQVYsRUFBa0I7QUFDZCxZQUFNLElBQUlULE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQyx3Q0FBbEMsQ0FBTjtBQUNIOztBQUVELFVBQU1hLE1BQU0sR0FBR0gsWUFBWSxDQUFDUixPQUFiLENBQXFCO0FBQUVLLFNBQUcsRUFBRUssUUFBUDtBQUFpQlQsZUFBUyxFQUFFLEtBQUtKO0FBQWpDLEtBQXJCLENBQWY7O0FBRUEsUUFBSSxDQUFDYyxNQUFMLEVBQWE7QUFDVCxZQUFNLElBQUl2QixNQUFNLENBQUNVLEtBQVgsQ0FBaUIsV0FBakIsRUFBOEIsbUJBQTlCLENBQU47QUFDSDs7QUFDRCxRQUFJO0FBQ0FVLGtCQUFZLENBQUNJLE1BQWIsQ0FBb0I7QUFBRVAsV0FBRyxFQUFFSztBQUFQLE9BQXBCO0FBQ0gsS0FGRCxDQUVFLE9BQU9ILEdBQVAsRUFBWTtBQUNWdkIsWUFBTSxDQUFDQyxHQUFQLENBQVdzQixHQUFYO0FBQ0EsWUFBTSxJQUFJbkIsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHlEQUFsQyxDQUFOO0FBQ0g7QUFDSjs7QUFwQlUsQ0FBZixFOzs7Ozs7Ozs7OztBQ05BLElBQUlWLE1BQUo7QUFBV04sTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7O0FBQXFELElBQUl1QixDQUFKOztBQUFNL0IsTUFBTSxDQUFDTyxJQUFQLENBQVksbUJBQVosRUFBZ0M7QUFBQ3dCLEdBQUMsQ0FBQ3ZCLENBQUQsRUFBRztBQUFDdUIsS0FBQyxHQUFDdkIsQ0FBRjtBQUFJOztBQUFWLENBQWhDLEVBQTRDLENBQTVDO0FBQStDLElBQUlDLE1BQUo7QUFBV1QsTUFBTSxDQUFDTyxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDRSxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUzs7QUFBcEIsQ0FBeEIsRUFBOEMsQ0FBOUM7QUFBaUQsSUFBSUUsT0FBSjtBQUFZVixNQUFNLENBQUNPLElBQVAsQ0FBWSxXQUFaLEVBQXdCO0FBQUNHLFNBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLFdBQU8sR0FBQ0YsQ0FBUjtBQUFVOztBQUF0QixDQUF4QixFQUFnRCxDQUFoRDtBQUFtRCxJQUFJdEIsU0FBSjtBQUFjYyxNQUFNLENBQUNPLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNyQixXQUFTLENBQUNzQixDQUFELEVBQUc7QUFBQ3RCLGFBQVMsR0FBQ3NCLENBQVY7QUFBWTs7QUFBMUIsQ0FBMUIsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSU4sTUFBSjtBQUFXRixNQUFNLENBQUNPLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUNMLFFBQU0sQ0FBQ00sQ0FBRCxFQUFHO0FBQUNOLFVBQU0sR0FBQ00sQ0FBUDtBQUFTOztBQUFwQixDQUF2QixFQUE2QyxDQUE3QztBQU9sVUYsTUFBTSxDQUFDSyxPQUFQLENBQWU7QUFFWHFCLGlCQUFlLENBQUNuQixNQUFELEVBQVM7QUFDcEIsVUFBTUMsT0FBTyxHQUFHLEVBQWhCOztBQUVBLFFBQUksQ0FBQyxLQUFLQyxNQUFWLEVBQWtCO0FBQ2QsWUFBTSxJQUFJVCxNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0Msd0NBQWxDLENBQU47QUFDSDs7QUFFRCxVQUFNQyxLQUFLLEdBQUdSLE1BQU0sQ0FBQ1MsT0FBUCxDQUFlO0FBQ3pCQyxlQUFTLEVBQUUsS0FBS0osTUFEUztBQUV6QkssU0FBRyxFQUFFLENBQ0Q7QUFBRUMsY0FBTSxFQUFFbkMsU0FBUyxDQUFDQyxhQUFWLENBQXdCQztBQUFsQyxPQURDLEVBRUQ7QUFBRWlDLGNBQU0sRUFBRW5DLFNBQVMsQ0FBQ0MsYUFBVixDQUF3Qkc7QUFBbEMsT0FGQztBQUZvQixLQUFmLENBQWQsQ0FQb0IsQ0FlcEI7O0FBQ0EsUUFBSSxDQUFDMkIsS0FBTCxFQUFZO0FBQ1IsWUFBTSxJQUFJWCxNQUFNLENBQUNVLEtBQVgsQ0FBaUIsV0FBakIsRUFBOEIsa0JBQTlCLENBQU47QUFDSDs7QUFFRCxVQUFNaUIsU0FBUyxHQUFHRixDQUFDLENBQUNHLE1BQUYsQ0FBU2pCLEtBQUssQ0FBQ2tCLEtBQWYsRUFBc0IsVUFBVUMsSUFBVixFQUFnQjtBQUNwRCxhQUFPQSxJQUFJLENBQUN2QixNQUFMLEtBQWdCQSxNQUF2QjtBQUNILEtBRmlCLENBQWxCOztBQUlBLFFBQUlvQixTQUFTLENBQUNJLE1BQVYsS0FBcUIsQ0FBekIsRUFBNEI7QUFDeEIsWUFBTSxJQUFJL0IsTUFBTSxDQUFDVSxLQUFYLENBQWlCLFdBQWpCLEVBQThCLHVCQUE5QixDQUFOO0FBQ0g7O0FBRUQsUUFBSTtBQUNBUCxZQUFNLENBQUNhLE1BQVAsQ0FDSTtBQUNJQyxXQUFHLEVBQUVOLEtBQUssQ0FBQ007QUFEZixPQURKLEVBSUk7QUFDSWUsYUFBSyxFQUFFO0FBQ0hILGVBQUssRUFBRTtBQUFFdEIsa0JBQU0sRUFBRUE7QUFBVjtBQURKO0FBRFgsT0FKSjtBQVVILEtBWEQsQ0FXRSxPQUFPWSxHQUFQLEVBQVk7QUFDVnZCLFlBQU0sQ0FBQ0MsR0FBUCxDQUFXc0IsR0FBWDtBQUNBLFlBQU0sSUFBSW5CLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQyx5REFBbEMsQ0FBTjtBQUNIO0FBQ0o7O0FBN0NVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNQQSxJQUFJVixNQUFKO0FBQVdOLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUkrQixNQUFKO0FBQVd2QyxNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNnQyxRQUFNLENBQUMvQixDQUFELEVBQUc7QUFBQytCLFVBQU0sR0FBQy9CLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsTUFBSixFQUFXaUIsWUFBWDtBQUF3QjFCLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTLEdBQXBCOztBQUFxQmtCLGNBQVksQ0FBQ2xCLENBQUQsRUFBRztBQUFDa0IsZ0JBQVksR0FBQ2xCLENBQWI7QUFBZTs7QUFBcEQsQ0FBN0IsRUFBbUYsQ0FBbkY7QUFBc0YsSUFBSUUsT0FBSjtBQUFZVixNQUFNLENBQUNPLElBQVAsQ0FBWSxXQUFaLEVBQXdCO0FBQUNHLFNBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLFdBQU8sR0FBQ0YsQ0FBUjtBQUFVOztBQUF0QixDQUF4QixFQUFnRCxDQUFoRDtBQUFtRCxJQUFJdEIsU0FBSjtBQUFjYyxNQUFNLENBQUNPLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNyQixXQUFTLENBQUNzQixDQUFELEVBQUc7QUFBQ3RCLGFBQVMsR0FBQ3NCLENBQVY7QUFBWTs7QUFBMUIsQ0FBMUIsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSU4sTUFBSjtBQUFXRixNQUFNLENBQUNPLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUNMLFFBQU0sQ0FBQ00sQ0FBRCxFQUFHO0FBQUNOLFVBQU0sR0FBQ00sQ0FBUDtBQUFTOztBQUFwQixDQUF2QixFQUE2QyxDQUE3QztBQU8vWEYsTUFBTSxDQUFDSyxPQUFQLENBQWU7QUFFWDZCLGNBQVksQ0FBQ1osUUFBRCxFQUFXO0FBQ25CLFVBQU1kLE9BQU8sR0FBRyxFQUFoQjs7QUFFQSxRQUFJLENBQUMsS0FBS0MsTUFBVixFQUFrQjtBQUNkLFlBQU0sSUFBSVQsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHdDQUFsQyxDQUFOO0FBQ0g7O0FBRUQsVUFBTWEsTUFBTSxHQUFHSCxZQUFZLENBQUNSLE9BQWIsQ0FBcUI7QUFBRUssU0FBRyxFQUFFSyxRQUFQO0FBQWlCVCxlQUFTLEVBQUUsS0FBS0o7QUFBakMsS0FBckIsQ0FBZjs7QUFFQSxRQUFJLENBQUNjLE1BQUwsRUFBYTtBQUNULFlBQU0sSUFBSXZCLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixXQUFqQixFQUE4Qix3QkFBOUIsQ0FBTjtBQUNIOztBQUVELFVBQU15QixRQUFRLEdBQUdaLE1BQU0sQ0FBQ1IsTUFBUCxLQUFrQm5DLFNBQVMsQ0FBQ00saUJBQVYsQ0FBNEJDLE9BQTlDLEdBQXdEUCxTQUFTLENBQUNNLGlCQUFWLENBQTRCRSxRQUFwRixHQUErRlIsU0FBUyxDQUFDTSxpQkFBVixDQUE0QkMsT0FBNUk7QUFFQSxRQUFJaUQsT0FBSjs7QUFFQSxRQUFJRCxRQUFRLEtBQUt2RCxTQUFTLENBQUNNLGlCQUFWLENBQTRCRSxRQUE3QyxFQUF1RDtBQUNuRGdELGFBQU8sR0FBRyxJQUFJQyxJQUFKLEVBQVY7QUFDSCxLQUZELE1BRU87QUFDSEQsYUFBTyxHQUFHLElBQVY7QUFDSDs7QUFHRCxRQUFJO0FBQ0FoQixrQkFBWSxDQUFDSixNQUFiLENBQ0k7QUFBRUMsV0FBRyxFQUFFSztBQUFQLE9BREosRUFFSTtBQUNJSixZQUFJLEVBQ0o7QUFDSUgsZ0JBQU0sRUFBRW9CLFFBRFo7QUFFSUcscUJBQVcsRUFBRUY7QUFGakI7QUFGSixPQUZKO0FBVUgsS0FYRCxDQVdFLE9BQU9qQixHQUFQLEVBQVk7QUFDVnZCLFlBQU0sQ0FBQ0MsR0FBUCxDQUFXc0IsR0FBWDtBQUNBLFlBQU0sSUFBSW5CLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQyx5REFBbEMsQ0FBTjtBQUNIO0FBQ0o7O0FBekNVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNQQSxJQUFJVixNQUFKO0FBQVdOLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLE1BQUosRUFBV2lCLFlBQVg7QUFBd0IxQixNQUFNLENBQUNPLElBQVAsQ0FBWSxXQUFaLEVBQXdCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTLEdBQXBCOztBQUFxQmtCLGNBQVksQ0FBQ2xCLENBQUQsRUFBRztBQUFDa0IsZ0JBQVksR0FBQ2xCLENBQWI7QUFBZTs7QUFBcEQsQ0FBeEIsRUFBOEUsQ0FBOUU7QUFBaUYsSUFBSUUsT0FBSjtBQUFZVixNQUFNLENBQUNPLElBQVAsQ0FBWSxXQUFaLEVBQXdCO0FBQUNHLFNBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLFdBQU8sR0FBQ0YsQ0FBUjtBQUFVOztBQUF0QixDQUF4QixFQUFnRCxDQUFoRDtBQUFtRCxJQUFJdEIsU0FBSjtBQUFjYyxNQUFNLENBQUNPLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNyQixXQUFTLENBQUNzQixDQUFELEVBQUc7QUFBQ3RCLGFBQVMsR0FBQ3NCLENBQVY7QUFBWTs7QUFBMUIsQ0FBMUIsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSU4sTUFBSjtBQUFXRixNQUFNLENBQUNPLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUNMLFFBQU0sQ0FBQ00sQ0FBRCxFQUFHO0FBQUNOLFVBQU0sR0FBQ00sQ0FBUDtBQUFTOztBQUFwQixDQUF2QixFQUE2QyxDQUE3QztBQU0xVEYsTUFBTSxDQUFDSyxPQUFQLENBQWU7QUFFWGtDLG1CQUFpQixHQUFHO0FBQ2hCLFVBQU0vQixPQUFPLEdBQUcsRUFBaEI7O0FBRUEsUUFBSSxDQUFDLEtBQUtDLE1BQVYsRUFBa0I7QUFDZCxZQUFNLElBQUlULE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQyx3Q0FBbEMsQ0FBTjtBQUNILEtBTGUsQ0FPaEI7OztBQUVBLFVBQU1DLEtBQUssR0FBR1IsTUFBTSxDQUFDUyxPQUFQLENBQWU7QUFDekJDLGVBQVMsRUFBRSxLQUFLSixNQURTO0FBRXpCSyxTQUFHLEVBQ0gsQ0FDSTtBQUFFQyxjQUFNLEVBQUVuQyxTQUFTLENBQUNDLGFBQVYsQ0FBd0JDO0FBQWxDLE9BREosRUFFSTtBQUFFaUMsY0FBTSxFQUFFbkMsU0FBUyxDQUFDQyxhQUFWLENBQXdCRztBQUFsQyxPQUZKO0FBSHlCLEtBQWYsQ0FBZCxDQVRnQixDQWtCaEI7O0FBQ0EsUUFBSSxDQUFDMkIsS0FBTCxFQUFZO0FBQ1IsWUFBTSxJQUFJWCxNQUFNLENBQUNVLEtBQVgsQ0FBaUIsV0FBakIsRUFBOEIsa0JBQTlCLENBQU47QUFDSDs7QUFFRCxRQUFJQyxLQUFLLENBQUNJLE1BQU4sS0FBaUJuQyxTQUFTLENBQUNDLGFBQVYsQ0FBd0JFLFFBQTdDLEVBQXVEO0FBQ25ELFlBQU0sSUFBSWlCLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQyw2QkFBbEMsQ0FBTjtBQUNIOztBQUVELFVBQU04QixTQUFTLEdBQUc3QixLQUFLLENBQUNJLE1BQU4sS0FBaUJuQyxTQUFTLENBQUNDLGFBQVYsQ0FBd0JHLE1BQXpDLEdBQWtESixTQUFTLENBQUNDLGFBQVYsQ0FBd0JDLE1BQTFFLEdBQW1GRixTQUFTLENBQUNDLGFBQVYsQ0FBd0JHLE1BQTdIOztBQUVBLFFBQUk7QUFDQW1CLFlBQU0sQ0FBQ2EsTUFBUCxDQUNJO0FBQUVDLFdBQUcsRUFBRU4sS0FBSyxDQUFDTTtBQUFiLE9BREosRUFFSTtBQUNJQyxZQUFJLEVBQ0o7QUFBRUgsZ0JBQU0sRUFBRXlCO0FBQVY7QUFGSixPQUZKO0FBT0gsS0FSRCxDQVFFLE9BQU9yQixHQUFQLEVBQVk7QUFDVnZCLFlBQU0sQ0FBQ0MsR0FBUCxDQUFXc0IsR0FBWDtBQUNBLFlBQU0sSUFBSW5CLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQyx3REFBbEMsQ0FBTjtBQUNIO0FBQ0o7O0FBM0NVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNOQSxJQUFJVixNQUFKO0FBQVdOLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLE1BQUosRUFBV2lCLFlBQVg7QUFBd0IxQixNQUFNLENBQUNPLElBQVAsQ0FBWSxXQUFaLEVBQXdCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTLEdBQXBCOztBQUFxQmtCLGNBQVksQ0FBQ2xCLENBQUQsRUFBRztBQUFDa0IsZ0JBQVksR0FBQ2xCLENBQWI7QUFBZTs7QUFBcEQsQ0FBeEIsRUFBOEUsQ0FBOUU7QUFBaUYsSUFBSUUsT0FBSjtBQUFZVixNQUFNLENBQUNPLElBQVAsQ0FBWSxXQUFaLEVBQXdCO0FBQUNHLFNBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLFdBQU8sR0FBQ0YsQ0FBUjtBQUFVOztBQUF0QixDQUF4QixFQUFnRCxDQUFoRDtBQUFtRCxJQUFJdEIsU0FBSjtBQUFjYyxNQUFNLENBQUNPLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNyQixXQUFTLENBQUNzQixDQUFELEVBQUc7QUFBQ3RCLGFBQVMsR0FBQ3NCLENBQVY7QUFBWTs7QUFBMUIsQ0FBMUIsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSU4sTUFBSjtBQUFXRixNQUFNLENBQUNPLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUNMLFFBQU0sQ0FBQ00sQ0FBRCxFQUFHO0FBQUNOLFVBQU0sR0FBQ00sQ0FBUDtBQUFTOztBQUFwQixDQUF2QixFQUE2QyxDQUE3QztBQU0xVEYsTUFBTSxDQUFDSyxPQUFQLENBQWU7QUFFWG9DLHFCQUFtQixHQUFHO0FBQ2xCLFVBQU1qQyxPQUFPLEdBQUcsRUFBaEI7O0FBRUEsUUFBSSxDQUFDLEtBQUtDLE1BQVYsRUFBa0I7QUFDZCxZQUFNLElBQUlULE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQyx3Q0FBbEMsQ0FBTjtBQUNIOztBQUVELFVBQU1DLEtBQUssR0FBR1IsTUFBTSxDQUFDUyxPQUFQLENBQWU7QUFDekJDLGVBQVMsRUFBRSxLQUFLSixNQURTO0FBRXpCSyxTQUFHLEVBQ0gsQ0FDSTtBQUFFQyxjQUFNLEVBQUVuQyxTQUFTLENBQUNDLGFBQVYsQ0FBd0JDO0FBQWxDLE9BREosRUFFSTtBQUFFaUMsY0FBTSxFQUFFbkMsU0FBUyxDQUFDQyxhQUFWLENBQXdCRztBQUFsQyxPQUZKO0FBSHlCLEtBQWYsQ0FBZCxDQVBrQixDQWdCbEI7O0FBQ0EsUUFBSSxDQUFDMkIsS0FBTCxFQUFZO0FBQ1IsWUFBTSxJQUFJWCxNQUFNLENBQUNVLEtBQVgsQ0FBaUIsV0FBakIsRUFBOEIsa0JBQTlCLENBQU47QUFDSDs7QUFFRCxVQUFNZ0MsSUFBSSxHQUFHLENBQUMvQixLQUFLLENBQUNnQyxhQUFwQjs7QUFFQSxRQUFJO0FBQ0F4QyxZQUFNLENBQUNhLE1BQVAsQ0FDSTtBQUNJQyxXQUFHLEVBQUVOLEtBQUssQ0FBQ007QUFEZixPQURKLEVBSUk7QUFDSUMsWUFBSSxFQUNKO0FBQ0l5Qix1QkFBYSxFQUFFRDtBQURuQjtBQUZKLE9BSko7QUFXSCxLQVpELENBWUUsT0FBT3ZCLEdBQVAsRUFBWTtBQUNWdkIsWUFBTSxDQUFDQyxHQUFQLENBQVdzQixHQUFYO0FBQ0EsWUFBTSxJQUFJbkIsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLCtEQUFsQyxDQUFOO0FBQ0g7QUFDSjs7QUF6Q1UsQ0FBZixFOzs7Ozs7Ozs7OztBQ05BLElBQUlWLE1BQUo7QUFBV04sTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7O0FBQXFELElBQUl1QixDQUFKOztBQUFNL0IsTUFBTSxDQUFDTyxJQUFQLENBQVksbUJBQVosRUFBZ0M7QUFBQ3dCLEdBQUMsQ0FBQ3ZCLENBQUQsRUFBRztBQUFDdUIsS0FBQyxHQUFDdkIsQ0FBRjtBQUFJOztBQUFWLENBQWhDLEVBQTRDLENBQTVDO0FBQStDLElBQUlDLE1BQUo7QUFBV1QsTUFBTSxDQUFDTyxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDRSxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUzs7QUFBcEIsQ0FBeEIsRUFBOEMsQ0FBOUM7QUFBaUQsSUFBSUUsT0FBSjtBQUFZVixNQUFNLENBQUNPLElBQVAsQ0FBWSxXQUFaLEVBQXdCO0FBQUNHLFNBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLFdBQU8sR0FBQ0YsQ0FBUjtBQUFVOztBQUF0QixDQUF4QixFQUFnRCxDQUFoRDtBQUFtRCxJQUFJdEIsU0FBSjtBQUFjYyxNQUFNLENBQUNPLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNyQixXQUFTLENBQUNzQixDQUFELEVBQUc7QUFBQ3RCLGFBQVMsR0FBQ3NCLENBQVY7QUFBWTs7QUFBMUIsQ0FBMUIsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSU4sTUFBSjtBQUFXRixNQUFNLENBQUNPLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUNMLFFBQU0sQ0FBQ00sQ0FBRCxFQUFHO0FBQUNOLFVBQU0sR0FBQ00sQ0FBUDtBQUFTOztBQUFwQixDQUF2QixFQUE2QyxDQUE3QztBQU9sVUYsTUFBTSxDQUFDSyxPQUFQLENBQWU7QUFFWHVDLFlBQVUsQ0FBQ3JDLE1BQUQsRUFBUztBQUNmLFVBQU1DLE9BQU8sR0FBRyxFQUFoQjs7QUFFQSxRQUFJLENBQUMsS0FBS0MsTUFBVixFQUFrQjtBQUNkLFlBQU0sSUFBSVQsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHdDQUFsQyxDQUFOO0FBQ0gsS0FMYyxDQU9mOzs7QUFFQSxVQUFNQyxLQUFLLEdBQUdSLE1BQU0sQ0FBQ1MsT0FBUCxDQUFlO0FBQ3pCQyxlQUFTLEVBQUUsS0FBS0osTUFEUztBQUV6Qk0sWUFBTSxFQUFFbkMsU0FBUyxDQUFDQyxhQUFWLENBQXdCQztBQUZQLEtBQWYsQ0FBZCxDQVRlLENBY2Y7O0FBQ0EsUUFBSSxDQUFDNkIsS0FBTCxFQUFZO0FBQ1IsWUFBTSxJQUFJWCxNQUFNLENBQUNVLEtBQVgsQ0FBaUIsV0FBakIsRUFBOEIsa0JBQTlCLENBQU47QUFDSDs7QUFFRCxVQUFNaUIsU0FBUyxHQUFHRixDQUFDLENBQUNHLE1BQUYsQ0FBU2pCLEtBQUssQ0FBQ2tCLEtBQWYsRUFBc0IsVUFBVUMsSUFBVixFQUFnQjtBQUNwRCxhQUFPQSxJQUFJLENBQUN2QixNQUFMLEtBQWdCQSxNQUF2QjtBQUNILEtBRmlCLENBQWxCOztBQUlBLFFBQUlvQixTQUFTLENBQUNJLE1BQVYsS0FBcUIsQ0FBekIsRUFBNEI7QUFDeEIsWUFBTSxJQUFJL0IsTUFBTSxDQUFDVSxLQUFYLENBQWlCLFdBQWpCLEVBQThCLHVCQUE5QixDQUFOO0FBQ0g7O0FBRUQsUUFBSW1DLFNBQVMsR0FBR2xCLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYW1CLEtBQWIsSUFBc0IsQ0FBdEM7QUFFQUQsYUFBUyxJQUFJLENBQWI7O0FBRUEsUUFBSTtBQUNBMUMsWUFBTSxDQUFDYSxNQUFQLENBQ0k7QUFDSUMsV0FBRyxFQUFFTixLQUFLLENBQUNNLEdBRGY7QUFFSSx3QkFBZ0JWO0FBRnBCLE9BREosRUFLSTtBQUNJVyxZQUFJLEVBQUU7QUFDRiwyQkFBaUIyQjtBQURmO0FBRFYsT0FMSjtBQVdILEtBWkQsQ0FZRSxPQUFPMUIsR0FBUCxFQUFZO0FBQ1Z2QixZQUFNLENBQUNDLEdBQVAsQ0FBV3NCLEdBQVg7QUFDQSxZQUFNLElBQUluQixNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0Msd0RBQWxDLENBQU47QUFDSDtBQUNKOztBQWpEVSxDQUFmLEU7Ozs7Ozs7Ozs7OztBQ1BBLE1BQUlxQyxZQUFKO0FBQWlCQyxTQUFPLENBQUMvQyxJQUFSLENBQWEsNkJBQWIsRUFBMkM7QUFBQzhDLGdCQUFZLENBQUM3QyxDQUFELEVBQUc7QUFBQzZDLGtCQUFZLEdBQUM3QyxDQUFiO0FBQWU7O0FBQWhDLEdBQTNDLEVBQTZFLENBQTdFO0FBQWdGLE1BQUl0QixTQUFKO0FBQWNvRSxTQUFPLENBQUMvQyxJQUFSLENBQWEsYUFBYixFQUEyQjtBQUFDckIsYUFBUyxDQUFDc0IsQ0FBRCxFQUFHO0FBQUN0QixlQUFTLEdBQUNzQixDQUFWO0FBQVk7O0FBQTFCLEdBQTNCLEVBQXVELENBQXZEO0FBSS9HLFFBQU1FLE9BQU8sR0FBRyxFQUFoQjtBQUVBQSxTQUFPLENBQUM2QyxTQUFSLEdBQW9CLElBQUlGLFlBQUosQ0FBaUI7QUFFakN4QyxVQUFNLEVBQUU7QUFDSjJDLFVBQUksRUFBRUMsTUFERjtBQUVKQyxXQUFLLEVBQUVMLFlBQVksQ0FBQ00sS0FBYixDQUFtQkMsRUFGdEI7QUFHSkMsY0FBUSxFQUFFO0FBSE4sS0FGeUI7QUFPakNDLFNBQUssRUFBRTtBQUNITixVQUFJLEVBQUVDLE1BREg7QUFFSE0sU0FBRyxFQUFFO0FBRkYsS0FQMEI7QUFXakMxQyxVQUFNLEVBQUU7QUFDSm1DLFVBQUksRUFBRUMsTUFERjtBQUVKTyxtQkFBYSxFQUFFOUUsU0FBUyxDQUFDTSxpQkFBVixDQUE0QkQ7QUFGdkMsS0FYeUI7QUFlakMwRSxZQUFRLEVBQUU7QUFDTlQsVUFBSSxFQUFFQyxNQURBO0FBRU5PLG1CQUFhLEVBQUU5RSxTQUFTLENBQUNTLGNBQVYsQ0FBeUJKO0FBRmxDLEtBZnVCO0FBbUJqQzZELFNBQUssRUFBRTtBQUNISSxVQUFJLEVBQUVVLE1BREg7QUFFSEwsY0FBUSxFQUFFO0FBRlAsS0FuQjBCO0FBdUJqQ00sYUFBUyxFQUFFO0FBQ1BYLFVBQUksRUFBRWI7QUFEQztBQXZCc0IsR0FBakIsQ0FBcEI7QUE2QkFqQyxTQUFPLENBQUNELE1BQVIsR0FBaUIsSUFBSTRDLFlBQUosQ0FBaUI7QUFFOUI5QixPQUFHLEVBQUU7QUFDRGlDLFVBQUksRUFBRUMsTUFETDtBQUVEQyxXQUFLLEVBQUVMLFlBQVksQ0FBQ00sS0FBYixDQUFtQkMsRUFGekI7QUFHREMsY0FBUSxFQUFFO0FBSFQsS0FGeUI7QUFPOUJNLGFBQVMsRUFBRTtBQUNQWCxVQUFJLEVBQUViLElBREM7QUFFUHlCLGVBQVMsRUFBRSxZQUFZO0FBQ25CLFlBQUksS0FBS0MsUUFBVCxFQUFtQjtBQUNmLGlCQUFPLElBQUkxQixJQUFKLEVBQVA7QUFDSDs7QUFDRCxhQUFLMkIsS0FBTDtBQUNIO0FBUE0sS0FQbUI7QUFnQjlCbkQsYUFBUyxFQUFFO0FBQ1BxQyxVQUFJLEVBQUVDLE1BREM7QUFFUEMsV0FBSyxFQUFFTCxZQUFZLENBQUNNLEtBQWIsQ0FBbUJDLEVBRm5CO0FBR1BRLGVBQVMsRUFBRSxZQUFZO0FBQ25CLFlBQUksS0FBS0MsUUFBVCxFQUFtQjtBQUNmLGlCQUFPLEtBQUt0RCxNQUFaO0FBQ0g7O0FBQ0QsYUFBS3VELEtBQUw7QUFDSDtBQVJNLEtBaEJtQjtBQTBCOUJqRCxVQUFNLEVBQUU7QUFDSm1DLFVBQUksRUFBRUMsTUFERjtBQUVKTyxtQkFBYSxFQUFFOUUsU0FBUyxDQUFDQyxhQUFWLENBQXdCSTtBQUZuQyxLQTFCc0I7QUE4QjlCNEMsU0FBSyxFQUFFO0FBQ0hxQixVQUFJLEVBQUUsQ0FBQzlDLE9BQU8sQ0FBQzZDLFNBQVQ7QUFESCxLQTlCdUI7QUFpQzlCTixpQkFBYSxFQUFFO0FBQ1hPLFVBQUksRUFBRWUsT0FESztBQUVYVixjQUFRLEVBQUUsSUFGQztBQUdYVyxrQkFBWSxFQUFFO0FBSEgsS0FqQ2U7QUFzQzlCQyxjQUFVLEVBQUU7QUFDUmpCLFVBQUksRUFBRWIsSUFERTtBQUVSa0IsY0FBUSxFQUFFO0FBRkYsS0F0Q2tCO0FBMEM5QmEsb0JBQWdCLEVBQUU7QUFDZGxCLFVBQUksRUFBRUMsTUFEUTtBQUVkSSxjQUFRLEVBQUU7QUFGSSxLQTFDWTtBQThDOUJjLGtCQUFjLEVBQUU7QUFDWm5CLFVBQUksRUFBRUMsTUFETTtBQUVaSSxjQUFRLEVBQUU7QUFGRSxLQTlDYztBQWtEOUJlLGtCQUFjLEVBQUU7QUFDWnBCLFVBQUksRUFBRUMsTUFETTtBQUVaSSxjQUFRLEVBQUU7QUFGRSxLQWxEYztBQXNEOUJnQixlQUFXLEVBQUU7QUFDVHJCLFVBQUksRUFBRUMsTUFERztBQUVUSSxjQUFRLEVBQUU7QUFGRDtBQXREaUIsR0FBakIsQ0FBakI7QUE0REFuRCxTQUFPLENBQUNvRSxPQUFSLEdBQWtCLElBQUl6QixZQUFKLENBQWlCO0FBQy9COUIsT0FBRyxFQUFFO0FBQ0RpQyxVQUFJLEVBQUVDLE1BREw7QUFFREMsV0FBSyxFQUFFTCxZQUFZLENBQUNNLEtBQWIsQ0FBbUJDLEVBRnpCO0FBR0RDLGNBQVEsRUFBRTtBQUhULEtBRDBCO0FBTS9CTSxhQUFTLEVBQUU7QUFDUFgsVUFBSSxFQUFFYixJQURDO0FBRVB5QixlQUFTLEVBQUUsWUFBWTtBQUNuQixZQUFJLEtBQUtDLFFBQVQsRUFBbUI7QUFDZixpQkFBTyxJQUFJMUIsSUFBSixFQUFQO0FBQ0g7O0FBRUQsYUFBSzJCLEtBQUw7QUFDSDtBQVJNLEtBTm9CO0FBZ0IvQm5ELGFBQVMsRUFBRTtBQUNQcUMsVUFBSSxFQUFFQyxNQURDO0FBRVBDLFdBQUssRUFBRUwsWUFBWSxDQUFDTSxLQUFiLENBQW1CQyxFQUZuQjtBQUdQUSxlQUFTLEVBQUUsWUFBWTtBQUNuQixZQUFJLEtBQUtDLFFBQVQsRUFBbUI7QUFDZixpQkFBTyxLQUFLdEQsTUFBWjtBQUNIOztBQUNELGFBQUt1RCxLQUFMO0FBQ0g7QUFSTSxLQWhCb0I7QUEwQi9CUixTQUFLLEVBQUU7QUFDSE4sVUFBSSxFQUFFQyxNQURIO0FBRUhNLFNBQUcsRUFBRTtBQUZGLEtBMUJ3QjtBQThCL0IxQyxVQUFNLEVBQUU7QUFDSm1DLFVBQUksRUFBRUMsTUFERjtBQUVKTyxtQkFBYSxFQUFFOUUsU0FBUyxDQUFDTSxpQkFBVixDQUE0QkQ7QUFGdkMsS0E5QnVCO0FBa0MvQnFELGVBQVcsRUFBRTtBQUNUWSxVQUFJLEVBQUViLElBREc7QUFFVGtCLGNBQVEsRUFBRTtBQUZEO0FBbENrQixHQUFqQixDQUFsQjtBQXdDQW5ELFNBQU8sQ0FBQ3FFLE9BQVIsR0FBa0IsSUFBSTFCLFlBQUosQ0FBaUI7QUFDL0IyQixRQUFJLEVBQUU7QUFDRnhCLFVBQUksRUFBRUMsTUFESjtBQUVGTSxTQUFHLEVBQUUsRUFGSDtBQUdGa0IsU0FBRyxFQUFFO0FBSEgsS0FEeUI7QUFNL0JDLGVBQVcsRUFBRTtBQUNUMUIsVUFBSSxFQUFFQyxNQURHO0FBRVRJLGNBQVEsRUFBRSxJQUZEO0FBR1RFLFNBQUcsRUFBRTtBQUhJLEtBTmtCO0FBVy9Cb0IsWUFBUSxFQUFFO0FBQ04zQixVQUFJLEVBQUVDLE1BREE7QUFFTkMsV0FBSyxFQUFFLGdEQUZEO0FBR051QixTQUFHLEVBQUU7QUFIQyxLQVhxQjtBQWdCL0JHLG1CQUFlLEVBQUU7QUFDYjVCLFVBQUksRUFBRUMsTUFETztBQUVid0IsU0FBRyxFQUFFLENBRlE7O0FBR2JJLFlBQU0sR0FBRztBQUNMLFlBQUksS0FBS0MsS0FBTCxLQUFlLEtBQUtDLEtBQUwsQ0FBVyxVQUFYLEVBQXVCRCxLQUExQyxFQUFpRDtBQUM3QyxpQkFBTyxrQkFBUDtBQUNIO0FBQ0o7O0FBUFk7QUFoQmMsR0FBakIsQ0FBbEI7QUEyQkE1RSxTQUFPLENBQUM4RSxRQUFSLEdBQW1CLElBQUluQyxZQUFKLENBQWlCO0FBQ2hDOUIsT0FBRyxFQUFFO0FBQ0RpQyxVQUFJLEVBQUVDLE1BREw7QUFFREMsV0FBSyxFQUFFTCxZQUFZLENBQUNNLEtBQWIsQ0FBbUJDLEVBRnpCO0FBR0RDLGNBQVEsRUFBRTtBQUhULEtBRDJCO0FBTWhDMUMsYUFBUyxFQUFFO0FBQ1BxQyxVQUFJLEVBQUVDLE1BREM7QUFFUEMsV0FBSyxFQUFFTCxZQUFZLENBQUNNLEtBQWIsQ0FBbUJDLEVBRm5CO0FBR1BRLGVBQVMsRUFBRSxZQUFZO0FBQ25CLFlBQUksS0FBS0MsUUFBVCxFQUFtQjtBQUNmLGlCQUFPLEtBQUt0RCxNQUFaO0FBQ0g7O0FBQ0QsYUFBS3VELEtBQUw7QUFDSCxPQVJNO0FBU1BULGNBQVEsRUFBRTtBQVRILEtBTnFCO0FBaUJoQzRCLG1CQUFlLEVBQUU7QUFDYmpDLFVBQUksRUFBRUMsTUFETztBQUViZSxrQkFBWSxFQUFFLDRCQUZEO0FBR2JYLGNBQVEsRUFBRTtBQUhHLEtBakJlO0FBc0JoQ2Esb0JBQWdCLEVBQUU7QUFDZGxCLFVBQUksRUFBRUMsTUFEUTtBQUVkZSxrQkFBWSxFQUFFLElBRkE7QUFHZFgsY0FBUSxFQUFFO0FBSEksS0F0QmM7QUEyQmhDYyxrQkFBYyxFQUFFO0FBQ1puQixVQUFJLEVBQUVDLE1BRE07QUFFWmUsa0JBQVksRUFBRSxJQUZGO0FBR1pYLGNBQVEsRUFBRTtBQUhFLEtBM0JnQjtBQWdDaENlLGtCQUFjLEVBQUU7QUFDWnBCLFVBQUksRUFBRUMsTUFETTtBQUVaZSxrQkFBWSxFQUFFLElBRkY7QUFHWlgsY0FBUSxFQUFFO0FBSEU7QUFoQ2dCLEdBQWpCLENBQW5CO0FBd0NBN0QsUUFBTSxDQUFDQyxPQUFQLEdBQWlCO0FBQUVTO0FBQUYsR0FBakI7Ozs7Ozs7Ozs7Ozs7QUMxTUEsTUFBSWdGLEtBQUo7QUFBVXBDLFNBQU8sQ0FBQy9DLElBQVIsQ0FBYSxjQUFiLEVBQTRCO0FBQUNtRixTQUFLLENBQUNsRixDQUFELEVBQUc7QUFBQ2tGLFdBQUssR0FBQ2xGLENBQU47QUFBUTs7QUFBbEIsR0FBNUIsRUFBZ0QsQ0FBaEQ7QUFBbUQsTUFBSUUsT0FBSjtBQUFZNEMsU0FBTyxDQUFDL0MsSUFBUixDQUFhLFdBQWIsRUFBeUI7QUFBQ0csV0FBTyxDQUFDRixDQUFELEVBQUc7QUFBQ0UsYUFBTyxHQUFDRixDQUFSO0FBQVU7O0FBQXRCLEdBQXpCLEVBQWlELENBQWpEOztBQUd6RSxNQUFJLENBQUNpRCxNQUFNLENBQUNrQyxTQUFQLENBQWlCQyxZQUF0QixFQUFvQztBQUNoQ25DLFVBQU0sQ0FBQ2tDLFNBQVAsQ0FBaUJDLFlBQWpCLEdBQWdDLFlBQVk7QUFDeEMsYUFBTyxLQUFLQyxPQUFMLENBQWEsUUFBYixFQUF1QixVQUFVQyxHQUFWLEVBQWU7QUFBRSxlQUFPQSxHQUFHLENBQUNDLE1BQUosQ0FBVyxDQUFYLEVBQWNDLFdBQWQsS0FBOEJGLEdBQUcsQ0FBQ0csTUFBSixDQUFXLENBQVgsRUFBY0MsV0FBZCxFQUFyQztBQUFtRSxPQUEzRyxDQUFQO0FBQ0gsS0FGRDtBQUdIOztBQUVELFFBQU16RixNQUFNLEdBQUcsSUFBSWlGLEtBQUssQ0FBQ1MsVUFBVixDQUFxQixRQUFyQixDQUFmO0FBQ0EsUUFBTXpFLFlBQVksR0FBRyxJQUFJZ0UsS0FBSyxDQUFDUyxVQUFWLENBQXFCLGVBQXJCLENBQXJCO0FBQ0EsUUFBTUMsV0FBVyxHQUFHLElBQUlWLEtBQUssQ0FBQ1MsVUFBVixDQUFxQixhQUFyQixDQUFwQjtBQUNBLFFBQU1YLFFBQVEsR0FBRyxJQUFJRSxLQUFLLENBQUNTLFVBQVYsQ0FBcUIsVUFBckIsQ0FBakI7QUFFQTFGLFFBQU0sQ0FBQzRGLFlBQVAsQ0FBb0IzRixPQUFPLENBQUNELE1BQTVCO0FBQ0FpQixjQUFZLENBQUMyRSxZQUFiLENBQTBCM0YsT0FBTyxDQUFDb0UsT0FBbEM7QUFDQVUsVUFBUSxDQUFDYSxZQUFULENBQXNCM0YsT0FBTyxDQUFDOEUsUUFBOUI7QUFFQSxRQUFNYyxPQUFPLEdBQUc7QUFDWkMsb0JBQWdCLEVBQUUsVUFETjtBQUVaQyxxQkFBaUIsRUFBRSw0QkFGUDtBQUdaQyxxQkFBaUIsRUFBRSxlQUhQO0FBSVpDLGdCQUFZLEVBQUUsSUFKRjtBQUtaQyxnQkFBWSxFQUFFLGFBTEY7O0FBTVpDLFlBQVEsR0FBRztBQUNQLGFBQU8sRUFBUDtBQUNILEtBUlc7O0FBU1pDLGVBQVcsR0FBRztBQUNWLFVBQUlDLFFBQVEsR0FBR3RCLFFBQVEsQ0FBQ3RFLE9BQVQsRUFBZjs7QUFFQSxVQUFJLENBQUM0RixRQUFMLEVBQWU7QUFDWEEsZ0JBQVEsR0FBRyxFQUFYO0FBQ0FBLGdCQUFRLENBQUNyQixlQUFULEdBQTJCYSxPQUFPLENBQUNFLGlCQUFuQztBQUNBTSxnQkFBUSxDQUFDcEMsZ0JBQVQsR0FBNEIsSUFBNUI7QUFDQW9DLGdCQUFRLENBQUNuQyxjQUFULEdBQTBCLElBQTFCO0FBQ0FtQyxnQkFBUSxDQUFDbEMsY0FBVCxHQUEwQixJQUExQjtBQUNIOztBQUVELGFBQU9rQyxRQUFQO0FBQ0g7O0FBckJXLEdBQWhCO0FBd0JBOUcsUUFBTSxDQUFDQyxPQUFQLEdBQWlCO0FBQ2JxRyxXQURhO0FBQ0o3RixVQURJO0FBQ0lpQixnQkFESjtBQUNrQjBFLGVBRGxCO0FBQytCWjtBQUQvQixHQUFqQjs7Ozs7Ozs7Ozs7O0FDMUNBLElBQUl1QixZQUFKO0FBQWlCL0csTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDeUcsU0FBTyxDQUFDeEcsQ0FBRCxFQUFHO0FBQUN1RyxnQkFBWSxHQUFDdkcsQ0FBYjtBQUFlOztBQUEzQixDQUE1QixFQUF5RCxDQUF6RDs7QUFFakIsTUFBTXlHLFVBQVUsR0FBRyxVQUFDQyxLQUFELEVBQTRCO0FBQUEsTUFBcEJDLFVBQW9CLHVFQUFQLEVBQU87QUFDM0MsUUFBTTdCLEtBQUssR0FBR3lCLFlBQVksQ0FBQ0csS0FBRCxFQUFRO0FBQzlCRSxlQUFXLEVBQUU7QUFEaUIsR0FBUixDQUExQjtBQUdBLFNBQU85QixLQUFLLElBQUk2QixVQUFoQjtBQUNILENBTEQ7O0FBRkFuSCxNQUFNLENBQUNxSCxhQUFQLENBU2VKLFVBVGYsRTs7Ozs7Ozs7Ozs7QUNBQSxJQUFJM0csTUFBSjtBQUFXTixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJOEcsTUFBSjtBQUFXdEgsTUFBTSxDQUFDTyxJQUFQLENBQVksUUFBWixFQUFxQjtBQUFDeUcsU0FBTyxDQUFDeEcsQ0FBRCxFQUFHO0FBQUM4RyxVQUFNLEdBQUM5RyxDQUFQO0FBQVM7O0FBQXJCLENBQXJCLEVBQTRDLENBQTVDO0FBQStDLElBQUlnRixRQUFKLEVBQWEvRSxNQUFiO0FBQW9CVCxNQUFNLENBQUNPLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDaUYsVUFBUSxDQUFDaEYsQ0FBRCxFQUFHO0FBQUNnRixZQUFRLEdBQUNoRixDQUFUO0FBQVcsR0FBeEI7O0FBQXlCQyxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUzs7QUFBNUMsQ0FBN0IsRUFBMkUsQ0FBM0U7QUFBOEUsSUFBSUUsT0FBSjtBQUFZVixNQUFNLENBQUNPLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDRyxTQUFPLENBQUNGLENBQUQsRUFBRztBQUFDRSxXQUFPLEdBQUNGLENBQVI7QUFBVTs7QUFBdEIsQ0FBN0IsRUFBcUQsQ0FBckQ7QUFBd0QsSUFBSXRCLFNBQUo7QUFBY2MsTUFBTSxDQUFDTyxJQUFQLENBQVksa0JBQVosRUFBK0I7QUFBQ3JCLFdBQVMsQ0FBQ3NCLENBQUQsRUFBRztBQUFDdEIsYUFBUyxHQUFDc0IsQ0FBVjtBQUFZOztBQUExQixDQUEvQixFQUEyRCxDQUEzRDtBQUE4RCxJQUFJTixNQUFKO0FBQVdGLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0wsUUFBTSxDQUFDTSxDQUFELEVBQUc7QUFBQ04sVUFBTSxHQUFDTSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl5RyxVQUFKO0FBQWVqSCxNQUFNLENBQUNPLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUN5RyxTQUFPLENBQUN4RyxDQUFELEVBQUc7QUFBQ3lHLGNBQVUsR0FBQ3pHLENBQVg7QUFBYTs7QUFBekIsQ0FBM0IsRUFBc0QsQ0FBdEQ7O0FBUTNiLE1BQU0rRyxTQUFTLEdBQUcsQ0FBQ3ZDLElBQUQsRUFBT3dDLE9BQVAsS0FBbUI7QUFDakMsUUFBTUMsT0FBTyxHQUFHUixVQUFVLENBQUNqQyxJQUFELENBQTFCO0FBQ0EsTUFBSSxDQUFDeUMsT0FBTCxFQUFjLGlCQUFVRCxPQUFWO0FBQ2QsTUFBSUMsT0FBTyxLQUFLLEVBQWhCLEVBQW9CLGlCQUFVRCxPQUFWO0FBQ3BCLFNBQU9DLE9BQVA7QUFDSCxDQUxEOztBQVFBbkgsTUFBTSxDQUFDSyxPQUFQLENBQWU7QUFFWCtHLGNBQVksQ0FBQzVHLE9BQUQsRUFBVWtFLElBQVYsRUFBZ0I7QUFDeEIsUUFBSSxDQUFDLEtBQUtqRSxNQUFWLEVBQWtCO0FBQ2QsWUFBTSxJQUFJVCxNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0Msd0NBQWxDLENBQU47QUFDSDs7QUFFRCxVQUFNQyxLQUFLLEdBQUdSLE1BQU0sQ0FBQ1MsT0FBUCxDQUFlO0FBQ3pCSyxTQUFHLEVBQUVULE9BRG9CO0FBRXpCSyxlQUFTLEVBQUUsS0FBS0o7QUFGUyxLQUFmLENBQWQ7O0FBS0EsUUFBSSxDQUFDRSxLQUFMLEVBQVk7QUFDUixZQUFNLElBQUlYLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixXQUFqQixFQUE4QiwyQkFBOUIsQ0FBTjtBQUNIOztBQUVELFFBQUlDLEtBQUssQ0FBQ0ksTUFBTixLQUFpQm5DLFNBQVMsQ0FBQ0MsYUFBVixDQUF3QkUsUUFBN0MsRUFBdUQ7QUFDbkQsWUFBTSxJQUFJaUIsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGtCQUFqQixFQUFxQyw2QkFBckMsQ0FBTjtBQUNIOztBQUVELFVBQU15RCxVQUFVLEdBQUcsSUFBSTlCLElBQUosRUFBbkI7QUFFQSxVQUFNNkUsT0FBTyxHQUFHRixNQUFNLENBQUM3QyxVQUFELENBQU4sQ0FBbUJrRCxNQUFuQixDQUEwQixpQkFBMUIsQ0FBaEI7QUFFQSxVQUFNOUMsV0FBVyxHQUFHMEMsU0FBUyxDQUFDdkMsSUFBRCxFQUFPd0MsT0FBUCxDQUE3Qjs7QUFFQSxRQUFJM0MsV0FBVyxLQUFLRyxJQUFoQixJQUF3QkEsSUFBSSxLQUFLLEVBQXJDLEVBQXlDO0FBQ3JDLFlBQU0sSUFBSTFFLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixjQUFqQixFQUFpQyw4Q0FBakMsQ0FBTjtBQUNIOztBQUVELFFBQUk4RixRQUFRLEdBQUd0QixRQUFRLENBQUN0RSxPQUFULENBQWlCO0FBQUVDLGVBQVMsRUFBRSxLQUFLSjtBQUFsQixLQUFqQixDQUFmOztBQUVBLFFBQUksQ0FBQytGLFFBQUwsRUFBZTtBQUNYQSxjQUFRLEdBQUc7QUFDUHBDLHdCQUFnQixFQUFFLElBRFg7QUFFUEMsc0JBQWMsRUFBRSxJQUZUO0FBR1BDLHNCQUFjLEVBQUU7QUFIVCxPQUFYO0FBS0g7O0FBRUQsUUFBSTtBQUNBbkUsWUFBTSxDQUFDYSxNQUFQLENBQ0k7QUFBRUMsV0FBRyxFQUFFTixLQUFLLENBQUNNO0FBQWIsT0FESixFQUVJO0FBQ0lDLFlBQUksRUFDSjtBQUNJSCxnQkFBTSxFQUFFbkMsU0FBUyxDQUFDQyxhQUFWLENBQXdCRSxRQURwQztBQUVJb0Ysb0JBRko7QUFHSUkscUJBSEo7QUFJSUgsMEJBQWdCLEVBQUVvQyxRQUFRLENBQUNwQyxnQkFKL0I7QUFLSUMsd0JBQWMsRUFBRW1DLFFBQVEsQ0FBQ25DLGNBTDdCO0FBTUlDLHdCQUFjLEVBQUVrQyxRQUFRLENBQUNsQztBQU43QjtBQUZKLE9BRko7QUFjSCxLQWZELENBZUUsT0FBT25ELEdBQVAsRUFBWTtBQUNWdkIsWUFBTSxDQUFDQyxHQUFQLENBQVdzQixHQUFYO0FBQ0EsWUFBTSxJQUFJbkIsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHlEQUFsQyxDQUFOO0FBQ0g7QUFDSjs7QUEzRFUsQ0FBZixFOzs7Ozs7Ozs7OztBQ2hCQSxJQUFJVixNQUFKO0FBQVdOLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlvSCxFQUFKO0FBQU81SCxNQUFNLENBQUNPLElBQVAsQ0FBWSxJQUFaLEVBQWlCO0FBQUN5RyxTQUFPLENBQUN4RyxDQUFELEVBQUc7QUFBQ29ILE1BQUUsR0FBQ3BILENBQUg7QUFBSzs7QUFBakIsQ0FBakIsRUFBb0MsQ0FBcEM7O0FBQXVDLElBQUl1QixDQUFKOztBQUFNL0IsTUFBTSxDQUFDTyxJQUFQLENBQVksbUJBQVosRUFBZ0M7QUFBQ3dCLEdBQUMsQ0FBQ3ZCLENBQUQsRUFBRztBQUFDdUIsS0FBQyxHQUFDdkIsQ0FBRjtBQUFJOztBQUFWLENBQWhDLEVBQTRDLENBQTVDO0FBSXBIRixNQUFNLENBQUNLLE9BQVAsQ0FBZTtBQUNYa0gsaUJBQWUsR0FBRztBQUNkLFVBQU1DLE1BQU0sR0FBRyxFQUFmO0FBRUEsVUFBTUMsVUFBVSxHQUFHSCxFQUFFLENBQUNJLFlBQUgsV0FBbUJDLE9BQU8sQ0FBQ0MsR0FBUixFQUFuQixVQUFuQjtBQUNBLFVBQU1DLFVBQVUsYUFBTUosVUFBTixzQkFBaEI7QUFDQSxVQUFNSyxjQUFjLGFBQU1ELFVBQU4sTUFBcEI7QUFDQSxVQUFNRSxHQUFHLEdBQUdULEVBQUUsQ0FBQ1UsV0FBSCxDQUFlRixjQUFmLENBQVo7QUFDQSxVQUFNRyxLQUFLLEdBQUdGLEdBQUcsQ0FBQ25HLE1BQUosQ0FBVyxVQUFVc0csR0FBVixFQUFlO0FBQUUsYUFBT0EsR0FBRyxDQUFDQyxLQUFKLENBQVUsYUFBVixDQUFQO0FBQWtDLEtBQTlELENBQWQ7O0FBRUExRyxLQUFDLENBQUMyRyxJQUFGLENBQU9ILEtBQVAsRUFBYyxVQUFVSSxHQUFWLEVBQWU7QUFDekJiLFlBQU0sQ0FBQ2MsSUFBUCxDQUFZO0FBQUVDLGdCQUFRLGFBQU1GLEdBQU47QUFBVixPQUFaO0FBQ0gsS0FGRDs7QUFJQSxXQUFPYixNQUFQO0FBQ0g7O0FBZlUsQ0FBZixFOzs7Ozs7Ozs7OztBQ0pBLElBQUl4SCxNQUFKO0FBQVdOLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLE1BQUosRUFBV2lCLFlBQVg7QUFBd0IxQixNQUFNLENBQUNPLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDRSxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUyxHQUFwQjs7QUFBcUJrQixjQUFZLENBQUNsQixDQUFELEVBQUc7QUFBQ2tCLGdCQUFZLEdBQUNsQixDQUFiO0FBQWU7O0FBQXBELENBQTdCLEVBQW1GLENBQW5GO0FBQXNGLElBQUlFLE9BQUo7QUFBWVYsTUFBTSxDQUFDTyxJQUFQLENBQVksZ0JBQVosRUFBNkI7QUFBQ0csU0FBTyxDQUFDRixDQUFELEVBQUc7QUFBQ0UsV0FBTyxHQUFDRixDQUFSO0FBQVU7O0FBQXRCLENBQTdCLEVBQXFELENBQXJEO0FBQXdELElBQUl0QixTQUFKO0FBQWNjLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGtCQUFaLEVBQStCO0FBQUNyQixXQUFTLENBQUNzQixDQUFELEVBQUc7QUFBQ3RCLGFBQVMsR0FBQ3NCLENBQVY7QUFBWTs7QUFBMUIsQ0FBL0IsRUFBMkQsQ0FBM0Q7QUFBOEQsSUFBSU4sTUFBSjtBQUFXRixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNMLFFBQU0sQ0FBQ00sQ0FBRCxFQUFHO0FBQUNOLFVBQU0sR0FBQ00sQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJeUcsVUFBSjtBQUFlakgsTUFBTSxDQUFDTyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDeUcsU0FBTyxDQUFDeEcsQ0FBRCxFQUFHO0FBQUN5RyxjQUFVLEdBQUN6RyxDQUFYO0FBQWE7O0FBQXpCLENBQTNCLEVBQXNELENBQXREO0FBTzdZRixNQUFNLENBQUNLLE9BQVAsQ0FBZTtBQUVYbUksbUJBQWlCLENBQUNoRixLQUFELEVBQVE7QUFDckIsVUFBTWhELE9BQU8sR0FBRyxFQUFoQjs7QUFFQSxRQUFJLENBQUMsS0FBS0MsTUFBVixFQUFrQjtBQUNkLFlBQU0sSUFBSVQsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHdDQUFsQyxDQUFOO0FBQ0g7O0FBRUQsVUFBTWEsTUFBTSxHQUFHLEVBQWY7QUFDQUEsVUFBTSxDQUFDaUMsS0FBUCxHQUFlbUQsVUFBVSxDQUFDbkQsS0FBRCxDQUF6QjtBQUVBakMsVUFBTSxDQUFDUixNQUFQLEdBQWdCbkMsU0FBUyxDQUFDTSxpQkFBVixDQUE0QkMsT0FBNUM7O0FBRUEsUUFBSW9DLE1BQU0sQ0FBQ2lDLEtBQVAsS0FBaUIsRUFBckIsRUFBeUI7QUFDckIsWUFBTSxJQUFJeEQsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGdCQUFqQixFQUFtQyw2Q0FBbkMsQ0FBTjtBQUNIOztBQUVELFFBQUk7QUFDQSxZQUFNWSxRQUFRLEdBQUdGLFlBQVksQ0FBQ3FILE1BQWIsQ0FBb0JsSCxNQUFwQixDQUFqQjtBQUNBLGFBQU9ELFFBQVA7QUFDSCxLQUhELENBR0UsT0FBT0gsR0FBUCxFQUFZO0FBQ1Z2QixZQUFNLENBQUNDLEdBQVAsQ0FBV3NCLEdBQVg7QUFDQSxZQUFNLElBQUluQixNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0MsbUVBQWxDLENBQU47QUFDSDtBQUNKOztBQXpCVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDUEEsSUFBSVYsTUFBSjtBQUFXTixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJK0IsTUFBSjtBQUFXdkMsTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDZ0MsUUFBTSxDQUFDL0IsQ0FBRCxFQUFHO0FBQUMrQixVQUFNLEdBQUMvQixDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEOztBQUFxRCxJQUFJdUIsQ0FBSjs7QUFBTS9CLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLG1CQUFaLEVBQWdDO0FBQUN3QixHQUFDLENBQUN2QixDQUFELEVBQUc7QUFBQ3VCLEtBQUMsR0FBQ3ZCLENBQUY7QUFBSTs7QUFBVixDQUFoQyxFQUE0QyxDQUE1QztBQUErQyxJQUFJQyxNQUFKO0FBQVdULE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixDQUE3QixFQUFtRCxDQUFuRDtBQUFzRCxJQUFJRSxPQUFKO0FBQVlWLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUNHLFNBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLFdBQU8sR0FBQ0YsQ0FBUjtBQUFVOztBQUF0QixDQUE3QixFQUFxRCxDQUFyRDtBQUF3RCxJQUFJdEIsU0FBSjtBQUFjYyxNQUFNLENBQUNPLElBQVAsQ0FBWSxrQkFBWixFQUErQjtBQUFDckIsV0FBUyxDQUFDc0IsQ0FBRCxFQUFHO0FBQUN0QixhQUFTLEdBQUNzQixDQUFWO0FBQVk7O0FBQTFCLENBQS9CLEVBQTJELENBQTNEO0FBQThELElBQUlOLE1BQUo7QUFBV0YsTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDTCxRQUFNLENBQUNNLENBQUQsRUFBRztBQUFDTixVQUFNLEdBQUNNLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXlHLFVBQUo7QUFBZWpILE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3lHLFNBQU8sQ0FBQ3hHLENBQUQsRUFBRztBQUFDeUcsY0FBVSxHQUFDekcsQ0FBWDtBQUFhOztBQUF6QixDQUEzQixFQUFzRCxDQUF0RDtBQVNyZEYsTUFBTSxDQUFDSyxPQUFQLENBQWU7QUFFWHFJLGlCQUFlLENBQUNsRixLQUFELEVBQVFHLFFBQVIsRUFBa0I7QUFDN0IsUUFBSW5ELE9BQU8sR0FBRyxFQUFkOztBQUVBLFFBQUksQ0FBQyxLQUFLQyxNQUFWLEVBQWtCO0FBQ2QsWUFBTSxJQUFJVCxNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0Msd0NBQWxDLENBQU47QUFDSDs7QUFFRCxVQUFNaUksUUFBUSxHQUFHaEMsVUFBVSxDQUFDbkQsS0FBRCxDQUEzQjs7QUFFQSxRQUFJbUYsUUFBUSxLQUFLLEVBQWpCLEVBQXFCO0FBQ2pCLFlBQU0sSUFBSTNJLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixnQkFBakIsRUFBbUMsNENBQW5DLENBQU47QUFDSCxLQVg0QixDQWE3Qjs7O0FBQ0EsUUFBSUMsS0FBSyxHQUFHUixNQUFNLENBQUNTLE9BQVAsQ0FBZTtBQUN2QkMsZUFBUyxFQUFFLEtBQUtKLE1BRE87QUFFdkJNLFlBQU0sRUFBRW5DLFNBQVMsQ0FBQ0MsYUFBVixDQUF3QkM7QUFGVCxLQUFmLENBQVo7O0FBS0EsUUFBSSxDQUFDNkIsS0FBTCxFQUFZO0FBQ1IsWUFBTWlJLFFBQVEsR0FBRyxFQUFqQjtBQUNBQSxjQUFRLENBQUM3SCxNQUFULEdBQWtCbkMsU0FBUyxDQUFDQyxhQUFWLENBQXdCQyxNQUExQztBQUNBOEosY0FBUSxDQUFDL0csS0FBVCxHQUFpQixFQUFqQjtBQUVBckIsYUFBTyxHQUFHTCxNQUFNLENBQUNzSSxNQUFQLENBQWNHLFFBQWQsQ0FBVjtBQUVBakksV0FBSyxHQUFHUixNQUFNLENBQUNTLE9BQVAsQ0FBZTtBQUFFSyxXQUFHLEVBQUVUO0FBQVAsT0FBZixDQUFSO0FBQ0gsS0FSRCxNQVFPO0FBQ0hBLGFBQU8sR0FBR0csS0FBSyxDQUFDTSxHQUFoQjtBQUNIOztBQUVELFVBQU00SCxHQUFHLEdBQUcsRUFBWjtBQUNBQSxPQUFHLENBQUN0SSxNQUFKLEdBQWEwQixNQUFNLENBQUM2RyxFQUFQLEVBQWI7QUFDQUQsT0FBRyxDQUFDckYsS0FBSixHQUFZbUYsUUFBWjtBQUNBRSxPQUFHLENBQUNsRixRQUFKLEdBQWVBLFFBQWY7QUFDQWtGLE9BQUcsQ0FBQzlILE1BQUosR0FBYW5DLFNBQVMsQ0FBQ00saUJBQVYsQ0FBNEJDLE9BQXpDO0FBQ0EwSixPQUFHLENBQUMvRixLQUFKLEdBQVksQ0FBWjtBQUNBK0YsT0FBRyxDQUFDaEYsU0FBSixHQUFnQixJQUFJeEIsSUFBSixFQUFoQjs7QUFFQSxRQUFJLENBQUNaLENBQUMsQ0FBQ3NILE9BQUYsQ0FBVXBJLEtBQUssQ0FBQ2tCLEtBQWhCLENBQUwsRUFBNkI7QUFDekJsQixXQUFLLENBQUNrQixLQUFOLEdBQWMsRUFBZDtBQUNILEtBekM0QixDQTJDN0I7OztBQUVBLFFBQUk7QUFDQTFCLFlBQU0sQ0FBQ2EsTUFBUCxDQUNJO0FBQUVDLFdBQUcsRUFBRVQ7QUFBUCxPQURKLEVBRUk7QUFDSXdJLGFBQUssRUFBRTtBQUNIbkgsZUFBSyxFQUFFZ0g7QUFESjtBQURYLE9BRko7QUFRQSxhQUFPckksT0FBUDtBQUNILEtBVkQsQ0FVRSxPQUFPVyxHQUFQLEVBQVk7QUFDVnZCLFlBQU0sQ0FBQ0MsR0FBUCxDQUFXc0IsR0FBWDtBQUNBLFlBQU0sSUFBSW5CLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQyxtRUFBbEMsQ0FBTjtBQUNIO0FBQ0o7O0FBN0RVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNUQSxJQUFJVixNQUFKO0FBQVdOLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUkrQixNQUFKO0FBQVd2QyxNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNnQyxRQUFNLENBQUMvQixDQUFELEVBQUc7QUFBQytCLFVBQU0sR0FBQy9CLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSStJLEtBQUo7QUFBVXZKLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ2dKLE9BQUssQ0FBQy9JLENBQUQsRUFBRztBQUFDK0ksU0FBSyxHQUFDL0ksQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJNkMsWUFBSjtBQUFpQnJELE1BQU0sQ0FBQ08sSUFBUCxDQUFZLDZCQUFaLEVBQTBDO0FBQUM4QyxjQUFZLENBQUM3QyxDQUFELEVBQUc7QUFBQzZDLGdCQUFZLEdBQUM3QyxDQUFiO0FBQWU7O0FBQWhDLENBQTFDLEVBQTRFLENBQTVFOztBQUErRSxJQUFJdUIsQ0FBSjs7QUFBTS9CLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLG1CQUFaLEVBQWdDO0FBQUN3QixHQUFDLENBQUN2QixDQUFELEVBQUc7QUFBQ3VCLEtBQUMsR0FBQ3ZCLENBQUY7QUFBSTs7QUFBVixDQUFoQyxFQUE0QyxDQUE1QztBQUErQyxJQUFJZ0YsUUFBSjtBQUFheEYsTUFBTSxDQUFDTyxJQUFQLENBQVksZ0JBQVosRUFBNkI7QUFBQ2lGLFVBQVEsQ0FBQ2hGLENBQUQsRUFBRztBQUFDZ0YsWUFBUSxHQUFDaEYsQ0FBVDtBQUFXOztBQUF4QixDQUE3QixFQUF1RCxDQUF2RDtBQUEwRCxJQUFJRSxPQUFKO0FBQVlWLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUNHLFNBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLFdBQU8sR0FBQ0YsQ0FBUjtBQUFVOztBQUF0QixDQUE3QixFQUFxRCxDQUFyRDtBQUF3RCxJQUFJTixNQUFKO0FBQVdGLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0wsUUFBTSxDQUFDTSxDQUFELEVBQUc7QUFBQ04sVUFBTSxHQUFDTSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl5RyxVQUFKO0FBQWVqSCxNQUFNLENBQUNPLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUN5RyxTQUFPLENBQUN4RyxDQUFELEVBQUc7QUFBQ3lHLGNBQVUsR0FBQ3pHLENBQVg7QUFBYTs7QUFBekIsQ0FBM0IsRUFBc0QsQ0FBdEQ7QUFVM2lCRixNQUFNLENBQUNLLE9BQVAsQ0FBZTtBQUVYNkksY0FBWSxDQUFDTCxHQUFELEVBQU07QUFDZCxRQUFJLENBQUMsS0FBS3BJLE1BQVYsRUFBa0I7QUFDZCxZQUFNLElBQUlULE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQyx3Q0FBbEMsQ0FBTjtBQUNIOztBQUVETixXQUFPLENBQUM4RSxRQUFSLENBQWlCaUUsUUFBakIsQ0FBMEJOLEdBQTFCO0FBRUEsVUFBTXJDLFFBQVEsR0FBR3RCLFFBQVEsQ0FBQ3RFLE9BQVQsQ0FBaUI7QUFBRUMsZUFBUyxFQUFFLEtBQUtKO0FBQWxCLEtBQWpCLENBQWpCO0FBRUEsVUFBTTJJLEtBQUssR0FBR3pDLFVBQVUsQ0FBQ2tDLEdBQUcsQ0FBQ3pFLGdCQUFMLEVBQXVCLElBQXZCLENBQXhCO0FBQ0EsVUFBTWlGLEdBQUcsR0FBRzFDLFVBQVUsQ0FBQ2tDLEdBQUcsQ0FBQ3hFLGNBQUwsRUFBcUIsSUFBckIsQ0FBdEI7QUFDQSxVQUFNaUYsR0FBRyxHQUFHM0MsVUFBVSxDQUFDa0MsR0FBRyxDQUFDdkUsY0FBTCxFQUFxQixJQUFyQixDQUF0Qjs7QUFFQSxRQUFJOEUsS0FBSyxLQUFLUCxHQUFHLENBQUN6RSxnQkFBZCxJQUFrQ2lGLEdBQUcsS0FBS1IsR0FBRyxDQUFDeEUsY0FBOUMsSUFBZ0VpRixHQUFHLEtBQUtULEdBQUcsQ0FBQ3ZFLGNBQWhGLEVBQWdHO0FBQzVGLFlBQU0sSUFBSXRFLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixnQkFBakIsRUFBbUMsd0NBQW5DLENBQU47QUFDSDs7QUFFRCxRQUFJO0FBQ0EsVUFBSWUsQ0FBQyxDQUFDOEgsV0FBRixDQUFjL0MsUUFBZCxDQUFKLEVBQTZCO0FBQ3pCdEIsZ0JBQVEsQ0FBQ3VELE1BQVQsQ0FBZ0JJLEdBQWhCO0FBQ0gsT0FGRCxNQUVPO0FBQ0gzRCxnQkFBUSxDQUFDbEUsTUFBVCxDQUNJO0FBQUVDLGFBQUcsRUFBRXVGLFFBQVEsQ0FBQ3ZGO0FBQWhCLFNBREosRUFFSTtBQUNJQyxjQUFJLEVBQUU7QUFDRmlFLDJCQUFlLEVBQUUwRCxHQUFHLENBQUMxRCxlQURuQjtBQUVGZiw0QkFBZ0IsRUFBRWdGLEtBRmhCO0FBR0YvRSwwQkFBYyxFQUFFZ0YsR0FIZDtBQUlGL0UsMEJBQWMsRUFBRWdGO0FBSmQ7QUFEVixTQUZKO0FBV0g7QUFDSixLQWhCRCxDQWdCRSxPQUFPbkksR0FBUCxFQUFZO0FBQ1Z2QixZQUFNLENBQUNDLEdBQVAsQ0FBV3NCLEdBQVg7QUFDQSxZQUFNLElBQUluQixNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0MsdURBQWxDLENBQU47QUFDSDtBQUNKOztBQXZDVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDVkEsSUFBSVYsTUFBSjtBQUFXTixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDs7QUFBcUQsSUFBSXVCLENBQUo7O0FBQU0vQixNQUFNLENBQUNPLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDd0IsR0FBQyxDQUFDdkIsQ0FBRCxFQUFHO0FBQUN1QixLQUFDLEdBQUN2QixDQUFGO0FBQUk7O0FBQVYsQ0FBaEMsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSUMsTUFBSixFQUFXaUIsWUFBWDtBQUF3QjFCLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTLEdBQXBCOztBQUFxQmtCLGNBQVksQ0FBQ2xCLENBQUQsRUFBRztBQUFDa0IsZ0JBQVksR0FBQ2xCLENBQWI7QUFBZTs7QUFBcEQsQ0FBN0IsRUFBbUYsQ0FBbkY7QUFBc0YsSUFBSXRCLFNBQUo7QUFBY2MsTUFBTSxDQUFDTyxJQUFQLENBQVksa0JBQVosRUFBK0I7QUFBQ3JCLFdBQVMsQ0FBQ3NCLENBQUQsRUFBRztBQUFDdEIsYUFBUyxHQUFDc0IsQ0FBVjtBQUFZOztBQUExQixDQUEvQixFQUEyRCxDQUEzRDtBQUE4RCxJQUFJc0osV0FBSjtBQUFnQjlKLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ3VKLGFBQVcsQ0FBQ3RKLENBQUQsRUFBRztBQUFDc0osZUFBVyxHQUFDdEosQ0FBWjtBQUFjOztBQUE5QixDQUE1QixFQUE0RCxDQUE1RDtBQUErRCxJQUFJeUcsVUFBSjtBQUFlakgsTUFBTSxDQUFDTyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDeUcsU0FBTyxDQUFDeEcsQ0FBRCxFQUFHO0FBQUN5RyxjQUFVLEdBQUN6RyxDQUFYO0FBQWE7O0FBQXpCLENBQTNCLEVBQXNELENBQXREO0FBTzdZRixNQUFNLENBQUNLLE9BQVAsQ0FBZTtBQUNYb0osb0JBQWtCLENBQUNDLFlBQUQsRUFBZUMsV0FBZixFQUE0QjtBQUMxQztBQUNBLFFBQUksQ0FBQyxLQUFLbEosTUFBVixFQUFrQjtBQUNkLFlBQU0sSUFBSVQsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLCtDQUFsQyxDQUFOO0FBQ0gsS0FKeUMsQ0FNMUM7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7OztBQUVBLFVBQU1rSixVQUFVLEdBQUdELFdBQVcsSUFBSSxFQUFsQzs7QUFFQSxRQUFJQyxVQUFVLEtBQUssRUFBbkIsRUFBdUI7QUFDbkIsWUFBTSxJQUFJNUosTUFBTSxDQUFDVSxLQUFYLENBQWlCLHdCQUFqQixFQUEyQywrQkFBM0MsQ0FBTjtBQUNIOztBQUVELFVBQU1tSixRQUFRLEdBQUdsRCxVQUFVLENBQUNpRCxVQUFELENBQTNCOztBQUVBLFFBQUlDLFFBQVEsS0FBSyxFQUFqQixFQUFxQjtBQUNqQixZQUFNLElBQUk3SixNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0Msd0JBQWxDLENBQU47QUFDSCxLQTFCeUMsQ0E0QjFDOzs7QUFFQSxVQUFNb0osT0FBTyxHQUFHMUksWUFBWSxDQUFDMkksSUFBYixDQUFrQjtBQUM5QmxKLGVBQVMsRUFBRSxLQUFLSixNQURjO0FBRTlCSyxTQUFHLEVBQUUsQ0FDRDtBQUFFQyxjQUFNLEVBQUVuQyxTQUFTLENBQUNNLGlCQUFWLENBQTRCQztBQUF0QyxPQURDLEVBRUQ7QUFDSTRCLGNBQU0sRUFBRW5DLFNBQVMsQ0FBQ00saUJBQVYsQ0FBNEJFLFFBRHhDO0FBRUlrRCxtQkFBVyxFQUFFO0FBQUUwSCxhQUFHLEVBQUUsSUFBSTNILElBQUosQ0FBU0EsSUFBSSxDQUFDNEgsR0FBTCxLQUFjLEtBQUssRUFBTCxHQUFVLEVBQVYsR0FBZSxJQUF0QztBQUFQO0FBRmpCLE9BRkM7QUFGeUIsS0FBbEIsRUFTYkMsS0FUYSxFQUFoQjs7QUFXQSxRQUFJSixPQUFPLENBQUMvSCxNQUFSLEtBQW1CLENBQXZCLEVBQTBCO0FBQ3RCLFlBQU0sSUFBSS9CLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixZQUFqQixFQUErQiw0REFBL0IsQ0FBTjtBQUNIOztBQUVELFVBQU15SixJQUFJLEdBQUcsRUFBYjtBQUVBLFVBQU1DLElBQUksR0FBR3BLLE1BQU0sQ0FBQ3FLLEtBQVAsQ0FBYXpKLE9BQWIsQ0FBcUIsS0FBS0gsTUFBMUIsQ0FBYjtBQUVBMEosUUFBSSxDQUFDRyxTQUFMLEdBQWlCRixJQUFJLENBQUNHLFFBQUwsQ0FBY2pGLFlBQWQsRUFBakI7QUFDQTZFLFFBQUksQ0FBQ0ssV0FBTCxHQUFtQixJQUFJbkksSUFBSixHQUFXb0ksV0FBWCxFQUFuQixDQWxEMEMsQ0FtRDFDOztBQUNBLFFBQUk1SSxLQUFLLEdBQUcsc0ZBQVo7QUFDQXNJLFFBQUksQ0FBQ08sVUFBTCxHQUFrQmpKLENBQUMsQ0FBQ2tKLE1BQUYsQ0FBU2IsT0FBVCxFQUFrQixRQUFsQixFQUE0QmMsT0FBNUIsQ0FBcUM5SSxJQUFELElBQVU7QUFDNUQsWUFBTStJLFVBQVUsR0FBSS9JLElBQUksQ0FBQ2YsTUFBTCxLQUFnQm5DLFNBQVMsQ0FBQ00saUJBQVYsQ0FBNEJFLFFBQTdDLEdBQXlELFVBQXpELEdBQXNFLFFBQXpGO0FBQ0EsWUFBTTBMLFNBQVMsR0FBSWhKLElBQUksQ0FBQ2YsTUFBTCxLQUFnQm5DLFNBQVMsQ0FBQ00saUJBQVYsQ0FBNEJFLFFBQTdDLEdBQXlELDZEQUF6RCxHQUF5SCxnREFBM0k7QUFDQXlDLFdBQUssbUNBQTJCaUosU0FBM0IsZ0JBQXlDaEosSUFBSSxDQUFDMEIsS0FBOUMsOEJBQXNFc0gsU0FBdEUsZ0JBQW9GRCxVQUFwRixlQUFMO0FBQ0gsS0FKaUIsQ0FBbEI7QUFNQVYsUUFBSSxDQUFDTyxVQUFMLEdBQWtCN0ksS0FBbEI7QUFFQSxVQUFNa0osSUFBSSxHQUFHcEQsT0FBTyxDQUFDcUQsR0FBUixDQUFZQyxrQkFBWixJQUFrQyxzQkFBL0M7QUFFQXpCLGVBQVcsQ0FBQzBCLGFBQVosQ0FBMEJyQixRQUExQixFQUFvQ2tCLElBQXBDLFlBQTZDWCxJQUFJLENBQUNHLFFBQUwsQ0FBY2pGLFlBQWQsRUFBN0Msb0JBQTBGLGFBQTFGLEVBQXlHNkUsSUFBekc7QUFDSDs7QUFqRVUsQ0FBZixFOzs7Ozs7Ozs7OztBQ1BBLElBQUluSyxNQUFKO0FBQVdOLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLE1BQUosRUFBV2lCLFlBQVg7QUFBd0IxQixNQUFNLENBQUNPLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDRSxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUyxHQUFwQjs7QUFBcUJrQixjQUFZLENBQUNsQixDQUFELEVBQUc7QUFBQ2tCLGdCQUFZLEdBQUNsQixDQUFiO0FBQWU7O0FBQXBELENBQTdCLEVBQW1GLENBQW5GO0FBQXNGLElBQUlFLE9BQUo7QUFBWVYsTUFBTSxDQUFDTyxJQUFQLENBQVksZ0JBQVosRUFBNkI7QUFBQ0csU0FBTyxDQUFDRixDQUFELEVBQUc7QUFBQ0UsV0FBTyxHQUFDRixDQUFSO0FBQVU7O0FBQXRCLENBQTdCLEVBQXFELENBQXJEO0FBQXdELElBQUl0QixTQUFKO0FBQWNjLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGtCQUFaLEVBQStCO0FBQUNyQixXQUFTLENBQUNzQixDQUFELEVBQUc7QUFBQ3RCLGFBQVMsR0FBQ3NCLENBQVY7QUFBWTs7QUFBMUIsQ0FBL0IsRUFBMkQsQ0FBM0Q7QUFBOEQsSUFBSU4sTUFBSjtBQUFXRixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNMLFFBQU0sQ0FBQ00sQ0FBRCxFQUFHO0FBQUNOLFVBQU0sR0FBQ00sQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJeUcsVUFBSjtBQUFlakgsTUFBTSxDQUFDTyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDeUcsU0FBTyxDQUFDeEcsQ0FBRCxFQUFHO0FBQUN5RyxjQUFVLEdBQUN6RyxDQUFYO0FBQWE7O0FBQXpCLENBQTNCLEVBQXNELENBQXREO0FBTzdZRixNQUFNLENBQUNLLE9BQVAsQ0FBZTtBQUVYOEssbUJBQWlCLENBQUM3SixRQUFELEVBQVdrQyxLQUFYLEVBQWtCO0FBQy9CLFVBQU1oRCxPQUFPLEdBQUcsRUFBaEI7O0FBRUEsUUFBSSxDQUFDLEtBQUtDLE1BQVYsRUFBa0I7QUFDZCxZQUFNLElBQUlULE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQyx3Q0FBbEMsQ0FBTjtBQUNIOztBQUVELFVBQU1hLE1BQU0sR0FBR0gsWUFBWSxDQUFDUixPQUFiLENBQXFCO0FBQUVLLFNBQUcsRUFBRUssUUFBUDtBQUFpQlQsZUFBUyxFQUFFLEtBQUtKO0FBQWpDLEtBQXJCLENBQWY7O0FBRUEsUUFBSSxDQUFDYyxNQUFMLEVBQWE7QUFDVCxZQUFNLElBQUl2QixNQUFNLENBQUNVLEtBQVgsQ0FBaUIsV0FBakIsRUFBOEIsd0JBQTlCLENBQU47QUFDSDs7QUFFRCxVQUFNaUksUUFBUSxHQUFHaEMsVUFBVSxDQUFDbkQsS0FBRCxDQUEzQjs7QUFFQSxRQUFJbUYsUUFBUSxLQUFLbkYsS0FBakIsRUFBd0I7QUFDcEIsWUFBTSxJQUFJeEQsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHdDQUFsQyxDQUFOO0FBQ0g7O0FBRUQsUUFBSTtBQUNBVSxrQkFBWSxDQUFDSixNQUFiLENBQ0k7QUFBRUMsV0FBRyxFQUFFSztBQUFQLE9BREosRUFFSTtBQUNJSixZQUFJLEVBQ0o7QUFDSXNDLGVBQUssRUFBRW1GO0FBRFg7QUFGSixPQUZKO0FBU0gsS0FWRCxDQVVFLE9BQU94SCxHQUFQLEVBQVk7QUFDVnZCLFlBQU0sQ0FBQ0MsR0FBUCxDQUFXc0IsR0FBWDtBQUNBLFlBQU0sSUFBSW5CLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQyx5REFBbEMsQ0FBTjtBQUNIO0FBQ0o7O0FBbkNVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNQQSxJQUFJVixNQUFKO0FBQVdOLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEOztBQUFxRCxJQUFJdUIsQ0FBSjs7QUFBTS9CLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLG1CQUFaLEVBQWdDO0FBQUN3QixHQUFDLENBQUN2QixDQUFELEVBQUc7QUFBQ3VCLEtBQUMsR0FBQ3ZCLENBQUY7QUFBSTs7QUFBVixDQUFoQyxFQUE0QyxDQUE1QztBQUErQyxJQUFJQyxNQUFKO0FBQVdULE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixDQUE3QixFQUFtRCxDQUFuRDtBQUFzRCxJQUFJRSxPQUFKO0FBQVlWLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUNHLFNBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLFdBQU8sR0FBQ0YsQ0FBUjtBQUFVOztBQUF0QixDQUE3QixFQUFxRCxDQUFyRDtBQUF3RCxJQUFJdEIsU0FBSjtBQUFjYyxNQUFNLENBQUNPLElBQVAsQ0FBWSxrQkFBWixFQUErQjtBQUFDckIsV0FBUyxDQUFDc0IsQ0FBRCxFQUFHO0FBQUN0QixhQUFTLEdBQUNzQixDQUFWO0FBQVk7O0FBQTFCLENBQS9CLEVBQTJELENBQTNEO0FBQThELElBQUlOLE1BQUo7QUFBV0YsTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDTCxRQUFNLENBQUNNLENBQUQsRUFBRztBQUFDTixVQUFNLEdBQUNNLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXlHLFVBQUo7QUFBZWpILE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3lHLFNBQU8sQ0FBQ3hHLENBQUQsRUFBRztBQUFDeUcsY0FBVSxHQUFDekcsQ0FBWDtBQUFhOztBQUF6QixDQUEzQixFQUFzRCxDQUF0RDtBQVFyWkYsTUFBTSxDQUFDSyxPQUFQLENBQWU7QUFFWCtLLHNCQUFvQixDQUFDN0ssTUFBRCxFQUFTaUQsS0FBVCxFQUFnQjtBQUNoQyxVQUFNaEQsT0FBTyxHQUFHLEVBQWhCOztBQUVBLFFBQUksQ0FBQyxLQUFLQyxNQUFWLEVBQWtCO0FBQ2QsWUFBTSxJQUFJVCxNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0Msd0NBQWxDLENBQU47QUFDSDs7QUFFRCxVQUFNQyxLQUFLLEdBQUdSLE1BQU0sQ0FBQ1MsT0FBUCxDQUFlO0FBQ3pCQyxlQUFTLEVBQUUsS0FBS0osTUFEUztBQUV6QkssU0FBRyxFQUFFLENBQ0Q7QUFBRUMsY0FBTSxFQUFFbkMsU0FBUyxDQUFDQyxhQUFWLENBQXdCQztBQUFsQyxPQURDLEVBRUQ7QUFBRWlDLGNBQU0sRUFBRW5DLFNBQVMsQ0FBQ0MsYUFBVixDQUF3Qkc7QUFBbEMsT0FGQztBQUZvQixLQUFmLENBQWQsQ0FQZ0MsQ0FlaEM7O0FBQ0EsUUFBSSxDQUFDMkIsS0FBTCxFQUFZO0FBQ1IsWUFBTSxJQUFJWCxNQUFNLENBQUNVLEtBQVgsQ0FBaUIsV0FBakIsRUFBOEIsa0JBQTlCLENBQU47QUFDSDs7QUFFRCxVQUFNaUIsU0FBUyxHQUFHRixDQUFDLENBQUNHLE1BQUYsQ0FBU2pCLEtBQUssQ0FBQ2tCLEtBQWYsRUFBc0IsVUFBVUMsSUFBVixFQUFnQjtBQUNwRCxhQUFPQSxJQUFJLENBQUN2QixNQUFMLEtBQWdCQSxNQUF2QjtBQUNILEtBRmlCLENBQWxCOztBQUlBLFFBQUlvQixTQUFTLENBQUNJLE1BQVYsS0FBcUIsQ0FBekIsRUFBNEI7QUFDeEIsWUFBTSxJQUFJL0IsTUFBTSxDQUFDVSxLQUFYLENBQWlCLFdBQWpCLEVBQThCLHVCQUE5QixDQUFOO0FBQ0g7O0FBRUQsUUFBSW1DLFNBQVMsR0FBR2xCLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYW1CLEtBQWIsSUFBc0IsQ0FBdEM7QUFFQUQsYUFBUyxJQUFJLENBQWI7QUFFQSxVQUFNOEYsUUFBUSxHQUFHaEMsVUFBVSxDQUFDbkQsS0FBRCxDQUEzQjs7QUFFQSxRQUFJbUYsUUFBUSxLQUFLLEVBQWpCLEVBQXFCO0FBQ2pCLFlBQU0sSUFBSTNJLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQyw0Q0FBbEMsQ0FBTjtBQUNIOztBQUVELFFBQUk7QUFDQVAsWUFBTSxDQUFDYSxNQUFQLENBQ0k7QUFDSUMsV0FBRyxFQUFFTixLQUFLLENBQUNNLEdBRGY7QUFFSSx3QkFBZ0JWO0FBRnBCLE9BREosRUFLSTtBQUNJVyxZQUFJLEVBQUU7QUFDRiwyQkFBaUJ5SDtBQURmO0FBRFYsT0FMSjtBQVdILEtBWkQsQ0FZRSxPQUFPeEgsR0FBUCxFQUFZO0FBQ1Z2QixZQUFNLENBQUNDLEdBQVAsQ0FBV3NCLEdBQVg7QUFDQSxZQUFNLElBQUluQixNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0MsNkRBQWxDLENBQU47QUFDSDtBQUNKOztBQXhEVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDUkEsSUFBSVYsTUFBSjtBQUFXTixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJb0gsRUFBSjtBQUFPNUgsTUFBTSxDQUFDTyxJQUFQLENBQVksSUFBWixFQUFpQjtBQUFDeUcsU0FBTyxDQUFDeEcsQ0FBRCxFQUFHO0FBQUNvSCxNQUFFLEdBQUNwSCxDQUFIO0FBQUs7O0FBQWpCLENBQWpCLEVBQW9DLENBQXBDOztBQUF1QyxJQUFJdUIsQ0FBSjs7QUFBTS9CLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLG1CQUFaLEVBQWdDO0FBQUN3QixHQUFDLENBQUN2QixDQUFELEVBQUc7QUFBQ3VCLEtBQUMsR0FBQ3ZCLENBQUY7QUFBSTs7QUFBVixDQUFoQyxFQUE0QyxDQUE1QztBQUErQyxJQUFJNEYsV0FBSjtBQUFnQnBHLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUM2RixhQUFXLENBQUM1RixDQUFELEVBQUc7QUFBQzRGLGVBQVcsR0FBQzVGLENBQVo7QUFBYzs7QUFBOUIsQ0FBN0IsRUFBNkQsQ0FBN0Q7QUFLbkxGLE1BQU0sQ0FBQ3FMLE9BQVAsQ0FBZSxhQUFmLEVBQThCLFlBQVk7QUFDdEMsUUFBTUMsSUFBSSxHQUFHLElBQWI7QUFDQSxRQUFNN0QsVUFBVSxHQUFHSCxFQUFFLENBQUNJLFlBQUgsV0FBbUJDLE9BQU8sQ0FBQ0MsR0FBUixFQUFuQixVQUFuQjtBQUNBLFFBQU1DLFVBQVUsYUFBTUosVUFBTixzQkFBaEI7QUFDQSxRQUFNSyxjQUFjLGFBQU1ELFVBQU4sa0JBQXBCO0FBQ0EsUUFBTUUsR0FBRyxHQUFHVCxFQUFFLENBQUNVLFdBQUgsQ0FBZUYsY0FBZixDQUFaOztBQUNBckcsR0FBQyxDQUFDMkcsSUFBRixDQUFPTCxHQUFQLEVBQVksVUFBVXdELFVBQVYsRUFBc0I7QUFDOUIsVUFBTUMsY0FBYyxHQUFHRCxVQUFVLENBQUNFLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsQ0FBdEIsRUFBeUJuRyxZQUF6QixFQUF2QjtBQUNBZ0csUUFBSSxDQUFDSSxLQUFMLENBQVcsYUFBWCxFQUEwQkgsVUFBMUIsRUFBc0M7QUFBRTdHLFVBQUksRUFBRThHLGNBQVI7QUFBd0J4RyxXQUFLLHlCQUFrQnVHLFVBQWxCO0FBQTdCLEtBQXRDO0FBQ0gsR0FIRDs7QUFJQSxPQUFLSSxLQUFMO0FBQ0gsQ0FYRCxFOzs7Ozs7Ozs7OztBQ0xBLElBQUkzTCxNQUFKO0FBQVdOLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUkrSSxLQUFKO0FBQVV2SixNQUFNLENBQUNPLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNnSixPQUFLLENBQUMvSSxDQUFELEVBQUc7QUFBQytJLFNBQUssR0FBQy9JLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSThGLE9BQUosRUFBWTVFLFlBQVo7QUFBeUIxQixNQUFNLENBQUNPLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDK0YsU0FBTyxDQUFDOUYsQ0FBRCxFQUFHO0FBQUM4RixXQUFPLEdBQUM5RixDQUFSO0FBQVUsR0FBdEI7O0FBQXVCa0IsY0FBWSxDQUFDbEIsQ0FBRCxFQUFHO0FBQUNrQixnQkFBWSxHQUFDbEIsQ0FBYjtBQUFlOztBQUF0RCxDQUE3QixFQUFxRixDQUFyRjtBQUF3RixJQUFJdEIsU0FBSjtBQUFjYyxNQUFNLENBQUNPLElBQVAsQ0FBWSxrQkFBWixFQUErQjtBQUFDckIsV0FBUyxDQUFDc0IsQ0FBRCxFQUFHO0FBQUN0QixhQUFTLEdBQUNzQixDQUFWO0FBQVk7O0FBQTFCLENBQS9CLEVBQTJELENBQTNEOztBQUszUGtCLFlBQVksQ0FBQ3dLLFlBQWIsQ0FBMEIsV0FBMUIsRUFBdUMsQ0FBdkM7O0FBQ0F4SyxZQUFZLENBQUN3SyxZQUFiLENBQTBCLFFBQTFCLEVBQW9DLENBQXBDOztBQUNBeEssWUFBWSxDQUFDd0ssWUFBYixDQUEwQixXQUExQixFQUF1QyxDQUF2Qzs7QUFFQTVMLE1BQU0sQ0FBQ3FMLE9BQVAsQ0FBZSxjQUFmLEVBQStCLFlBQVk7QUFDdkMsTUFBSSxDQUFDLEtBQUs1SyxNQUFWLEVBQWtCO0FBQ2QsU0FBS29MLElBQUw7QUFDQSxXQUFPLElBQVA7QUFDSDs7QUFFRCxTQUFPekssWUFBWSxDQUFDMkksSUFBYixDQUFrQjtBQUNyQmxKLGFBQVMsRUFBRSxLQUFLSixNQURLO0FBRXJCTSxVQUFNLEVBQUVuQyxTQUFTLENBQUNNLGlCQUFWLENBQTRCQztBQUZmLEdBQWxCLENBQVA7QUFJSCxDQVZEO0FBWUFhLE1BQU0sQ0FBQ3FMLE9BQVAsQ0FBZSxhQUFmLEVBQThCLFVBQVVTLE1BQVYsRUFBa0I7QUFDNUMsTUFBSSxDQUFDLEtBQUtyTCxNQUFWLEVBQWtCO0FBQ2QsV0FBTyxJQUFQO0FBQ0g7O0FBRUQsTUFBSSxDQUFDd0ksS0FBSyxDQUFDOEMsSUFBTixDQUFXRCxNQUFYLEVBQW1CO0FBQUVFLFNBQUssRUFBRXBJLE1BQVQ7QUFBaUJxSSxXQUFPLEVBQUVoSTtBQUExQixHQUFuQixDQUFMLEVBQThEO0FBQzFELFdBQU8sSUFBUDtBQUNIOztBQUVELFFBQU1pSSxLQUFLLEdBQUc7QUFDVnJMLGFBQVMsRUFBRSxLQUFLSjtBQUROLEdBQWQ7O0FBSUEsTUFBSSxDQUFDcUwsTUFBTSxDQUFDRyxPQUFaLEVBQXFCO0FBQ2pCQyxTQUFLLENBQUNuTCxNQUFOLEdBQWVuQyxTQUFTLENBQUNNLGlCQUFWLENBQTRCQyxPQUEzQztBQUNIOztBQUVELFNBQU9pQyxZQUFZLENBQUMySSxJQUFiLENBQWtCbUMsS0FBbEIsRUFBeUI7QUFBRUMsUUFBSSxFQUFFO0FBQUU3SixpQkFBVyxFQUFFO0FBQWYsS0FBUjtBQUE0QjBKLFNBQUssRUFBRUYsTUFBTSxDQUFDRTtBQUExQyxHQUF6QixDQUFQO0FBQ0gsQ0FsQkQ7QUFvQkE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pDQSxJQUFJaE0sTUFBSjtBQUFXTixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxNQUFKO0FBQVdULE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixDQUE3QixFQUFtRCxDQUFuRDtBQUFzRCxJQUFJdEIsU0FBSjtBQUFjYyxNQUFNLENBQUNPLElBQVAsQ0FBWSxrQkFBWixFQUErQjtBQUFDckIsV0FBUyxDQUFDc0IsQ0FBRCxFQUFHO0FBQUN0QixhQUFTLEdBQUNzQixDQUFWO0FBQVk7O0FBQTFCLENBQS9CLEVBQTJELENBQTNEOztBQUkvSUMsTUFBTSxDQUFDeUwsWUFBUCxDQUFvQixXQUFwQixFQUFpQyxDQUFqQzs7QUFDQXpMLE1BQU0sQ0FBQ3lMLFlBQVAsQ0FBb0IsUUFBcEIsRUFBOEIsQ0FBOUI7O0FBRUE1TCxNQUFNLENBQUNxTCxPQUFQLENBQWUsZUFBZixFQUFnQyxZQUFZO0FBQ3hDLE1BQUksQ0FBQyxLQUFLNUssTUFBVixFQUFrQjtBQUNkLFdBQU8sSUFBUDtBQUNIOztBQUVELFNBQU9OLE1BQU0sQ0FBQzRKLElBQVAsQ0FBWTtBQUNmbEosYUFBUyxFQUFFLEtBQUtKLE1BREQ7QUFFZk0sVUFBTSxFQUFFO0FBQ0pxTCxTQUFHLEVBQUUsQ0FBQ3hOLFNBQVMsQ0FBQ0MsYUFBVixDQUF3QkMsTUFBekIsRUFBaUNGLFNBQVMsQ0FBQ0MsYUFBVixDQUF3QkcsTUFBekQ7QUFERDtBQUZPLEdBQVosQ0FBUDtBQU1ILENBWEQ7QUFhQWdCLE1BQU0sQ0FBQ3FMLE9BQVAsQ0FBZSxpQkFBZixFQUFrQyxZQUFZO0FBQzFDLE1BQUksQ0FBQyxLQUFLNUssTUFBVixFQUFrQjtBQUNkLFdBQU8sSUFBUDtBQUNIOztBQUVELFNBQU9OLE1BQU0sQ0FBQzRKLElBQVAsQ0FBWTtBQUFFbEosYUFBUyxFQUFFLEtBQUtKLE1BQWxCO0FBQTBCTSxVQUFNLEVBQUVuQyxTQUFTLENBQUNDLGFBQVYsQ0FBd0JFO0FBQTFELEdBQVosQ0FBUDtBQUNILENBTkQ7QUFRQWlCLE1BQU0sQ0FBQ3FMLE9BQVAsQ0FBZSx1QkFBZixFQUF3QyxVQUFVN0ssT0FBVixFQUFtQjtBQUN2RCxNQUFJLENBQUMsS0FBS0MsTUFBVixFQUFrQjtBQUNkLFdBQU8sSUFBUDtBQUNIOztBQUVELFNBQU9OLE1BQU0sQ0FBQzRKLElBQVAsQ0FBWTtBQUFFOUksT0FBRyxFQUFFVCxPQUFQO0FBQWdCSyxhQUFTLEVBQUUsS0FBS0osTUFBaEM7QUFBd0NNLFVBQU0sRUFBRW5DLFNBQVMsQ0FBQ0MsYUFBVixDQUF3QkU7QUFBeEUsR0FBWixDQUFQO0FBQ0gsQ0FORCxFOzs7Ozs7Ozs7OztBQzVCQSxJQUFJaUIsTUFBSjtBQUFXTixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJZ0YsUUFBSjtBQUFheEYsTUFBTSxDQUFDTyxJQUFQLENBQVksZ0JBQVosRUFBNkI7QUFBQ2lGLFVBQVEsQ0FBQ2hGLENBQUQsRUFBRztBQUFDZ0YsWUFBUSxHQUFDaEYsQ0FBVDtBQUFXOztBQUF4QixDQUE3QixFQUF1RCxDQUF2RDs7QUFHN0VnRixRQUFRLENBQUMwRyxZQUFULENBQXNCLFdBQXRCLEVBQW1DLENBQW5DOztBQUVBNUwsTUFBTSxDQUFDcUwsT0FBUCxDQUFlLFVBQWYsRUFBMkIsWUFBWTtBQUNuQyxNQUFJLENBQUNyTCxNQUFNLENBQUNTLE1BQVAsRUFBTCxFQUFzQjtBQUNsQixXQUFPLElBQVA7QUFDSDs7QUFFRCxTQUFPeUUsUUFBUSxDQUFDNkUsSUFBVCxDQUFjO0FBQUVsSixhQUFTLEVBQUViLE1BQU0sQ0FBQ1MsTUFBUDtBQUFiLEdBQWQsQ0FBUDtBQUNILENBTkQsRTs7Ozs7Ozs7Ozs7O0FDTEEsTUFBSVQsTUFBSjtBQUFXZ0QsU0FBTyxDQUFDL0MsSUFBUixDQUFhLGVBQWIsRUFBNkI7QUFBQ0QsVUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsWUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLEdBQTdCLEVBQW1ELENBQW5EO0FBQXNELE1BQUltTSxHQUFKO0FBQVFySixTQUFPLENBQUMvQyxJQUFSLENBQWEsd0JBQWIsRUFBc0M7QUFBQ29NLE9BQUcsQ0FBQ25NLENBQUQsRUFBRztBQUFDbU0sU0FBRyxHQUFDbk0sQ0FBSjtBQUFNOztBQUFkLEdBQXRDLEVBQXNELENBQXREO0FBQXlELE1BQUlvTSxLQUFKO0FBQVV0SixTQUFPLENBQUMvQyxJQUFSLENBQWEsY0FBYixFQUE0QjtBQUFDcU0sU0FBSyxDQUFDcE0sQ0FBRCxFQUFHO0FBQUNvTSxXQUFLLEdBQUNwTSxDQUFOO0FBQVE7O0FBQWxCLEdBQTVCLEVBQWdELENBQWhEO0FBQW1ELE1BQUlxTSxLQUFKO0FBQVV2SixTQUFPLENBQUMvQyxJQUFSLENBQWEsY0FBYixFQUE0QjtBQUFDeUcsV0FBTyxDQUFDeEcsQ0FBRCxFQUFHO0FBQUNxTSxXQUFLLEdBQUNyTSxDQUFOO0FBQVE7O0FBQXBCLEdBQTVCLEVBQWtELENBQWxEO0FBQXFELE1BQUl0QixTQUFKO0FBQWNvRSxTQUFPLENBQUMvQyxJQUFSLENBQWEsa0JBQWIsRUFBZ0M7QUFBQ3JCLGFBQVMsQ0FBQ3NCLENBQUQsRUFBRztBQUFDdEIsZUFBUyxHQUFDc0IsQ0FBVjtBQUFZOztBQUExQixHQUFoQyxFQUE0RCxDQUE1RDs7QUFPNVEsTUFBSSxDQUFDaUQsTUFBTSxDQUFDa0MsU0FBUCxDQUFpQkMsWUFBdEIsRUFBb0M7QUFDaENuQyxVQUFNLENBQUNrQyxTQUFQLENBQWlCQyxZQUFqQixHQUFnQyxZQUFZO0FBQ3hDLGFBQU8sS0FBS0MsT0FBTCxDQUFhLFFBQWIsRUFBdUIsVUFBVUMsR0FBVixFQUFlO0FBQUUsZUFBT0EsR0FBRyxDQUFDQyxNQUFKLENBQVcsQ0FBWCxFQUFjQyxXQUFkLEtBQThCRixHQUFHLENBQUNHLE1BQUosQ0FBVyxDQUFYLEVBQWNDLFdBQWQsRUFBckM7QUFBbUUsT0FBM0csQ0FBUDtBQUNILEtBRkQ7QUFHSDs7QUFFRHlHLEtBQUcsQ0FBQ0csZUFBSixDQUFvQixhQUFwQixFQUFtQ0MsTUFBTSxDQUFDQyxPQUFQLENBQWUsaUNBQWYsQ0FBbkM7QUFFQUMsVUFBUSxDQUFDQyxXQUFULENBQXFCQyxPQUFyQixDQUE2QjtBQUN6QmhDLGNBQVUsRUFBRSxZQUFZO0FBQ3BCLGFBQU8sS0FBSzlKLE1BQUwsS0FBZ0JuQyxTQUFTLENBQUNNLGlCQUFWLENBQTRCRSxRQUFuRDtBQUNIO0FBSHdCLEdBQTdCO0FBTUEsUUFBTW9LLFdBQVcsR0FBRyxFQUFwQjs7QUFFQUEsYUFBVyxDQUFDc0QsU0FBWixHQUF3QixDQUFDQyxFQUFELEVBQUtoQyxJQUFMLEVBQVdpQyxPQUFYLEVBQW9CQyxJQUFwQixLQUE2QjtBQUNqRFYsU0FBSyxDQUFDLENBQUNRLEVBQUQsRUFBS2hDLElBQUwsRUFBV2lDLE9BQVgsRUFBb0JDLElBQXBCLENBQUQsRUFBNEIsQ0FBQzlKLE1BQUQsQ0FBNUIsQ0FBTDtBQUVBbkQsVUFBTSxDQUFDa04sS0FBUCxDQUFhLFlBQVk7QUFDckJaLFdBQUssQ0FBQ2EsSUFBTixDQUFXO0FBQ1BKLFVBQUUsRUFBRUEsRUFERztBQUVQaEMsWUFBSSxFQUFFQSxJQUFJLElBQUksc0JBRlA7QUFHUGlDLGVBQU8sRUFBRUEsT0FIRjtBQUlQQyxZQUFJLEVBQUVBO0FBSkMsT0FBWDtBQU1ILEtBUEQ7QUFRSCxHQVhEOztBQWFBekQsYUFBVyxDQUFDMEIsYUFBWixHQUE0QixDQUFDNkIsRUFBRCxFQUFLaEMsSUFBTCxFQUFXaUMsT0FBWCxFQUFvQkksWUFBcEIsRUFBa0NqRCxJQUFsQyxLQUEyQztBQUNuRSxRQUFJa0QsSUFBSSxHQUFHaEIsR0FBRyxDQUFDaUIsTUFBSixDQUFXRixZQUFYLEVBQXlCakQsSUFBekIsQ0FBWDtBQUVBbkssVUFBTSxDQUFDa04sS0FBUCxDQUFhLFlBQVk7QUFDckJaLFdBQUssQ0FBQ2EsSUFBTixDQUFXO0FBQ1BKLFVBQUUsRUFBRUEsRUFERztBQUVQaEMsWUFBSSxFQUFFQSxJQUFJLElBQUksc0JBRlA7QUFHUGlDLGVBQU8sRUFBRUEsT0FIRjtBQUlQTyxZQUFJLEVBQUVGO0FBSkMsT0FBWDtBQU1ILEtBUEQ7QUFRSCxHQVhEOztBQWFBM04sUUFBTSxDQUFDQyxPQUFQLEdBQWlCO0FBQUU2SjtBQUFGLEdBQWpCOzs7Ozs7Ozs7Ozs7QUNqREEsSUFBSXhKLE1BQUo7QUFBV04sTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFFWEYsTUFBTSxDQUFDd04sT0FBUCxDQUFlLE1BQU0sQ0FDbkI7QUFDRCxDQUZELEU7Ozs7Ozs7Ozs7O0FDRkE5TixNQUFNLENBQUMrTixNQUFQLENBQWM7QUFBQ0Msc0JBQW9CLEVBQUMsTUFBSUE7QUFBMUIsQ0FBZDs7QUFBK0QsSUFBSWpNLENBQUo7O0FBQU0vQixNQUFNLENBQUNPLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDd0IsR0FBQyxDQUFDdkIsQ0FBRCxFQUFHO0FBQUN1QixLQUFDLEdBQUN2QixDQUFGO0FBQUk7O0FBQVYsQ0FBaEMsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSXlNLFFBQUo7QUFBYWpOLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLG1CQUFaLEVBQWdDO0FBQUMwTSxVQUFRLENBQUN6TSxDQUFELEVBQUc7QUFBQ3lNLFlBQVEsR0FBQ3pNLENBQVQ7QUFBVzs7QUFBeEIsQ0FBaEMsRUFBMEQsQ0FBMUQ7QUFBNkQsSUFBSXlOLEtBQUo7QUFBVWpPLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQzBOLE9BQUssQ0FBQ3pOLENBQUQsRUFBRztBQUFDeU4sU0FBSyxHQUFDek4sQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJME4sT0FBSjtBQUFZbE8sTUFBTSxDQUFDTyxJQUFQLENBQVksZ0JBQVosRUFBNkI7QUFBQzJOLFNBQU8sQ0FBQzFOLENBQUQsRUFBRztBQUFDME4sV0FBTyxHQUFDMU4sQ0FBUjtBQUFVOztBQUF0QixDQUE3QixFQUFxRCxDQUFyRDs7QUFNdFEsTUFBTTJOLE9BQU8sR0FBRyxTQUFTQSxPQUFULENBQWlCQyxRQUFqQixFQUEyQjtBQUN2QyxRQUFNQyxFQUFFLEdBQUdDLFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixLQUF2QixDQUFYO0FBQ0FELFVBQVEsQ0FBQ1gsSUFBVCxDQUFjYSxXQUFkLENBQTBCSCxFQUExQjs7QUFFQSxNQUFJO0FBQ0FELFlBQVEsQ0FBQ0MsRUFBRCxDQUFSO0FBQ0gsR0FGRCxTQUVVO0FBQ05DLFlBQVEsQ0FBQ1gsSUFBVCxDQUFjYyxXQUFkLENBQTBCSixFQUExQjtBQUNIO0FBQ0osQ0FURDs7QUFXTyxNQUFNTCxvQkFBb0IsR0FBRyxTQUFTQSxvQkFBVCxDQUE4QlUsUUFBOUIsRUFBd0NqRSxJQUF4QyxFQUE4QzJELFFBQTlDLEVBQXdEO0FBQ3hGRCxTQUFPLENBQUVFLEVBQUQsSUFBUTtBQUNaLFVBQU1NLFdBQVcsR0FBRzVNLENBQUMsQ0FBQzZNLFFBQUYsQ0FBV0YsUUFBWCxJQUF1QnpCLFFBQVEsQ0FBQ3lCLFFBQUQsQ0FBL0IsR0FBNENBLFFBQWhFO0FBQ0FULFNBQUssQ0FBQ1ksY0FBTixDQUFxQkYsV0FBckIsRUFBa0NsRSxJQUFsQyxFQUF3QzRELEVBQXhDO0FBQ0FILFdBQU8sQ0FBQ1ksS0FBUjtBQUNBVixZQUFRLENBQUNDLEVBQUQsRUFBS00sV0FBTCxDQUFSO0FBQ0gsR0FMTSxDQUFQO0FBTUgsQ0FQTSxDOzs7Ozs7Ozs7Ozs7QUNqQlAsTUFBSXBNLE1BQUo7QUFBV2UsU0FBTyxDQUFDL0MsSUFBUixDQUFhLGVBQWIsRUFBNkI7QUFBQ2dDLFVBQU0sQ0FBQy9CLENBQUQsRUFBRztBQUFDK0IsWUFBTSxHQUFDL0IsQ0FBUDtBQUFTOztBQUFwQixHQUE3QixFQUFtRCxDQUFuRDs7QUFBc0QsTUFBSXVCLENBQUo7O0FBQU11QixTQUFPLENBQUMvQyxJQUFSLENBQWEsbUJBQWIsRUFBaUM7QUFBQ3dCLEtBQUMsQ0FBQ3ZCLENBQUQsRUFBRztBQUFDdUIsT0FBQyxHQUFDdkIsQ0FBRjtBQUFJOztBQUFWLEdBQWpDLEVBQTZDLENBQTdDO0FBQWdELE1BQUl0QixTQUFKO0FBQWNvRSxTQUFPLENBQUMvQyxJQUFSLENBQWEsa0JBQWIsRUFBZ0M7QUFBQ3JCLGFBQVMsQ0FBQ3NCLENBQUQsRUFBRztBQUFDdEIsZUFBUyxHQUFDc0IsQ0FBVjtBQUFZOztBQUExQixHQUFoQyxFQUE0RCxDQUE1RDtBQUtySSxRQUFNdU8sUUFBUSxHQUFHO0FBRWJDLGdCQUFZLENBQUNDLFVBQUQsRUFBYTtBQUNyQixVQUFJQyxLQUFLLEdBQUcsRUFBWjs7QUFFQSxVQUFJLENBQUNuTixDQUFDLENBQUM4SCxXQUFGLENBQWNvRixVQUFkLENBQUwsRUFBZ0M7QUFDNUJDLGFBQUssR0FBR0QsVUFBUjtBQUNIOztBQUVELFlBQU16SixRQUFRLEdBQUcsRUFBakI7QUFDQUEsY0FBUSxDQUFDQyxlQUFULEdBQTJCLGNBQTNCO0FBQ0FELGNBQVEsQ0FBQ2QsZ0JBQVQsR0FBNEIsd0JBQTVCO0FBQ0FjLGNBQVEsQ0FBQ2IsY0FBVCxHQUEwQixzQkFBMUI7QUFDQWEsY0FBUSxDQUFDWixjQUFULEdBQTBCLHNCQUExQjtBQUVBLGFBQU9ZLFFBQVA7QUFDSCxLQWhCWTs7QUFpQmIySix3QkFBb0IsQ0FBQ0YsVUFBRCxFQUFhO0FBQzdCLFVBQUlDLEtBQUssR0FBRyxFQUFaOztBQUVBLFVBQUksQ0FBQ25OLENBQUMsQ0FBQzhILFdBQUYsQ0FBY29GLFVBQWQsQ0FBTCxFQUFnQztBQUM1QkMsYUFBSyxHQUFHRCxVQUFSO0FBQ0g7O0FBRUQsWUFBTTdJLFdBQVcsR0FBRyxFQUFwQjtBQUVBQSxpQkFBVyxDQUFDd0MsSUFBWixDQUFpQjtBQUFFNUQsWUFBSSxFQUFFLFNBQVI7QUFBbUJNLGFBQUssRUFBRTtBQUExQixPQUFqQjtBQUNBYyxpQkFBVyxDQUFDd0MsSUFBWixDQUFpQjtBQUFFNUQsWUFBSSxFQUFFLFNBQVI7QUFBbUJNLGFBQUssRUFBRTtBQUExQixPQUFqQjtBQUNBYyxpQkFBVyxDQUFDd0MsSUFBWixDQUFpQjtBQUFFNUQsWUFBSSxFQUFFLFdBQVI7QUFBcUJNLGFBQUssRUFBRTtBQUE1QixPQUFqQjtBQUNBYyxpQkFBVyxDQUFDd0MsSUFBWixDQUFpQjtBQUFFNUQsWUFBSSxFQUFFLFVBQVI7QUFBb0JNLGFBQUssRUFBRTtBQUEzQixPQUFqQjtBQUNBYyxpQkFBVyxDQUFDd0MsSUFBWixDQUFpQjtBQUFFNUQsWUFBSSxFQUFFLFVBQVI7QUFBb0JNLGFBQUssRUFBRTtBQUEzQixPQUFqQjtBQUVBLGFBQU9jLFdBQVA7QUFDSCxLQWpDWTs7QUFtQ2JnSixtQkFBZSxDQUFDSCxVQUFELEVBQWE7QUFDeEIsVUFBSUMsS0FBSyxHQUFHLEVBQVo7O0FBRUEsVUFBSSxDQUFDbk4sQ0FBQyxDQUFDOEgsV0FBRixDQUFjb0YsVUFBZCxDQUFMLEVBQWdDO0FBQzVCQyxhQUFLLEdBQUdELFVBQVI7QUFDSDs7QUFFRCxZQUFNSSxXQUFXLEdBQUcsRUFBcEI7QUFFQUEsaUJBQVcsQ0FBQzlOLEdBQVosR0FBa0IyTixLQUFLLENBQUMzTixHQUFOLElBQWFnQixNQUFNLENBQUM2RyxFQUFQLEVBQS9CO0FBQ0FpRyxpQkFBVyxDQUFDbE8sU0FBWixHQUF3QitOLEtBQUssQ0FBQy9OLFNBQU4sSUFBbUJvQixNQUFNLENBQUM2RyxFQUFQLEVBQTNDO0FBQ0FpRyxpQkFBVyxDQUFDbEwsU0FBWixHQUF3QitLLEtBQUssQ0FBQy9LLFNBQU4sSUFBbUIsSUFBSXhCLElBQUosRUFBM0M7QUFDQTBNLGlCQUFXLENBQUN2TCxLQUFaLEdBQW9Cb0wsS0FBSyxDQUFDcEwsS0FBTixJQUFlLFlBQW5DO0FBQ0F1TCxpQkFBVyxDQUFDaE8sTUFBWixHQUFxQjZOLEtBQUssQ0FBQzdOLE1BQU4sSUFBZ0JuQyxTQUFTLENBQUNNLGlCQUFWLENBQTRCQyxPQUFqRTtBQUNBNFAsaUJBQVcsQ0FBQ3pNLFdBQVosR0FBMEJzTSxLQUFLLENBQUN0TSxXQUFOLElBQXFCLElBQS9DO0FBRUEsYUFBT3lNLFdBQVA7QUFDSCxLQXBEWTs7QUFzRGJDLGlCQUFhLENBQUNMLFVBQUQsRUFBYTtBQUN0QixVQUFJQyxLQUFLLEdBQUcsRUFBWjs7QUFFQSxVQUFJLENBQUNuTixDQUFDLENBQUM4SCxXQUFGLENBQWNvRixVQUFkLENBQUwsRUFBZ0M7QUFDNUJDLGFBQUssR0FBR0QsVUFBUjtBQUNIOztBQUVELFlBQU0xTCxTQUFTLEdBQUcsRUFBbEI7QUFFQUEsZUFBUyxDQUFDMUMsTUFBVixHQUFtQnFPLEtBQUssQ0FBQ3JPLE1BQU4sSUFBZ0IwQixNQUFNLENBQUM2RyxFQUFQLEVBQW5DO0FBQ0E3RixlQUFTLENBQUNPLEtBQVYsR0FBa0JvTCxLQUFLLENBQUNwTCxLQUFOLElBQWUsWUFBakM7QUFDQVAsZUFBUyxDQUFDbEMsTUFBVixHQUFtQjZOLEtBQUssQ0FBQzdOLE1BQU4sSUFBZ0JuQyxTQUFTLENBQUNNLGlCQUFWLENBQTRCQyxPQUEvRDtBQUNBOEQsZUFBUyxDQUFDVSxRQUFWLEdBQXFCaUwsS0FBSyxDQUFDakwsUUFBTixJQUFrQjFCLE1BQU0sQ0FBQ2dOLE1BQVAsQ0FBYyxDQUFDclEsU0FBUyxDQUFDUyxjQUFWLENBQXlCQyxLQUExQixFQUFpQ1YsU0FBUyxDQUFDUyxjQUFWLENBQXlCRSxHQUExRCxFQUErRFgsU0FBUyxDQUFDUyxjQUFWLENBQXlCRyxHQUF4RixDQUFkLENBQXZDO0FBQ0F5RCxlQUFTLENBQUNILEtBQVYsR0FBa0I4TCxLQUFLLENBQUM5TCxLQUFOLElBQWUsQ0FBakM7QUFDQUcsZUFBUyxDQUFDWSxTQUFWLEdBQXNCK0ssS0FBSyxDQUFDL0ssU0FBTixJQUFtQixJQUFJeEIsSUFBSixFQUF6QztBQUVBLGFBQU9ZLFNBQVA7QUFDSCxLQXZFWTs7QUF5RWJpTSxrQkFBYyxDQUFDUCxVQUFELEVBQWFRLEtBQWIsRUFBb0I7QUFDOUIsWUFBTXROLEtBQUssR0FBRyxFQUFkO0FBRUEsVUFBSSxDQUFDc04sS0FBTCxFQUFZQSxLQUFLLEdBQUcsQ0FBUjs7QUFFWixXQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdELEtBQXBCLEVBQTJCQyxDQUFDLElBQUksQ0FBaEMsRUFBbUM7QUFDL0J2TixhQUFLLENBQUN5RyxJQUFOLENBQVcsS0FBSzBHLGFBQUwsQ0FBbUJMLFVBQW5CLENBQVgsRUFEK0IsQ0FDWTtBQUM5Qzs7QUFFRCxhQUFPOU0sS0FBUDtBQUNILEtBbkZZOztBQXFGYndOLGFBQVMsQ0FBQ1YsVUFBRCxFQUFhO0FBQ2xCLFVBQUlDLEtBQUssR0FBRyxFQUFaOztBQUVBLFVBQUksQ0FBQ25OLENBQUMsQ0FBQzhILFdBQUYsQ0FBY29GLFVBQWQsQ0FBTCxFQUFnQztBQUM1QkMsYUFBSyxHQUFHRCxVQUFSO0FBQ0g7O0FBRUQsWUFBTVcsS0FBSyxHQUFHLEVBQWQ7QUFFQUEsV0FBSyxDQUFDck8sR0FBTixHQUFZMk4sS0FBSyxDQUFDM04sR0FBTixJQUFhZ0IsTUFBTSxDQUFDNkcsRUFBUCxFQUF6QjtBQUNBd0csV0FBSyxDQUFDekwsU0FBTixHQUFrQixJQUFJeEIsSUFBSixFQUFsQjtBQUNBaU4sV0FBSyxDQUFDek8sU0FBTixHQUFrQitOLEtBQUssQ0FBQy9OLFNBQU4sSUFBbUJvQixNQUFNLENBQUM2RyxFQUFQLEVBQXJDO0FBQ0F3RyxXQUFLLENBQUM5TCxLQUFOLEdBQWNvTCxLQUFLLENBQUNwTCxLQUFOLElBQWUsWUFBN0I7QUFDQThMLFdBQUssQ0FBQ3ZPLE1BQU4sR0FBZTZOLEtBQUssQ0FBQzdOLE1BQU4sSUFBZ0JuQyxTQUFTLENBQUNDLGFBQVYsQ0FBd0JDLE1BQXZEO0FBQ0F3USxXQUFLLENBQUN6TixLQUFOLEdBQWMrTSxLQUFLLENBQUMvTSxLQUFOLElBQWUsS0FBS3FOLGNBQUwsQ0FBb0IsRUFBcEIsRUFBd0JOLEtBQUssQ0FBQ08sS0FBTixJQUFlLENBQXZDLENBQTdCO0FBQ0FHLFdBQUssQ0FBQzNNLGFBQU4sR0FBc0JsQixDQUFDLENBQUM4SCxXQUFGLENBQWNxRixLQUFLLENBQUNqTSxhQUFwQixJQUFxQyxLQUFyQyxHQUE2Q2lNLEtBQUssQ0FBQ2pNLGFBQXpFO0FBQ0EyTSxXQUFLLENBQUNuTCxVQUFOLEdBQW1CeUssS0FBSyxDQUFDekssVUFBTixJQUFvQixJQUFJOUIsSUFBSixFQUF2QztBQUNBaU4sV0FBSyxDQUFDbEwsZ0JBQU4sR0FBeUIsd0JBQXpCO0FBQ0FrTCxXQUFLLENBQUNqTCxjQUFOLEdBQXVCLHNCQUF2QjtBQUNBaUwsV0FBSyxDQUFDaEwsY0FBTixHQUF1QixzQkFBdkI7O0FBQ0EsVUFBSXNLLEtBQUssQ0FBQ3JLLFdBQVYsRUFBdUI7QUFDbkIrSyxhQUFLLENBQUMvSyxXQUFOLEdBQW9CcUssS0FBSyxDQUFDckssV0FBMUI7QUFDSDs7QUFFRCxhQUFPK0ssS0FBUDtBQUNIOztBQTlHWSxHQUFqQjtBQWlIQTVQLFFBQU0sQ0FBQ0MsT0FBUCxHQUFpQjtBQUFFOE87QUFBRixHQUFqQiIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgQ29uc3RhbnRzID0ge1xuICAgIFJldHJvU3RhdHVzZXM6IHtcbiAgICAgICAgQUNUSVZFOiAnQWN0aXZlJyxcbiAgICAgICAgQVJDSElWRUQ6ICdBcmNoaXZlZCcsXG4gICAgICAgIEZST1pFTjogJ0Zyb3plbicsXG4gICAgICAgIHZhbHVlczogWydBY3RpdmUnLCAnQXJjaGl2ZWQnLCAnRnJvemVuJ11cbiAgICB9LFxuICAgIFJldHJvSXRlbVN0YXR1c2VzOiB7XG4gICAgICAgIFBFTkRJTkc6ICdQZW5kaW5nJyxcbiAgICAgICAgQ09NUExFVEU6ICdDb21wbGV0ZScsXG4gICAgICAgIHZhbHVlczogWydQZW5kaW5nJywgJ0NvbXBsZXRlJ11cbiAgICB9LFxuICAgIFJldHJvSXRlbVR5cGVzOiB7XG4gICAgICAgIEhBUFBZOiAnSGFwcHknLFxuICAgICAgICBNRUg6ICdNZWgnLFxuICAgICAgICBTQUQ6ICdTYWQnLFxuICAgICAgICBBQ1RJT046ICdBY3Rpb24nLFxuICAgICAgICB2YWx1ZXM6IFsnSGFwcHknLCAnTWVoJywgJ1NhZCcsICdBY3Rpb24nXVxuICAgIH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSB7IENvbnN0YW50cyB9XG4iLCJjb25zdCBMb2dnZXIgPSB7XG4gICAgbG9nOiAobWVzc2FnZSkgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZyhtZXNzYWdlKVxuICAgIH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSB7IExvZ2dlciB9XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgUmV0cm9zIH0gZnJvbSAnLi9zZXF1ZW50J1xuaW1wb3J0IHsgU2NoZW1hcyB9IGZyb20gJy4vc2NoZW1hcydcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4vY29uc3RhbnRzJ1xuaW1wb3J0IHsgTG9nZ2VyIH0gZnJvbSAnLi9sb2dnZXInXG5cbk1ldGVvci5tZXRob2RzKHtcblxuICAgIGNvbXBsZXRlUmV0cm9JdGVtKGl0ZW1JZCkge1xuICAgICAgICBjb25zdCByZXRyb0lkID0gJydcblxuICAgICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtbG9nZ2VkLWluJywgJ1lvdSBtdXN0IGJlIGxvZ2dlZCBpbnRvIGEgcmV0cm8gYm9hcmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHZhbGlkYXRlIGl0ZW0gdHlwZVxuXG4gICAgICAgIGNvbnN0IHJldHJvID0gUmV0cm9zLmZpbmRPbmUoe1xuICAgICAgICAgICAgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCxcbiAgICAgICAgICAgICRvcjogW1xuICAgICAgICAgICAgICAgIHsgc3RhdHVzOiBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5BQ1RJVkUgfSxcbiAgICAgICAgICAgICAgICB7IHN0YXR1czogQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuRlJPWkVOIH1cbiAgICAgICAgICAgIF1cbiAgICAgICAgfSlcblxuICAgICAgICAvLyBuZWVkIHRvIHNlZSBpZiB0aGVyZSBpc1xuICAgICAgICBpZiAoIXJldHJvKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtZm91bmQnLCAnUmV0cm8gbm90IGZvdW5kIScpXG4gICAgICAgIH1cblxuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBSZXRyb3MudXBkYXRlKFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgX2lkOiByZXRyby5faWQsXG4gICAgICAgICAgICAgICAgICAgICdpdGVtcy5pdGVtSWQnOiBpdGVtSWRcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgJHNldDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgJ2l0ZW1zLiQuc3RhdHVzJzogQ29uc3RhbnRzLlJldHJvSXRlbVN0YXR1c2VzLkNPTVBMRVRFXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgTG9nZ2VyLmxvZyhlcnIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCd1cGRhdGUtZmFpbGVkJywgJ1dlIGNvdWxkIG5vdCBjb21wbGV0ZSB0aGUgcmV0cm8gaXRlbSAtIHBsZWFzZSB0cnkgYWdhaW4gbGF0ZXInKVxuICAgICAgICB9XG4gICAgfVxuXG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IFJldHJvcywgUmV0cm9BY3Rpb25zIH0gZnJvbSAnLi9zZXF1ZW50J1xuaW1wb3J0IHsgU2NoZW1hcyB9IGZyb20gJy4vc2NoZW1hcydcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4vY29uc3RhbnRzJ1xuaW1wb3J0IHsgTG9nZ2VyIH0gZnJvbSAnLi9sb2dnZXInXG5cbk1ldGVvci5tZXRob2RzKHtcblxuICAgIHJlbW92ZUFjdGlvbihhY3Rpb25JZCkge1xuICAgICAgICBjb25zdCByZXRyb0lkID0gJydcblxuICAgICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtbG9nZ2VkLWluJywgJ1lvdSBtdXN0IGJlIGxvZ2dlZCBpbnRvIGEgcmV0cm8gYm9hcmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGFjdGlvbiA9IFJldHJvQWN0aW9ucy5maW5kT25lKHsgX2lkOiBhY3Rpb25JZCwgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCB9KVxuXG4gICAgICAgIGlmICghYWN0aW9uKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtZm91bmQnLCAnQWN0aW9uIG5vdCBmb3VuZCEnKVxuICAgICAgICB9XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBSZXRyb0FjdGlvbnMucmVtb3ZlKHsgX2lkOiBhY3Rpb25JZCB9KVxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIExvZ2dlci5sb2coZXJyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignZGVsZXRlLWZhaWxlZCcsICdXZSBjb3VsZCBub3QgZGVsZXRlIHRoZSBhY3Rpb24gLSBwbGVhc2UgdHJ5IGFnYWluIGxhdGVyJylcbiAgICAgICAgfVxuICAgIH1cblxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBfIH0gZnJvbSAnbWV0ZW9yL3VuZGVyc2NvcmUnXG5pbXBvcnQgeyBSZXRyb3MgfSBmcm9tICcuL3NlcXVlbnQnXG5pbXBvcnQgeyBTY2hlbWFzIH0gZnJvbSAnLi9zY2hlbWFzJ1xuaW1wb3J0IHsgQ29uc3RhbnRzIH0gZnJvbSAnLi9jb25zdGFudHMnXG5pbXBvcnQgeyBMb2dnZXIgfSBmcm9tICcuL2xvZ2dlcidcblxuTWV0ZW9yLm1ldGhvZHMoe1xuXG4gICAgcmVtb3ZlUmV0cm9JdGVtKGl0ZW1JZCkge1xuICAgICAgICBjb25zdCByZXRyb0lkID0gJydcblxuICAgICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtbG9nZ2VkLWluJywgJ1lvdSBtdXN0IGJlIGxvZ2dlZCBpbnRvIGEgcmV0cm8gYm9hcmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHJldHJvID0gUmV0cm9zLmZpbmRPbmUoe1xuICAgICAgICAgICAgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCxcbiAgICAgICAgICAgICRvcjogW1xuICAgICAgICAgICAgICAgIHsgc3RhdHVzOiBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5BQ1RJVkUgfSxcbiAgICAgICAgICAgICAgICB7IHN0YXR1czogQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuRlJPWkVOIH0sXG4gICAgICAgICAgICBdLFxuICAgICAgICB9KVxuXG4gICAgICAgIC8vIG5lZWQgdG8gc2VlIGlmIHRoZXJlIGlzXG4gICAgICAgIGlmICghcmV0cm8pIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1mb3VuZCcsICdSZXRybyBub3QgZm91bmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHJldHJvSXRlbSA9IF8uZmlsdGVyKHJldHJvLml0ZW1zLCBmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgICAgICAgcmV0dXJuIGl0ZW0uaXRlbUlkID09PSBpdGVtSWRcbiAgICAgICAgfSlcblxuICAgICAgICBpZiAocmV0cm9JdGVtLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWZvdW5kJywgJ1JldHJvIEl0ZW0gbm90IGZvdW5kIScpXG4gICAgICAgIH1cblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgUmV0cm9zLnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIF9pZDogcmV0cm8uX2lkLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAkcHVsbDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgaXRlbXM6IHsgaXRlbUlkOiBpdGVtSWQgfSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgKVxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIExvZ2dlci5sb2coZXJyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcigndXBkYXRlLWZhaWxlZCcsICdXZSBjb3VsZCBub3QgcmVtb3ZlIHJldHJvIGl0ZW0gLSBwbGVhc2UgdHJ5IGFnYWluIGxhdGVyJylcbiAgICAgICAgfVxuICAgIH0sXG5cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgUmFuZG9tIH0gZnJvbSAnbWV0ZW9yL3JhbmRvbSdcbmltcG9ydCB7IFJldHJvcywgUmV0cm9BY3Rpb25zIH0gZnJvbSAnLi4vbGliL3NlcXVlbnQnXG5pbXBvcnQgeyBTY2hlbWFzIH0gZnJvbSAnLi9zY2hlbWFzJ1xuaW1wb3J0IHsgQ29uc3RhbnRzIH0gZnJvbSAnLi9jb25zdGFudHMnXG5pbXBvcnQgeyBMb2dnZXIgfSBmcm9tICcuL2xvZ2dlcidcblxuTWV0ZW9yLm1ldGhvZHMoe1xuXG4gICAgdG9nZ2xlQWN0aW9uKGFjdGlvbklkKSB7XG4gICAgICAgIGNvbnN0IHJldHJvSWQgPSAnJ1xuXG4gICAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1sb2dnZWQtaW4nLCAnWW91IG11c3QgYmUgbG9nZ2VkIGludG8gYSByZXRybyBib2FyZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgYWN0aW9uID0gUmV0cm9BY3Rpb25zLmZpbmRPbmUoeyBfaWQ6IGFjdGlvbklkLCBjcmVhdGVkQnk6IHRoaXMudXNlcklkIH0pXG5cbiAgICAgICAgaWYgKCFhY3Rpb24pIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1mb3VuZCcsICdSZXRyb0FjdGlvbiBub3QgZm91bmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IG5ld1ZhbHVlID0gYWN0aW9uLnN0YXR1cyA9PT0gQ29uc3RhbnRzLlJldHJvSXRlbVN0YXR1c2VzLlBFTkRJTkcgPyBDb25zdGFudHMuUmV0cm9JdGVtU3RhdHVzZXMuQ09NUExFVEUgOiBDb25zdGFudHMuUmV0cm9JdGVtU3RhdHVzZXMuUEVORElOR1xuXG4gICAgICAgIGxldCBuZXdEYXRlXG5cbiAgICAgICAgaWYgKG5ld1ZhbHVlID09PSBDb25zdGFudHMuUmV0cm9JdGVtU3RhdHVzZXMuQ09NUExFVEUpIHtcbiAgICAgICAgICAgIG5ld0RhdGUgPSBuZXcgRGF0ZSgpXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBuZXdEYXRlID0gbnVsbFxuICAgICAgICB9XG5cblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgUmV0cm9BY3Rpb25zLnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7IF9pZDogYWN0aW9uSWQgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICRzZXQ6XG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czogbmV3VmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBjb21wbGV0ZWRBdDogbmV3RGF0ZVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKVxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIExvZ2dlci5sb2coZXJyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignZGVsZXRlLWZhaWxlZCcsICdXZSBjb3VsZCBub3QgZGVsZXRlIHRoZSBhY3Rpb24gLSBwbGVhc2UgdHJ5IGFnYWluIGxhdGVyJylcbiAgICAgICAgfVxuICAgIH1cblxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBSZXRyb3MsIFJldHJvQWN0aW9ucyB9IGZyb20gJy4vc2VxdWVudCdcbmltcG9ydCB7IFNjaGVtYXMgfSBmcm9tICcuL3NjaGVtYXMnXG5pbXBvcnQgeyBDb25zdGFudHMgfSBmcm9tICcuL2NvbnN0YW50cydcbmltcG9ydCB7IExvZ2dlciB9IGZyb20gJy4vbG9nZ2VyJ1xuXG5NZXRlb3IubWV0aG9kcyh7XG5cbiAgICB0b2dnbGVSZXRyb0Zyb3plbigpIHtcbiAgICAgICAgY29uc3QgcmV0cm9JZCA9ICcnXG5cbiAgICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWxvZ2dlZC1pbicsICdZb3UgbXVzdCBiZSBsb2dnZWQgaW50byBhIHJldHJvIGJvYXJkIScpXG4gICAgICAgIH1cblxuICAgICAgICAvLyB2YWxpZGF0ZSBpdGVtIHR5cGVcblxuICAgICAgICBjb25zdCByZXRybyA9IFJldHJvcy5maW5kT25lKHtcbiAgICAgICAgICAgIGNyZWF0ZWRCeTogdGhpcy51c2VySWQsXG4gICAgICAgICAgICAkb3I6XG4gICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgeyBzdGF0dXM6IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkFDVElWRSB9LFxuICAgICAgICAgICAgICAgIHsgc3RhdHVzOiBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5GUk9aRU4gfVxuICAgICAgICAgICAgXVxuICAgICAgICB9KVxuXG4gICAgICAgIC8vIG5lZWQgdG8gc2VlIGlmIHRoZXJlIGlzXG4gICAgICAgIGlmICghcmV0cm8pIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1mb3VuZCcsICdSZXRybyBub3QgZm91bmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChyZXRyby5zdGF0dXMgPT09IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkFSQ0hJVkVEKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdpbnZhbGlkLXN0YXRlJywgJ1JldHJvIG11c3Qgbm90IGJlIGFyY2hpdmVkIScpXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBuZXdTdGF0dXMgPSByZXRyby5zdGF0dXMgPT09IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkZST1pFTiA/IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkFDVElWRSA6IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkZST1pFTlxuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBSZXRyb3MudXBkYXRlKFxuICAgICAgICAgICAgICAgIHsgX2lkOiByZXRyby5faWQgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICRzZXQ6XG4gICAgICAgICAgICAgICAgICAgIHsgc3RhdHVzOiBuZXdTdGF0dXMgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIClcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBMb2dnZXIubG9nKGVycilcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ3VwZGF0ZS1mYWlsZWQnLCAnV2UgY291bGQgbm90IGZyZWV6ZSB0aGUgcmV0cm8gLSBwbGVhc2UgdHJ5IGFnYWluIGxhdGVyJylcbiAgICAgICAgfVxuICAgIH1cblxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBSZXRyb3MsIFJldHJvQWN0aW9ucyB9IGZyb20gJy4vc2VxdWVudCdcbmltcG9ydCB7IFNjaGVtYXMgfSBmcm9tICcuL3NjaGVtYXMnXG5pbXBvcnQgeyBDb25zdGFudHMgfSBmcm9tICcuL2NvbnN0YW50cydcbmltcG9ydCB7IExvZ2dlciB9IGZyb20gJy4vbG9nZ2VyJ1xuXG5NZXRlb3IubWV0aG9kcyh7XG5cbiAgICB0b2dnbGVTaG93Q29tcGxldGVkKCkge1xuICAgICAgICBjb25zdCByZXRyb0lkID0gJydcblxuICAgICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtbG9nZ2VkLWluJywgJ1lvdSBtdXN0IGJlIGxvZ2dlZCBpbnRvIGEgcmV0cm8gYm9hcmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHJldHJvID0gUmV0cm9zLmZpbmRPbmUoe1xuICAgICAgICAgICAgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCxcbiAgICAgICAgICAgICRvcjpcbiAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICB7IHN0YXR1czogQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuQUNUSVZFIH0sXG4gICAgICAgICAgICAgICAgeyBzdGF0dXM6IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkZST1pFTiB9XG4gICAgICAgICAgICBdXG4gICAgICAgIH0pXG5cbiAgICAgICAgLy8gbmVlZCB0byBzZWUgaWYgdGhlcmUgaXNcbiAgICAgICAgaWYgKCFyZXRybykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWZvdW5kJywgJ1JldHJvIG5vdCBmb3VuZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3Qgc2hvdyA9ICFyZXRyby5zaG93Q29tcGxldGVkXG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIFJldHJvcy51cGRhdGUoXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBfaWQ6IHJldHJvLl9pZFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAkc2V0OlxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93Q29tcGxldGVkOiBzaG93XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgTG9nZ2VyLmxvZyhlcnIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCd1cGRhdGUtZmFpbGVkJywgJ1dlIGNvdWxkIHRvZ2dsZSByZXRybyBzaG93IGNvbXBsZXRlZCAtIHBsZWFzZSB0cnkgYWdhaW4gbGF0ZXInKVxuICAgICAgICB9XG4gICAgfVxuXG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IF8gfSBmcm9tICdtZXRlb3IvdW5kZXJzY29yZSdcbmltcG9ydCB7IFJldHJvcyB9IGZyb20gJy4vc2VxdWVudCdcbmltcG9ydCB7IFNjaGVtYXMgfSBmcm9tICcuL3NjaGVtYXMnXG5pbXBvcnQgeyBDb25zdGFudHMgfSBmcm9tICcuL2NvbnN0YW50cydcbmltcG9ydCB7IExvZ2dlciB9IGZyb20gJy4vbG9nZ2VyJ1xuXG5NZXRlb3IubWV0aG9kcyh7XG5cbiAgICB1cFZvdGVJdGVtKGl0ZW1JZCkge1xuICAgICAgICBjb25zdCByZXRyb0lkID0gJydcblxuICAgICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtbG9nZ2VkLWluJywgJ1lvdSBtdXN0IGJlIGxvZ2dlZCBpbnRvIGEgcmV0cm8gYm9hcmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHZhbGlkYXRlIGl0ZW0gdHlwZVxuXG4gICAgICAgIGNvbnN0IHJldHJvID0gUmV0cm9zLmZpbmRPbmUoe1xuICAgICAgICAgICAgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCxcbiAgICAgICAgICAgIHN0YXR1czogQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuQUNUSVZFXG4gICAgICAgIH0pXG5cbiAgICAgICAgLy8gbmVlZCB0byBzZWUgaWYgdGhlcmUgaXNcbiAgICAgICAgaWYgKCFyZXRybykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWZvdW5kJywgJ1JldHJvIG5vdCBmb3VuZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcmV0cm9JdGVtID0gXy5maWx0ZXIocmV0cm8uaXRlbXMsIGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgICAgICByZXR1cm4gaXRlbS5pdGVtSWQgPT09IGl0ZW1JZFxuICAgICAgICB9KVxuXG4gICAgICAgIGlmIChyZXRyb0l0ZW0ubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtZm91bmQnLCAnUmV0cm8gSXRlbSBub3QgZm91bmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGxldCB2b3RlQ291bnQgPSByZXRyb0l0ZW1bMF0udm90ZXMgfHwgMFxuXG4gICAgICAgIHZvdGVDb3VudCArPSAxXG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIFJldHJvcy51cGRhdGUoXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBfaWQ6IHJldHJvLl9pZCxcbiAgICAgICAgICAgICAgICAgICAgJ2l0ZW1zLml0ZW1JZCc6IGl0ZW1JZFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAnaXRlbXMuJC52b3Rlcyc6IHZvdGVDb3VudFxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKVxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIExvZ2dlci5sb2coZXJyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcigndXBkYXRlLWZhaWxlZCcsICdXZSBjb3VsZCBub3QgdXB2b3RlIHRoaXMgaXRlbSAtIHBsZWFzZSB0cnkgYWdhaW4gbGF0ZXInKVxuICAgICAgICB9XG4gICAgfVxuXG59KVxuIiwiXG5pbXBvcnQgeyBTaW1wbGVTY2hlbWEgfSBmcm9tICdtZXRlb3IvYWxkZWVkOnNpbXBsZS1zY2hlbWEnXG5pbXBvcnQgeyBDb25zdGFudHMgfSBmcm9tICcuL2NvbnN0YW50cydcblxuY29uc3QgU2NoZW1hcyA9IHt9XG5cblNjaGVtYXMuUmV0cm9JdGVtID0gbmV3IFNpbXBsZVNjaGVtYSh7XG5cbiAgICBpdGVtSWQ6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICByZWdFeDogU2ltcGxlU2NoZW1hLlJlZ0V4LklkLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0sXG4gICAgdGl0bGU6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBtYXg6IDI1NVxuICAgIH0sXG4gICAgc3RhdHVzOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgYWxsb3dlZFZhbHVlczogQ29uc3RhbnRzLlJldHJvSXRlbVN0YXR1c2VzLnZhbHVlc1xuICAgIH0sXG4gICAgaXRlbVR5cGU6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBDb25zdGFudHMuUmV0cm9JdGVtVHlwZXMudmFsdWVzXG4gICAgfSxcbiAgICB2b3Rlczoge1xuICAgICAgICB0eXBlOiBOdW1iZXIsXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSxcbiAgICBjcmVhdGVkQXQ6IHtcbiAgICAgICAgdHlwZTogRGF0ZVxuICAgIH1cblxufSlcblxuU2NoZW1hcy5SZXRyb3MgPSBuZXcgU2ltcGxlU2NoZW1hKHtcblxuICAgIF9pZDoge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIHJlZ0V4OiBTaW1wbGVTY2hlbWEuUmVnRXguSWQsXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSxcbiAgICBjcmVhdGVkQXQ6IHtcbiAgICAgICAgdHlwZTogRGF0ZSxcbiAgICAgICAgYXV0b1ZhbHVlOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5pc0luc2VydCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy51bnNldCgpXG4gICAgICAgIH1cbiAgICB9LFxuICAgIGNyZWF0ZWRCeToge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIHJlZ0V4OiBTaW1wbGVTY2hlbWEuUmVnRXguSWQsXG4gICAgICAgIGF1dG9WYWx1ZTogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaWYgKHRoaXMuaXNJbnNlcnQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy51c2VySWQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLnVuc2V0KClcbiAgICAgICAgfVxuICAgIH0sXG4gICAgc3RhdHVzOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgYWxsb3dlZFZhbHVlczogQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMudmFsdWVzXG4gICAgfSxcbiAgICBpdGVtczoge1xuICAgICAgICB0eXBlOiBbU2NoZW1hcy5SZXRyb0l0ZW1dXG4gICAgfSxcbiAgICBzaG93Q29tcGxldGVkOiB7XG4gICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxuICAgICAgICBkZWZhdWx0VmFsdWU6IGZhbHNlXG4gICAgfSxcbiAgICBhcmNoaXZlZEF0OiB7XG4gICAgICAgIHR5cGU6IERhdGUsXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSxcbiAgICBoYXBweVBsYWNlaG9sZGVyOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9LFxuICAgIG1laFBsYWNlaG9sZGVyOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9LFxuICAgIHNhZFBsYWNlaG9sZGVyOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9LFxuICAgIGFyY2hpdmVOYW1lOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9XG59KVxuXG5TY2hlbWFzLkFjdGlvbnMgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICBfaWQ6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICByZWdFeDogU2ltcGxlU2NoZW1hLlJlZ0V4LklkLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0sXG4gICAgY3JlYXRlZEF0OiB7XG4gICAgICAgIHR5cGU6IERhdGUsXG4gICAgICAgIGF1dG9WYWx1ZTogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaWYgKHRoaXMuaXNJbnNlcnQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gbmV3IERhdGUoKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdGhpcy51bnNldCgpXG4gICAgICAgIH1cbiAgICB9LFxuICAgIGNyZWF0ZWRCeToge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIHJlZ0V4OiBTaW1wbGVTY2hlbWEuUmVnRXguSWQsXG4gICAgICAgIGF1dG9WYWx1ZTogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaWYgKHRoaXMuaXNJbnNlcnQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy51c2VySWQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLnVuc2V0KClcbiAgICAgICAgfVxuICAgIH0sXG4gICAgdGl0bGU6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBtYXg6IDI1NVxuICAgIH0sXG4gICAgc3RhdHVzOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgYWxsb3dlZFZhbHVlczogQ29uc3RhbnRzLlJldHJvSXRlbVN0YXR1c2VzLnZhbHVlc1xuICAgIH0sXG4gICAgY29tcGxldGVkQXQ6IHtcbiAgICAgICAgdHlwZTogRGF0ZSxcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9XG59KVxuXG5TY2hlbWFzLk5ld1RlYW0gPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICBuYW1lOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgbWF4OiA2MCxcbiAgICAgICAgbWluOiA1XG4gICAgfSxcbiAgICBkZXNjcmlwdGlvbjoge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxuICAgICAgICBtYXg6IDI1NVxuICAgIH0sXG4gICAgcGFzc3dvcmQ6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICByZWdFeDogL14oPz0uKlthLXpdKSg/PS4qW0EtWl0pKD89LipcXGQpW2EtekEtWlxcZF17OCx9JC8sXG4gICAgICAgIG1pbjogOCxcbiAgICB9LFxuICAgIGNvbmZpcm1QYXNzd29yZDoge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIG1pbjogOCxcbiAgICAgICAgY3VzdG9tKCkge1xuICAgICAgICAgICAgaWYgKHRoaXMudmFsdWUgIT09IHRoaXMuZmllbGQoJ3Bhc3N3b3JkJykudmFsdWUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gJ3Bhc3N3b3JkTWlzbWF0Y2gnO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufSlcblxuU2NoZW1hcy5TZXR0aW5ncyA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgIF9pZDoge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIHJlZ0V4OiBTaW1wbGVTY2hlbWEuUmVnRXguSWQsXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSxcbiAgICBjcmVhdGVkQnk6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICByZWdFeDogU2ltcGxlU2NoZW1hLlJlZ0V4LklkLFxuICAgICAgICBhdXRvVmFsdWU6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLmlzSW5zZXJ0KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMudXNlcklkO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy51bnNldCgpXG4gICAgICAgIH0sXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSxcbiAgICBiYWNrZ3JvdW5kSW1hZ2U6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBkZWZhdWx0VmFsdWU6ICcvYmFja2dyb3VuZHMvdHJpYW5nbGVzLnBuZycsXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSxcbiAgICBoYXBweVBsYWNlaG9sZGVyOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgZGVmYXVsdFZhbHVlOiAnOiknLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0sXG4gICAgbWVoUGxhY2Vob2xkZXI6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBkZWZhdWx0VmFsdWU6ICc6fCcsXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSxcbiAgICBzYWRQbGFjZWhvbGRlcjoge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIGRlZmF1bHRWYWx1ZTogJzooJyxcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9XG5cbn0pXG5cbm1vZHVsZS5leHBvcnRzID0geyBTY2hlbWFzIH1cbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJ1xuaW1wb3J0IHsgU2NoZW1hcyB9IGZyb20gJy4vc2NoZW1hcydcblxuaWYgKCFTdHJpbmcucHJvdG90eXBlLnRvUHJvcGVyQ2FzZSkge1xuICAgIFN0cmluZy5wcm90b3R5cGUudG9Qcm9wZXJDYXNlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5yZXBsYWNlKC9cXHdcXFMqL2csIGZ1bmN0aW9uICh0eHQpIHsgcmV0dXJuIHR4dC5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArIHR4dC5zdWJzdHIoMSkudG9Mb3dlckNhc2UoKTsgfSk7XG4gICAgfTtcbn1cblxuY29uc3QgUmV0cm9zID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3JldHJvcycpXG5jb25zdCBSZXRyb0FjdGlvbnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncmV0cm8tYWN0aW9ucycpXG5jb25zdCBCYWNrZ3JvdW5kcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdiYWNrZ3JvdW5kcycpXG5jb25zdCBTZXR0aW5ncyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdzZXR0aW5ncycpXG5cblJldHJvcy5hdHRhY2hTY2hlbWEoU2NoZW1hcy5SZXRyb3MpXG5SZXRyb0FjdGlvbnMuYXR0YWNoU2NoZW1hKFNjaGVtYXMuQWN0aW9ucylcblNldHRpbmdzLmF0dGFjaFNjaGVtYShTY2hlbWFzLlNldHRpbmdzKVxuXG5jb25zdCBTZXF1ZW50ID0ge1xuICAgIGFyY2hpdmVSb3V0ZU5hbWU6ICdhcmNoaXZlcycsXG4gICAgZGVmYXVsdEJhY2tncm91bmQ6ICcvYmFja2dyb3VuZHMvdHJpYW5nbGVzLnBuZycsXG4gICAgZGVmYXVsdENvbmZpcm1Nc2c6ICdBcmUgeW91IHN1cmU/JyxcbiAgICBUb2FzdFRpbWVPdXQ6IDMwMDAsXG4gICAgRU1BSUxfVEFSR0VUOiAnZW1haWxUYXJnZXQnLFxuICAgIHBhZ2VTaXplKCkge1xuICAgICAgICByZXR1cm4gMjVcbiAgICB9LFxuICAgIGdldFNldHRpbmdzKCkge1xuICAgICAgICBsZXQgc2V0dGluZ3MgPSBTZXR0aW5ncy5maW5kT25lKClcblxuICAgICAgICBpZiAoIXNldHRpbmdzKSB7XG4gICAgICAgICAgICBzZXR0aW5ncyA9IHt9XG4gICAgICAgICAgICBzZXR0aW5ncy5iYWNrZ3JvdW5kSW1hZ2UgPSBTZXF1ZW50LmRlZmF1bHRCYWNrZ3JvdW5kXG4gICAgICAgICAgICBzZXR0aW5ncy5oYXBweVBsYWNlaG9sZGVyID0gJzopJ1xuICAgICAgICAgICAgc2V0dGluZ3MubWVoUGxhY2Vob2xkZXIgPSAnOnwnXG4gICAgICAgICAgICBzZXR0aW5ncy5zYWRQbGFjZWhvbGRlciA9ICc6KCdcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBzZXR0aW5nc1xuICAgIH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gICAgU2VxdWVudCwgUmV0cm9zLCBSZXRyb0FjdGlvbnMsIEJhY2tncm91bmRzLCBTZXR0aW5nc1xufVxuIiwiaW1wb3J0IHNhbml0aXplSHRtbCBmcm9tICdzYW5pdGl6ZS1odG1sJ1xuXG5jb25zdCBjbGVhbklucHV0ID0gKGlucHV0LCBkZWZhdWx0VmFsID0gJycpID0+IHtcbiAgICBjb25zdCB2YWx1ZSA9IHNhbml0aXplSHRtbChpbnB1dCwge1xuICAgICAgICBhbGxvd2VkVGFnczogW11cbiAgICB9KVxuICAgIHJldHVybiB2YWx1ZSB8fCBkZWZhdWx0VmFsXG59XG5cbmV4cG9ydCBkZWZhdWx0IGNsZWFuSW5wdXRcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgbW9tZW50IGZyb20gJ21vbWVudCdcbmltcG9ydCB7IFNldHRpbmdzLCBSZXRyb3MgfSBmcm9tICcuLi9saWIvc2VxdWVudCdcbmltcG9ydCB7IFNjaGVtYXMgfSBmcm9tICcuLi9saWIvc2NoZW1hcydcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4uL2xpYi9jb25zdGFudHMnXG5pbXBvcnQgeyBMb2dnZXIgfSBmcm9tICcuLi9saWIvbG9nZ2VyJ1xuaW1wb3J0IGNsZWFuSW5wdXQgZnJvbSAnLi9jbGVhbklucHV0J1xuXG5jb25zdCBpbnB1dE5hbWUgPSAobmFtZSwgZGF0ZVZhbCkgPT4ge1xuICAgIGNvbnN0IG5ld05hbWUgPSBjbGVhbklucHV0KG5hbWUpXG4gICAgaWYgKCFuZXdOYW1lKSByZXR1cm4gYCR7ZGF0ZVZhbH1gXG4gICAgaWYgKG5ld05hbWUgPT09ICcnKSByZXR1cm4gYCR7ZGF0ZVZhbH1gXG4gICAgcmV0dXJuIG5ld05hbWVcbn1cblxuXG5NZXRlb3IubWV0aG9kcyh7XG5cbiAgICBhcmNoaXZlUmV0cm8ocmV0cm9JZCwgbmFtZSkge1xuICAgICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtbG9nZ2VkLWluJywgJ1lvdSBtdXN0IGJlIGxvZ2dlZCBpbnRvIGEgcmV0cm8gYm9hcmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHJldHJvID0gUmV0cm9zLmZpbmRPbmUoe1xuICAgICAgICAgICAgX2lkOiByZXRyb0lkLFxuICAgICAgICAgICAgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZFxuICAgICAgICB9KVxuXG4gICAgICAgIGlmICghcmV0cm8pIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1mb3VuZCcsICdSZXRybyBjb3VsZCBub3QgYmUgZm91bmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChyZXRyby5zdGF0dXMgPT09IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkFSQ0hJVkVEKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdhbHJlYWR5LWFyY2hpdmVkJywgJ1JldHJvIHdhcyBhbHJlYWR5IGFyY2hpdmVkIScpXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBhcmNoaXZlZEF0ID0gbmV3IERhdGUoKVxuXG4gICAgICAgIGNvbnN0IGRhdGVWYWwgPSBtb21lbnQoYXJjaGl2ZWRBdCkuZm9ybWF0KCdNTS1ERC1ZWVlZIC0gTFQnKVxuXG4gICAgICAgIGNvbnN0IGFyY2hpdmVOYW1lID0gaW5wdXROYW1lKG5hbWUsIGRhdGVWYWwpXG5cbiAgICAgICAgaWYgKGFyY2hpdmVOYW1lICE9PSBuYW1lICYmIG5hbWUgIT09ICcnKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdpbnZhbGlkLW5hbWUnLCAnSW52YWxpZCBBcmNoaXZlIG5hbWUuIEhUTUwgdGFncyBub3QgYWxsb3dlZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgbGV0IHNldHRpbmdzID0gU2V0dGluZ3MuZmluZE9uZSh7IGNyZWF0ZWRCeTogdGhpcy51c2VySWQgfSlcblxuICAgICAgICBpZiAoIXNldHRpbmdzKSB7XG4gICAgICAgICAgICBzZXR0aW5ncyA9IHtcbiAgICAgICAgICAgICAgICBoYXBweVBsYWNlaG9sZGVyOiAnOiknLFxuICAgICAgICAgICAgICAgIG1laFBsYWNlaG9sZGVyOiAnOnwnLFxuICAgICAgICAgICAgICAgIHNhZFBsYWNlaG9sZGVyOiAnOignXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgUmV0cm9zLnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7IF9pZDogcmV0cm8uX2lkIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAkc2V0OlxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkFSQ0hJVkVELFxuICAgICAgICAgICAgICAgICAgICAgICAgYXJjaGl2ZWRBdCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFyY2hpdmVOYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgaGFwcHlQbGFjZWhvbGRlcjogc2V0dGluZ3MuaGFwcHlQbGFjZWhvbGRlcixcbiAgICAgICAgICAgICAgICAgICAgICAgIG1laFBsYWNlaG9sZGVyOiBzZXR0aW5ncy5tZWhQbGFjZWhvbGRlcixcbiAgICAgICAgICAgICAgICAgICAgICAgIHNhZFBsYWNlaG9sZGVyOiBzZXR0aW5ncy5zYWRQbGFjZWhvbGRlclxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKVxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIExvZ2dlci5sb2coZXJyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcigndXBkYXRlLWZhaWxlZCcsICdXZSBjb3VsZCBub3QgYXJjaGl2ZSB0aGUgcmV0cm8gLSBwbGVhc2UgdHJ5IGFnYWluIGxhdGVyJylcbiAgICAgICAgfVxuICAgIH1cblxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgZnMgZnJvbSAnZnMnXG5pbXBvcnQgeyBfIH0gZnJvbSAnbWV0ZW9yL3VuZGVyc2NvcmUnXG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICBjb21wb25lbnRJbWFnZXMoKSB7XG4gICAgICAgIGNvbnN0IGltYWdlcyA9IFtdXG5cbiAgICAgICAgY29uc3QgbWV0ZW9yUm9vdCA9IGZzLnJlYWxwYXRoU3luYyhgJHtwcm9jZXNzLmN3ZCgpfS8uLi9gKTtcbiAgICAgICAgY29uc3QgcHVibGljUGF0aCA9IGAke21ldGVvclJvb3R9L3dlYi5icm93c2VyL2FwcC9gO1xuICAgICAgICBjb25zdCBiYWNrZ3JvdW5kUGF0aCA9IGAke3B1YmxpY1BhdGh9L2A7XG4gICAgICAgIGNvbnN0IGJncyA9IGZzLnJlYWRkaXJTeW5jKGJhY2tncm91bmRQYXRoKTtcbiAgICAgICAgY29uc3QgZmlsZXMgPSBiZ3MuZmlsdGVyKGZ1bmN0aW9uIChlbG0pIHsgcmV0dXJuIGVsbS5tYXRjaCgvLipcXC4ocG5nKS9pZyk7IH0pXG5cbiAgICAgICAgXy5lYWNoKGZpbGVzLCBmdW5jdGlvbiAoaW1nKSB7XG4gICAgICAgICAgICBpbWFnZXMucHVzaCh7IGZpbGVOYW1lOiBgLyR7aW1nfWAgfSlcbiAgICAgICAgfSlcblxuICAgICAgICByZXR1cm4gaW1hZ2VzXG4gICAgfVxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBSZXRyb3MsIFJldHJvQWN0aW9ucyB9IGZyb20gJy4uL2xpYi9zZXF1ZW50J1xuaW1wb3J0IHsgU2NoZW1hcyB9IGZyb20gJy4uL2xpYi9zY2hlbWFzJ1xuaW1wb3J0IHsgQ29uc3RhbnRzIH0gZnJvbSAnLi4vbGliL2NvbnN0YW50cydcbmltcG9ydCB7IExvZ2dlciB9IGZyb20gJy4uL2xpYi9sb2dnZXInXG5pbXBvcnQgY2xlYW5JbnB1dCBmcm9tICcuL2NsZWFuSW5wdXQnXG5cbk1ldGVvci5tZXRob2RzKHtcblxuICAgIGNyZWF0ZVJldHJvQWN0aW9uKHRpdGxlKSB7XG4gICAgICAgIGNvbnN0IHJldHJvSWQgPSAnJ1xuXG4gICAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1sb2dnZWQtaW4nLCAnWW91IG11c3QgYmUgbG9nZ2VkIGludG8gYSByZXRybyBib2FyZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgYWN0aW9uID0ge31cbiAgICAgICAgYWN0aW9uLnRpdGxlID0gY2xlYW5JbnB1dCh0aXRsZSlcblxuICAgICAgICBhY3Rpb24uc3RhdHVzID0gQ29uc3RhbnRzLlJldHJvSXRlbVN0YXR1c2VzLlBFTkRJTkdcblxuICAgICAgICBpZiAoYWN0aW9uLnRpdGxlID09PSAnJykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcigndGl0bGUtcmVxdWlyZWQnLCAnSW52YWxpZCBhY3Rpb24gaXRlbSEgSFRNTCBUYWdzIG5vdCBhbGxvd2VkLicpXG4gICAgICAgIH1cblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgYWN0aW9uSWQgPSBSZXRyb0FjdGlvbnMuaW5zZXJ0KGFjdGlvbilcbiAgICAgICAgICAgIHJldHVybiBhY3Rpb25JZFxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIExvZ2dlci5sb2coZXJyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignaW5zZXJ0LWZhaWxlZCcsICdXZSBjb3VsZCBub3QgYWRkIHJldHJvIGl0ZW0gdG8gdGhlIHJldHJvIC0gcGxlYXNlIHRyeSBhZ2FpbiBsYXRlcicpXG4gICAgICAgIH1cbiAgICB9XG5cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgUmFuZG9tIH0gZnJvbSAnbWV0ZW9yL3JhbmRvbSdcbmltcG9ydCB7IF8gfSBmcm9tICdtZXRlb3IvdW5kZXJzY29yZSdcbmltcG9ydCB7IFJldHJvcyB9IGZyb20gJy4uL2xpYi9zZXF1ZW50J1xuaW1wb3J0IHsgU2NoZW1hcyB9IGZyb20gJy4uL2xpYi9zY2hlbWFzJ1xuaW1wb3J0IHsgQ29uc3RhbnRzIH0gZnJvbSAnLi4vbGliL2NvbnN0YW50cydcbmltcG9ydCB7IExvZ2dlciB9IGZyb20gJy4uL2xpYi9sb2dnZXInXG5pbXBvcnQgY2xlYW5JbnB1dCBmcm9tICcuL2NsZWFuSW5wdXQnXG5cbk1ldGVvci5tZXRob2RzKHtcblxuICAgIGNyZWF0ZVJldHJvSXRlbSh0aXRsZSwgaXRlbVR5cGUpIHtcbiAgICAgICAgbGV0IHJldHJvSWQgPSAnJ1xuXG4gICAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1sb2dnZWQtaW4nLCAnWW91IG11c3QgYmUgbG9nZ2VkIGludG8gYSByZXRybyBib2FyZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgbmV3VGl0bGUgPSBjbGVhbklucHV0KHRpdGxlKVxuXG4gICAgICAgIGlmIChuZXdUaXRsZSA9PT0gJycpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ3RpdGxlLXJlcXVpcmVkJywgJ0ludmFsaWQgcmV0cm8gaXRlbSEgSFRNTCBUYWdzIG5vdCBhbGxvd2VkLicpXG4gICAgICAgIH1cblxuICAgICAgICAvLyBpZiB0aGVyZSBhcmUgbm8gYWN0aXZlIHJldHJvcyBmb3IgdGhpcyB1c2VyIGNyZWF0ZSBvbmVcbiAgICAgICAgbGV0IHJldHJvID0gUmV0cm9zLmZpbmRPbmUoe1xuICAgICAgICAgICAgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCxcbiAgICAgICAgICAgIHN0YXR1czogQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuQUNUSVZFXG4gICAgICAgIH0pXG5cbiAgICAgICAgaWYgKCFyZXRybykge1xuICAgICAgICAgICAgY29uc3QgcmV0cm9Eb2MgPSB7fVxuICAgICAgICAgICAgcmV0cm9Eb2Muc3RhdHVzID0gQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuQUNUSVZFXG4gICAgICAgICAgICByZXRyb0RvYy5pdGVtcyA9IFtdXG5cbiAgICAgICAgICAgIHJldHJvSWQgPSBSZXRyb3MuaW5zZXJ0KHJldHJvRG9jKVxuXG4gICAgICAgICAgICByZXRybyA9IFJldHJvcy5maW5kT25lKHsgX2lkOiByZXRyb0lkIH0pXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXRyb0lkID0gcmV0cm8uX2lkXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkb2MgPSB7fVxuICAgICAgICBkb2MuaXRlbUlkID0gUmFuZG9tLmlkKClcbiAgICAgICAgZG9jLnRpdGxlID0gbmV3VGl0bGVcbiAgICAgICAgZG9jLml0ZW1UeXBlID0gaXRlbVR5cGVcbiAgICAgICAgZG9jLnN0YXR1cyA9IENvbnN0YW50cy5SZXRyb0l0ZW1TdGF0dXNlcy5QRU5ESU5HXG4gICAgICAgIGRvYy52b3RlcyA9IDBcbiAgICAgICAgZG9jLmNyZWF0ZWRBdCA9IG5ldyBEYXRlKClcblxuICAgICAgICBpZiAoIV8uaXNBcnJheShyZXRyby5pdGVtcykpIHtcbiAgICAgICAgICAgIHJldHJvLml0ZW1zID0gW11cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHJldHJvLml0ZW1zLnB1c2goZG9jKVxuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBSZXRyb3MudXBkYXRlKFxuICAgICAgICAgICAgICAgIHsgX2lkOiByZXRyb0lkIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAkcHVzaDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgaXRlbXM6IGRvY1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgcmV0dXJuIHJldHJvSWRcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBMb2dnZXIubG9nKGVycilcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ2luc2VydC1mYWlsZWQnLCAnV2UgY291bGQgbm90IGFkZCByZXRybyBpdGVtIHRvIHRoZSByZXRybyAtIHBsZWFzZSB0cnkgYWdhaW4gbGF0ZXInKVxuICAgICAgICB9XG4gICAgfVxuXG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IFJhbmRvbSB9IGZyb20gJ21ldGVvci9yYW5kb20nXG5pbXBvcnQgeyBNYXRjaCB9IGZyb20gJ21ldGVvci9jaGVjaydcbmltcG9ydCB7IFNpbXBsZVNjaGVtYSB9IGZyb20gJ21ldGVvci9hbGRlZWQ6c2ltcGxlLXNjaGVtYSdcbmltcG9ydCB7IF8gfSBmcm9tICdtZXRlb3IvdW5kZXJzY29yZSdcbmltcG9ydCB7IFNldHRpbmdzIH0gZnJvbSAnLi4vbGliL3NlcXVlbnQnXG5pbXBvcnQgeyBTY2hlbWFzIH0gZnJvbSAnLi4vbGliL3NjaGVtYXMnXG5pbXBvcnQgeyBMb2dnZXIgfSBmcm9tICcuLi9saWIvbG9nZ2VyJ1xuaW1wb3J0IGNsZWFuSW5wdXQgZnJvbSAnLi9jbGVhbklucHV0J1xuXG5NZXRlb3IubWV0aG9kcyh7XG5cbiAgICBzYXZlU2V0dGluZ3MoZG9jKSB7XG4gICAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1sb2dnZWQtaW4nLCAnWW91IG11c3QgYmUgbG9nZ2VkIGludG8gYSByZXRybyBib2FyZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgU2NoZW1hcy5TZXR0aW5ncy52YWxpZGF0ZShkb2MpXG5cbiAgICAgICAgY29uc3Qgc2V0dGluZ3MgPSBTZXR0aW5ncy5maW5kT25lKHsgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCB9KVxuXG4gICAgICAgIGNvbnN0IGhhcHB5ID0gY2xlYW5JbnB1dChkb2MuaGFwcHlQbGFjZWhvbGRlciwgJzopJylcbiAgICAgICAgY29uc3QgbWVoID0gY2xlYW5JbnB1dChkb2MubWVoUGxhY2Vob2xkZXIsICc6fCcpXG4gICAgICAgIGNvbnN0IHNhZCA9IGNsZWFuSW5wdXQoZG9jLnNhZFBsYWNlaG9sZGVyLCAnOignKVxuXG4gICAgICAgIGlmIChoYXBweSAhPT0gZG9jLmhhcHB5UGxhY2Vob2xkZXIgfHwgbWVoICE9PSBkb2MubWVoUGxhY2Vob2xkZXIgfHwgc2FkICE9PSBkb2Muc2FkUGxhY2Vob2xkZXIpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ2ludmFsaWQtcHJvbXB0JywgJ0ludmFsaWQgcHJvbXB0ISBIVE1MIFRhZ3Mgbm90IGFsbG93ZWQuJylcbiAgICAgICAgfVxuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZiAoXy5pc1VuZGVmaW5lZChzZXR0aW5ncykpIHtcbiAgICAgICAgICAgICAgICBTZXR0aW5ncy5pbnNlcnQoZG9jKVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBTZXR0aW5ncy51cGRhdGUoXG4gICAgICAgICAgICAgICAgICAgIHsgX2lkOiBzZXR0aW5ncy5faWQgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgJHNldDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRJbWFnZTogZG9jLmJhY2tncm91bmRJbWFnZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYXBweVBsYWNlaG9sZGVyOiBoYXBweSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZWhQbGFjZWhvbGRlcjogbWVoLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNhZFBsYWNlaG9sZGVyOiBzYWRcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBMb2dnZXIubG9nKGVycilcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ3VwZGF0ZS1mYWlsZWQnLCAnV2UgY291bGQgbm90IHVwZGF0ZSBzZXR0aW5ncyAtIHBsZWFzZSB0cnkgYWdhaW4gbGF0ZXInKVxuICAgICAgICB9XG4gICAgfVxuXG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IF8gfSBmcm9tICdtZXRlb3IvdW5kZXJzY29yZSdcbmltcG9ydCB7IFJldHJvcywgUmV0cm9BY3Rpb25zIH0gZnJvbSAnLi4vbGliL3NlcXVlbnQnXG5pbXBvcnQgeyBDb25zdGFudHMgfSBmcm9tICcuLi9saWIvY29uc3RhbnRzJ1xuaW1wb3J0IHsgU2VydmVyVXRpbHMgfSBmcm9tICcuL3NlcnZlclV0aWxzJ1xuaW1wb3J0IGNsZWFuSW5wdXQgZnJvbSAnLi9jbGVhbklucHV0J1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgc2VuZEFjdGlvbnNCeUVtYWlsKGN1cnJlbnRSZXRybywgdGFyZ2V0RW1haWwpIHtcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ2hpIHRoZXJlJylcbiAgICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWxvZ2dlZC1pbicsICdZb3UgbXVzdCBiZSBsb2dnZWQgaW4gdG8gcGVyZm9ybSB0aGlzIGFjdGlvbiEnKVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gY29uc3QgcmV0cm8gPSBSZXRyb3MuZmluZE9uZSh7IF9pZDogY3VycmVudFJldHJvIH0pXG5cbiAgICAgICAgLy8gaWYgKCFyZXRybykge1xuICAgICAgICAvLyAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWZvdW5kJywgJ1JldHJvIG5vdCBmb3VuZCEnKVxuICAgICAgICAvLyB9XG5cbiAgICAgICAgLy8gaWYgKHJldHJvLmNyZWF0ZWRCeSAhPT0gdGhpcy51c2VySWQpIHtcbiAgICAgICAgLy8gICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC10aGUtb3duZXInLCAnWW91IGFyZSBub3QgdGhlIG93bmVyIG9mIHRoaXMgcmV0cm8hJylcbiAgICAgICAgLy8gfVxuXG4gICAgICAgIGNvbnN0IGVtYWlsVG9Vc2UgPSB0YXJnZXRFbWFpbCB8fCAnJ1xuXG4gICAgICAgIGlmIChlbWFpbFRvVXNlID09PSAnJykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignZW1haWwtYWRkcmVzcy1yZXF1aXJlZCcsICdBbiBlbWFpbCBhZGRyZXNzIGlzIHJlcXVpcmVkIScpXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBuZXdFbWFpbCA9IGNsZWFuSW5wdXQoZW1haWxUb1VzZSlcblxuICAgICAgICBpZiAobmV3RW1haWwgPT09ICcnKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdjb250YWlucy1odG1sJywgJ0ludmFsaWQgZW1haWwgYWRkcmVzcyEnKVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gY29uc29sZS5sb2coJ2VtYWlsJywgbmV3RW1haWwpXG5cbiAgICAgICAgY29uc3QgYWN0aW9ucyA9IFJldHJvQWN0aW9ucy5maW5kKHtcbiAgICAgICAgICAgIGNyZWF0ZWRCeTogdGhpcy51c2VySWQsXG4gICAgICAgICAgICAkb3I6IFtcbiAgICAgICAgICAgICAgICB7IHN0YXR1czogQ29uc3RhbnRzLlJldHJvSXRlbVN0YXR1c2VzLlBFTkRJTkcgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHN0YXR1czogQ29uc3RhbnRzLlJldHJvSXRlbVN0YXR1c2VzLkNPTVBMRVRFLFxuICAgICAgICAgICAgICAgICAgICBjb21wbGV0ZWRBdDogeyAkZ3Q6IG5ldyBEYXRlKERhdGUubm93KCkgLSAoMjQgKiA2MCAqIDYwICogMTAwMCkpIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBdXG4gICAgICAgIH0pLmZldGNoKClcblxuICAgICAgICBpZiAoYWN0aW9ucy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vLWFjdGlvbnMnLCAnVGhlcmUgYXJlIG5vIGFjdGl2ZSBvciByZWNlbnRseSBjb21wbGV0ZWQgYWN0aW9ucyB0byBzZW5kIScpXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkYXRhID0ge31cblxuICAgICAgICBjb25zdCB1c2VyID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUodGhpcy51c2VySWQpXG5cbiAgICAgICAgZGF0YS5yZXRyb05hbWUgPSB1c2VyLnVzZXJuYW1lLnRvUHJvcGVyQ2FzZSgpXG4gICAgICAgIGRhdGEuY3VycmVudFllYXIgPSBuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKClcbiAgICAgICAgLy8gdHVybiBpbnRvIGh0bWwgbGlzdFxuICAgICAgICBsZXQgaXRlbXMgPSAnPHRyPjx0aD5BY3Rpb24gSXRlbTwvdGg+PHRoIGNsYXNzPVwidGV4dC1jZW50ZXJcIiBzdHlsZT1cIndpZHRoOiAyNSU7XCI+U3RhdHVzPC90aD48L3RyPidcbiAgICAgICAgZGF0YS5yZXRyb0l0ZW1zID0gXy5zb3J0QnkoYWN0aW9ucywgJ3N0YXR1cycpLmZvckVhY2goKGl0ZW0pID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGlzQ29tcGxldGUgPSAoaXRlbS5zdGF0dXMgPT09IENvbnN0YW50cy5SZXRyb0l0ZW1TdGF0dXNlcy5DT01QTEVURSkgPyAnQ29tcGxldGUnIDogJ0FjdGl2ZSdcbiAgICAgICAgICAgIGNvbnN0IGl0ZW1TdHlsZSA9IChpdGVtLnN0YXR1cyA9PT0gQ29uc3RhbnRzLlJldHJvSXRlbVN0YXR1c2VzLkNPTVBMRVRFKSA/ICdjb2xvcjogIzk5OTsgcGFkZGluZzogNHB4IDRweCA0cHggMHB4OyB2ZXJ0aWNhbC1hbGlnbjogdG9wOycgOiAncGFkZGluZzogNHB4IDRweCA0cHggMHB4OyB2ZXJ0aWNhbC1hbGlnbjogdG9wOydcbiAgICAgICAgICAgIGl0ZW1zICs9IGA8dHI+PC90cj48dGQgc3R5bGU9XCIke2l0ZW1TdHlsZX1cIj4ke2l0ZW0udGl0bGV9PC90ZD48dGQgc3R5bGU9XCIke2l0ZW1TdHlsZX1cIj4ke2lzQ29tcGxldGV9PC90ZD48L3RyPmBcbiAgICAgICAgfSlcblxuICAgICAgICBkYXRhLnJldHJvSXRlbXMgPSBpdGVtc1xuXG4gICAgICAgIGNvbnN0IGZyb20gPSBwcm9jZXNzLmVudi5GUk9NX0VNQUlMX0FERFJFU1MgfHwgJ3NlcXVlbnRANnRoY2VudHMuY29tJ1xuXG4gICAgICAgIFNlcnZlclV0aWxzLnNlbmRIdG1sRW1haWwobmV3RW1haWwsIGZyb20sIGAke3VzZXIudXNlcm5hbWUudG9Qcm9wZXJDYXNlKCl9IEFjdGlvbiBJdGVtc2AsICdhY3Rpb25JdGVtcycsIGRhdGEpXG4gICAgfVxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBSZXRyb3MsIFJldHJvQWN0aW9ucyB9IGZyb20gJy4uL2xpYi9zZXF1ZW50J1xuaW1wb3J0IHsgU2NoZW1hcyB9IGZyb20gJy4uL2xpYi9zY2hlbWFzJ1xuaW1wb3J0IHsgQ29uc3RhbnRzIH0gZnJvbSAnLi4vbGliL2NvbnN0YW50cydcbmltcG9ydCB7IExvZ2dlciB9IGZyb20gJy4uL2xpYi9sb2dnZXInXG5pbXBvcnQgY2xlYW5JbnB1dCBmcm9tICcuL2NsZWFuSW5wdXQnXG5cbk1ldGVvci5tZXRob2RzKHtcblxuICAgIHVwZGF0ZUFjdGlvblRpdGxlKGFjdGlvbklkLCB0aXRsZSkge1xuICAgICAgICBjb25zdCByZXRyb0lkID0gJydcblxuICAgICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtbG9nZ2VkLWluJywgJ1lvdSBtdXN0IGJlIGxvZ2dlZCBpbnRvIGEgcmV0cm8gYm9hcmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGFjdGlvbiA9IFJldHJvQWN0aW9ucy5maW5kT25lKHsgX2lkOiBhY3Rpb25JZCwgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCB9KVxuXG4gICAgICAgIGlmICghYWN0aW9uKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtZm91bmQnLCAnUmV0cm9BY3Rpb24gbm90IGZvdW5kIScpXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBuZXdUaXRsZSA9IGNsZWFuSW5wdXQodGl0bGUpXG5cbiAgICAgICAgaWYgKG5ld1RpdGxlICE9PSB0aXRsZSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignaW52YWxpZC10aXRsZScsICdJbnZhbGlkIGFjdGlvbiEgSFRNTCB0YWdzIG5vdCBhbGxvd2VkLicpXG4gICAgICAgIH1cblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgUmV0cm9BY3Rpb25zLnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7IF9pZDogYWN0aW9uSWQgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICRzZXQ6XG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBuZXdUaXRsZVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKVxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIExvZ2dlci5sb2coZXJyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignZGVsZXRlLWZhaWxlZCcsICdXZSBjb3VsZCBub3QgZGVsZXRlIHRoZSBhY3Rpb24gLSBwbGVhc2UgdHJ5IGFnYWluIGxhdGVyJylcbiAgICAgICAgfVxuICAgIH1cblxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBfIH0gZnJvbSAnbWV0ZW9yL3VuZGVyc2NvcmUnXG5pbXBvcnQgeyBSZXRyb3MgfSBmcm9tICcuLi9saWIvc2VxdWVudCdcbmltcG9ydCB7IFNjaGVtYXMgfSBmcm9tICcuLi9saWIvc2NoZW1hcydcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4uL2xpYi9jb25zdGFudHMnXG5pbXBvcnQgeyBMb2dnZXIgfSBmcm9tICcuLi9saWIvbG9nZ2VyJ1xuaW1wb3J0IGNsZWFuSW5wdXQgZnJvbSAnLi9jbGVhbklucHV0J1xuXG5NZXRlb3IubWV0aG9kcyh7XG5cbiAgICB1cGRhdGVSZXRyb0l0ZW1UaXRsZShpdGVtSWQsIHRpdGxlKSB7XG4gICAgICAgIGNvbnN0IHJldHJvSWQgPSAnJ1xuXG4gICAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1sb2dnZWQtaW4nLCAnWW91IG11c3QgYmUgbG9nZ2VkIGludG8gYSByZXRybyBib2FyZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcmV0cm8gPSBSZXRyb3MuZmluZE9uZSh7XG4gICAgICAgICAgICBjcmVhdGVkQnk6IHRoaXMudXNlcklkLFxuICAgICAgICAgICAgJG9yOiBbXG4gICAgICAgICAgICAgICAgeyBzdGF0dXM6IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkFDVElWRSB9LFxuICAgICAgICAgICAgICAgIHsgc3RhdHVzOiBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5GUk9aRU4gfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgIH0pXG5cbiAgICAgICAgLy8gbmVlZCB0byBzZWUgaWYgdGhlcmUgaXNcbiAgICAgICAgaWYgKCFyZXRybykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWZvdW5kJywgJ1JldHJvIG5vdCBmb3VuZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcmV0cm9JdGVtID0gXy5maWx0ZXIocmV0cm8uaXRlbXMsIGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgICAgICByZXR1cm4gaXRlbS5pdGVtSWQgPT09IGl0ZW1JZFxuICAgICAgICB9KVxuXG4gICAgICAgIGlmIChyZXRyb0l0ZW0ubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtZm91bmQnLCAnUmV0cm8gSXRlbSBub3QgZm91bmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGxldCB2b3RlQ291bnQgPSByZXRyb0l0ZW1bMF0udm90ZXMgfHwgMFxuXG4gICAgICAgIHZvdGVDb3VudCArPSAxXG5cbiAgICAgICAgY29uc3QgbmV3VGl0bGUgPSBjbGVhbklucHV0KHRpdGxlKVxuXG4gICAgICAgIGlmIChuZXdUaXRsZSA9PT0gJycpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ2ludmFsaWQtdGl0bGUnLCAnSW52YWxpZCBSZXRybyBJdGVtLiBIVE1MIHRhZ3Mgbm90IGFsbG93ZWQuJylcbiAgICAgICAgfVxuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBSZXRyb3MudXBkYXRlKFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgX2lkOiByZXRyby5faWQsXG4gICAgICAgICAgICAgICAgICAgICdpdGVtcy5pdGVtSWQnOiBpdGVtSWRcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgJHNldDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgJ2l0ZW1zLiQudGl0bGUnOiBuZXdUaXRsZVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKVxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIExvZ2dlci5sb2coZXJyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcigndXBkYXRlLWZhaWxlZCcsICdXZSBjb3VsZCBub3QgdXBkYXRlIHRoZSByZXRybyBpdGVtIC0gcGxlYXNlIHRyeSBhZ2FpbiBsYXRlcicpXG4gICAgICAgIH1cbiAgICB9XG5cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IGZzIGZyb20gJ2ZzJ1xuaW1wb3J0IHsgXyB9IGZyb20gJ21ldGVvci91bmRlcnNjb3JlJ1xuaW1wb3J0IHsgQmFja2dyb3VuZHMgfSBmcm9tICcuLi9saWIvc2VxdWVudCdcblxuTWV0ZW9yLnB1Ymxpc2goJ2JhY2tncm91bmRzJywgZnVuY3Rpb24gKCkge1xuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuICAgIGNvbnN0IG1ldGVvclJvb3QgPSBmcy5yZWFscGF0aFN5bmMoYCR7cHJvY2Vzcy5jd2QoKX0vLi4vYCk7XG4gICAgY29uc3QgcHVibGljUGF0aCA9IGAke21ldGVvclJvb3R9L3dlYi5icm93c2VyL2FwcC9gO1xuICAgIGNvbnN0IGJhY2tncm91bmRQYXRoID0gYCR7cHVibGljUGF0aH0vYmFja2dyb3VuZHMvYDtcbiAgICBjb25zdCBiZ3MgPSBmcy5yZWFkZGlyU3luYyhiYWNrZ3JvdW5kUGF0aCk7XG4gICAgXy5lYWNoKGJncywgZnVuY3Rpb24gKGJhY2tncm91bmQpIHtcbiAgICAgICAgY29uc3QgYmFja2dyb3VuZE5hbWUgPSBiYWNrZ3JvdW5kLnNwbGl0KCcuJylbMF0udG9Qcm9wZXJDYXNlKClcbiAgICAgICAgc2VsZi5hZGRlZCgnYmFja2dyb3VuZHMnLCBiYWNrZ3JvdW5kLCB7IG5hbWU6IGJhY2tncm91bmROYW1lLCB2YWx1ZTogYC9iYWNrZ3JvdW5kcy8ke2JhY2tncm91bmR9YCB9KTtcbiAgICB9KVxuICAgIHRoaXMucmVhZHkoKTtcbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IE1hdGNoIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJ1xuaW1wb3J0IHsgU2VxdWVudCwgUmV0cm9BY3Rpb25zIH0gZnJvbSAnLi4vbGliL3NlcXVlbnQnXG5pbXBvcnQgeyBDb25zdGFudHMgfSBmcm9tICcuLi9saWIvY29uc3RhbnRzJ1xuXG5SZXRyb0FjdGlvbnMuX2Vuc3VyZUluZGV4KCdjcmVhdGVkQnknLCAxKVxuUmV0cm9BY3Rpb25zLl9lbnN1cmVJbmRleCgnc3RhdHVzJywgMSlcblJldHJvQWN0aW9ucy5fZW5zdXJlSW5kZXgoJ2NyZWF0ZWRBdCcsIDEpXG5cbk1ldGVvci5wdWJsaXNoKCdvcGVuLWFjdGlvbnMnLCBmdW5jdGlvbiAoKSB7XG4gICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICB0aGlzLnN0b3AoKVxuICAgICAgICByZXR1cm4gbnVsbFxuICAgIH1cblxuICAgIHJldHVybiBSZXRyb0FjdGlvbnMuZmluZCh7XG4gICAgICAgIGNyZWF0ZWRCeTogdGhpcy51c2VySWQsXG4gICAgICAgIHN0YXR1czogQ29uc3RhbnRzLlJldHJvSXRlbVN0YXR1c2VzLlBFTkRJTkdcbiAgICB9KVxufSk7XG5cbk1ldGVvci5wdWJsaXNoKCdhbGwtYWN0aW9ucycsIGZ1bmN0aW9uIChzZWFyY2gpIHtcbiAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgIHJldHVybiBudWxsXG4gICAgfVxuXG4gICAgaWYgKCFNYXRjaC50ZXN0KHNlYXJjaCwgeyBsaW1pdDogTnVtYmVyLCBzaG93QWxsOiBCb29sZWFuIH0pKSB7XG4gICAgICAgIHJldHVybiBudWxsXG4gICAgfVxuXG4gICAgY29uc3QgcXVlcnkgPSB7XG4gICAgICAgIGNyZWF0ZWRCeTogdGhpcy51c2VySWRcbiAgICB9XG5cbiAgICBpZiAoIXNlYXJjaC5zaG93QWxsKSB7XG4gICAgICAgIHF1ZXJ5LnN0YXR1cyA9IENvbnN0YW50cy5SZXRyb0l0ZW1TdGF0dXNlcy5QRU5ESU5HXG4gICAgfVxuXG4gICAgcmV0dXJuIFJldHJvQWN0aW9ucy5maW5kKHF1ZXJ5LCB7IHNvcnQ6IHsgY29tcGxldGVkQXQ6IDEgfSwgbGltaXQ6IHNlYXJjaC5saW1pdCB9KVxufSk7XG5cbi8qXG5tZXNzYWdlcy5maW5kKHsnbWV0YWRhdGEudGhyZWFkJzogdGhyZWFkSWR9LFxuICB7XG4gICAgc29ydDogeydkYXRlJyA6IHNvcnR9LFxuICAgIGxpbWl0OiBsaW1pdCxcbiAgICBkaXNhYmxlT3Bsb2c6IHRydWUsXG4gICAgcG9sbGluZ1Rocm90dGxlTXM6IDEyMDAwLFxuICAgIHBvbGxpbmdJbnRlcnZhbE1zOiAxMjAwMFxuICB9XG4pO1xuKi9cbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBSZXRyb3MgfSBmcm9tICcuLi9saWIvc2VxdWVudCdcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4uL2xpYi9jb25zdGFudHMnXG5cblJldHJvcy5fZW5zdXJlSW5kZXgoJ2NyZWF0ZWRCeScsIDEpXG5SZXRyb3MuX2Vuc3VyZUluZGV4KCdzdGF0dXMnLCAxKVxuXG5NZXRlb3IucHVibGlzaCgnYWN0aXZlLXJldHJvcycsIGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgIHJldHVybiBudWxsXG4gICAgfVxuXG4gICAgcmV0dXJuIFJldHJvcy5maW5kKHtcbiAgICAgICAgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCxcbiAgICAgICAgc3RhdHVzOiB7XG4gICAgICAgICAgICAkaW46IFtDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5BQ1RJVkUsIENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkZST1pFTl1cbiAgICAgICAgfVxuICAgIH0pXG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goJ2FyY2hpdmVkLXJldHJvcycsIGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgIHJldHVybiBudWxsXG4gICAgfVxuXG4gICAgcmV0dXJuIFJldHJvcy5maW5kKHsgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCwgc3RhdHVzOiBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5BUkNISVZFRCB9KVxufSk7XG5cbk1ldGVvci5wdWJsaXNoKCdzaW5nbGUtYXJjaGl2ZWQtcmV0cm8nLCBmdW5jdGlvbiAocmV0cm9JZCkge1xuICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG5cbiAgICByZXR1cm4gUmV0cm9zLmZpbmQoeyBfaWQ6IHJldHJvSWQsIGNyZWF0ZWRCeTogdGhpcy51c2VySWQsIHN0YXR1czogQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuQVJDSElWRUQgfSlcbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IFNldHRpbmdzIH0gZnJvbSAnLi4vbGliL3NlcXVlbnQnXG5cblNldHRpbmdzLl9lbnN1cmVJbmRleCgnY3JlYXRlZEJ5JywgMSlcblxuTWV0ZW9yLnB1Ymxpc2goJ3NldHRpbmdzJywgZnVuY3Rpb24gKCkge1xuICAgIGlmICghTWV0ZW9yLnVzZXJJZCgpKSB7XG4gICAgICAgIHJldHVybiBudWxsXG4gICAgfVxuXG4gICAgcmV0dXJuIFNldHRpbmdzLmZpbmQoeyBjcmVhdGVkQnk6IE1ldGVvci51c2VySWQoKSB9KVxufSk7XG5cbiIsIi8qIGdsb2JhbCBBc3NldHMgVGVtcGxhdGUgKi9cbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBTU1IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yaGFja3M6c3NyJ1xuaW1wb3J0IHsgRW1haWwgfSBmcm9tICdtZXRlb3IvZW1haWwnXG5pbXBvcnQgY2hlY2sgZnJvbSAnbWV0ZW9yL2NoZWNrJ1xuaW1wb3J0IHsgQ29uc3RhbnRzIH0gZnJvbSAnLi4vbGliL2NvbnN0YW50cydcblxuaWYgKCFTdHJpbmcucHJvdG90eXBlLnRvUHJvcGVyQ2FzZSkge1xuICAgIFN0cmluZy5wcm90b3R5cGUudG9Qcm9wZXJDYXNlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5yZXBsYWNlKC9cXHdcXFMqL2csIGZ1bmN0aW9uICh0eHQpIHsgcmV0dXJuIHR4dC5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArIHR4dC5zdWJzdHIoMSkudG9Mb3dlckNhc2UoKTsgfSk7XG4gICAgfTtcbn1cblxuU1NSLmNvbXBpbGVUZW1wbGF0ZSgnYWN0aW9uSXRlbXMnLCBBc3NldHMuZ2V0VGV4dCgnZW1haWxUZW1wbGF0ZXMvYWN0aW9uSXRlbXMuaHRtbCcpKTtcblxuVGVtcGxhdGUuYWN0aW9uSXRlbXMuaGVscGVycyh7XG4gICAgaXNDb21wbGV0ZTogZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zdGF0dXMgPT09IENvbnN0YW50cy5SZXRyb0l0ZW1TdGF0dXNlcy5DT01QTEVURVxuICAgIH1cbn0pXG5cbmNvbnN0IFNlcnZlclV0aWxzID0ge31cblxuU2VydmVyVXRpbHMuc2VuZEVtYWlsID0gKHRvLCBmcm9tLCBzdWJqZWN0LCB0ZXh0KSA9PiB7XG4gICAgY2hlY2soW3RvLCBmcm9tLCBzdWJqZWN0LCB0ZXh0XSwgW1N0cmluZ10pO1xuXG4gICAgTWV0ZW9yLmRlZmVyKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgRW1haWwuc2VuZCh7XG4gICAgICAgICAgICB0bzogdG8sXG4gICAgICAgICAgICBmcm9tOiBmcm9tIHx8ICdub3JlcGx5QDZ0aGNlbnRzLmNvbScsXG4gICAgICAgICAgICBzdWJqZWN0OiBzdWJqZWN0LFxuICAgICAgICAgICAgdGV4dDogdGV4dFxuICAgICAgICB9KTtcbiAgICB9KTtcbn1cblxuU2VydmVyVXRpbHMuc2VuZEh0bWxFbWFpbCA9ICh0bywgZnJvbSwgc3ViamVjdCwgdGVtcGxhdGVOYW1lLCBkYXRhKSA9PiB7XG4gICAgdmFyIGJvZHkgPSBTU1IucmVuZGVyKHRlbXBsYXRlTmFtZSwgZGF0YSk7XG5cbiAgICBNZXRlb3IuZGVmZXIoZnVuY3Rpb24gKCkge1xuICAgICAgICBFbWFpbC5zZW5kKHtcbiAgICAgICAgICAgIHRvOiB0byxcbiAgICAgICAgICAgIGZyb206IGZyb20gfHwgJ3NlcXVlbnRANnRoY2VudHMuY29tJyxcbiAgICAgICAgICAgIHN1YmplY3Q6IHN1YmplY3QsXG4gICAgICAgICAgICBodG1sOiBib2R5XG4gICAgICAgIH0pXG4gICAgfSk7XG59XG5cbm1vZHVsZS5leHBvcnRzID0geyBTZXJ2ZXJVdGlscyB9XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcblxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICAvLyBjb2RlIHRvIHJ1biBvbiBzZXJ2ZXIgYXQgc3RhcnR1cFxufSk7XG4iLCIvKiBnbG9iYWwgZG9jdW1lbnQgKi9cbmltcG9ydCB7IF8gfSBmcm9tICdtZXRlb3IvdW5kZXJzY29yZSc7XG5pbXBvcnQgeyBUZW1wbGF0ZSB9IGZyb20gJ21ldGVvci90ZW1wbGF0aW5nJztcbmltcG9ydCB7IEJsYXplIH0gZnJvbSAnbWV0ZW9yL2JsYXplJztcbmltcG9ydCB7IFRyYWNrZXIgfSBmcm9tICdtZXRlb3IvdHJhY2tlcic7XG5cbmNvbnN0IHdpdGhEaXYgPSBmdW5jdGlvbiB3aXRoRGl2KGNhbGxiYWNrKSB7XG4gICAgY29uc3QgZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGVsKTtcblxuICAgIHRyeSB7XG4gICAgICAgIGNhbGxiYWNrKGVsKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGVsKTtcbiAgICB9XG59O1xuXG5leHBvcnQgY29uc3Qgd2l0aFJlbmRlcmVkVGVtcGxhdGUgPSBmdW5jdGlvbiB3aXRoUmVuZGVyZWRUZW1wbGF0ZSh0ZW1wbGF0ZSwgZGF0YSwgY2FsbGJhY2spIHtcbiAgICB3aXRoRGl2KChlbCkgPT4ge1xuICAgICAgICBjb25zdCB0aGVUZW1wbGF0ZSA9IF8uaXNTdHJpbmcodGVtcGxhdGUpID8gVGVtcGxhdGVbdGVtcGxhdGVdIDogdGVtcGxhdGU7XG4gICAgICAgIEJsYXplLnJlbmRlcldpdGhEYXRhKHRoZVRlbXBsYXRlLCBkYXRhLCBlbCk7XG4gICAgICAgIFRyYWNrZXIuZmx1c2goKTtcbiAgICAgICAgY2FsbGJhY2soZWwsIHRoZVRlbXBsYXRlKTtcbiAgICB9KTtcbn07XG4iLCIvKiBnbG9iYWwgbW9tZW50ICovXG5pbXBvcnQgeyBSYW5kb20gfSBmcm9tICdtZXRlb3IvcmFuZG9tJ1xuaW1wb3J0IHsgXyB9IGZyb20gJ21ldGVvci91bmRlcnNjb3JlJ1xuaW1wb3J0IHsgQ29uc3RhbnRzIH0gZnJvbSAnLi4vbGliL2NvbnN0YW50cydcblxuY29uc3QgVGVzdERhdGEgPSB7XG5cbiAgICBmYWtlU2V0dGluZ3MocGFyYW1ldGVycykge1xuICAgICAgICBsZXQgcGFybXMgPSB7fVxuXG4gICAgICAgIGlmICghXy5pc1VuZGVmaW5lZChwYXJhbWV0ZXJzKSkge1xuICAgICAgICAgICAgcGFybXMgPSBwYXJhbWV0ZXJzO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgU2V0dGluZ3MgPSB7fVxuICAgICAgICBTZXR0aW5ncy5iYWNrZ3JvdW5kSW1hZ2UgPSAnL2Zha2VPbmUuanBnJ1xuICAgICAgICBTZXR0aW5ncy5oYXBweVBsYWNlaG9sZGVyID0gJ0Zha2UgaGFwcHkgcGxhY2Vob2xkZXInXG4gICAgICAgIFNldHRpbmdzLm1laFBsYWNlaG9sZGVyID0gJ0Zha2UgbWVoIHBsYWNlaG9sZGVyJ1xuICAgICAgICBTZXR0aW5ncy5zYWRQbGFjZWhvbGRlciA9ICdGYWtlIHNhZCBwbGFjZWhvbGRlcidcblxuICAgICAgICByZXR1cm4gU2V0dGluZ3NcbiAgICB9LFxuICAgIGZha2VCYWNrZ3JvdW5kc0FycmF5KHBhcmFtZXRlcnMpIHtcbiAgICAgICAgbGV0IHBhcm1zID0ge31cblxuICAgICAgICBpZiAoIV8uaXNVbmRlZmluZWQocGFyYW1ldGVycykpIHtcbiAgICAgICAgICAgIHBhcm1zID0gcGFyYW1ldGVycztcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IEJhY2tncm91bmRzID0gW11cblxuICAgICAgICBCYWNrZ3JvdW5kcy5wdXNoKHsgbmFtZTogJ2Zha2VPbmUnLCB2YWx1ZTogJy9mYWtlT25lLmpwZycgfSlcbiAgICAgICAgQmFja2dyb3VuZHMucHVzaCh7IG5hbWU6ICdmYWtlVHdvJywgdmFsdWU6ICcvZmFrZVR3by5qcGcnIH0pXG4gICAgICAgIEJhY2tncm91bmRzLnB1c2goeyBuYW1lOiAnZmFrZVRocmVlJywgdmFsdWU6ICcvZmFrZVRocmVlLmpwZycgfSlcbiAgICAgICAgQmFja2dyb3VuZHMucHVzaCh7IG5hbWU6ICdmYWtlRm91cicsIHZhbHVlOiAnL2Zha2VGb3VyLmpwZycgfSlcbiAgICAgICAgQmFja2dyb3VuZHMucHVzaCh7IG5hbWU6ICdmYWtlRml2ZScsIHZhbHVlOiAnL2Zha2VGaXZlLmpwZycgfSlcblxuICAgICAgICByZXR1cm4gQmFja2dyb3VuZHNcbiAgICB9LFxuXG4gICAgZmFrZVJldHJvQWN0aW9uKHBhcmFtZXRlcnMpIHtcbiAgICAgICAgbGV0IHBhcm1zID0ge31cblxuICAgICAgICBpZiAoIV8uaXNVbmRlZmluZWQocGFyYW1ldGVycykpIHtcbiAgICAgICAgICAgIHBhcm1zID0gcGFyYW1ldGVycztcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IFJldHJvQWN0aW9uID0ge31cblxuICAgICAgICBSZXRyb0FjdGlvbi5faWQgPSBwYXJtcy5faWQgfHwgUmFuZG9tLmlkKClcbiAgICAgICAgUmV0cm9BY3Rpb24uY3JlYXRlZEJ5ID0gcGFybXMuY3JlYXRlZEJ5IHx8IFJhbmRvbS5pZCgpXG4gICAgICAgIFJldHJvQWN0aW9uLmNyZWF0ZWRBdCA9IHBhcm1zLmNyZWF0ZWRBdCB8fCBuZXcgRGF0ZSgpXG4gICAgICAgIFJldHJvQWN0aW9uLnRpdGxlID0gcGFybXMudGl0bGUgfHwgJ2Zha2UgdGl0bGUnXG4gICAgICAgIFJldHJvQWN0aW9uLnN0YXR1cyA9IHBhcm1zLnN0YXR1cyB8fCBDb25zdGFudHMuUmV0cm9JdGVtU3RhdHVzZXMuUEVORElOR1xuICAgICAgICBSZXRyb0FjdGlvbi5jb21wbGV0ZWRBdCA9IHBhcm1zLmNvbXBsZXRlZEF0IHx8IG51bGxcblxuICAgICAgICByZXR1cm4gUmV0cm9BY3Rpb25cbiAgICB9LFxuXG4gICAgZmFrZVJldHJvSXRlbShwYXJhbWV0ZXJzKSB7XG4gICAgICAgIGxldCBwYXJtcyA9IHt9XG5cbiAgICAgICAgaWYgKCFfLmlzVW5kZWZpbmVkKHBhcmFtZXRlcnMpKSB7XG4gICAgICAgICAgICBwYXJtcyA9IHBhcmFtZXRlcnM7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBSZXRyb0l0ZW0gPSB7fVxuXG4gICAgICAgIFJldHJvSXRlbS5pdGVtSWQgPSBwYXJtcy5pdGVtSWQgfHwgUmFuZG9tLmlkKClcbiAgICAgICAgUmV0cm9JdGVtLnRpdGxlID0gcGFybXMudGl0bGUgfHwgJ2Zha2UgdGl0bGUnXG4gICAgICAgIFJldHJvSXRlbS5zdGF0dXMgPSBwYXJtcy5zdGF0dXMgfHwgQ29uc3RhbnRzLlJldHJvSXRlbVN0YXR1c2VzLlBFTkRJTkdcbiAgICAgICAgUmV0cm9JdGVtLml0ZW1UeXBlID0gcGFybXMuaXRlbVR5cGUgfHwgUmFuZG9tLmNob2ljZShbQ29uc3RhbnRzLlJldHJvSXRlbVR5cGVzLkhBUFBZLCBDb25zdGFudHMuUmV0cm9JdGVtVHlwZXMuTUVILCBDb25zdGFudHMuUmV0cm9JdGVtVHlwZXMuU0FEXSlcbiAgICAgICAgUmV0cm9JdGVtLnZvdGVzID0gcGFybXMudm90ZXMgfHwgMFxuICAgICAgICBSZXRyb0l0ZW0uY3JlYXRlZEF0ID0gcGFybXMuY3JlYXRlZEF0IHx8IG5ldyBEYXRlKClcblxuICAgICAgICByZXR1cm4gUmV0cm9JdGVtXG4gICAgfSxcblxuICAgIGZha2VSZXRyb0l0ZW1zKHBhcmFtZXRlcnMsIGNvdW50KSB7XG4gICAgICAgIGNvbnN0IGl0ZW1zID0gW11cblxuICAgICAgICBpZiAoIWNvdW50KSBjb3VudCA9IDFcblxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNvdW50OyBpICs9IDEpIHtcbiAgICAgICAgICAgIGl0ZW1zLnB1c2godGhpcy5mYWtlUmV0cm9JdGVtKHBhcmFtZXRlcnMpKSAvLyAgZXNsaW50LWRpc2FibGUtbGluZVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGl0ZW1zXG4gICAgfSxcblxuICAgIGZha2VSZXRybyhwYXJhbWV0ZXJzKSB7XG4gICAgICAgIGxldCBwYXJtcyA9IHt9XG5cbiAgICAgICAgaWYgKCFfLmlzVW5kZWZpbmVkKHBhcmFtZXRlcnMpKSB7XG4gICAgICAgICAgICBwYXJtcyA9IHBhcmFtZXRlcnM7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBSZXRybyA9IHt9XG5cbiAgICAgICAgUmV0cm8uX2lkID0gcGFybXMuX2lkIHx8IFJhbmRvbS5pZCgpXG4gICAgICAgIFJldHJvLmNyZWF0ZWRBdCA9IG5ldyBEYXRlKClcbiAgICAgICAgUmV0cm8uY3JlYXRlZEJ5ID0gcGFybXMuY3JlYXRlZEJ5IHx8IFJhbmRvbS5pZCgpXG4gICAgICAgIFJldHJvLnRpdGxlID0gcGFybXMudGl0bGUgfHwgJ2Zha2UgdGl0bGUnXG4gICAgICAgIFJldHJvLnN0YXR1cyA9IHBhcm1zLnN0YXR1cyB8fCBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5BQ1RJVkVcbiAgICAgICAgUmV0cm8uaXRlbXMgPSBwYXJtcy5pdGVtcyB8fCB0aGlzLmZha2VSZXRyb0l0ZW1zKHt9LCBwYXJtcy5jb3VudCB8fCAzKVxuICAgICAgICBSZXRyby5zaG93Q29tcGxldGVkID0gXy5pc1VuZGVmaW5lZChwYXJtcy5zaG93Q29tcGxldGVkKSA/IGZhbHNlIDogcGFybXMuc2hvd0NvbXBsZXRlZFxuICAgICAgICBSZXRyby5hcmNoaXZlZEF0ID0gcGFybXMuYXJjaGl2ZWRBdCB8fCBuZXcgRGF0ZSgpXG4gICAgICAgIFJldHJvLmhhcHB5UGxhY2Vob2xkZXIgPSAnRmFrZSBoYXBweSBwbGFjZWhvbGRlcidcbiAgICAgICAgUmV0cm8ubWVoUGxhY2Vob2xkZXIgPSAnRmFrZSBtZWggcGxhY2Vob2xkZXInXG4gICAgICAgIFJldHJvLnNhZFBsYWNlaG9sZGVyID0gJ0Zha2Ugc2FkIHBsYWNlaG9sZGVyJ1xuICAgICAgICBpZiAocGFybXMuYXJjaGl2ZU5hbWUpIHtcbiAgICAgICAgICAgIFJldHJvLmFyY2hpdmVOYW1lID0gcGFybXMuYXJjaGl2ZU5hbWVcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBSZXRyb1xuICAgIH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSB7IFRlc3REYXRhIH1cblxuIl19
