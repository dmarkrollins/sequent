var require = meteorInstall({"lib":{"constants.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/constants.js                                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
!function (module1) {
  const Constants = {
    RetroStatuses: {
      ACTIVE: 'Active',
      ARCHIVED: 'Archived',
      FROZEN: 'Frozen',
      values: ['Active', 'Archived', 'Frozen']
    },
    RetroItemStatuses: {
      PENDING: 'Pending',
      COMPLETE: 'Complete',
      values: ['Pending', 'Complete']
    },
    RetroItemTypes: {
      HAPPY: 'Happy',
      MEH: 'Meh',
      SAD: 'Sad',
      ACTION: 'Action',
      values: ['Happy', 'Meh', 'Sad', 'Action']
    }
  };
  module.exports = {
    Constants
  };
}.call(this, module);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"logger.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/logger.js                                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
!function (module1) {
  const Logger = {
    log: message => {
      console.log(message);
    }
  };
  module.exports = {
    Logger
  };
}.call(this, module);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-completeRetroItem.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/method-completeRetroItem.js                                                                                  //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Retros;
module.link("./sequent", {
  Retros(v) {
    Retros = v;
  }

}, 1);
let Schemas;
module.link("./schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 2);
let Constants;
module.link("./constants", {
  Constants(v) {
    Constants = v;
  }

}, 3);
let Logger;
module.link("./logger", {
  Logger(v) {
    Logger = v;
  }

}, 4);
Meteor.methods({
  completeRetroItem(itemId) {
    const retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    } // validate item type


    const retro = Retros.findOne({
      createdBy: this.userId,
      $or: [{
        status: Constants.RetroStatuses.ACTIVE
      }, {
        status: Constants.RetroStatuses.FROZEN
      }]
    }); // need to see if there is

    if (!retro) {
      throw new Meteor.Error('not-found', 'Retro not found!');
    }

    try {
      Retros.update({
        _id: retro._id,
        'items.itemId': itemId
      }, {
        $set: {
          'items.$.status': Constants.RetroItemStatuses.COMPLETE
        }
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('update-failed', 'We could not complete the retro item - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-removeAction.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/method-removeAction.js                                                                                       //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Retros, RetroActions;
module.link("./sequent", {
  Retros(v) {
    Retros = v;
  },

  RetroActions(v) {
    RetroActions = v;
  }

}, 1);
let Schemas;
module.link("./schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 2);
let Constants;
module.link("./constants", {
  Constants(v) {
    Constants = v;
  }

}, 3);
let Logger;
module.link("./logger", {
  Logger(v) {
    Logger = v;
  }

}, 4);
Meteor.methods({
  removeAction(actionId) {
    const retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    const action = RetroActions.findOne({
      _id: actionId,
      createdBy: this.userId
    });

    if (!action) {
      throw new Meteor.Error('not-found', 'Action not found!');
    }

    try {
      RetroActions.remove({
        _id: actionId
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('delete-failed', 'We could not delete the action - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-removeRetroItem.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/method-removeRetroItem.js                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 1);
let Retros;
module.link("./sequent", {
  Retros(v) {
    Retros = v;
  }

}, 2);
let Schemas;
module.link("./schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 3);
let Constants;
module.link("./constants", {
  Constants(v) {
    Constants = v;
  }

}, 4);
let Logger;
module.link("./logger", {
  Logger(v) {
    Logger = v;
  }

}, 5);
Meteor.methods({
  removeRetroItem(itemId) {
    const retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    const retro = Retros.findOne({
      createdBy: this.userId,
      $or: [{
        status: Constants.RetroStatuses.ACTIVE
      }, {
        status: Constants.RetroStatuses.FROZEN
      }]
    }); // need to see if there is

    if (!retro) {
      throw new Meteor.Error('not-found', 'Retro not found!');
    }

    const retroItem = _.filter(retro.items, function (item) {
      return item.itemId === itemId;
    });

    if (retroItem.length === 0) {
      throw new Meteor.Error('not-found', 'Retro Item not found!');
    }

    try {
      Retros.update({
        _id: retro._id
      }, {
        $pull: {
          items: {
            itemId: itemId
          }
        }
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('update-failed', 'We could not remove retro item - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-toggleAction.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/method-toggleAction.js                                                                                       //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Random;
module.link("meteor/random", {
  Random(v) {
    Random = v;
  }

}, 1);
let Retros, RetroActions;
module.link("../lib/sequent", {
  Retros(v) {
    Retros = v;
  },

  RetroActions(v) {
    RetroActions = v;
  }

}, 2);
let Schemas;
module.link("./schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 3);
let Constants;
module.link("./constants", {
  Constants(v) {
    Constants = v;
  }

}, 4);
let Logger;
module.link("./logger", {
  Logger(v) {
    Logger = v;
  }

}, 5);
Meteor.methods({
  toggleAction(actionId) {
    const retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    const action = RetroActions.findOne({
      _id: actionId,
      createdBy: this.userId
    });

    if (!action) {
      throw new Meteor.Error('not-found', 'RetroAction not found!');
    }

    const newValue = action.status === Constants.RetroItemStatuses.PENDING ? Constants.RetroItemStatuses.COMPLETE : Constants.RetroItemStatuses.PENDING;
    let newDate;

    if (newValue === Constants.RetroItemStatuses.COMPLETE) {
      newDate = new Date();
    } else {
      newDate = null;
    }

    try {
      RetroActions.update({
        _id: actionId
      }, {
        $set: {
          status: newValue,
          completedAt: newDate
        }
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('delete-failed', 'We could not delete the action - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-toggleRetroFrozen.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/method-toggleRetroFrozen.js                                                                                  //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Retros, RetroActions;
module.link("./sequent", {
  Retros(v) {
    Retros = v;
  },

  RetroActions(v) {
    RetroActions = v;
  }

}, 1);
let Schemas;
module.link("./schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 2);
let Constants;
module.link("./constants", {
  Constants(v) {
    Constants = v;
  }

}, 3);
let Logger;
module.link("./logger", {
  Logger(v) {
    Logger = v;
  }

}, 4);
Meteor.methods({
  toggleRetroFrozen() {
    const retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    } // validate item type


    const retro = Retros.findOne({
      createdBy: this.userId,
      $or: [{
        status: Constants.RetroStatuses.ACTIVE
      }, {
        status: Constants.RetroStatuses.FROZEN
      }]
    }); // need to see if there is

    if (!retro) {
      throw new Meteor.Error('not-found', 'Retro not found!');
    }

    if (retro.status === Constants.RetroStatuses.ARCHIVED) {
      throw new Meteor.Error('invalid-state', 'Retro must not be archived!');
    }

    const newStatus = retro.status === Constants.RetroStatuses.FROZEN ? Constants.RetroStatuses.ACTIVE : Constants.RetroStatuses.FROZEN;

    try {
      Retros.update({
        _id: retro._id
      }, {
        $set: {
          status: newStatus
        }
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('update-failed', 'We could not freeze the retro - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-toggleShowCompleted.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/method-toggleShowCompleted.js                                                                                //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Retros, RetroActions;
module.link("./sequent", {
  Retros(v) {
    Retros = v;
  },

  RetroActions(v) {
    RetroActions = v;
  }

}, 1);
let Schemas;
module.link("./schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 2);
let Constants;
module.link("./constants", {
  Constants(v) {
    Constants = v;
  }

}, 3);
let Logger;
module.link("./logger", {
  Logger(v) {
    Logger = v;
  }

}, 4);
Meteor.methods({
  toggleShowCompleted() {
    const retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    const retro = Retros.findOne({
      createdBy: this.userId,
      $or: [{
        status: Constants.RetroStatuses.ACTIVE
      }, {
        status: Constants.RetroStatuses.FROZEN
      }]
    }); // need to see if there is

    if (!retro) {
      throw new Meteor.Error('not-found', 'Retro not found!');
    }

    const show = !retro.showCompleted;

    try {
      Retros.update({
        _id: retro._id
      }, {
        $set: {
          showCompleted: show
        }
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('update-failed', 'We could toggle retro show completed - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-upVoteItem.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/method-upVoteItem.js                                                                                         //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 1);
let Retros;
module.link("./sequent", {
  Retros(v) {
    Retros = v;
  }

}, 2);
let Schemas;
module.link("./schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 3);
let Constants;
module.link("./constants", {
  Constants(v) {
    Constants = v;
  }

}, 4);
let Logger;
module.link("./logger", {
  Logger(v) {
    Logger = v;
  }

}, 5);
Meteor.methods({
  upVoteItem(itemId) {
    const retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    } // validate item type


    const retro = Retros.findOne({
      createdBy: this.userId,
      status: Constants.RetroStatuses.ACTIVE
    }); // need to see if there is

    if (!retro) {
      throw new Meteor.Error('not-found', 'Retro not found!');
    }

    const retroItem = _.filter(retro.items, function (item) {
      return item.itemId === itemId;
    });

    if (retroItem.length === 0) {
      throw new Meteor.Error('not-found', 'Retro Item not found!');
    }

    let voteCount = retroItem[0].votes || 0;
    voteCount += 1;

    try {
      Retros.update({
        _id: retro._id,
        'items.itemId': itemId
      }, {
        $set: {
          'items.$.votes': voteCount
        }
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('update-failed', 'We could not upvote this item - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"schemas.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/schemas.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
!function (module1) {
  let SimpleSchema;
  module1.link("meteor/aldeed:simple-schema", {
    SimpleSchema(v) {
      SimpleSchema = v;
    }

  }, 0);
  let Constants;
  module1.link("./constants", {
    Constants(v) {
      Constants = v;
    }

  }, 1);
  const Schemas = {};
  Schemas.RetroItem = new SimpleSchema({
    itemId: {
      type: String,
      regEx: SimpleSchema.RegEx.Id,
      optional: true
    },
    title: {
      type: String,
      max: 255
    },
    status: {
      type: String,
      allowedValues: Constants.RetroItemStatuses.values
    },
    itemType: {
      type: String,
      allowedValues: Constants.RetroItemTypes.values
    },
    votes: {
      type: Number,
      optional: true
    },
    createdAt: {
      type: Date
    }
  });
  Schemas.Retros = new SimpleSchema({
    _id: {
      type: String,
      regEx: SimpleSchema.RegEx.Id,
      optional: true
    },
    createdAt: {
      type: Date,
      autoValue: function () {
        if (this.isInsert) {
          return new Date();
        }

        this.unset();
      }
    },
    createdBy: {
      type: String,
      regEx: SimpleSchema.RegEx.Id,
      autoValue: function () {
        if (this.isInsert) {
          return this.userId;
        }

        this.unset();
      }
    },
    status: {
      type: String,
      allowedValues: Constants.RetroStatuses.values
    },
    items: {
      type: [Schemas.RetroItem]
    },
    showCompleted: {
      type: Boolean,
      optional: true,
      defaultValue: false
    },
    archivedAt: {
      type: Date,
      optional: true
    },
    happyPlaceholder: {
      type: String,
      optional: true
    },
    mehPlaceholder: {
      type: String,
      optional: true
    },
    sadPlaceholder: {
      type: String,
      optional: true
    },
    archiveName: {
      type: String,
      optional: true
    }
  });
  Schemas.Actions = new SimpleSchema({
    _id: {
      type: String,
      regEx: SimpleSchema.RegEx.Id,
      optional: true
    },
    createdAt: {
      type: Date,
      autoValue: function () {
        if (this.isInsert) {
          return new Date();
        }

        this.unset();
      }
    },
    createdBy: {
      type: String,
      regEx: SimpleSchema.RegEx.Id,
      autoValue: function () {
        if (this.isInsert) {
          return this.userId;
        }

        this.unset();
      }
    },
    title: {
      type: String,
      max: 255
    },
    status: {
      type: String,
      allowedValues: Constants.RetroItemStatuses.values
    },
    completedAt: {
      type: Date,
      optional: true
    }
  });
  Schemas.NewTeam = new SimpleSchema({
    name: {
      type: String,
      max: 60,
      min: 5
    },
    description: {
      type: String,
      optional: true,
      max: 255
    },
    password: {
      type: String,
      regEx: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/,
      min: 8
    },
    confirmPassword: {
      type: String,
      min: 8,

      custom() {
        if (this.value !== this.field('password').value) {
          return 'passwordMismatch';
        }
      }

    }
  });
  Schemas.Settings = new SimpleSchema({
    _id: {
      type: String,
      regEx: SimpleSchema.RegEx.Id,
      optional: true
    },
    createdBy: {
      type: String,
      regEx: SimpleSchema.RegEx.Id,
      autoValue: function () {
        if (this.isInsert) {
          return this.userId;
        }

        this.unset();
      },
      optional: true
    },
    backgroundImage: {
      type: String,
      defaultValue: '/backgrounds/triangles.png',
      optional: true
    },
    happyPlaceholder: {
      type: String,
      defaultValue: ':)',
      optional: true
    },
    mehPlaceholder: {
      type: String,
      defaultValue: ':|',
      optional: true
    },
    sadPlaceholder: {
      type: String,
      defaultValue: ':(',
      optional: true
    }
  });
  module.exports = {
    Schemas
  };
}.call(this, module);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"sequent.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/sequent.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
!function (module1) {
  let Mongo;
  module1.link("meteor/mongo", {
    Mongo(v) {
      Mongo = v;
    }

  }, 0);
  let Schemas;
  module1.link("./schemas", {
    Schemas(v) {
      Schemas = v;
    }

  }, 1);

  if (!String.prototype.toProperCase) {
    String.prototype.toProperCase = function () {
      return this.replace(/\w\S*/g, function (txt) {
        return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
      });
    };
  }

  const Retros = new Mongo.Collection('retros');
  const RetroActions = new Mongo.Collection('retro-actions');
  const Backgrounds = new Mongo.Collection('backgrounds');
  const Settings = new Mongo.Collection('settings');
  Retros.attachSchema(Schemas.Retros);
  RetroActions.attachSchema(Schemas.Actions);
  Settings.attachSchema(Schemas.Settings);
  const Sequent = {
    archiveRouteName: 'archives',
    defaultBackground: '/backgrounds/triangles.png',
    defaultConfirmMsg: 'Are you sure?',
    ToastTimeOut: 3000,
    EMAIL_TARGET: 'emailTarget',

    pageSize() {
      return 25;
    },

    getSettings() {
      let settings = Settings.findOne();

      if (!settings) {
        settings = {};
        settings.backgroundImage = Sequent.defaultBackground;
        settings.happyPlaceholder = ':)';
        settings.mehPlaceholder = ':|';
        settings.sadPlaceholder = ':(';
      }

      return settings;
    }

  };
  module.exports = {
    Sequent,
    Retros,
    RetroActions,
    Backgrounds,
    Settings
  };
}.call(this, module);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"cleanInput.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/cleanInput.js                                                                                             //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let sanitizeHtml;
module.link("sanitize-html", {
  default(v) {
    sanitizeHtml = v;
  }

}, 0);

const cleanInput = function (input) {
  let defaultVal = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
  const value = sanitizeHtml(input, {
    allowedTags: []
  });
  return value || defaultVal;
};

module.exportDefault(cleanInput);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"convertRetro.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/convertRetro.js                                                                                           //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
!function (module1) {
  let _;

  module1.link("meteor/underscore", {
    _(v) {
      _ = v;
    }

  }, 0);

  const ConvertRetro = (settings, retro) => {
    const items = [];
    let doc = '';
    doc += "\"".concat(settings.happyPlaceholder, "\",\"").concat(settings.mehPlaceholder, "\",\"").concat(settings.sadPlaceholder, "\"\n");

    const happy = _.filter(retro.items, item => item.itemType.toLowerCase() === 'happy');

    happy.forEach(item => {
      items.push({
        happy: item.title,
        meh: '',
        sad: ''
      });
    });

    const meh = _.filter(retro.items, item => item.itemType.toLowerCase() === 'meh');

    meh.forEach(item => {
      const next = _.find(items, i => i.meh === '');

      if (next) {
        next.meh = item.title;
      } else {
        items.push({
          happy: '',
          meh: item.title,
          sad: ''
        });
      }
    });

    const sad = _.filter(retro.items, item => item.itemType.toLowerCase() === 'sad');

    sad.forEach(item => {
      const next = _.find(items, i => i.sad === '');

      if (next) {
        next.sad = item.title;
      } else {
        items.push({
          happy: '',
          meh: '',
          sad: item.title
        });
      }
    });
    items.forEach(item => {
      doc += "\"".concat(item.happy, "\",\"").concat(item.meh, "\",\"").concat(item.sad, "\"\n");
    });
    return doc;
  };

  module.exports = {
    ConvertRetro
  };
}.call(this, module);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"exportBoard.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/exportBoard.js                                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let WebApp;
module.link("meteor/webapp", {
  WebApp(v) {
    WebApp = v;
  }

}, 1);
let Settings, Retros;
module.link("../lib/sequent", {
  Settings(v) {
    Settings = v;
  },

  Retros(v) {
    Retros = v;
  }

}, 2);
let ConvertRetro;
module.link("./convertRetro", {
  ConvertRetro(v) {
    ConvertRetro = v;
  }

}, 3);
WebApp.connectHandlers.use('/export/retro', (req, res, next) => {
  const {
    id
  } = req.query;
  const retro = Retros.findOne(id);

  if (!retro) {
    res.writeHead(400);
    res.end('Retro not found!');
  }

  let settings = Settings.findOne({
    createdBy: retro.createdBy
  });

  if (!settings) {
    settings = {
      happyPlaceholder: ':)',
      mehPlaceholder: ':|',
      sadPlaceholder: ':('
    };
  }

  const user = Meteor.users.findOne({
    _id: retro.createdBy
  });

  if (!user) {
    user.username = 'sequent';
  }

  const doc = ConvertRetro(settings, retro);
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', "attachment; filename=".concat(user.username, "-export.csv"));
  res.end(doc);
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-archiveRetro.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/method-archiveRetro.js                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let moment;
module.link("moment", {
  default(v) {
    moment = v;
  }

}, 1);
let Settings, Retros;
module.link("../lib/sequent", {
  Settings(v) {
    Settings = v;
  },

  Retros(v) {
    Retros = v;
  }

}, 2);
let Schemas;
module.link("../lib/schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 3);
let Constants;
module.link("../lib/constants", {
  Constants(v) {
    Constants = v;
  }

}, 4);
let Logger;
module.link("../lib/logger", {
  Logger(v) {
    Logger = v;
  }

}, 5);
let cleanInput;
module.link("./cleanInput", {
  default(v) {
    cleanInput = v;
  }

}, 6);

const inputName = (name, dateVal) => {
  const newName = cleanInput(name);
  if (!newName) return "".concat(dateVal);
  if (newName === '') return "".concat(dateVal);
  return newName;
};

Meteor.methods({
  archiveRetro(retroId, name) {
    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    const retro = Retros.findOne({
      _id: retroId,
      createdBy: this.userId
    });

    if (!retro) {
      throw new Meteor.Error('not-found', 'Retro could not be found!');
    }

    if (retro.status === Constants.RetroStatuses.ARCHIVED) {
      throw new Meteor.Error('already-archived', 'Retro was already archived!');
    }

    const archivedAt = new Date();
    const dateVal = moment(archivedAt).format('MM-DD-YYYY - LT');
    const archiveName = inputName(name, dateVal);

    if (archiveName !== name && name !== '') {
      throw new Meteor.Error('invalid-name', 'Invalid Archive name. HTML tags not allowed!');
    }

    let settings = Settings.findOne({
      createdBy: this.userId
    });

    if (!settings) {
      settings = {
        happyPlaceholder: ':)',
        mehPlaceholder: ':|',
        sadPlaceholder: ':('
      };
    }

    try {
      Retros.update({
        _id: retro._id
      }, {
        $set: {
          status: Constants.RetroStatuses.ARCHIVED,
          archivedAt,
          archiveName,
          happyPlaceholder: settings.happyPlaceholder,
          mehPlaceholder: settings.mehPlaceholder,
          sadPlaceholder: settings.sadPlaceholder
        }
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('update-failed', 'We could not archive the retro - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-clearRetroBoard.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/method-clearRetroBoard.js                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Retros;
module.link("../lib/sequent", {
  Retros(v) {
    Retros = v;
  }

}, 1);
let Constants;
module.link("../lib/constants", {
  Constants(v) {
    Constants = v;
  }

}, 2);
let Logger;
module.link("../lib/logger", {
  Logger(v) {
    Logger = v;
  }

}, 3);
Meteor.methods({
  clearRetroBoard(retroId, name) {
    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    const retro = Retros.findOne({
      _id: retroId,
      createdBy: this.userId
    });

    if (!retro) {
      throw new Meteor.Error('not-found', 'Retro could not be found!');
    }

    if (retro.status === Constants.RetroStatuses.ARCHIVED) {
      throw new Meteor.Error('already-archived', 'Retro is archived and cannot be cleared!');
    }

    try {
      Retros.update({
        _id: retro._id
      }, {
        $set: {
          items: []
        }
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('update-failed', 'We could not clear this retro board - please try again later.');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-componentImages.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/method-componentImages.js                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let fs;
module.link("fs", {
  default(v) {
    fs = v;
  }

}, 1);

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 2);
Meteor.methods({
  componentImages() {
    const images = [];
    const meteorRoot = fs.realpathSync("".concat(process.cwd(), "/../"));
    const publicPath = "".concat(meteorRoot, "/web.browser/app/");
    const backgroundPath = "".concat(publicPath, "/");
    const bgs = fs.readdirSync(backgroundPath);
    const files = bgs.filter(function (elm) {
      return elm.match(/.*\.(png)/ig);
    });

    _.each(files, function (img) {
      images.push({
        fileName: "/".concat(img)
      });
    });

    return images;
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-createRetroAction.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/method-createRetroAction.js                                                                               //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Retros, RetroActions;
module.link("../lib/sequent", {
  Retros(v) {
    Retros = v;
  },

  RetroActions(v) {
    RetroActions = v;
  }

}, 1);
let Schemas;
module.link("../lib/schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 2);
let Constants;
module.link("../lib/constants", {
  Constants(v) {
    Constants = v;
  }

}, 3);
let Logger;
module.link("../lib/logger", {
  Logger(v) {
    Logger = v;
  }

}, 4);
let cleanInput;
module.link("./cleanInput", {
  default(v) {
    cleanInput = v;
  }

}, 5);
Meteor.methods({
  createRetroAction(title) {
    const retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    const action = {};
    action.title = cleanInput(title);
    action.status = Constants.RetroItemStatuses.PENDING;

    if (action.title === '') {
      throw new Meteor.Error('title-required', 'Invalid action item! HTML Tags not allowed.');
    }

    try {
      const actionId = RetroActions.insert(action);
      return actionId;
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('insert-failed', 'We could not add retro item to the retro - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-createRetroItem.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/method-createRetroItem.js                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Random;
module.link("meteor/random", {
  Random(v) {
    Random = v;
  }

}, 1);

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 2);
let Retros;
module.link("../lib/sequent", {
  Retros(v) {
    Retros = v;
  }

}, 3);
let Schemas;
module.link("../lib/schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 4);
let Constants;
module.link("../lib/constants", {
  Constants(v) {
    Constants = v;
  }

}, 5);
let Logger;
module.link("../lib/logger", {
  Logger(v) {
    Logger = v;
  }

}, 6);
let cleanInput;
module.link("./cleanInput", {
  default(v) {
    cleanInput = v;
  }

}, 7);
Meteor.methods({
  createRetroItem(title, itemType) {
    let retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    const newTitle = cleanInput(title);

    if (newTitle === '') {
      throw new Meteor.Error('title-required', 'Invalid retro item! HTML Tags not allowed.');
    } // if there are no active retros for this user create one


    let retro = Retros.findOne({
      createdBy: this.userId,
      status: Constants.RetroStatuses.ACTIVE
    });

    if (!retro) {
      const retroDoc = {};
      retroDoc.status = Constants.RetroStatuses.ACTIVE;
      retroDoc.items = [];
      retroId = Retros.insert(retroDoc);
      retro = Retros.findOne({
        _id: retroId
      });
    } else {
      retroId = retro._id;
    }

    const doc = {};
    doc.itemId = Random.id();
    doc.title = newTitle;
    doc.itemType = itemType;
    doc.status = Constants.RetroItemStatuses.PENDING;
    doc.votes = 0;
    doc.createdAt = new Date();

    if (!_.isArray(retro.items)) {
      retro.items = [];
    } // retro.items.push(doc)


    try {
      Retros.update({
        _id: retroId
      }, {
        $push: {
          items: doc
        }
      });
      return retroId;
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('insert-failed', 'We could not add retro item to the retro - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-getChartUrl.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/method-getChartUrl.js                                                                                     //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
Meteor.methods({
  getChartUrl() {
    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    const retval = process.env.USAGE_URL || '';
    return retval;
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-saveSettings.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/method-saveSettings.js                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Random;
module.link("meteor/random", {
  Random(v) {
    Random = v;
  }

}, 1);
let Match;
module.link("meteor/check", {
  Match(v) {
    Match = v;
  }

}, 2);
let SimpleSchema;
module.link("meteor/aldeed:simple-schema", {
  SimpleSchema(v) {
    SimpleSchema = v;
  }

}, 3);

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 4);
let Settings;
module.link("../lib/sequent", {
  Settings(v) {
    Settings = v;
  }

}, 5);
let Schemas;
module.link("../lib/schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 6);
let Logger;
module.link("../lib/logger", {
  Logger(v) {
    Logger = v;
  }

}, 7);
let cleanInput;
module.link("./cleanInput", {
  default(v) {
    cleanInput = v;
  }

}, 8);
Meteor.methods({
  saveSettings(doc) {
    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    Schemas.Settings.validate(doc);
    const settings = Settings.findOne({
      createdBy: this.userId
    });
    const happy = cleanInput(doc.happyPlaceholder, ':)');
    const meh = cleanInput(doc.mehPlaceholder, ':|');
    const sad = cleanInput(doc.sadPlaceholder, ':(');

    if (happy !== doc.happyPlaceholder || meh !== doc.mehPlaceholder || sad !== doc.sadPlaceholder) {
      throw new Meteor.Error('invalid-prompt', 'Invalid prompt! HTML Tags not allowed.');
    }

    try {
      if (_.isUndefined(settings)) {
        Settings.insert(doc);
      } else {
        Settings.update({
          _id: settings._id
        }, {
          $set: {
            backgroundImage: doc.backgroundImage,
            happyPlaceholder: happy,
            mehPlaceholder: meh,
            sadPlaceholder: sad
          }
        });
      }
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('update-failed', 'We could not update settings - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-sendActionsByEmail.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/method-sendActionsByEmail.js                                                                              //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 1);
let Retros, RetroActions;
module.link("../lib/sequent", {
  Retros(v) {
    Retros = v;
  },

  RetroActions(v) {
    RetroActions = v;
  }

}, 2);
let Constants;
module.link("../lib/constants", {
  Constants(v) {
    Constants = v;
  }

}, 3);
let ServerUtils;
module.link("./serverUtils", {
  ServerUtils(v) {
    ServerUtils = v;
  }

}, 4);
let cleanInput;
module.link("./cleanInput", {
  default(v) {
    cleanInput = v;
  }

}, 5);
Meteor.methods({
  sendActionsByEmail(currentRetro, targetEmail) {
    // console.log('hi there')
    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged in to perform this action!');
    } // const retro = Retros.findOne({ _id: currentRetro })
    // if (!retro) {
    //     throw new Meteor.Error('not-found', 'Retro not found!')
    // }
    // if (retro.createdBy !== this.userId) {
    //     throw new Meteor.Error('not-the-owner', 'You are not the owner of this retro!')
    // }


    const emailToUse = targetEmail || '';

    if (emailToUse === '') {
      throw new Meteor.Error('email-address-required', 'An email address is required!');
    }

    const newEmail = cleanInput(emailToUse);

    if (newEmail === '') {
      throw new Meteor.Error('contains-html', 'Invalid email address!');
    } // console.log('email', newEmail)


    const actions = RetroActions.find({
      createdBy: this.userId,
      $or: [{
        status: Constants.RetroItemStatuses.PENDING
      }, {
        status: Constants.RetroItemStatuses.COMPLETE,
        completedAt: {
          $gt: new Date(Date.now() - 24 * 60 * 60 * 1000)
        }
      }]
    }).fetch();

    if (actions.length === 0) {
      throw new Meteor.Error('no-actions', 'There are no active or recently completed actions to send!');
    }

    const data = {};
    const user = Meteor.users.findOne(this.userId);
    data.retroName = user.username.toProperCase();
    data.currentYear = new Date().getFullYear(); // turn into html list

    let items = '<tr><th>Action Item</th><th class="text-center" style="width: 25%;">Status</th></tr>';
    data.retroItems = _.sortBy(actions, 'status').forEach(item => {
      const isComplete = item.status === Constants.RetroItemStatuses.COMPLETE ? 'Complete' : 'Active';
      const itemStyle = item.status === Constants.RetroItemStatuses.COMPLETE ? 'color: #999; padding: 4px 4px 4px 0px; vertical-align: top;' : 'padding: 4px 4px 4px 0px; vertical-align: top;';
      items += "<tr></tr><td style=\"".concat(itemStyle, "\">").concat(item.title, "</td><td style=\"").concat(itemStyle, "\">").concat(isComplete, "</td></tr>");
    });
    data.retroItems = items;
    const from = process.env.FROM_EMAIL_ADDRESS || 'sequent@6thcents.com';
    ServerUtils.sendHtmlEmail(newEmail, from, "".concat(user.username.toProperCase(), " Action Items"), 'actionItems', data);
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-updateActionTitle.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/method-updateActionTitle.js                                                                               //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Retros, RetroActions;
module.link("../lib/sequent", {
  Retros(v) {
    Retros = v;
  },

  RetroActions(v) {
    RetroActions = v;
  }

}, 1);
let Schemas;
module.link("../lib/schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 2);
let Constants;
module.link("../lib/constants", {
  Constants(v) {
    Constants = v;
  }

}, 3);
let Logger;
module.link("../lib/logger", {
  Logger(v) {
    Logger = v;
  }

}, 4);
let cleanInput;
module.link("./cleanInput", {
  default(v) {
    cleanInput = v;
  }

}, 5);
Meteor.methods({
  updateActionTitle(actionId, title) {
    const retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    const action = RetroActions.findOne({
      _id: actionId,
      createdBy: this.userId
    });

    if (!action) {
      throw new Meteor.Error('not-found', 'RetroAction not found!');
    }

    const newTitle = cleanInput(title);

    if (newTitle !== title) {
      throw new Meteor.Error('invalid-title', 'Invalid action! HTML tags not allowed.');
    }

    try {
      RetroActions.update({
        _id: actionId
      }, {
        $set: {
          title: newTitle
        }
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('delete-failed', 'We could not delete the action - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method-updateRetroItemTitle.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/method-updateRetroItemTitle.js                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 1);
let Retros;
module.link("../lib/sequent", {
  Retros(v) {
    Retros = v;
  }

}, 2);
let Schemas;
module.link("../lib/schemas", {
  Schemas(v) {
    Schemas = v;
  }

}, 3);
let Constants;
module.link("../lib/constants", {
  Constants(v) {
    Constants = v;
  }

}, 4);
let Logger;
module.link("../lib/logger", {
  Logger(v) {
    Logger = v;
  }

}, 5);
let cleanInput;
module.link("./cleanInput", {
  default(v) {
    cleanInput = v;
  }

}, 6);
Meteor.methods({
  updateRetroItemTitle(itemId, title) {
    const retroId = '';

    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'You must be logged into a retro board!');
    }

    const retro = Retros.findOne({
      createdBy: this.userId,
      $or: [{
        status: Constants.RetroStatuses.ACTIVE
      }, {
        status: Constants.RetroStatuses.FROZEN
      }]
    }); // need to see if there is

    if (!retro) {
      throw new Meteor.Error('not-found', 'Retro not found!');
    }

    const retroItem = _.filter(retro.items, function (item) {
      return item.itemId === itemId;
    });

    if (retroItem.length === 0) {
      throw new Meteor.Error('not-found', 'Retro Item not found!');
    }

    let voteCount = retroItem[0].votes || 0;
    voteCount += 1;
    const newTitle = cleanInput(title);

    if (newTitle === '') {
      throw new Meteor.Error('invalid-title', 'Invalid Retro Item. HTML tags not allowed.');
    }

    try {
      Retros.update({
        _id: retro._id,
        'items.itemId': itemId
      }, {
        $set: {
          'items.$.title': newTitle
        }
      });
    } catch (err) {
      Logger.log(err);
      throw new Meteor.Error('update-failed', 'We could not update the retro item - please try again later');
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publication-backgrounds.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/publication-backgrounds.js                                                                                //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let fs;
module.link("fs", {
  default(v) {
    fs = v;
  }

}, 1);

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 2);
let Backgrounds;
module.link("../lib/sequent", {
  Backgrounds(v) {
    Backgrounds = v;
  }

}, 3);
Meteor.publish('backgrounds', function () {
  const self = this;
  const meteorRoot = fs.realpathSync("".concat(process.cwd(), "/../"));
  const publicPath = "".concat(meteorRoot, "/web.browser/app/");
  const backgroundPath = "".concat(publicPath, "/backgrounds/");
  const bgs = fs.readdirSync(backgroundPath);

  _.each(bgs, function (background) {
    const backgroundName = background.split('.')[0].toProperCase();
    self.added('backgrounds', background, {
      name: backgroundName,
      value: "/backgrounds/".concat(background)
    });
  });

  this.ready();
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications-actions.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/publications-actions.js                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Match;
module.link("meteor/check", {
  Match(v) {
    Match = v;
  }

}, 1);
let Sequent, RetroActions;
module.link("../lib/sequent", {
  Sequent(v) {
    Sequent = v;
  },

  RetroActions(v) {
    RetroActions = v;
  }

}, 2);
let Constants;
module.link("../lib/constants", {
  Constants(v) {
    Constants = v;
  }

}, 3);

RetroActions._ensureIndex('createdBy', 1);

RetroActions._ensureIndex('status', 1);

RetroActions._ensureIndex('createdAt', 1);

Meteor.publish('open-actions', function () {
  if (!this.userId) {
    this.stop();
    return null;
  }

  return RetroActions.find({
    createdBy: this.userId,
    status: Constants.RetroItemStatuses.PENDING
  });
});
Meteor.publish('all-actions', function (search) {
  if (!this.userId) {
    return null;
  }

  if (!Match.test(search, {
    limit: Number,
    showAll: Boolean
  })) {
    return null;
  }

  const query = {
    createdBy: this.userId
  };

  if (!search.showAll) {
    query.status = Constants.RetroItemStatuses.PENDING;
  }

  return RetroActions.find(query, {
    sort: {
      completedAt: 1
    },
    limit: search.limit
  });
});
/*
messages.find({'metadata.thread': threadId},
  {
    sort: {'date' : sort},
    limit: limit,
    disableOplog: true,
    pollingThrottleMs: 12000,
    pollingIntervalMs: 12000
  }
);
*/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications-retros.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/publications-retros.js                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Retros;
module.link("../lib/sequent", {
  Retros(v) {
    Retros = v;
  }

}, 1);
let Constants;
module.link("../lib/constants", {
  Constants(v) {
    Constants = v;
  }

}, 2);

Retros._ensureIndex('createdBy', 1);

Retros._ensureIndex('status', 1);

Meteor.publish('active-retros', function () {
  if (!this.userId) {
    return null;
  }

  return Retros.find({
    createdBy: this.userId,
    status: {
      $in: [Constants.RetroStatuses.ACTIVE, Constants.RetroStatuses.FROZEN]
    }
  });
});
Meteor.publish('archived-retros', function () {
  if (!this.userId) {
    return null;
  }

  return Retros.find({
    createdBy: this.userId,
    status: Constants.RetroStatuses.ARCHIVED
  });
});
Meteor.publish('single-archived-retro', function (retroId) {
  if (!this.userId) {
    return null;
  }

  return Retros.find({
    _id: retroId,
    createdBy: this.userId,
    status: Constants.RetroStatuses.ARCHIVED
  });
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications-settings.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/publications-settings.js                                                                                  //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Settings;
module.link("../lib/sequent", {
  Settings(v) {
    Settings = v;
  }

}, 1);

Settings._ensureIndex('createdBy', 1);

Meteor.publish('settings', function () {
  if (!Meteor.userId()) {
    return null;
  }

  return Settings.find({
    createdBy: Meteor.userId()
  });
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"serverUtils.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/serverUtils.js                                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
!function (module1) {
  let Meteor;
  module1.link("meteor/meteor", {
    Meteor(v) {
      Meteor = v;
    }

  }, 0);
  let SSR;
  module1.link("meteor/meteorhacks:ssr", {
    SSR(v) {
      SSR = v;
    }

  }, 1);
  let Email;
  module1.link("meteor/email", {
    Email(v) {
      Email = v;
    }

  }, 2);
  let check;
  module1.link("meteor/check", {
    default(v) {
      check = v;
    }

  }, 3);
  let Constants;
  module1.link("../lib/constants", {
    Constants(v) {
      Constants = v;
    }

  }, 4);

  if (!String.prototype.toProperCase) {
    String.prototype.toProperCase = function () {
      return this.replace(/\w\S*/g, function (txt) {
        return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
      });
    };
  }

  SSR.compileTemplate('actionItems', Assets.getText('emailTemplates/actionItems.html'));
  Template.actionItems.helpers({
    isComplete: function () {
      return this.status === Constants.RetroItemStatuses.COMPLETE;
    }
  });
  const ServerUtils = {};

  ServerUtils.sendEmail = (to, from, subject, text) => {
    check([to, from, subject, text], [String]);
    Meteor.defer(function () {
      Email.send({
        to: to,
        from: from || 'noreply@6thcents.com',
        subject: subject,
        text: text
      });
    });
  };

  ServerUtils.sendHtmlEmail = (to, from, subject, templateName, data) => {
    var body = SSR.render(templateName, data);
    Meteor.defer(function () {
      Email.send({
        to: to,
        from: from || 'sequent@6thcents.com',
        subject: subject,
        html: body
      });
    });
  };

  module.exports = {
    ServerUtils
  };
}.call(this, module);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/main.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
Meteor.startup(() => {// code to run on server at startup
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"testSuite":{"client-test-helpers.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// testSuite/client-test-helpers.js                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  withRenderedTemplate: () => withRenderedTemplate
});

let _;

module.link("meteor/underscore", {
  _(v) {
    _ = v;
  }

}, 0);
let Template;
module.link("meteor/templating", {
  Template(v) {
    Template = v;
  }

}, 1);
let Blaze;
module.link("meteor/blaze", {
  Blaze(v) {
    Blaze = v;
  }

}, 2);
let Tracker;
module.link("meteor/tracker", {
  Tracker(v) {
    Tracker = v;
  }

}, 3);

const withDiv = function withDiv(callback) {
  const el = document.createElement('div');
  document.body.appendChild(el);

  try {
    callback(el);
  } finally {
    document.body.removeChild(el);
  }
};

const withRenderedTemplate = function withRenderedTemplate(template, data, callback) {
  withDiv(el => {
    const theTemplate = _.isString(template) ? Template[template] : template;
    Blaze.renderWithData(theTemplate, data, el);
    Tracker.flush();
    callback(el, theTemplate);
  });
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"testData.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// testSuite/testData.js                                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
!function (module1) {
  let Random;
  module1.link("meteor/random", {
    Random(v) {
      Random = v;
    }

  }, 0);

  let _;

  module1.link("meteor/underscore", {
    _(v) {
      _ = v;
    }

  }, 1);
  let Constants;
  module1.link("../lib/constants", {
    Constants(v) {
      Constants = v;
    }

  }, 2);
  const TestData = {
    fakeSettings(parameters) {
      let parms = {};

      if (!_.isUndefined(parameters)) {
        parms = parameters;
      }

      const Settings = {};
      Settings.backgroundImage = '/fakeOne.jpg';
      Settings.happyPlaceholder = 'Fake happy placeholder';
      Settings.mehPlaceholder = 'Fake meh placeholder';
      Settings.sadPlaceholder = 'Fake sad placeholder';
      return Settings;
    },

    fakeBackgroundsArray(parameters) {
      let parms = {};

      if (!_.isUndefined(parameters)) {
        parms = parameters;
      }

      const Backgrounds = [];
      Backgrounds.push({
        name: 'fakeOne',
        value: '/fakeOne.jpg'
      });
      Backgrounds.push({
        name: 'fakeTwo',
        value: '/fakeTwo.jpg'
      });
      Backgrounds.push({
        name: 'fakeThree',
        value: '/fakeThree.jpg'
      });
      Backgrounds.push({
        name: 'fakeFour',
        value: '/fakeFour.jpg'
      });
      Backgrounds.push({
        name: 'fakeFive',
        value: '/fakeFive.jpg'
      });
      return Backgrounds;
    },

    fakeRetroAction(parameters) {
      let parms = {};

      if (!_.isUndefined(parameters)) {
        parms = parameters;
      }

      const RetroAction = {};
      RetroAction._id = parms._id || Random.id();
      RetroAction.createdBy = parms.createdBy || Random.id();
      RetroAction.createdAt = parms.createdAt || new Date();
      RetroAction.title = parms.title || 'fake title';
      RetroAction.status = parms.status || Constants.RetroItemStatuses.PENDING;
      RetroAction.completedAt = parms.completedAt || null;
      return RetroAction;
    },

    fakeRetroItem(parameters) {
      let parms = {};

      if (!_.isUndefined(parameters)) {
        parms = parameters;
      }

      const RetroItem = {};
      RetroItem.itemId = parms.itemId || Random.id();
      RetroItem.title = parms.title || 'fake title';
      RetroItem.status = parms.status || Constants.RetroItemStatuses.PENDING;
      RetroItem.itemType = parms.itemType || Random.choice([Constants.RetroItemTypes.HAPPY, Constants.RetroItemTypes.MEH, Constants.RetroItemTypes.SAD]);
      RetroItem.votes = parms.votes || 0;
      RetroItem.createdAt = parms.createdAt || new Date();
      return RetroItem;
    },

    fakeRetroItems(parameters, count) {
      const items = [];
      if (!count) count = 1;

      for (let i = 0; i < count; i += 1) {
        items.push(this.fakeRetroItem(parameters)); //  eslint-disable-line
      }

      return items;
    },

    fakeRetro(parameters) {
      let parms = {};

      if (!_.isUndefined(parameters)) {
        parms = parameters;
      }

      const Retro = {};
      Retro._id = parms._id || Random.id();
      Retro.createdAt = new Date();
      Retro.createdBy = parms.createdBy || Random.id();
      Retro.title = parms.title || 'fake title';
      Retro.status = parms.status || Constants.RetroStatuses.ACTIVE;
      Retro.items = parms.items || this.fakeRetroItems({}, parms.count || 3);
      Retro.showCompleted = _.isUndefined(parms.showCompleted) ? false : parms.showCompleted;
      Retro.archivedAt = parms.archivedAt || new Date();
      Retro.happyPlaceholder = 'Fake happy placeholder';
      Retro.mehPlaceholder = 'Fake meh placeholder';
      Retro.sadPlaceholder = 'Fake sad placeholder';

      if (parms.archiveName) {
        Retro.archiveName = parms.archiveName;
      }

      return Retro;
    },

    fakeRetro2(parameters) {
      let parms = {};

      if (!_.isUndefined(parameters)) {
        parms = parameters;
      }

      const Retro = {};
      Retro._id = parms._id || Random.id();
      Retro.createdAt = new Date();
      Retro.createdBy = parms.createdBy || Random.id();
      Retro.title = parms.title || 'fake title';
      Retro.status = parms.status || Constants.RetroStatuses.ACTIVE;
      Retro.items = parms.items || this.fakeRetroItems(parameters, parms.count || 3);
      Retro.showCompleted = _.isUndefined(parms.showCompleted) ? false : parms.showCompleted;
      Retro.archivedAt = parms.archivedAt || new Date();
      Retro.happyPlaceholder = 'Fake happy placeholder';
      Retro.mehPlaceholder = 'Fake meh placeholder';
      Retro.sadPlaceholder = 'Fake sad placeholder';

      if (parms.archiveName) {
        Retro.archiveName = parms.archiveName;
      }

      return Retro;
    }

  };
  module.exports = {
    TestData
  };
}.call(this, module);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".mjs"
  ]
});

require("/lib/constants.js");
require("/lib/logger.js");
require("/lib/method-completeRetroItem.js");
require("/lib/method-removeAction.js");
require("/lib/method-removeRetroItem.js");
require("/lib/method-toggleAction.js");
require("/lib/method-toggleRetroFrozen.js");
require("/lib/method-toggleShowCompleted.js");
require("/lib/method-upVoteItem.js");
require("/lib/schemas.js");
require("/lib/sequent.js");
require("/server/cleanInput.js");
require("/server/convertRetro.js");
require("/server/exportBoard.js");
require("/server/method-archiveRetro.js");
require("/server/method-clearRetroBoard.js");
require("/server/method-componentImages.js");
require("/server/method-createRetroAction.js");
require("/server/method-createRetroItem.js");
require("/server/method-getChartUrl.js");
require("/server/method-saveSettings.js");
require("/server/method-sendActionsByEmail.js");
require("/server/method-updateActionTitle.js");
require("/server/method-updateRetroItemTitle.js");
require("/server/publication-backgrounds.js");
require("/server/publications-actions.js");
require("/server/publications-retros.js");
require("/server/publications-settings.js");
require("/server/serverUtils.js");
require("/testSuite/client-test-helpers.js");
require("/testSuite/testData.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvbGliL2NvbnN0YW50cy5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL2xvZ2dlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL21ldGhvZC1jb21wbGV0ZVJldHJvSXRlbS5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL21ldGhvZC1yZW1vdmVBY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9tZXRob2QtcmVtb3ZlUmV0cm9JdGVtLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvbWV0aG9kLXRvZ2dsZUFjdGlvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL21ldGhvZC10b2dnbGVSZXRyb0Zyb3plbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL21ldGhvZC10b2dnbGVTaG93Q29tcGxldGVkLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvbWV0aG9kLXVwVm90ZUl0ZW0uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9zY2hlbWFzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvc2VxdWVudC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2NsZWFuSW5wdXQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9jb252ZXJ0UmV0cm8uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9leHBvcnRCb2FyZC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21ldGhvZC1hcmNoaXZlUmV0cm8uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tZXRob2QtY2xlYXJSZXRyb0JvYXJkLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWV0aG9kLWNvbXBvbmVudEltYWdlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21ldGhvZC1jcmVhdGVSZXRyb0FjdGlvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21ldGhvZC1jcmVhdGVSZXRyb0l0ZW0uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tZXRob2QtZ2V0Q2hhcnRVcmwuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tZXRob2Qtc2F2ZVNldHRpbmdzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWV0aG9kLXNlbmRBY3Rpb25zQnlFbWFpbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21ldGhvZC11cGRhdGVBY3Rpb25UaXRsZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21ldGhvZC11cGRhdGVSZXRyb0l0ZW1UaXRsZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1YmxpY2F0aW9uLWJhY2tncm91bmRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvcHVibGljYXRpb25zLWFjdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9wdWJsaWNhdGlvbnMtcmV0cm9zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvcHVibGljYXRpb25zLXNldHRpbmdzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvc2VydmVyVXRpbHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC90ZXN0U3VpdGUvY2xpZW50LXRlc3QtaGVscGVycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvdGVzdFN1aXRlL3Rlc3REYXRhLmpzIl0sIm5hbWVzIjpbIkNvbnN0YW50cyIsIlJldHJvU3RhdHVzZXMiLCJBQ1RJVkUiLCJBUkNISVZFRCIsIkZST1pFTiIsInZhbHVlcyIsIlJldHJvSXRlbVN0YXR1c2VzIiwiUEVORElORyIsIkNPTVBMRVRFIiwiUmV0cm9JdGVtVHlwZXMiLCJIQVBQWSIsIk1FSCIsIlNBRCIsIkFDVElPTiIsIm1vZHVsZSIsImV4cG9ydHMiLCJMb2dnZXIiLCJsb2ciLCJtZXNzYWdlIiwiY29uc29sZSIsIk1ldGVvciIsImxpbmsiLCJ2IiwiUmV0cm9zIiwiU2NoZW1hcyIsIm1ldGhvZHMiLCJjb21wbGV0ZVJldHJvSXRlbSIsIml0ZW1JZCIsInJldHJvSWQiLCJ1c2VySWQiLCJFcnJvciIsInJldHJvIiwiZmluZE9uZSIsImNyZWF0ZWRCeSIsIiRvciIsInN0YXR1cyIsInVwZGF0ZSIsIl9pZCIsIiRzZXQiLCJlcnIiLCJSZXRyb0FjdGlvbnMiLCJyZW1vdmVBY3Rpb24iLCJhY3Rpb25JZCIsImFjdGlvbiIsInJlbW92ZSIsIl8iLCJyZW1vdmVSZXRyb0l0ZW0iLCJyZXRyb0l0ZW0iLCJmaWx0ZXIiLCJpdGVtcyIsIml0ZW0iLCJsZW5ndGgiLCIkcHVsbCIsIlJhbmRvbSIsInRvZ2dsZUFjdGlvbiIsIm5ld1ZhbHVlIiwibmV3RGF0ZSIsIkRhdGUiLCJjb21wbGV0ZWRBdCIsInRvZ2dsZVJldHJvRnJvemVuIiwibmV3U3RhdHVzIiwidG9nZ2xlU2hvd0NvbXBsZXRlZCIsInNob3ciLCJzaG93Q29tcGxldGVkIiwidXBWb3RlSXRlbSIsInZvdGVDb3VudCIsInZvdGVzIiwiU2ltcGxlU2NoZW1hIiwibW9kdWxlMSIsIlJldHJvSXRlbSIsInR5cGUiLCJTdHJpbmciLCJyZWdFeCIsIlJlZ0V4IiwiSWQiLCJvcHRpb25hbCIsInRpdGxlIiwibWF4IiwiYWxsb3dlZFZhbHVlcyIsIml0ZW1UeXBlIiwiTnVtYmVyIiwiY3JlYXRlZEF0IiwiYXV0b1ZhbHVlIiwiaXNJbnNlcnQiLCJ1bnNldCIsIkJvb2xlYW4iLCJkZWZhdWx0VmFsdWUiLCJhcmNoaXZlZEF0IiwiaGFwcHlQbGFjZWhvbGRlciIsIm1laFBsYWNlaG9sZGVyIiwic2FkUGxhY2Vob2xkZXIiLCJhcmNoaXZlTmFtZSIsIkFjdGlvbnMiLCJOZXdUZWFtIiwibmFtZSIsIm1pbiIsImRlc2NyaXB0aW9uIiwicGFzc3dvcmQiLCJjb25maXJtUGFzc3dvcmQiLCJjdXN0b20iLCJ2YWx1ZSIsImZpZWxkIiwiU2V0dGluZ3MiLCJiYWNrZ3JvdW5kSW1hZ2UiLCJNb25nbyIsInByb3RvdHlwZSIsInRvUHJvcGVyQ2FzZSIsInJlcGxhY2UiLCJ0eHQiLCJjaGFyQXQiLCJ0b1VwcGVyQ2FzZSIsInN1YnN0ciIsInRvTG93ZXJDYXNlIiwiQ29sbGVjdGlvbiIsIkJhY2tncm91bmRzIiwiYXR0YWNoU2NoZW1hIiwiU2VxdWVudCIsImFyY2hpdmVSb3V0ZU5hbWUiLCJkZWZhdWx0QmFja2dyb3VuZCIsImRlZmF1bHRDb25maXJtTXNnIiwiVG9hc3RUaW1lT3V0IiwiRU1BSUxfVEFSR0VUIiwicGFnZVNpemUiLCJnZXRTZXR0aW5ncyIsInNldHRpbmdzIiwic2FuaXRpemVIdG1sIiwiZGVmYXVsdCIsImNsZWFuSW5wdXQiLCJpbnB1dCIsImRlZmF1bHRWYWwiLCJhbGxvd2VkVGFncyIsImV4cG9ydERlZmF1bHQiLCJDb252ZXJ0UmV0cm8iLCJkb2MiLCJoYXBweSIsImZvckVhY2giLCJwdXNoIiwibWVoIiwic2FkIiwibmV4dCIsImZpbmQiLCJpIiwiV2ViQXBwIiwiY29ubmVjdEhhbmRsZXJzIiwidXNlIiwicmVxIiwicmVzIiwiaWQiLCJxdWVyeSIsIndyaXRlSGVhZCIsImVuZCIsInVzZXIiLCJ1c2VycyIsInVzZXJuYW1lIiwic2V0SGVhZGVyIiwibW9tZW50IiwiaW5wdXROYW1lIiwiZGF0ZVZhbCIsIm5ld05hbWUiLCJhcmNoaXZlUmV0cm8iLCJmb3JtYXQiLCJjbGVhclJldHJvQm9hcmQiLCJmcyIsImNvbXBvbmVudEltYWdlcyIsImltYWdlcyIsIm1ldGVvclJvb3QiLCJyZWFscGF0aFN5bmMiLCJwcm9jZXNzIiwiY3dkIiwicHVibGljUGF0aCIsImJhY2tncm91bmRQYXRoIiwiYmdzIiwicmVhZGRpclN5bmMiLCJmaWxlcyIsImVsbSIsIm1hdGNoIiwiZWFjaCIsImltZyIsImZpbGVOYW1lIiwiY3JlYXRlUmV0cm9BY3Rpb24iLCJpbnNlcnQiLCJjcmVhdGVSZXRyb0l0ZW0iLCJuZXdUaXRsZSIsInJldHJvRG9jIiwiaXNBcnJheSIsIiRwdXNoIiwiZ2V0Q2hhcnRVcmwiLCJyZXR2YWwiLCJlbnYiLCJVU0FHRV9VUkwiLCJNYXRjaCIsInNhdmVTZXR0aW5ncyIsInZhbGlkYXRlIiwiaXNVbmRlZmluZWQiLCJTZXJ2ZXJVdGlscyIsInNlbmRBY3Rpb25zQnlFbWFpbCIsImN1cnJlbnRSZXRybyIsInRhcmdldEVtYWlsIiwiZW1haWxUb1VzZSIsIm5ld0VtYWlsIiwiYWN0aW9ucyIsIiRndCIsIm5vdyIsImZldGNoIiwiZGF0YSIsInJldHJvTmFtZSIsImN1cnJlbnRZZWFyIiwiZ2V0RnVsbFllYXIiLCJyZXRyb0l0ZW1zIiwic29ydEJ5IiwiaXNDb21wbGV0ZSIsIml0ZW1TdHlsZSIsImZyb20iLCJGUk9NX0VNQUlMX0FERFJFU1MiLCJzZW5kSHRtbEVtYWlsIiwidXBkYXRlQWN0aW9uVGl0bGUiLCJ1cGRhdGVSZXRyb0l0ZW1UaXRsZSIsInB1Ymxpc2giLCJzZWxmIiwiYmFja2dyb3VuZCIsImJhY2tncm91bmROYW1lIiwic3BsaXQiLCJhZGRlZCIsInJlYWR5IiwiX2Vuc3VyZUluZGV4Iiwic3RvcCIsInNlYXJjaCIsInRlc3QiLCJsaW1pdCIsInNob3dBbGwiLCJzb3J0IiwiJGluIiwiU1NSIiwiRW1haWwiLCJjaGVjayIsImNvbXBpbGVUZW1wbGF0ZSIsIkFzc2V0cyIsImdldFRleHQiLCJUZW1wbGF0ZSIsImFjdGlvbkl0ZW1zIiwiaGVscGVycyIsInNlbmRFbWFpbCIsInRvIiwic3ViamVjdCIsInRleHQiLCJkZWZlciIsInNlbmQiLCJ0ZW1wbGF0ZU5hbWUiLCJib2R5IiwicmVuZGVyIiwiaHRtbCIsInN0YXJ0dXAiLCJleHBvcnQiLCJ3aXRoUmVuZGVyZWRUZW1wbGF0ZSIsIkJsYXplIiwiVHJhY2tlciIsIndpdGhEaXYiLCJjYWxsYmFjayIsImVsIiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50IiwiYXBwZW5kQ2hpbGQiLCJyZW1vdmVDaGlsZCIsInRlbXBsYXRlIiwidGhlVGVtcGxhdGUiLCJpc1N0cmluZyIsInJlbmRlcldpdGhEYXRhIiwiZmx1c2giLCJUZXN0RGF0YSIsImZha2VTZXR0aW5ncyIsInBhcmFtZXRlcnMiLCJwYXJtcyIsImZha2VCYWNrZ3JvdW5kc0FycmF5IiwiZmFrZVJldHJvQWN0aW9uIiwiUmV0cm9BY3Rpb24iLCJmYWtlUmV0cm9JdGVtIiwiY2hvaWNlIiwiZmFrZVJldHJvSXRlbXMiLCJjb3VudCIsImZha2VSZXRybyIsIlJldHJvIiwiZmFrZVJldHJvMiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUEsUUFBTUEsU0FBUyxHQUFHO0FBQ2RDLGlCQUFhLEVBQUU7QUFDWEMsWUFBTSxFQUFFLFFBREc7QUFFWEMsY0FBUSxFQUFFLFVBRkM7QUFHWEMsWUFBTSxFQUFFLFFBSEc7QUFJWEMsWUFBTSxFQUFFLENBQUMsUUFBRCxFQUFXLFVBQVgsRUFBdUIsUUFBdkI7QUFKRyxLQUREO0FBT2RDLHFCQUFpQixFQUFFO0FBQ2ZDLGFBQU8sRUFBRSxTQURNO0FBRWZDLGNBQVEsRUFBRSxVQUZLO0FBR2ZILFlBQU0sRUFBRSxDQUFDLFNBQUQsRUFBWSxVQUFaO0FBSE8sS0FQTDtBQVlkSSxrQkFBYyxFQUFFO0FBQ1pDLFdBQUssRUFBRSxPQURLO0FBRVpDLFNBQUcsRUFBRSxLQUZPO0FBR1pDLFNBQUcsRUFBRSxLQUhPO0FBSVpDLFlBQU0sRUFBRSxRQUpJO0FBS1pSLFlBQU0sRUFBRSxDQUFDLE9BQUQsRUFBVSxLQUFWLEVBQWlCLEtBQWpCLEVBQXdCLFFBQXhCO0FBTEk7QUFaRixHQUFsQjtBQXFCQVMsUUFBTSxDQUFDQyxPQUFQLEdBQWlCO0FBQUVmO0FBQUYsR0FBakI7Ozs7Ozs7Ozs7Ozs7QUNyQkEsUUFBTWdCLE1BQU0sR0FBRztBQUNYQyxPQUFHLEVBQUdDLE9BQUQsSUFBYTtBQUNkQyxhQUFPLENBQUNGLEdBQVIsQ0FBWUMsT0FBWjtBQUNIO0FBSFUsR0FBZjtBQU1BSixRQUFNLENBQUNDLE9BQVAsR0FBaUI7QUFBRUM7QUFBRixHQUFqQjs7Ozs7Ozs7Ozs7O0FDTkEsSUFBSUksTUFBSjtBQUFXTixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxNQUFKO0FBQVdULE1BQU0sQ0FBQ08sSUFBUCxDQUFZLFdBQVosRUFBd0I7QUFBQ0UsUUFBTSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsVUFBTSxHQUFDRCxDQUFQO0FBQVM7O0FBQXBCLENBQXhCLEVBQThDLENBQTlDO0FBQWlELElBQUlFLE9BQUo7QUFBWVYsTUFBTSxDQUFDTyxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDRyxTQUFPLENBQUNGLENBQUQsRUFBRztBQUFDRSxXQUFPLEdBQUNGLENBQVI7QUFBVTs7QUFBdEIsQ0FBeEIsRUFBZ0QsQ0FBaEQ7QUFBbUQsSUFBSXRCLFNBQUo7QUFBY2MsTUFBTSxDQUFDTyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDckIsV0FBUyxDQUFDc0IsQ0FBRCxFQUFHO0FBQUN0QixhQUFTLEdBQUNzQixDQUFWO0FBQVk7O0FBQTFCLENBQTFCLEVBQXNELENBQXREO0FBQXlELElBQUlOLE1BQUo7QUFBV0YsTUFBTSxDQUFDTyxJQUFQLENBQVksVUFBWixFQUF1QjtBQUFDTCxRQUFNLENBQUNNLENBQUQsRUFBRztBQUFDTixVQUFNLEdBQUNNLENBQVA7QUFBUzs7QUFBcEIsQ0FBdkIsRUFBNkMsQ0FBN0M7QUFNN1FGLE1BQU0sQ0FBQ0ssT0FBUCxDQUFlO0FBRVhDLG1CQUFpQixDQUFDQyxNQUFELEVBQVM7QUFDdEIsVUFBTUMsT0FBTyxHQUFHLEVBQWhCOztBQUVBLFFBQUksQ0FBQyxLQUFLQyxNQUFWLEVBQWtCO0FBQ2QsWUFBTSxJQUFJVCxNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0Msd0NBQWxDLENBQU47QUFDSCxLQUxxQixDQU90Qjs7O0FBRUEsVUFBTUMsS0FBSyxHQUFHUixNQUFNLENBQUNTLE9BQVAsQ0FBZTtBQUN6QkMsZUFBUyxFQUFFLEtBQUtKLE1BRFM7QUFFekJLLFNBQUcsRUFBRSxDQUNEO0FBQUVDLGNBQU0sRUFBRW5DLFNBQVMsQ0FBQ0MsYUFBVixDQUF3QkM7QUFBbEMsT0FEQyxFQUVEO0FBQUVpQyxjQUFNLEVBQUVuQyxTQUFTLENBQUNDLGFBQVYsQ0FBd0JHO0FBQWxDLE9BRkM7QUFGb0IsS0FBZixDQUFkLENBVHNCLENBaUJ0Qjs7QUFDQSxRQUFJLENBQUMyQixLQUFMLEVBQVk7QUFDUixZQUFNLElBQUlYLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixXQUFqQixFQUE4QixrQkFBOUIsQ0FBTjtBQUNIOztBQUdELFFBQUk7QUFDQVAsWUFBTSxDQUFDYSxNQUFQLENBQ0k7QUFDSUMsV0FBRyxFQUFFTixLQUFLLENBQUNNLEdBRGY7QUFFSSx3QkFBZ0JWO0FBRnBCLE9BREosRUFLSTtBQUNJVyxZQUFJLEVBQUU7QUFDRiw0QkFBa0J0QyxTQUFTLENBQUNNLGlCQUFWLENBQTRCRTtBQUQ1QztBQURWLE9BTEo7QUFXSCxLQVpELENBWUUsT0FBTytCLEdBQVAsRUFBWTtBQUNWdkIsWUFBTSxDQUFDQyxHQUFQLENBQVdzQixHQUFYO0FBQ0EsWUFBTSxJQUFJbkIsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLCtEQUFsQyxDQUFOO0FBQ0g7QUFDSjs7QUF6Q1UsQ0FBZixFOzs7Ozs7Ozs7OztBQ05BLElBQUlWLE1BQUo7QUFBV04sTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsTUFBSixFQUFXaUIsWUFBWDtBQUF3QjFCLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLFdBQVosRUFBd0I7QUFBQ0UsUUFBTSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsVUFBTSxHQUFDRCxDQUFQO0FBQVMsR0FBcEI7O0FBQXFCa0IsY0FBWSxDQUFDbEIsQ0FBRCxFQUFHO0FBQUNrQixnQkFBWSxHQUFDbEIsQ0FBYjtBQUFlOztBQUFwRCxDQUF4QixFQUE4RSxDQUE5RTtBQUFpRixJQUFJRSxPQUFKO0FBQVlWLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLFdBQVosRUFBd0I7QUFBQ0csU0FBTyxDQUFDRixDQUFELEVBQUc7QUFBQ0UsV0FBTyxHQUFDRixDQUFSO0FBQVU7O0FBQXRCLENBQXhCLEVBQWdELENBQWhEO0FBQW1ELElBQUl0QixTQUFKO0FBQWNjLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ3JCLFdBQVMsQ0FBQ3NCLENBQUQsRUFBRztBQUFDdEIsYUFBUyxHQUFDc0IsQ0FBVjtBQUFZOztBQUExQixDQUExQixFQUFzRCxDQUF0RDtBQUF5RCxJQUFJTixNQUFKO0FBQVdGLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLFVBQVosRUFBdUI7QUFBQ0wsUUFBTSxDQUFDTSxDQUFELEVBQUc7QUFBQ04sVUFBTSxHQUFDTSxDQUFQO0FBQVM7O0FBQXBCLENBQXZCLEVBQTZDLENBQTdDO0FBTTFURixNQUFNLENBQUNLLE9BQVAsQ0FBZTtBQUVYZ0IsY0FBWSxDQUFDQyxRQUFELEVBQVc7QUFDbkIsVUFBTWQsT0FBTyxHQUFHLEVBQWhCOztBQUVBLFFBQUksQ0FBQyxLQUFLQyxNQUFWLEVBQWtCO0FBQ2QsWUFBTSxJQUFJVCxNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0Msd0NBQWxDLENBQU47QUFDSDs7QUFFRCxVQUFNYSxNQUFNLEdBQUdILFlBQVksQ0FBQ1IsT0FBYixDQUFxQjtBQUFFSyxTQUFHLEVBQUVLLFFBQVA7QUFBaUJULGVBQVMsRUFBRSxLQUFLSjtBQUFqQyxLQUFyQixDQUFmOztBQUVBLFFBQUksQ0FBQ2MsTUFBTCxFQUFhO0FBQ1QsWUFBTSxJQUFJdkIsTUFBTSxDQUFDVSxLQUFYLENBQWlCLFdBQWpCLEVBQThCLG1CQUE5QixDQUFOO0FBQ0g7O0FBQ0QsUUFBSTtBQUNBVSxrQkFBWSxDQUFDSSxNQUFiLENBQW9CO0FBQUVQLFdBQUcsRUFBRUs7QUFBUCxPQUFwQjtBQUNILEtBRkQsQ0FFRSxPQUFPSCxHQUFQLEVBQVk7QUFDVnZCLFlBQU0sQ0FBQ0MsR0FBUCxDQUFXc0IsR0FBWDtBQUNBLFlBQU0sSUFBSW5CLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQyx5REFBbEMsQ0FBTjtBQUNIO0FBQ0o7O0FBcEJVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNOQSxJQUFJVixNQUFKO0FBQVdOLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEOztBQUFxRCxJQUFJdUIsQ0FBSjs7QUFBTS9CLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLG1CQUFaLEVBQWdDO0FBQUN3QixHQUFDLENBQUN2QixDQUFELEVBQUc7QUFBQ3VCLEtBQUMsR0FBQ3ZCLENBQUY7QUFBSTs7QUFBVixDQUFoQyxFQUE0QyxDQUE1QztBQUErQyxJQUFJQyxNQUFKO0FBQVdULE1BQU0sQ0FBQ08sSUFBUCxDQUFZLFdBQVosRUFBd0I7QUFBQ0UsUUFBTSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsVUFBTSxHQUFDRCxDQUFQO0FBQVM7O0FBQXBCLENBQXhCLEVBQThDLENBQTlDO0FBQWlELElBQUlFLE9BQUo7QUFBWVYsTUFBTSxDQUFDTyxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDRyxTQUFPLENBQUNGLENBQUQsRUFBRztBQUFDRSxXQUFPLEdBQUNGLENBQVI7QUFBVTs7QUFBdEIsQ0FBeEIsRUFBZ0QsQ0FBaEQ7QUFBbUQsSUFBSXRCLFNBQUo7QUFBY2MsTUFBTSxDQUFDTyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDckIsV0FBUyxDQUFDc0IsQ0FBRCxFQUFHO0FBQUN0QixhQUFTLEdBQUNzQixDQUFWO0FBQVk7O0FBQTFCLENBQTFCLEVBQXNELENBQXREO0FBQXlELElBQUlOLE1BQUo7QUFBV0YsTUFBTSxDQUFDTyxJQUFQLENBQVksVUFBWixFQUF1QjtBQUFDTCxRQUFNLENBQUNNLENBQUQsRUFBRztBQUFDTixVQUFNLEdBQUNNLENBQVA7QUFBUzs7QUFBcEIsQ0FBdkIsRUFBNkMsQ0FBN0M7QUFPbFVGLE1BQU0sQ0FBQ0ssT0FBUCxDQUFlO0FBRVhxQixpQkFBZSxDQUFDbkIsTUFBRCxFQUFTO0FBQ3BCLFVBQU1DLE9BQU8sR0FBRyxFQUFoQjs7QUFFQSxRQUFJLENBQUMsS0FBS0MsTUFBVixFQUFrQjtBQUNkLFlBQU0sSUFBSVQsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHdDQUFsQyxDQUFOO0FBQ0g7O0FBRUQsVUFBTUMsS0FBSyxHQUFHUixNQUFNLENBQUNTLE9BQVAsQ0FBZTtBQUN6QkMsZUFBUyxFQUFFLEtBQUtKLE1BRFM7QUFFekJLLFNBQUcsRUFBRSxDQUNEO0FBQUVDLGNBQU0sRUFBRW5DLFNBQVMsQ0FBQ0MsYUFBVixDQUF3QkM7QUFBbEMsT0FEQyxFQUVEO0FBQUVpQyxjQUFNLEVBQUVuQyxTQUFTLENBQUNDLGFBQVYsQ0FBd0JHO0FBQWxDLE9BRkM7QUFGb0IsS0FBZixDQUFkLENBUG9CLENBZXBCOztBQUNBLFFBQUksQ0FBQzJCLEtBQUwsRUFBWTtBQUNSLFlBQU0sSUFBSVgsTUFBTSxDQUFDVSxLQUFYLENBQWlCLFdBQWpCLEVBQThCLGtCQUE5QixDQUFOO0FBQ0g7O0FBRUQsVUFBTWlCLFNBQVMsR0FBR0YsQ0FBQyxDQUFDRyxNQUFGLENBQVNqQixLQUFLLENBQUNrQixLQUFmLEVBQXNCLFVBQVVDLElBQVYsRUFBZ0I7QUFDcEQsYUFBT0EsSUFBSSxDQUFDdkIsTUFBTCxLQUFnQkEsTUFBdkI7QUFDSCxLQUZpQixDQUFsQjs7QUFJQSxRQUFJb0IsU0FBUyxDQUFDSSxNQUFWLEtBQXFCLENBQXpCLEVBQTRCO0FBQ3hCLFlBQU0sSUFBSS9CLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixXQUFqQixFQUE4Qix1QkFBOUIsQ0FBTjtBQUNIOztBQUVELFFBQUk7QUFDQVAsWUFBTSxDQUFDYSxNQUFQLENBQ0k7QUFDSUMsV0FBRyxFQUFFTixLQUFLLENBQUNNO0FBRGYsT0FESixFQUlJO0FBQ0llLGFBQUssRUFBRTtBQUNISCxlQUFLLEVBQUU7QUFBRXRCLGtCQUFNLEVBQUVBO0FBQVY7QUFESjtBQURYLE9BSko7QUFVSCxLQVhELENBV0UsT0FBT1ksR0FBUCxFQUFZO0FBQ1Z2QixZQUFNLENBQUNDLEdBQVAsQ0FBV3NCLEdBQVg7QUFDQSxZQUFNLElBQUluQixNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0MseURBQWxDLENBQU47QUFDSDtBQUNKOztBQTdDVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDUEEsSUFBSVYsTUFBSjtBQUFXTixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJK0IsTUFBSjtBQUFXdkMsTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDZ0MsUUFBTSxDQUFDL0IsQ0FBRCxFQUFHO0FBQUMrQixVQUFNLEdBQUMvQixDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLE1BQUosRUFBV2lCLFlBQVg7QUFBd0IxQixNQUFNLENBQUNPLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDRSxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUyxHQUFwQjs7QUFBcUJrQixjQUFZLENBQUNsQixDQUFELEVBQUc7QUFBQ2tCLGdCQUFZLEdBQUNsQixDQUFiO0FBQWU7O0FBQXBELENBQTdCLEVBQW1GLENBQW5GO0FBQXNGLElBQUlFLE9BQUo7QUFBWVYsTUFBTSxDQUFDTyxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDRyxTQUFPLENBQUNGLENBQUQsRUFBRztBQUFDRSxXQUFPLEdBQUNGLENBQVI7QUFBVTs7QUFBdEIsQ0FBeEIsRUFBZ0QsQ0FBaEQ7QUFBbUQsSUFBSXRCLFNBQUo7QUFBY2MsTUFBTSxDQUFDTyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDckIsV0FBUyxDQUFDc0IsQ0FBRCxFQUFHO0FBQUN0QixhQUFTLEdBQUNzQixDQUFWO0FBQVk7O0FBQTFCLENBQTFCLEVBQXNELENBQXREO0FBQXlELElBQUlOLE1BQUo7QUFBV0YsTUFBTSxDQUFDTyxJQUFQLENBQVksVUFBWixFQUF1QjtBQUFDTCxRQUFNLENBQUNNLENBQUQsRUFBRztBQUFDTixVQUFNLEdBQUNNLENBQVA7QUFBUzs7QUFBcEIsQ0FBdkIsRUFBNkMsQ0FBN0M7QUFPL1hGLE1BQU0sQ0FBQ0ssT0FBUCxDQUFlO0FBRVg2QixjQUFZLENBQUNaLFFBQUQsRUFBVztBQUNuQixVQUFNZCxPQUFPLEdBQUcsRUFBaEI7O0FBRUEsUUFBSSxDQUFDLEtBQUtDLE1BQVYsRUFBa0I7QUFDZCxZQUFNLElBQUlULE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQyx3Q0FBbEMsQ0FBTjtBQUNIOztBQUVELFVBQU1hLE1BQU0sR0FBR0gsWUFBWSxDQUFDUixPQUFiLENBQXFCO0FBQUVLLFNBQUcsRUFBRUssUUFBUDtBQUFpQlQsZUFBUyxFQUFFLEtBQUtKO0FBQWpDLEtBQXJCLENBQWY7O0FBRUEsUUFBSSxDQUFDYyxNQUFMLEVBQWE7QUFDVCxZQUFNLElBQUl2QixNQUFNLENBQUNVLEtBQVgsQ0FBaUIsV0FBakIsRUFBOEIsd0JBQTlCLENBQU47QUFDSDs7QUFFRCxVQUFNeUIsUUFBUSxHQUFHWixNQUFNLENBQUNSLE1BQVAsS0FBa0JuQyxTQUFTLENBQUNNLGlCQUFWLENBQTRCQyxPQUE5QyxHQUF3RFAsU0FBUyxDQUFDTSxpQkFBVixDQUE0QkUsUUFBcEYsR0FBK0ZSLFNBQVMsQ0FBQ00saUJBQVYsQ0FBNEJDLE9BQTVJO0FBRUEsUUFBSWlELE9BQUo7O0FBRUEsUUFBSUQsUUFBUSxLQUFLdkQsU0FBUyxDQUFDTSxpQkFBVixDQUE0QkUsUUFBN0MsRUFBdUQ7QUFDbkRnRCxhQUFPLEdBQUcsSUFBSUMsSUFBSixFQUFWO0FBQ0gsS0FGRCxNQUVPO0FBQ0hELGFBQU8sR0FBRyxJQUFWO0FBQ0g7O0FBR0QsUUFBSTtBQUNBaEIsa0JBQVksQ0FBQ0osTUFBYixDQUNJO0FBQUVDLFdBQUcsRUFBRUs7QUFBUCxPQURKLEVBRUk7QUFDSUosWUFBSSxFQUNKO0FBQ0lILGdCQUFNLEVBQUVvQixRQURaO0FBRUlHLHFCQUFXLEVBQUVGO0FBRmpCO0FBRkosT0FGSjtBQVVILEtBWEQsQ0FXRSxPQUFPakIsR0FBUCxFQUFZO0FBQ1Z2QixZQUFNLENBQUNDLEdBQVAsQ0FBV3NCLEdBQVg7QUFDQSxZQUFNLElBQUluQixNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0MseURBQWxDLENBQU47QUFDSDtBQUNKOztBQXpDVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDUEEsSUFBSVYsTUFBSjtBQUFXTixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxNQUFKLEVBQVdpQixZQUFYO0FBQXdCMUIsTUFBTSxDQUFDTyxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDRSxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUyxHQUFwQjs7QUFBcUJrQixjQUFZLENBQUNsQixDQUFELEVBQUc7QUFBQ2tCLGdCQUFZLEdBQUNsQixDQUFiO0FBQWU7O0FBQXBELENBQXhCLEVBQThFLENBQTlFO0FBQWlGLElBQUlFLE9BQUo7QUFBWVYsTUFBTSxDQUFDTyxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDRyxTQUFPLENBQUNGLENBQUQsRUFBRztBQUFDRSxXQUFPLEdBQUNGLENBQVI7QUFBVTs7QUFBdEIsQ0FBeEIsRUFBZ0QsQ0FBaEQ7QUFBbUQsSUFBSXRCLFNBQUo7QUFBY2MsTUFBTSxDQUFDTyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDckIsV0FBUyxDQUFDc0IsQ0FBRCxFQUFHO0FBQUN0QixhQUFTLEdBQUNzQixDQUFWO0FBQVk7O0FBQTFCLENBQTFCLEVBQXNELENBQXREO0FBQXlELElBQUlOLE1BQUo7QUFBV0YsTUFBTSxDQUFDTyxJQUFQLENBQVksVUFBWixFQUF1QjtBQUFDTCxRQUFNLENBQUNNLENBQUQsRUFBRztBQUFDTixVQUFNLEdBQUNNLENBQVA7QUFBUzs7QUFBcEIsQ0FBdkIsRUFBNkMsQ0FBN0M7QUFNMVRGLE1BQU0sQ0FBQ0ssT0FBUCxDQUFlO0FBRVhrQyxtQkFBaUIsR0FBRztBQUNoQixVQUFNL0IsT0FBTyxHQUFHLEVBQWhCOztBQUVBLFFBQUksQ0FBQyxLQUFLQyxNQUFWLEVBQWtCO0FBQ2QsWUFBTSxJQUFJVCxNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0Msd0NBQWxDLENBQU47QUFDSCxLQUxlLENBT2hCOzs7QUFFQSxVQUFNQyxLQUFLLEdBQUdSLE1BQU0sQ0FBQ1MsT0FBUCxDQUFlO0FBQ3pCQyxlQUFTLEVBQUUsS0FBS0osTUFEUztBQUV6QkssU0FBRyxFQUNILENBQ0k7QUFBRUMsY0FBTSxFQUFFbkMsU0FBUyxDQUFDQyxhQUFWLENBQXdCQztBQUFsQyxPQURKLEVBRUk7QUFBRWlDLGNBQU0sRUFBRW5DLFNBQVMsQ0FBQ0MsYUFBVixDQUF3Qkc7QUFBbEMsT0FGSjtBQUh5QixLQUFmLENBQWQsQ0FUZ0IsQ0FrQmhCOztBQUNBLFFBQUksQ0FBQzJCLEtBQUwsRUFBWTtBQUNSLFlBQU0sSUFBSVgsTUFBTSxDQUFDVSxLQUFYLENBQWlCLFdBQWpCLEVBQThCLGtCQUE5QixDQUFOO0FBQ0g7O0FBRUQsUUFBSUMsS0FBSyxDQUFDSSxNQUFOLEtBQWlCbkMsU0FBUyxDQUFDQyxhQUFWLENBQXdCRSxRQUE3QyxFQUF1RDtBQUNuRCxZQUFNLElBQUlpQixNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0MsNkJBQWxDLENBQU47QUFDSDs7QUFFRCxVQUFNOEIsU0FBUyxHQUFHN0IsS0FBSyxDQUFDSSxNQUFOLEtBQWlCbkMsU0FBUyxDQUFDQyxhQUFWLENBQXdCRyxNQUF6QyxHQUFrREosU0FBUyxDQUFDQyxhQUFWLENBQXdCQyxNQUExRSxHQUFtRkYsU0FBUyxDQUFDQyxhQUFWLENBQXdCRyxNQUE3SDs7QUFFQSxRQUFJO0FBQ0FtQixZQUFNLENBQUNhLE1BQVAsQ0FDSTtBQUFFQyxXQUFHLEVBQUVOLEtBQUssQ0FBQ007QUFBYixPQURKLEVBRUk7QUFDSUMsWUFBSSxFQUNKO0FBQUVILGdCQUFNLEVBQUV5QjtBQUFWO0FBRkosT0FGSjtBQU9ILEtBUkQsQ0FRRSxPQUFPckIsR0FBUCxFQUFZO0FBQ1Z2QixZQUFNLENBQUNDLEdBQVAsQ0FBV3NCLEdBQVg7QUFDQSxZQUFNLElBQUluQixNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0Msd0RBQWxDLENBQU47QUFDSDtBQUNKOztBQTNDVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDTkEsSUFBSVYsTUFBSjtBQUFXTixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxNQUFKLEVBQVdpQixZQUFYO0FBQXdCMUIsTUFBTSxDQUFDTyxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDRSxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUyxHQUFwQjs7QUFBcUJrQixjQUFZLENBQUNsQixDQUFELEVBQUc7QUFBQ2tCLGdCQUFZLEdBQUNsQixDQUFiO0FBQWU7O0FBQXBELENBQXhCLEVBQThFLENBQTlFO0FBQWlGLElBQUlFLE9BQUo7QUFBWVYsTUFBTSxDQUFDTyxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDRyxTQUFPLENBQUNGLENBQUQsRUFBRztBQUFDRSxXQUFPLEdBQUNGLENBQVI7QUFBVTs7QUFBdEIsQ0FBeEIsRUFBZ0QsQ0FBaEQ7QUFBbUQsSUFBSXRCLFNBQUo7QUFBY2MsTUFBTSxDQUFDTyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDckIsV0FBUyxDQUFDc0IsQ0FBRCxFQUFHO0FBQUN0QixhQUFTLEdBQUNzQixDQUFWO0FBQVk7O0FBQTFCLENBQTFCLEVBQXNELENBQXREO0FBQXlELElBQUlOLE1BQUo7QUFBV0YsTUFBTSxDQUFDTyxJQUFQLENBQVksVUFBWixFQUF1QjtBQUFDTCxRQUFNLENBQUNNLENBQUQsRUFBRztBQUFDTixVQUFNLEdBQUNNLENBQVA7QUFBUzs7QUFBcEIsQ0FBdkIsRUFBNkMsQ0FBN0M7QUFNMVRGLE1BQU0sQ0FBQ0ssT0FBUCxDQUFlO0FBRVhvQyxxQkFBbUIsR0FBRztBQUNsQixVQUFNakMsT0FBTyxHQUFHLEVBQWhCOztBQUVBLFFBQUksQ0FBQyxLQUFLQyxNQUFWLEVBQWtCO0FBQ2QsWUFBTSxJQUFJVCxNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0Msd0NBQWxDLENBQU47QUFDSDs7QUFFRCxVQUFNQyxLQUFLLEdBQUdSLE1BQU0sQ0FBQ1MsT0FBUCxDQUFlO0FBQ3pCQyxlQUFTLEVBQUUsS0FBS0osTUFEUztBQUV6QkssU0FBRyxFQUNILENBQ0k7QUFBRUMsY0FBTSxFQUFFbkMsU0FBUyxDQUFDQyxhQUFWLENBQXdCQztBQUFsQyxPQURKLEVBRUk7QUFBRWlDLGNBQU0sRUFBRW5DLFNBQVMsQ0FBQ0MsYUFBVixDQUF3Qkc7QUFBbEMsT0FGSjtBQUh5QixLQUFmLENBQWQsQ0FQa0IsQ0FnQmxCOztBQUNBLFFBQUksQ0FBQzJCLEtBQUwsRUFBWTtBQUNSLFlBQU0sSUFBSVgsTUFBTSxDQUFDVSxLQUFYLENBQWlCLFdBQWpCLEVBQThCLGtCQUE5QixDQUFOO0FBQ0g7O0FBRUQsVUFBTWdDLElBQUksR0FBRyxDQUFDL0IsS0FBSyxDQUFDZ0MsYUFBcEI7O0FBRUEsUUFBSTtBQUNBeEMsWUFBTSxDQUFDYSxNQUFQLENBQ0k7QUFDSUMsV0FBRyxFQUFFTixLQUFLLENBQUNNO0FBRGYsT0FESixFQUlJO0FBQ0lDLFlBQUksRUFDSjtBQUNJeUIsdUJBQWEsRUFBRUQ7QUFEbkI7QUFGSixPQUpKO0FBV0gsS0FaRCxDQVlFLE9BQU92QixHQUFQLEVBQVk7QUFDVnZCLFlBQU0sQ0FBQ0MsR0FBUCxDQUFXc0IsR0FBWDtBQUNBLFlBQU0sSUFBSW5CLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQywrREFBbEMsQ0FBTjtBQUNIO0FBQ0o7O0FBekNVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNOQSxJQUFJVixNQUFKO0FBQVdOLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEOztBQUFxRCxJQUFJdUIsQ0FBSjs7QUFBTS9CLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLG1CQUFaLEVBQWdDO0FBQUN3QixHQUFDLENBQUN2QixDQUFELEVBQUc7QUFBQ3VCLEtBQUMsR0FBQ3ZCLENBQUY7QUFBSTs7QUFBVixDQUFoQyxFQUE0QyxDQUE1QztBQUErQyxJQUFJQyxNQUFKO0FBQVdULE1BQU0sQ0FBQ08sSUFBUCxDQUFZLFdBQVosRUFBd0I7QUFBQ0UsUUFBTSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsVUFBTSxHQUFDRCxDQUFQO0FBQVM7O0FBQXBCLENBQXhCLEVBQThDLENBQTlDO0FBQWlELElBQUlFLE9BQUo7QUFBWVYsTUFBTSxDQUFDTyxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDRyxTQUFPLENBQUNGLENBQUQsRUFBRztBQUFDRSxXQUFPLEdBQUNGLENBQVI7QUFBVTs7QUFBdEIsQ0FBeEIsRUFBZ0QsQ0FBaEQ7QUFBbUQsSUFBSXRCLFNBQUo7QUFBY2MsTUFBTSxDQUFDTyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDckIsV0FBUyxDQUFDc0IsQ0FBRCxFQUFHO0FBQUN0QixhQUFTLEdBQUNzQixDQUFWO0FBQVk7O0FBQTFCLENBQTFCLEVBQXNELENBQXREO0FBQXlELElBQUlOLE1BQUo7QUFBV0YsTUFBTSxDQUFDTyxJQUFQLENBQVksVUFBWixFQUF1QjtBQUFDTCxRQUFNLENBQUNNLENBQUQsRUFBRztBQUFDTixVQUFNLEdBQUNNLENBQVA7QUFBUzs7QUFBcEIsQ0FBdkIsRUFBNkMsQ0FBN0M7QUFPbFVGLE1BQU0sQ0FBQ0ssT0FBUCxDQUFlO0FBRVh1QyxZQUFVLENBQUNyQyxNQUFELEVBQVM7QUFDZixVQUFNQyxPQUFPLEdBQUcsRUFBaEI7O0FBRUEsUUFBSSxDQUFDLEtBQUtDLE1BQVYsRUFBa0I7QUFDZCxZQUFNLElBQUlULE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQyx3Q0FBbEMsQ0FBTjtBQUNILEtBTGMsQ0FPZjs7O0FBRUEsVUFBTUMsS0FBSyxHQUFHUixNQUFNLENBQUNTLE9BQVAsQ0FBZTtBQUN6QkMsZUFBUyxFQUFFLEtBQUtKLE1BRFM7QUFFekJNLFlBQU0sRUFBRW5DLFNBQVMsQ0FBQ0MsYUFBVixDQUF3QkM7QUFGUCxLQUFmLENBQWQsQ0FUZSxDQWNmOztBQUNBLFFBQUksQ0FBQzZCLEtBQUwsRUFBWTtBQUNSLFlBQU0sSUFBSVgsTUFBTSxDQUFDVSxLQUFYLENBQWlCLFdBQWpCLEVBQThCLGtCQUE5QixDQUFOO0FBQ0g7O0FBRUQsVUFBTWlCLFNBQVMsR0FBR0YsQ0FBQyxDQUFDRyxNQUFGLENBQVNqQixLQUFLLENBQUNrQixLQUFmLEVBQXNCLFVBQVVDLElBQVYsRUFBZ0I7QUFDcEQsYUFBT0EsSUFBSSxDQUFDdkIsTUFBTCxLQUFnQkEsTUFBdkI7QUFDSCxLQUZpQixDQUFsQjs7QUFJQSxRQUFJb0IsU0FBUyxDQUFDSSxNQUFWLEtBQXFCLENBQXpCLEVBQTRCO0FBQ3hCLFlBQU0sSUFBSS9CLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixXQUFqQixFQUE4Qix1QkFBOUIsQ0FBTjtBQUNIOztBQUVELFFBQUltQyxTQUFTLEdBQUdsQixTQUFTLENBQUMsQ0FBRCxDQUFULENBQWFtQixLQUFiLElBQXNCLENBQXRDO0FBRUFELGFBQVMsSUFBSSxDQUFiOztBQUVBLFFBQUk7QUFDQTFDLFlBQU0sQ0FBQ2EsTUFBUCxDQUNJO0FBQ0lDLFdBQUcsRUFBRU4sS0FBSyxDQUFDTSxHQURmO0FBRUksd0JBQWdCVjtBQUZwQixPQURKLEVBS0k7QUFDSVcsWUFBSSxFQUFFO0FBQ0YsMkJBQWlCMkI7QUFEZjtBQURWLE9BTEo7QUFXSCxLQVpELENBWUUsT0FBTzFCLEdBQVAsRUFBWTtBQUNWdkIsWUFBTSxDQUFDQyxHQUFQLENBQVdzQixHQUFYO0FBQ0EsWUFBTSxJQUFJbkIsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHdEQUFsQyxDQUFOO0FBQ0g7QUFDSjs7QUFqRFUsQ0FBZixFOzs7Ozs7Ozs7Ozs7QUNQQSxNQUFJcUMsWUFBSjtBQUFpQkMsU0FBTyxDQUFDL0MsSUFBUixDQUFhLDZCQUFiLEVBQTJDO0FBQUM4QyxnQkFBWSxDQUFDN0MsQ0FBRCxFQUFHO0FBQUM2QyxrQkFBWSxHQUFDN0MsQ0FBYjtBQUFlOztBQUFoQyxHQUEzQyxFQUE2RSxDQUE3RTtBQUFnRixNQUFJdEIsU0FBSjtBQUFjb0UsU0FBTyxDQUFDL0MsSUFBUixDQUFhLGFBQWIsRUFBMkI7QUFBQ3JCLGFBQVMsQ0FBQ3NCLENBQUQsRUFBRztBQUFDdEIsZUFBUyxHQUFDc0IsQ0FBVjtBQUFZOztBQUExQixHQUEzQixFQUF1RCxDQUF2RDtBQUkvRyxRQUFNRSxPQUFPLEdBQUcsRUFBaEI7QUFFQUEsU0FBTyxDQUFDNkMsU0FBUixHQUFvQixJQUFJRixZQUFKLENBQWlCO0FBRWpDeEMsVUFBTSxFQUFFO0FBQ0oyQyxVQUFJLEVBQUVDLE1BREY7QUFFSkMsV0FBSyxFQUFFTCxZQUFZLENBQUNNLEtBQWIsQ0FBbUJDLEVBRnRCO0FBR0pDLGNBQVEsRUFBRTtBQUhOLEtBRnlCO0FBT2pDQyxTQUFLLEVBQUU7QUFDSE4sVUFBSSxFQUFFQyxNQURIO0FBRUhNLFNBQUcsRUFBRTtBQUZGLEtBUDBCO0FBV2pDMUMsVUFBTSxFQUFFO0FBQ0ptQyxVQUFJLEVBQUVDLE1BREY7QUFFSk8sbUJBQWEsRUFBRTlFLFNBQVMsQ0FBQ00saUJBQVYsQ0FBNEJEO0FBRnZDLEtBWHlCO0FBZWpDMEUsWUFBUSxFQUFFO0FBQ05ULFVBQUksRUFBRUMsTUFEQTtBQUVOTyxtQkFBYSxFQUFFOUUsU0FBUyxDQUFDUyxjQUFWLENBQXlCSjtBQUZsQyxLQWZ1QjtBQW1CakM2RCxTQUFLLEVBQUU7QUFDSEksVUFBSSxFQUFFVSxNQURIO0FBRUhMLGNBQVEsRUFBRTtBQUZQLEtBbkIwQjtBQXVCakNNLGFBQVMsRUFBRTtBQUNQWCxVQUFJLEVBQUViO0FBREM7QUF2QnNCLEdBQWpCLENBQXBCO0FBNkJBakMsU0FBTyxDQUFDRCxNQUFSLEdBQWlCLElBQUk0QyxZQUFKLENBQWlCO0FBRTlCOUIsT0FBRyxFQUFFO0FBQ0RpQyxVQUFJLEVBQUVDLE1BREw7QUFFREMsV0FBSyxFQUFFTCxZQUFZLENBQUNNLEtBQWIsQ0FBbUJDLEVBRnpCO0FBR0RDLGNBQVEsRUFBRTtBQUhULEtBRnlCO0FBTzlCTSxhQUFTLEVBQUU7QUFDUFgsVUFBSSxFQUFFYixJQURDO0FBRVB5QixlQUFTLEVBQUUsWUFBWTtBQUNuQixZQUFJLEtBQUtDLFFBQVQsRUFBbUI7QUFDZixpQkFBTyxJQUFJMUIsSUFBSixFQUFQO0FBQ0g7O0FBQ0QsYUFBSzJCLEtBQUw7QUFDSDtBQVBNLEtBUG1CO0FBZ0I5Qm5ELGFBQVMsRUFBRTtBQUNQcUMsVUFBSSxFQUFFQyxNQURDO0FBRVBDLFdBQUssRUFBRUwsWUFBWSxDQUFDTSxLQUFiLENBQW1CQyxFQUZuQjtBQUdQUSxlQUFTLEVBQUUsWUFBWTtBQUNuQixZQUFJLEtBQUtDLFFBQVQsRUFBbUI7QUFDZixpQkFBTyxLQUFLdEQsTUFBWjtBQUNIOztBQUNELGFBQUt1RCxLQUFMO0FBQ0g7QUFSTSxLQWhCbUI7QUEwQjlCakQsVUFBTSxFQUFFO0FBQ0ptQyxVQUFJLEVBQUVDLE1BREY7QUFFSk8sbUJBQWEsRUFBRTlFLFNBQVMsQ0FBQ0MsYUFBVixDQUF3Qkk7QUFGbkMsS0ExQnNCO0FBOEI5QjRDLFNBQUssRUFBRTtBQUNIcUIsVUFBSSxFQUFFLENBQUM5QyxPQUFPLENBQUM2QyxTQUFUO0FBREgsS0E5QnVCO0FBaUM5Qk4saUJBQWEsRUFBRTtBQUNYTyxVQUFJLEVBQUVlLE9BREs7QUFFWFYsY0FBUSxFQUFFLElBRkM7QUFHWFcsa0JBQVksRUFBRTtBQUhILEtBakNlO0FBc0M5QkMsY0FBVSxFQUFFO0FBQ1JqQixVQUFJLEVBQUViLElBREU7QUFFUmtCLGNBQVEsRUFBRTtBQUZGLEtBdENrQjtBQTBDOUJhLG9CQUFnQixFQUFFO0FBQ2RsQixVQUFJLEVBQUVDLE1BRFE7QUFFZEksY0FBUSxFQUFFO0FBRkksS0ExQ1k7QUE4QzlCYyxrQkFBYyxFQUFFO0FBQ1puQixVQUFJLEVBQUVDLE1BRE07QUFFWkksY0FBUSxFQUFFO0FBRkUsS0E5Q2M7QUFrRDlCZSxrQkFBYyxFQUFFO0FBQ1pwQixVQUFJLEVBQUVDLE1BRE07QUFFWkksY0FBUSxFQUFFO0FBRkUsS0FsRGM7QUFzRDlCZ0IsZUFBVyxFQUFFO0FBQ1RyQixVQUFJLEVBQUVDLE1BREc7QUFFVEksY0FBUSxFQUFFO0FBRkQ7QUF0RGlCLEdBQWpCLENBQWpCO0FBNERBbkQsU0FBTyxDQUFDb0UsT0FBUixHQUFrQixJQUFJekIsWUFBSixDQUFpQjtBQUMvQjlCLE9BQUcsRUFBRTtBQUNEaUMsVUFBSSxFQUFFQyxNQURMO0FBRURDLFdBQUssRUFBRUwsWUFBWSxDQUFDTSxLQUFiLENBQW1CQyxFQUZ6QjtBQUdEQyxjQUFRLEVBQUU7QUFIVCxLQUQwQjtBQU0vQk0sYUFBUyxFQUFFO0FBQ1BYLFVBQUksRUFBRWIsSUFEQztBQUVQeUIsZUFBUyxFQUFFLFlBQVk7QUFDbkIsWUFBSSxLQUFLQyxRQUFULEVBQW1CO0FBQ2YsaUJBQU8sSUFBSTFCLElBQUosRUFBUDtBQUNIOztBQUVELGFBQUsyQixLQUFMO0FBQ0g7QUFSTSxLQU5vQjtBQWdCL0JuRCxhQUFTLEVBQUU7QUFDUHFDLFVBQUksRUFBRUMsTUFEQztBQUVQQyxXQUFLLEVBQUVMLFlBQVksQ0FBQ00sS0FBYixDQUFtQkMsRUFGbkI7QUFHUFEsZUFBUyxFQUFFLFlBQVk7QUFDbkIsWUFBSSxLQUFLQyxRQUFULEVBQW1CO0FBQ2YsaUJBQU8sS0FBS3RELE1BQVo7QUFDSDs7QUFDRCxhQUFLdUQsS0FBTDtBQUNIO0FBUk0sS0FoQm9CO0FBMEIvQlIsU0FBSyxFQUFFO0FBQ0hOLFVBQUksRUFBRUMsTUFESDtBQUVITSxTQUFHLEVBQUU7QUFGRixLQTFCd0I7QUE4Qi9CMUMsVUFBTSxFQUFFO0FBQ0ptQyxVQUFJLEVBQUVDLE1BREY7QUFFSk8sbUJBQWEsRUFBRTlFLFNBQVMsQ0FBQ00saUJBQVYsQ0FBNEJEO0FBRnZDLEtBOUJ1QjtBQWtDL0JxRCxlQUFXLEVBQUU7QUFDVFksVUFBSSxFQUFFYixJQURHO0FBRVRrQixjQUFRLEVBQUU7QUFGRDtBQWxDa0IsR0FBakIsQ0FBbEI7QUF3Q0FuRCxTQUFPLENBQUNxRSxPQUFSLEdBQWtCLElBQUkxQixZQUFKLENBQWlCO0FBQy9CMkIsUUFBSSxFQUFFO0FBQ0Z4QixVQUFJLEVBQUVDLE1BREo7QUFFRk0sU0FBRyxFQUFFLEVBRkg7QUFHRmtCLFNBQUcsRUFBRTtBQUhILEtBRHlCO0FBTS9CQyxlQUFXLEVBQUU7QUFDVDFCLFVBQUksRUFBRUMsTUFERztBQUVUSSxjQUFRLEVBQUUsSUFGRDtBQUdURSxTQUFHLEVBQUU7QUFISSxLQU5rQjtBQVcvQm9CLFlBQVEsRUFBRTtBQUNOM0IsVUFBSSxFQUFFQyxNQURBO0FBRU5DLFdBQUssRUFBRSxnREFGRDtBQUdOdUIsU0FBRyxFQUFFO0FBSEMsS0FYcUI7QUFnQi9CRyxtQkFBZSxFQUFFO0FBQ2I1QixVQUFJLEVBQUVDLE1BRE87QUFFYndCLFNBQUcsRUFBRSxDQUZROztBQUdiSSxZQUFNLEdBQUc7QUFDTCxZQUFJLEtBQUtDLEtBQUwsS0FBZSxLQUFLQyxLQUFMLENBQVcsVUFBWCxFQUF1QkQsS0FBMUMsRUFBaUQ7QUFDN0MsaUJBQU8sa0JBQVA7QUFDSDtBQUNKOztBQVBZO0FBaEJjLEdBQWpCLENBQWxCO0FBMkJBNUUsU0FBTyxDQUFDOEUsUUFBUixHQUFtQixJQUFJbkMsWUFBSixDQUFpQjtBQUNoQzlCLE9BQUcsRUFBRTtBQUNEaUMsVUFBSSxFQUFFQyxNQURMO0FBRURDLFdBQUssRUFBRUwsWUFBWSxDQUFDTSxLQUFiLENBQW1CQyxFQUZ6QjtBQUdEQyxjQUFRLEVBQUU7QUFIVCxLQUQyQjtBQU1oQzFDLGFBQVMsRUFBRTtBQUNQcUMsVUFBSSxFQUFFQyxNQURDO0FBRVBDLFdBQUssRUFBRUwsWUFBWSxDQUFDTSxLQUFiLENBQW1CQyxFQUZuQjtBQUdQUSxlQUFTLEVBQUUsWUFBWTtBQUNuQixZQUFJLEtBQUtDLFFBQVQsRUFBbUI7QUFDZixpQkFBTyxLQUFLdEQsTUFBWjtBQUNIOztBQUNELGFBQUt1RCxLQUFMO0FBQ0gsT0FSTTtBQVNQVCxjQUFRLEVBQUU7QUFUSCxLQU5xQjtBQWlCaEM0QixtQkFBZSxFQUFFO0FBQ2JqQyxVQUFJLEVBQUVDLE1BRE87QUFFYmUsa0JBQVksRUFBRSw0QkFGRDtBQUdiWCxjQUFRLEVBQUU7QUFIRyxLQWpCZTtBQXNCaENhLG9CQUFnQixFQUFFO0FBQ2RsQixVQUFJLEVBQUVDLE1BRFE7QUFFZGUsa0JBQVksRUFBRSxJQUZBO0FBR2RYLGNBQVEsRUFBRTtBQUhJLEtBdEJjO0FBMkJoQ2Msa0JBQWMsRUFBRTtBQUNabkIsVUFBSSxFQUFFQyxNQURNO0FBRVplLGtCQUFZLEVBQUUsSUFGRjtBQUdaWCxjQUFRLEVBQUU7QUFIRSxLQTNCZ0I7QUFnQ2hDZSxrQkFBYyxFQUFFO0FBQ1pwQixVQUFJLEVBQUVDLE1BRE07QUFFWmUsa0JBQVksRUFBRSxJQUZGO0FBR1pYLGNBQVEsRUFBRTtBQUhFO0FBaENnQixHQUFqQixDQUFuQjtBQXdDQTdELFFBQU0sQ0FBQ0MsT0FBUCxHQUFpQjtBQUFFUztBQUFGLEdBQWpCOzs7Ozs7Ozs7Ozs7O0FDMU1BLE1BQUlnRixLQUFKO0FBQVVwQyxTQUFPLENBQUMvQyxJQUFSLENBQWEsY0FBYixFQUE0QjtBQUFDbUYsU0FBSyxDQUFDbEYsQ0FBRCxFQUFHO0FBQUNrRixXQUFLLEdBQUNsRixDQUFOO0FBQVE7O0FBQWxCLEdBQTVCLEVBQWdELENBQWhEO0FBQW1ELE1BQUlFLE9BQUo7QUFBWTRDLFNBQU8sQ0FBQy9DLElBQVIsQ0FBYSxXQUFiLEVBQXlCO0FBQUNHLFdBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGFBQU8sR0FBQ0YsQ0FBUjtBQUFVOztBQUF0QixHQUF6QixFQUFpRCxDQUFqRDs7QUFHekUsTUFBSSxDQUFDaUQsTUFBTSxDQUFDa0MsU0FBUCxDQUFpQkMsWUFBdEIsRUFBb0M7QUFDaENuQyxVQUFNLENBQUNrQyxTQUFQLENBQWlCQyxZQUFqQixHQUFnQyxZQUFZO0FBQ3hDLGFBQU8sS0FBS0MsT0FBTCxDQUFhLFFBQWIsRUFBdUIsVUFBVUMsR0FBVixFQUFlO0FBQUUsZUFBT0EsR0FBRyxDQUFDQyxNQUFKLENBQVcsQ0FBWCxFQUFjQyxXQUFkLEtBQThCRixHQUFHLENBQUNHLE1BQUosQ0FBVyxDQUFYLEVBQWNDLFdBQWQsRUFBckM7QUFBbUUsT0FBM0csQ0FBUDtBQUNILEtBRkQ7QUFHSDs7QUFFRCxRQUFNekYsTUFBTSxHQUFHLElBQUlpRixLQUFLLENBQUNTLFVBQVYsQ0FBcUIsUUFBckIsQ0FBZjtBQUNBLFFBQU16RSxZQUFZLEdBQUcsSUFBSWdFLEtBQUssQ0FBQ1MsVUFBVixDQUFxQixlQUFyQixDQUFyQjtBQUNBLFFBQU1DLFdBQVcsR0FBRyxJQUFJVixLQUFLLENBQUNTLFVBQVYsQ0FBcUIsYUFBckIsQ0FBcEI7QUFDQSxRQUFNWCxRQUFRLEdBQUcsSUFBSUUsS0FBSyxDQUFDUyxVQUFWLENBQXFCLFVBQXJCLENBQWpCO0FBRUExRixRQUFNLENBQUM0RixZQUFQLENBQW9CM0YsT0FBTyxDQUFDRCxNQUE1QjtBQUNBaUIsY0FBWSxDQUFDMkUsWUFBYixDQUEwQjNGLE9BQU8sQ0FBQ29FLE9BQWxDO0FBQ0FVLFVBQVEsQ0FBQ2EsWUFBVCxDQUFzQjNGLE9BQU8sQ0FBQzhFLFFBQTlCO0FBRUEsUUFBTWMsT0FBTyxHQUFHO0FBQ1pDLG9CQUFnQixFQUFFLFVBRE47QUFFWkMscUJBQWlCLEVBQUUsNEJBRlA7QUFHWkMscUJBQWlCLEVBQUUsZUFIUDtBQUlaQyxnQkFBWSxFQUFFLElBSkY7QUFLWkMsZ0JBQVksRUFBRSxhQUxGOztBQU1aQyxZQUFRLEdBQUc7QUFDUCxhQUFPLEVBQVA7QUFDSCxLQVJXOztBQVNaQyxlQUFXLEdBQUc7QUFDVixVQUFJQyxRQUFRLEdBQUd0QixRQUFRLENBQUN0RSxPQUFULEVBQWY7O0FBRUEsVUFBSSxDQUFDNEYsUUFBTCxFQUFlO0FBQ1hBLGdCQUFRLEdBQUcsRUFBWDtBQUNBQSxnQkFBUSxDQUFDckIsZUFBVCxHQUEyQmEsT0FBTyxDQUFDRSxpQkFBbkM7QUFDQU0sZ0JBQVEsQ0FBQ3BDLGdCQUFULEdBQTRCLElBQTVCO0FBQ0FvQyxnQkFBUSxDQUFDbkMsY0FBVCxHQUEwQixJQUExQjtBQUNBbUMsZ0JBQVEsQ0FBQ2xDLGNBQVQsR0FBMEIsSUFBMUI7QUFDSDs7QUFFRCxhQUFPa0MsUUFBUDtBQUNIOztBQXJCVyxHQUFoQjtBQXdCQTlHLFFBQU0sQ0FBQ0MsT0FBUCxHQUFpQjtBQUNicUcsV0FEYTtBQUNKN0YsVUFESTtBQUNJaUIsZ0JBREo7QUFDa0IwRSxlQURsQjtBQUMrQlo7QUFEL0IsR0FBakI7Ozs7Ozs7Ozs7OztBQzFDQSxJQUFJdUIsWUFBSjtBQUFpQi9HLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ3lHLFNBQU8sQ0FBQ3hHLENBQUQsRUFBRztBQUFDdUcsZ0JBQVksR0FBQ3ZHLENBQWI7QUFBZTs7QUFBM0IsQ0FBNUIsRUFBeUQsQ0FBekQ7O0FBRWpCLE1BQU15RyxVQUFVLEdBQUcsVUFBQ0MsS0FBRCxFQUE0QjtBQUFBLE1BQXBCQyxVQUFvQix1RUFBUCxFQUFPO0FBQzNDLFFBQU03QixLQUFLLEdBQUd5QixZQUFZLENBQUNHLEtBQUQsRUFBUTtBQUM5QkUsZUFBVyxFQUFFO0FBRGlCLEdBQVIsQ0FBMUI7QUFHQSxTQUFPOUIsS0FBSyxJQUFJNkIsVUFBaEI7QUFDSCxDQUxEOztBQUZBbkgsTUFBTSxDQUFDcUgsYUFBUCxDQVNlSixVQVRmLEU7Ozs7Ozs7Ozs7OztBQ0FBLE1BQUlsRixDQUFKOztBQUFNdUIsU0FBTyxDQUFDL0MsSUFBUixDQUFhLG1CQUFiLEVBQWlDO0FBQUN3QixLQUFDLENBQUN2QixDQUFELEVBQUc7QUFBQ3VCLE9BQUMsR0FBQ3ZCLENBQUY7QUFBSTs7QUFBVixHQUFqQyxFQUE2QyxDQUE3Qzs7QUFFTixRQUFNOEcsWUFBWSxHQUFHLENBQUNSLFFBQUQsRUFBVzdGLEtBQVgsS0FBcUI7QUFDdEMsVUFBTWtCLEtBQUssR0FBRyxFQUFkO0FBRUEsUUFBSW9GLEdBQUcsR0FBRyxFQUFWO0FBRUFBLE9BQUcsZ0JBQVFULFFBQVEsQ0FBQ3BDLGdCQUFqQixrQkFBdUNvQyxRQUFRLENBQUNuQyxjQUFoRCxrQkFBb0VtQyxRQUFRLENBQUNsQyxjQUE3RSxTQUFIOztBQUVBLFVBQU00QyxLQUFLLEdBQUd6RixDQUFDLENBQUNHLE1BQUYsQ0FBU2pCLEtBQUssQ0FBQ2tCLEtBQWYsRUFBc0JDLElBQUksSUFBSUEsSUFBSSxDQUFDNkIsUUFBTCxDQUFjaUMsV0FBZCxPQUFnQyxPQUE5RCxDQUFkOztBQUNBc0IsU0FBSyxDQUFDQyxPQUFOLENBQWVyRixJQUFELElBQVU7QUFDcEJELFdBQUssQ0FBQ3VGLElBQU4sQ0FBVztBQUNQRixhQUFLLEVBQUVwRixJQUFJLENBQUMwQixLQURMO0FBRVA2RCxXQUFHLEVBQUUsRUFGRTtBQUdQQyxXQUFHLEVBQUU7QUFIRSxPQUFYO0FBS0gsS0FORDs7QUFRQSxVQUFNRCxHQUFHLEdBQUc1RixDQUFDLENBQUNHLE1BQUYsQ0FBU2pCLEtBQUssQ0FBQ2tCLEtBQWYsRUFBc0JDLElBQUksSUFBSUEsSUFBSSxDQUFDNkIsUUFBTCxDQUFjaUMsV0FBZCxPQUFnQyxLQUE5RCxDQUFaOztBQUNBeUIsT0FBRyxDQUFDRixPQUFKLENBQWFyRixJQUFELElBQVU7QUFDbEIsWUFBTXlGLElBQUksR0FBRzlGLENBQUMsQ0FBQytGLElBQUYsQ0FBTzNGLEtBQVAsRUFBYzRGLENBQUMsSUFBSUEsQ0FBQyxDQUFDSixHQUFGLEtBQVUsRUFBN0IsQ0FBYjs7QUFDQSxVQUFJRSxJQUFKLEVBQVU7QUFDTkEsWUFBSSxDQUFDRixHQUFMLEdBQVd2RixJQUFJLENBQUMwQixLQUFoQjtBQUNILE9BRkQsTUFFTztBQUNIM0IsYUFBSyxDQUFDdUYsSUFBTixDQUFXO0FBQ1BGLGVBQUssRUFBRSxFQURBO0FBRVBHLGFBQUcsRUFBRXZGLElBQUksQ0FBQzBCLEtBRkg7QUFHUDhELGFBQUcsRUFBRTtBQUhFLFNBQVg7QUFLSDtBQUNKLEtBWEQ7O0FBYUEsVUFBTUEsR0FBRyxHQUFHN0YsQ0FBQyxDQUFDRyxNQUFGLENBQVNqQixLQUFLLENBQUNrQixLQUFmLEVBQXNCQyxJQUFJLElBQUlBLElBQUksQ0FBQzZCLFFBQUwsQ0FBY2lDLFdBQWQsT0FBZ0MsS0FBOUQsQ0FBWjs7QUFDQTBCLE9BQUcsQ0FBQ0gsT0FBSixDQUFhckYsSUFBRCxJQUFVO0FBQ2xCLFlBQU15RixJQUFJLEdBQUc5RixDQUFDLENBQUMrRixJQUFGLENBQU8zRixLQUFQLEVBQWM0RixDQUFDLElBQUlBLENBQUMsQ0FBQ0gsR0FBRixLQUFVLEVBQTdCLENBQWI7O0FBQ0EsVUFBSUMsSUFBSixFQUFVO0FBQ05BLFlBQUksQ0FBQ0QsR0FBTCxHQUFXeEYsSUFBSSxDQUFDMEIsS0FBaEI7QUFDSCxPQUZELE1BRU87QUFDSDNCLGFBQUssQ0FBQ3VGLElBQU4sQ0FBVztBQUNQRixlQUFLLEVBQUUsRUFEQTtBQUVQRyxhQUFHLEVBQUUsRUFGRTtBQUdQQyxhQUFHLEVBQUV4RixJQUFJLENBQUMwQjtBQUhILFNBQVg7QUFLSDtBQUNKLEtBWEQ7QUFhQTNCLFNBQUssQ0FBQ3NGLE9BQU4sQ0FBZXJGLElBQUQsSUFBVTtBQUNwQm1GLFNBQUcsZ0JBQVFuRixJQUFJLENBQUNvRixLQUFiLGtCQUF3QnBGLElBQUksQ0FBQ3VGLEdBQTdCLGtCQUFzQ3ZGLElBQUksQ0FBQ3dGLEdBQTNDLFNBQUg7QUFDSCxLQUZEO0FBSUEsV0FBT0wsR0FBUDtBQUNILEdBakREOztBQW1EQXZILFFBQU0sQ0FBQ0MsT0FBUCxHQUFpQjtBQUFFcUg7QUFBRixHQUFqQjs7Ozs7Ozs7Ozs7O0FDckRBLElBQUloSCxNQUFKO0FBQVdOLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl3SCxNQUFKO0FBQVdoSSxNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUN5SCxRQUFNLENBQUN4SCxDQUFELEVBQUc7QUFBQ3dILFVBQU0sR0FBQ3hILENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSWdGLFFBQUosRUFBYS9FLE1BQWI7QUFBb0JULE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUNpRixVQUFRLENBQUNoRixDQUFELEVBQUc7QUFBQ2dGLFlBQVEsR0FBQ2hGLENBQVQ7QUFBVyxHQUF4Qjs7QUFBeUJDLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUE1QyxDQUE3QixFQUEyRSxDQUEzRTtBQUE4RSxJQUFJOEcsWUFBSjtBQUFpQnRILE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUMrRyxjQUFZLENBQUM5RyxDQUFELEVBQUc7QUFBQzhHLGdCQUFZLEdBQUM5RyxDQUFiO0FBQWU7O0FBQWhDLENBQTdCLEVBQStELENBQS9EO0FBTW5Qd0gsTUFBTSxDQUFDQyxlQUFQLENBQXVCQyxHQUF2QixDQUEyQixlQUEzQixFQUE0QyxDQUFDQyxHQUFELEVBQU1DLEdBQU4sRUFBV1AsSUFBWCxLQUFvQjtBQUM1RCxRQUFNO0FBQUVRO0FBQUYsTUFBU0YsR0FBRyxDQUFDRyxLQUFuQjtBQUVBLFFBQU1ySCxLQUFLLEdBQUdSLE1BQU0sQ0FBQ1MsT0FBUCxDQUFlbUgsRUFBZixDQUFkOztBQUNBLE1BQUksQ0FBQ3BILEtBQUwsRUFBWTtBQUNSbUgsT0FBRyxDQUFDRyxTQUFKLENBQWMsR0FBZDtBQUNBSCxPQUFHLENBQUNJLEdBQUosQ0FBUSxrQkFBUjtBQUNIOztBQUVELE1BQUkxQixRQUFRLEdBQUd0QixRQUFRLENBQUN0RSxPQUFULENBQWlCO0FBQUVDLGFBQVMsRUFBRUYsS0FBSyxDQUFDRTtBQUFuQixHQUFqQixDQUFmOztBQUNBLE1BQUksQ0FBQzJGLFFBQUwsRUFBZTtBQUNYQSxZQUFRLEdBQUc7QUFDUHBDLHNCQUFnQixFQUFFLElBRFg7QUFFUEMsb0JBQWMsRUFBRSxJQUZUO0FBR1BDLG9CQUFjLEVBQUU7QUFIVCxLQUFYO0FBS0g7O0FBRUQsUUFBTTZELElBQUksR0FBR25JLE1BQU0sQ0FBQ29JLEtBQVAsQ0FBYXhILE9BQWIsQ0FBcUI7QUFBRUssT0FBRyxFQUFFTixLQUFLLENBQUNFO0FBQWIsR0FBckIsQ0FBYjs7QUFDQSxNQUFJLENBQUNzSCxJQUFMLEVBQVc7QUFDUEEsUUFBSSxDQUFDRSxRQUFMLEdBQWdCLFNBQWhCO0FBQ0g7O0FBRUQsUUFBTXBCLEdBQUcsR0FBR0QsWUFBWSxDQUFDUixRQUFELEVBQVc3RixLQUFYLENBQXhCO0FBRUFtSCxLQUFHLENBQUNRLFNBQUosQ0FBYyxjQUFkLEVBQThCLFVBQTlCO0FBQ0FSLEtBQUcsQ0FBQ1EsU0FBSixDQUFjLHFCQUFkLGlDQUE2REgsSUFBSSxDQUFDRSxRQUFsRTtBQUVBUCxLQUFHLENBQUNJLEdBQUosQ0FBUWpCLEdBQVI7QUFDSCxDQTdCRCxFOzs7Ozs7Ozs7OztBQ05BLElBQUlqSCxNQUFKO0FBQVdOLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlxSSxNQUFKO0FBQVc3SSxNQUFNLENBQUNPLElBQVAsQ0FBWSxRQUFaLEVBQXFCO0FBQUN5RyxTQUFPLENBQUN4RyxDQUFELEVBQUc7QUFBQ3FJLFVBQU0sR0FBQ3JJLENBQVA7QUFBUzs7QUFBckIsQ0FBckIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSWdGLFFBQUosRUFBYS9FLE1BQWI7QUFBb0JULE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUNpRixVQUFRLENBQUNoRixDQUFELEVBQUc7QUFBQ2dGLFlBQVEsR0FBQ2hGLENBQVQ7QUFBVyxHQUF4Qjs7QUFBeUJDLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUE1QyxDQUE3QixFQUEyRSxDQUEzRTtBQUE4RSxJQUFJRSxPQUFKO0FBQVlWLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUNHLFNBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLFdBQU8sR0FBQ0YsQ0FBUjtBQUFVOztBQUF0QixDQUE3QixFQUFxRCxDQUFyRDtBQUF3RCxJQUFJdEIsU0FBSjtBQUFjYyxNQUFNLENBQUNPLElBQVAsQ0FBWSxrQkFBWixFQUErQjtBQUFDckIsV0FBUyxDQUFDc0IsQ0FBRCxFQUFHO0FBQUN0QixhQUFTLEdBQUNzQixDQUFWO0FBQVk7O0FBQTFCLENBQS9CLEVBQTJELENBQTNEO0FBQThELElBQUlOLE1BQUo7QUFBV0YsTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDTCxRQUFNLENBQUNNLENBQUQsRUFBRztBQUFDTixVQUFNLEdBQUNNLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXlHLFVBQUo7QUFBZWpILE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3lHLFNBQU8sQ0FBQ3hHLENBQUQsRUFBRztBQUFDeUcsY0FBVSxHQUFDekcsQ0FBWDtBQUFhOztBQUF6QixDQUEzQixFQUFzRCxDQUF0RDs7QUFRM2IsTUFBTXNJLFNBQVMsR0FBRyxDQUFDOUQsSUFBRCxFQUFPK0QsT0FBUCxLQUFtQjtBQUNqQyxRQUFNQyxPQUFPLEdBQUcvQixVQUFVLENBQUNqQyxJQUFELENBQTFCO0FBQ0EsTUFBSSxDQUFDZ0UsT0FBTCxFQUFjLGlCQUFVRCxPQUFWO0FBQ2QsTUFBSUMsT0FBTyxLQUFLLEVBQWhCLEVBQW9CLGlCQUFVRCxPQUFWO0FBQ3BCLFNBQU9DLE9BQVA7QUFDSCxDQUxEOztBQVFBMUksTUFBTSxDQUFDSyxPQUFQLENBQWU7QUFFWHNJLGNBQVksQ0FBQ25JLE9BQUQsRUFBVWtFLElBQVYsRUFBZ0I7QUFDeEIsUUFBSSxDQUFDLEtBQUtqRSxNQUFWLEVBQWtCO0FBQ2QsWUFBTSxJQUFJVCxNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0Msd0NBQWxDLENBQU47QUFDSDs7QUFFRCxVQUFNQyxLQUFLLEdBQUdSLE1BQU0sQ0FBQ1MsT0FBUCxDQUFlO0FBQ3pCSyxTQUFHLEVBQUVULE9BRG9CO0FBRXpCSyxlQUFTLEVBQUUsS0FBS0o7QUFGUyxLQUFmLENBQWQ7O0FBS0EsUUFBSSxDQUFDRSxLQUFMLEVBQVk7QUFDUixZQUFNLElBQUlYLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixXQUFqQixFQUE4QiwyQkFBOUIsQ0FBTjtBQUNIOztBQUVELFFBQUlDLEtBQUssQ0FBQ0ksTUFBTixLQUFpQm5DLFNBQVMsQ0FBQ0MsYUFBVixDQUF3QkUsUUFBN0MsRUFBdUQ7QUFDbkQsWUFBTSxJQUFJaUIsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGtCQUFqQixFQUFxQyw2QkFBckMsQ0FBTjtBQUNIOztBQUVELFVBQU15RCxVQUFVLEdBQUcsSUFBSTlCLElBQUosRUFBbkI7QUFFQSxVQUFNb0csT0FBTyxHQUFHRixNQUFNLENBQUNwRSxVQUFELENBQU4sQ0FBbUJ5RSxNQUFuQixDQUEwQixpQkFBMUIsQ0FBaEI7QUFFQSxVQUFNckUsV0FBVyxHQUFHaUUsU0FBUyxDQUFDOUQsSUFBRCxFQUFPK0QsT0FBUCxDQUE3Qjs7QUFFQSxRQUFJbEUsV0FBVyxLQUFLRyxJQUFoQixJQUF3QkEsSUFBSSxLQUFLLEVBQXJDLEVBQXlDO0FBQ3JDLFlBQU0sSUFBSTFFLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixjQUFqQixFQUFpQyw4Q0FBakMsQ0FBTjtBQUNIOztBQUVELFFBQUk4RixRQUFRLEdBQUd0QixRQUFRLENBQUN0RSxPQUFULENBQWlCO0FBQUVDLGVBQVMsRUFBRSxLQUFLSjtBQUFsQixLQUFqQixDQUFmOztBQUVBLFFBQUksQ0FBQytGLFFBQUwsRUFBZTtBQUNYQSxjQUFRLEdBQUc7QUFDUHBDLHdCQUFnQixFQUFFLElBRFg7QUFFUEMsc0JBQWMsRUFBRSxJQUZUO0FBR1BDLHNCQUFjLEVBQUU7QUFIVCxPQUFYO0FBS0g7O0FBRUQsUUFBSTtBQUNBbkUsWUFBTSxDQUFDYSxNQUFQLENBQ0k7QUFBRUMsV0FBRyxFQUFFTixLQUFLLENBQUNNO0FBQWIsT0FESixFQUVJO0FBQ0lDLFlBQUksRUFDSjtBQUNJSCxnQkFBTSxFQUFFbkMsU0FBUyxDQUFDQyxhQUFWLENBQXdCRSxRQURwQztBQUVJb0Ysb0JBRko7QUFHSUkscUJBSEo7QUFJSUgsMEJBQWdCLEVBQUVvQyxRQUFRLENBQUNwQyxnQkFKL0I7QUFLSUMsd0JBQWMsRUFBRW1DLFFBQVEsQ0FBQ25DLGNBTDdCO0FBTUlDLHdCQUFjLEVBQUVrQyxRQUFRLENBQUNsQztBQU43QjtBQUZKLE9BRko7QUFjSCxLQWZELENBZUUsT0FBT25ELEdBQVAsRUFBWTtBQUNWdkIsWUFBTSxDQUFDQyxHQUFQLENBQVdzQixHQUFYO0FBQ0EsWUFBTSxJQUFJbkIsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHlEQUFsQyxDQUFOO0FBQ0g7QUFDSjs7QUEzRFUsQ0FBZixFOzs7Ozs7Ozs7OztBQ2hCQSxJQUFJVixNQUFKO0FBQVdOLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLE1BQUo7QUFBV1QsTUFBTSxDQUFDTyxJQUFQLENBQVksZ0JBQVosRUFBNkI7QUFBQ0UsUUFBTSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsVUFBTSxHQUFDRCxDQUFQO0FBQVM7O0FBQXBCLENBQTdCLEVBQW1ELENBQW5EO0FBQXNELElBQUl0QixTQUFKO0FBQWNjLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGtCQUFaLEVBQStCO0FBQUNyQixXQUFTLENBQUNzQixDQUFELEVBQUc7QUFBQ3RCLGFBQVMsR0FBQ3NCLENBQVY7QUFBWTs7QUFBMUIsQ0FBL0IsRUFBMkQsQ0FBM0Q7QUFBOEQsSUFBSU4sTUFBSjtBQUFXRixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNMLFFBQU0sQ0FBQ00sQ0FBRCxFQUFHO0FBQUNOLFVBQU0sR0FBQ00sQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUt4TkYsTUFBTSxDQUFDSyxPQUFQLENBQWU7QUFFWHdJLGlCQUFlLENBQUNySSxPQUFELEVBQVVrRSxJQUFWLEVBQWdCO0FBQzNCLFFBQUksQ0FBQyxLQUFLakUsTUFBVixFQUFrQjtBQUNkLFlBQU0sSUFBSVQsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHdDQUFsQyxDQUFOO0FBQ0g7O0FBRUQsVUFBTUMsS0FBSyxHQUFHUixNQUFNLENBQUNTLE9BQVAsQ0FBZTtBQUN6QkssU0FBRyxFQUFFVCxPQURvQjtBQUV6QkssZUFBUyxFQUFFLEtBQUtKO0FBRlMsS0FBZixDQUFkOztBQUtBLFFBQUksQ0FBQ0UsS0FBTCxFQUFZO0FBQ1IsWUFBTSxJQUFJWCxNQUFNLENBQUNVLEtBQVgsQ0FBaUIsV0FBakIsRUFBOEIsMkJBQTlCLENBQU47QUFDSDs7QUFFRCxRQUFJQyxLQUFLLENBQUNJLE1BQU4sS0FBaUJuQyxTQUFTLENBQUNDLGFBQVYsQ0FBd0JFLFFBQTdDLEVBQXVEO0FBQ25ELFlBQU0sSUFBSWlCLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixrQkFBakIsRUFBcUMsMENBQXJDLENBQU47QUFDSDs7QUFFRCxRQUFJO0FBQ0FQLFlBQU0sQ0FBQ2EsTUFBUCxDQUNJO0FBQUVDLFdBQUcsRUFBRU4sS0FBSyxDQUFDTTtBQUFiLE9BREosRUFFSTtBQUNJQyxZQUFJLEVBQ0o7QUFDSVcsZUFBSyxFQUFFO0FBRFg7QUFGSixPQUZKO0FBU0gsS0FWRCxDQVVFLE9BQU9WLEdBQVAsRUFBWTtBQUNWdkIsWUFBTSxDQUFDQyxHQUFQLENBQVdzQixHQUFYO0FBQ0EsWUFBTSxJQUFJbkIsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLCtEQUFsQyxDQUFOO0FBQ0g7QUFDSjs7QUFsQ1UsQ0FBZixFOzs7Ozs7Ozs7OztBQ0xBLElBQUlWLE1BQUo7QUFBV04sTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSTRJLEVBQUo7QUFBT3BKLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLElBQVosRUFBaUI7QUFBQ3lHLFNBQU8sQ0FBQ3hHLENBQUQsRUFBRztBQUFDNEksTUFBRSxHQUFDNUksQ0FBSDtBQUFLOztBQUFqQixDQUFqQixFQUFvQyxDQUFwQzs7QUFBdUMsSUFBSXVCLENBQUo7O0FBQU0vQixNQUFNLENBQUNPLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDd0IsR0FBQyxDQUFDdkIsQ0FBRCxFQUFHO0FBQUN1QixLQUFDLEdBQUN2QixDQUFGO0FBQUk7O0FBQVYsQ0FBaEMsRUFBNEMsQ0FBNUM7QUFJcEhGLE1BQU0sQ0FBQ0ssT0FBUCxDQUFlO0FBQ1gwSSxpQkFBZSxHQUFHO0FBQ2QsVUFBTUMsTUFBTSxHQUFHLEVBQWY7QUFFQSxVQUFNQyxVQUFVLEdBQUdILEVBQUUsQ0FBQ0ksWUFBSCxXQUFtQkMsT0FBTyxDQUFDQyxHQUFSLEVBQW5CLFVBQW5CO0FBQ0EsVUFBTUMsVUFBVSxhQUFNSixVQUFOLHNCQUFoQjtBQUNBLFVBQU1LLGNBQWMsYUFBTUQsVUFBTixNQUFwQjtBQUNBLFVBQU1FLEdBQUcsR0FBR1QsRUFBRSxDQUFDVSxXQUFILENBQWVGLGNBQWYsQ0FBWjtBQUNBLFVBQU1HLEtBQUssR0FBR0YsR0FBRyxDQUFDM0gsTUFBSixDQUFXLFVBQVU4SCxHQUFWLEVBQWU7QUFBRSxhQUFPQSxHQUFHLENBQUNDLEtBQUosQ0FBVSxhQUFWLENBQVA7QUFBa0MsS0FBOUQsQ0FBZDs7QUFFQWxJLEtBQUMsQ0FBQ21JLElBQUYsQ0FBT0gsS0FBUCxFQUFjLFVBQVVJLEdBQVYsRUFBZTtBQUN6QmIsWUFBTSxDQUFDNUIsSUFBUCxDQUFZO0FBQUUwQyxnQkFBUSxhQUFNRCxHQUFOO0FBQVYsT0FBWjtBQUNILEtBRkQ7O0FBSUEsV0FBT2IsTUFBUDtBQUNIOztBQWZVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNKQSxJQUFJaEosTUFBSjtBQUFXTixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxNQUFKLEVBQVdpQixZQUFYO0FBQXdCMUIsTUFBTSxDQUFDTyxJQUFQLENBQVksZ0JBQVosRUFBNkI7QUFBQ0UsUUFBTSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsVUFBTSxHQUFDRCxDQUFQO0FBQVMsR0FBcEI7O0FBQXFCa0IsY0FBWSxDQUFDbEIsQ0FBRCxFQUFHO0FBQUNrQixnQkFBWSxHQUFDbEIsQ0FBYjtBQUFlOztBQUFwRCxDQUE3QixFQUFtRixDQUFuRjtBQUFzRixJQUFJRSxPQUFKO0FBQVlWLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUNHLFNBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLFdBQU8sR0FBQ0YsQ0FBUjtBQUFVOztBQUF0QixDQUE3QixFQUFxRCxDQUFyRDtBQUF3RCxJQUFJdEIsU0FBSjtBQUFjYyxNQUFNLENBQUNPLElBQVAsQ0FBWSxrQkFBWixFQUErQjtBQUFDckIsV0FBUyxDQUFDc0IsQ0FBRCxFQUFHO0FBQUN0QixhQUFTLEdBQUNzQixDQUFWO0FBQVk7O0FBQTFCLENBQS9CLEVBQTJELENBQTNEO0FBQThELElBQUlOLE1BQUo7QUFBV0YsTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDTCxRQUFNLENBQUNNLENBQUQsRUFBRztBQUFDTixVQUFNLEdBQUNNLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXlHLFVBQUo7QUFBZWpILE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3lHLFNBQU8sQ0FBQ3hHLENBQUQsRUFBRztBQUFDeUcsY0FBVSxHQUFDekcsQ0FBWDtBQUFhOztBQUF6QixDQUEzQixFQUFzRCxDQUF0RDtBQU83WUYsTUFBTSxDQUFDSyxPQUFQLENBQWU7QUFFWDBKLG1CQUFpQixDQUFDdkcsS0FBRCxFQUFRO0FBQ3JCLFVBQU1oRCxPQUFPLEdBQUcsRUFBaEI7O0FBRUEsUUFBSSxDQUFDLEtBQUtDLE1BQVYsRUFBa0I7QUFDZCxZQUFNLElBQUlULE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQyx3Q0FBbEMsQ0FBTjtBQUNIOztBQUVELFVBQU1hLE1BQU0sR0FBRyxFQUFmO0FBQ0FBLFVBQU0sQ0FBQ2lDLEtBQVAsR0FBZW1ELFVBQVUsQ0FBQ25ELEtBQUQsQ0FBekI7QUFFQWpDLFVBQU0sQ0FBQ1IsTUFBUCxHQUFnQm5DLFNBQVMsQ0FBQ00saUJBQVYsQ0FBNEJDLE9BQTVDOztBQUVBLFFBQUlvQyxNQUFNLENBQUNpQyxLQUFQLEtBQWlCLEVBQXJCLEVBQXlCO0FBQ3JCLFlBQU0sSUFBSXhELE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixnQkFBakIsRUFBbUMsNkNBQW5DLENBQU47QUFDSDs7QUFFRCxRQUFJO0FBQ0EsWUFBTVksUUFBUSxHQUFHRixZQUFZLENBQUM0SSxNQUFiLENBQW9CekksTUFBcEIsQ0FBakI7QUFDQSxhQUFPRCxRQUFQO0FBQ0gsS0FIRCxDQUdFLE9BQU9ILEdBQVAsRUFBWTtBQUNWdkIsWUFBTSxDQUFDQyxHQUFQLENBQVdzQixHQUFYO0FBQ0EsWUFBTSxJQUFJbkIsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLG1FQUFsQyxDQUFOO0FBQ0g7QUFDSjs7QUF6QlUsQ0FBZixFOzs7Ozs7Ozs7OztBQ1BBLElBQUlWLE1BQUo7QUFBV04sTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSStCLE1BQUo7QUFBV3ZDLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ2dDLFFBQU0sQ0FBQy9CLENBQUQsRUFBRztBQUFDK0IsVUFBTSxHQUFDL0IsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDs7QUFBcUQsSUFBSXVCLENBQUo7O0FBQU0vQixNQUFNLENBQUNPLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDd0IsR0FBQyxDQUFDdkIsQ0FBRCxFQUFHO0FBQUN1QixLQUFDLEdBQUN2QixDQUFGO0FBQUk7O0FBQVYsQ0FBaEMsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSUMsTUFBSjtBQUFXVCxNQUFNLENBQUNPLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDRSxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUzs7QUFBcEIsQ0FBN0IsRUFBbUQsQ0FBbkQ7QUFBc0QsSUFBSUUsT0FBSjtBQUFZVixNQUFNLENBQUNPLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDRyxTQUFPLENBQUNGLENBQUQsRUFBRztBQUFDRSxXQUFPLEdBQUNGLENBQVI7QUFBVTs7QUFBdEIsQ0FBN0IsRUFBcUQsQ0FBckQ7QUFBd0QsSUFBSXRCLFNBQUo7QUFBY2MsTUFBTSxDQUFDTyxJQUFQLENBQVksa0JBQVosRUFBK0I7QUFBQ3JCLFdBQVMsQ0FBQ3NCLENBQUQsRUFBRztBQUFDdEIsYUFBUyxHQUFDc0IsQ0FBVjtBQUFZOztBQUExQixDQUEvQixFQUEyRCxDQUEzRDtBQUE4RCxJQUFJTixNQUFKO0FBQVdGLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0wsUUFBTSxDQUFDTSxDQUFELEVBQUc7QUFBQ04sVUFBTSxHQUFDTSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl5RyxVQUFKO0FBQWVqSCxNQUFNLENBQUNPLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUN5RyxTQUFPLENBQUN4RyxDQUFELEVBQUc7QUFBQ3lHLGNBQVUsR0FBQ3pHLENBQVg7QUFBYTs7QUFBekIsQ0FBM0IsRUFBc0QsQ0FBdEQ7QUFTcmRGLE1BQU0sQ0FBQ0ssT0FBUCxDQUFlO0FBRVg0SixpQkFBZSxDQUFDekcsS0FBRCxFQUFRRyxRQUFSLEVBQWtCO0FBQzdCLFFBQUluRCxPQUFPLEdBQUcsRUFBZDs7QUFFQSxRQUFJLENBQUMsS0FBS0MsTUFBVixFQUFrQjtBQUNkLFlBQU0sSUFBSVQsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHdDQUFsQyxDQUFOO0FBQ0g7O0FBRUQsVUFBTXdKLFFBQVEsR0FBR3ZELFVBQVUsQ0FBQ25ELEtBQUQsQ0FBM0I7O0FBRUEsUUFBSTBHLFFBQVEsS0FBSyxFQUFqQixFQUFxQjtBQUNqQixZQUFNLElBQUlsSyxNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZ0JBQWpCLEVBQW1DLDRDQUFuQyxDQUFOO0FBQ0gsS0FYNEIsQ0FhN0I7OztBQUNBLFFBQUlDLEtBQUssR0FBR1IsTUFBTSxDQUFDUyxPQUFQLENBQWU7QUFDdkJDLGVBQVMsRUFBRSxLQUFLSixNQURPO0FBRXZCTSxZQUFNLEVBQUVuQyxTQUFTLENBQUNDLGFBQVYsQ0FBd0JDO0FBRlQsS0FBZixDQUFaOztBQUtBLFFBQUksQ0FBQzZCLEtBQUwsRUFBWTtBQUNSLFlBQU13SixRQUFRLEdBQUcsRUFBakI7QUFDQUEsY0FBUSxDQUFDcEosTUFBVCxHQUFrQm5DLFNBQVMsQ0FBQ0MsYUFBVixDQUF3QkMsTUFBMUM7QUFDQXFMLGNBQVEsQ0FBQ3RJLEtBQVQsR0FBaUIsRUFBakI7QUFFQXJCLGFBQU8sR0FBR0wsTUFBTSxDQUFDNkosTUFBUCxDQUFjRyxRQUFkLENBQVY7QUFFQXhKLFdBQUssR0FBR1IsTUFBTSxDQUFDUyxPQUFQLENBQWU7QUFBRUssV0FBRyxFQUFFVDtBQUFQLE9BQWYsQ0FBUjtBQUNILEtBUkQsTUFRTztBQUNIQSxhQUFPLEdBQUdHLEtBQUssQ0FBQ00sR0FBaEI7QUFDSDs7QUFFRCxVQUFNZ0csR0FBRyxHQUFHLEVBQVo7QUFDQUEsT0FBRyxDQUFDMUcsTUFBSixHQUFhMEIsTUFBTSxDQUFDOEYsRUFBUCxFQUFiO0FBQ0FkLE9BQUcsQ0FBQ3pELEtBQUosR0FBWTBHLFFBQVo7QUFDQWpELE9BQUcsQ0FBQ3RELFFBQUosR0FBZUEsUUFBZjtBQUNBc0QsT0FBRyxDQUFDbEcsTUFBSixHQUFhbkMsU0FBUyxDQUFDTSxpQkFBVixDQUE0QkMsT0FBekM7QUFDQThILE9BQUcsQ0FBQ25FLEtBQUosR0FBWSxDQUFaO0FBQ0FtRSxPQUFHLENBQUNwRCxTQUFKLEdBQWdCLElBQUl4QixJQUFKLEVBQWhCOztBQUVBLFFBQUksQ0FBQ1osQ0FBQyxDQUFDMkksT0FBRixDQUFVekosS0FBSyxDQUFDa0IsS0FBaEIsQ0FBTCxFQUE2QjtBQUN6QmxCLFdBQUssQ0FBQ2tCLEtBQU4sR0FBYyxFQUFkO0FBQ0gsS0F6QzRCLENBMkM3Qjs7O0FBRUEsUUFBSTtBQUNBMUIsWUFBTSxDQUFDYSxNQUFQLENBQ0k7QUFBRUMsV0FBRyxFQUFFVDtBQUFQLE9BREosRUFFSTtBQUNJNkosYUFBSyxFQUFFO0FBQ0h4SSxlQUFLLEVBQUVvRjtBQURKO0FBRFgsT0FGSjtBQVFBLGFBQU96RyxPQUFQO0FBQ0gsS0FWRCxDQVVFLE9BQU9XLEdBQVAsRUFBWTtBQUNWdkIsWUFBTSxDQUFDQyxHQUFQLENBQVdzQixHQUFYO0FBQ0EsWUFBTSxJQUFJbkIsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLG1FQUFsQyxDQUFOO0FBQ0g7QUFDSjs7QUE3RFUsQ0FBZixFOzs7Ozs7Ozs7OztBQ1RBLElBQUlWLE1BQUo7QUFBV04sTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFFWEYsTUFBTSxDQUFDSyxPQUFQLENBQWU7QUFDWGlLLGFBQVcsR0FBRztBQUNWLFFBQUksQ0FBQyxLQUFLN0osTUFBVixFQUFrQjtBQUNkLFlBQU0sSUFBSVQsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHdDQUFsQyxDQUFOO0FBQ0g7O0FBRUQsVUFBTTZKLE1BQU0sR0FBR3BCLE9BQU8sQ0FBQ3FCLEdBQVIsQ0FBWUMsU0FBWixJQUF5QixFQUF4QztBQUVBLFdBQU9GLE1BQVA7QUFDSDs7QUFUVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDRkEsSUFBSXZLLE1BQUo7QUFBV04sTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSStCLE1BQUo7QUFBV3ZDLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ2dDLFFBQU0sQ0FBQy9CLENBQUQsRUFBRztBQUFDK0IsVUFBTSxHQUFDL0IsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJd0ssS0FBSjtBQUFVaEwsTUFBTSxDQUFDTyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDeUssT0FBSyxDQUFDeEssQ0FBRCxFQUFHO0FBQUN3SyxTQUFLLEdBQUN4SyxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUk2QyxZQUFKO0FBQWlCckQsTUFBTSxDQUFDTyxJQUFQLENBQVksNkJBQVosRUFBMEM7QUFBQzhDLGNBQVksQ0FBQzdDLENBQUQsRUFBRztBQUFDNkMsZ0JBQVksR0FBQzdDLENBQWI7QUFBZTs7QUFBaEMsQ0FBMUMsRUFBNEUsQ0FBNUU7O0FBQStFLElBQUl1QixDQUFKOztBQUFNL0IsTUFBTSxDQUFDTyxJQUFQLENBQVksbUJBQVosRUFBZ0M7QUFBQ3dCLEdBQUMsQ0FBQ3ZCLENBQUQsRUFBRztBQUFDdUIsS0FBQyxHQUFDdkIsQ0FBRjtBQUFJOztBQUFWLENBQWhDLEVBQTRDLENBQTVDO0FBQStDLElBQUlnRixRQUFKO0FBQWF4RixNQUFNLENBQUNPLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDaUYsVUFBUSxDQUFDaEYsQ0FBRCxFQUFHO0FBQUNnRixZQUFRLEdBQUNoRixDQUFUO0FBQVc7O0FBQXhCLENBQTdCLEVBQXVELENBQXZEO0FBQTBELElBQUlFLE9BQUo7QUFBWVYsTUFBTSxDQUFDTyxJQUFQLENBQVksZ0JBQVosRUFBNkI7QUFBQ0csU0FBTyxDQUFDRixDQUFELEVBQUc7QUFBQ0UsV0FBTyxHQUFDRixDQUFSO0FBQVU7O0FBQXRCLENBQTdCLEVBQXFELENBQXJEO0FBQXdELElBQUlOLE1BQUo7QUFBV0YsTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDTCxRQUFNLENBQUNNLENBQUQsRUFBRztBQUFDTixVQUFNLEdBQUNNLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXlHLFVBQUo7QUFBZWpILE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3lHLFNBQU8sQ0FBQ3hHLENBQUQsRUFBRztBQUFDeUcsY0FBVSxHQUFDekcsQ0FBWDtBQUFhOztBQUF6QixDQUEzQixFQUFzRCxDQUF0RDtBQVUzaUJGLE1BQU0sQ0FBQ0ssT0FBUCxDQUFlO0FBRVhzSyxjQUFZLENBQUMxRCxHQUFELEVBQU07QUFDZCxRQUFJLENBQUMsS0FBS3hHLE1BQVYsRUFBa0I7QUFDZCxZQUFNLElBQUlULE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQyx3Q0FBbEMsQ0FBTjtBQUNIOztBQUVETixXQUFPLENBQUM4RSxRQUFSLENBQWlCMEYsUUFBakIsQ0FBMEIzRCxHQUExQjtBQUVBLFVBQU1ULFFBQVEsR0FBR3RCLFFBQVEsQ0FBQ3RFLE9BQVQsQ0FBaUI7QUFBRUMsZUFBUyxFQUFFLEtBQUtKO0FBQWxCLEtBQWpCLENBQWpCO0FBRUEsVUFBTXlHLEtBQUssR0FBR1AsVUFBVSxDQUFDTSxHQUFHLENBQUM3QyxnQkFBTCxFQUF1QixJQUF2QixDQUF4QjtBQUNBLFVBQU1pRCxHQUFHLEdBQUdWLFVBQVUsQ0FBQ00sR0FBRyxDQUFDNUMsY0FBTCxFQUFxQixJQUFyQixDQUF0QjtBQUNBLFVBQU1pRCxHQUFHLEdBQUdYLFVBQVUsQ0FBQ00sR0FBRyxDQUFDM0MsY0FBTCxFQUFxQixJQUFyQixDQUF0Qjs7QUFFQSxRQUFJNEMsS0FBSyxLQUFLRCxHQUFHLENBQUM3QyxnQkFBZCxJQUFrQ2lELEdBQUcsS0FBS0osR0FBRyxDQUFDNUMsY0FBOUMsSUFBZ0VpRCxHQUFHLEtBQUtMLEdBQUcsQ0FBQzNDLGNBQWhGLEVBQWdHO0FBQzVGLFlBQU0sSUFBSXRFLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixnQkFBakIsRUFBbUMsd0NBQW5DLENBQU47QUFDSDs7QUFFRCxRQUFJO0FBQ0EsVUFBSWUsQ0FBQyxDQUFDb0osV0FBRixDQUFjckUsUUFBZCxDQUFKLEVBQTZCO0FBQ3pCdEIsZ0JBQVEsQ0FBQzhFLE1BQVQsQ0FBZ0IvQyxHQUFoQjtBQUNILE9BRkQsTUFFTztBQUNIL0IsZ0JBQVEsQ0FBQ2xFLE1BQVQsQ0FDSTtBQUFFQyxhQUFHLEVBQUV1RixRQUFRLENBQUN2RjtBQUFoQixTQURKLEVBRUk7QUFDSUMsY0FBSSxFQUFFO0FBQ0ZpRSwyQkFBZSxFQUFFOEIsR0FBRyxDQUFDOUIsZUFEbkI7QUFFRmYsNEJBQWdCLEVBQUU4QyxLQUZoQjtBQUdGN0MsMEJBQWMsRUFBRWdELEdBSGQ7QUFJRi9DLDBCQUFjLEVBQUVnRDtBQUpkO0FBRFYsU0FGSjtBQVdIO0FBQ0osS0FoQkQsQ0FnQkUsT0FBT25HLEdBQVAsRUFBWTtBQUNWdkIsWUFBTSxDQUFDQyxHQUFQLENBQVdzQixHQUFYO0FBQ0EsWUFBTSxJQUFJbkIsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHVEQUFsQyxDQUFOO0FBQ0g7QUFDSjs7QUF2Q1UsQ0FBZixFOzs7Ozs7Ozs7OztBQ1ZBLElBQUlWLE1BQUo7QUFBV04sTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7O0FBQXFELElBQUl1QixDQUFKOztBQUFNL0IsTUFBTSxDQUFDTyxJQUFQLENBQVksbUJBQVosRUFBZ0M7QUFBQ3dCLEdBQUMsQ0FBQ3ZCLENBQUQsRUFBRztBQUFDdUIsS0FBQyxHQUFDdkIsQ0FBRjtBQUFJOztBQUFWLENBQWhDLEVBQTRDLENBQTVDO0FBQStDLElBQUlDLE1BQUosRUFBV2lCLFlBQVg7QUFBd0IxQixNQUFNLENBQUNPLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDRSxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUyxHQUFwQjs7QUFBcUJrQixjQUFZLENBQUNsQixDQUFELEVBQUc7QUFBQ2tCLGdCQUFZLEdBQUNsQixDQUFiO0FBQWU7O0FBQXBELENBQTdCLEVBQW1GLENBQW5GO0FBQXNGLElBQUl0QixTQUFKO0FBQWNjLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGtCQUFaLEVBQStCO0FBQUNyQixXQUFTLENBQUNzQixDQUFELEVBQUc7QUFBQ3RCLGFBQVMsR0FBQ3NCLENBQVY7QUFBWTs7QUFBMUIsQ0FBL0IsRUFBMkQsQ0FBM0Q7QUFBOEQsSUFBSTRLLFdBQUo7QUFBZ0JwTCxNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUM2SyxhQUFXLENBQUM1SyxDQUFELEVBQUc7QUFBQzRLLGVBQVcsR0FBQzVLLENBQVo7QUFBYzs7QUFBOUIsQ0FBNUIsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSXlHLFVBQUo7QUFBZWpILE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3lHLFNBQU8sQ0FBQ3hHLENBQUQsRUFBRztBQUFDeUcsY0FBVSxHQUFDekcsQ0FBWDtBQUFhOztBQUF6QixDQUEzQixFQUFzRCxDQUF0RDtBQU83WUYsTUFBTSxDQUFDSyxPQUFQLENBQWU7QUFDWDBLLG9CQUFrQixDQUFDQyxZQUFELEVBQWVDLFdBQWYsRUFBNEI7QUFDMUM7QUFDQSxRQUFJLENBQUMsS0FBS3hLLE1BQVYsRUFBa0I7QUFDZCxZQUFNLElBQUlULE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQywrQ0FBbEMsQ0FBTjtBQUNILEtBSnlDLENBTTFDO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOzs7QUFFQSxVQUFNd0ssVUFBVSxHQUFHRCxXQUFXLElBQUksRUFBbEM7O0FBRUEsUUFBSUMsVUFBVSxLQUFLLEVBQW5CLEVBQXVCO0FBQ25CLFlBQU0sSUFBSWxMLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQix3QkFBakIsRUFBMkMsK0JBQTNDLENBQU47QUFDSDs7QUFFRCxVQUFNeUssUUFBUSxHQUFHeEUsVUFBVSxDQUFDdUUsVUFBRCxDQUEzQjs7QUFFQSxRQUFJQyxRQUFRLEtBQUssRUFBakIsRUFBcUI7QUFDakIsWUFBTSxJQUFJbkwsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHdCQUFsQyxDQUFOO0FBQ0gsS0ExQnlDLENBNEIxQzs7O0FBRUEsVUFBTTBLLE9BQU8sR0FBR2hLLFlBQVksQ0FBQ29HLElBQWIsQ0FBa0I7QUFDOUIzRyxlQUFTLEVBQUUsS0FBS0osTUFEYztBQUU5QkssU0FBRyxFQUFFLENBQ0Q7QUFBRUMsY0FBTSxFQUFFbkMsU0FBUyxDQUFDTSxpQkFBVixDQUE0QkM7QUFBdEMsT0FEQyxFQUVEO0FBQ0k0QixjQUFNLEVBQUVuQyxTQUFTLENBQUNNLGlCQUFWLENBQTRCRSxRQUR4QztBQUVJa0QsbUJBQVcsRUFBRTtBQUFFK0ksYUFBRyxFQUFFLElBQUloSixJQUFKLENBQVNBLElBQUksQ0FBQ2lKLEdBQUwsS0FBYyxLQUFLLEVBQUwsR0FBVSxFQUFWLEdBQWUsSUFBdEM7QUFBUDtBQUZqQixPQUZDO0FBRnlCLEtBQWxCLEVBU2JDLEtBVGEsRUFBaEI7O0FBV0EsUUFBSUgsT0FBTyxDQUFDckosTUFBUixLQUFtQixDQUF2QixFQUEwQjtBQUN0QixZQUFNLElBQUkvQixNQUFNLENBQUNVLEtBQVgsQ0FBaUIsWUFBakIsRUFBK0IsNERBQS9CLENBQU47QUFDSDs7QUFFRCxVQUFNOEssSUFBSSxHQUFHLEVBQWI7QUFFQSxVQUFNckQsSUFBSSxHQUFHbkksTUFBTSxDQUFDb0ksS0FBUCxDQUFheEgsT0FBYixDQUFxQixLQUFLSCxNQUExQixDQUFiO0FBRUErSyxRQUFJLENBQUNDLFNBQUwsR0FBaUJ0RCxJQUFJLENBQUNFLFFBQUwsQ0FBYy9DLFlBQWQsRUFBakI7QUFDQWtHLFFBQUksQ0FBQ0UsV0FBTCxHQUFtQixJQUFJckosSUFBSixHQUFXc0osV0FBWCxFQUFuQixDQWxEMEMsQ0FtRDFDOztBQUNBLFFBQUk5SixLQUFLLEdBQUcsc0ZBQVo7QUFDQTJKLFFBQUksQ0FBQ0ksVUFBTCxHQUFrQm5LLENBQUMsQ0FBQ29LLE1BQUYsQ0FBU1QsT0FBVCxFQUFrQixRQUFsQixFQUE0QmpFLE9BQTVCLENBQXFDckYsSUFBRCxJQUFVO0FBQzVELFlBQU1nSyxVQUFVLEdBQUloSyxJQUFJLENBQUNmLE1BQUwsS0FBZ0JuQyxTQUFTLENBQUNNLGlCQUFWLENBQTRCRSxRQUE3QyxHQUF5RCxVQUF6RCxHQUFzRSxRQUF6RjtBQUNBLFlBQU0yTSxTQUFTLEdBQUlqSyxJQUFJLENBQUNmLE1BQUwsS0FBZ0JuQyxTQUFTLENBQUNNLGlCQUFWLENBQTRCRSxRQUE3QyxHQUF5RCw2REFBekQsR0FBeUgsZ0RBQTNJO0FBQ0F5QyxXQUFLLG1DQUEyQmtLLFNBQTNCLGdCQUF5Q2pLLElBQUksQ0FBQzBCLEtBQTlDLDhCQUFzRXVJLFNBQXRFLGdCQUFvRkQsVUFBcEYsZUFBTDtBQUNILEtBSmlCLENBQWxCO0FBTUFOLFFBQUksQ0FBQ0ksVUFBTCxHQUFrQi9KLEtBQWxCO0FBRUEsVUFBTW1LLElBQUksR0FBRzdDLE9BQU8sQ0FBQ3FCLEdBQVIsQ0FBWXlCLGtCQUFaLElBQWtDLHNCQUEvQztBQUVBbkIsZUFBVyxDQUFDb0IsYUFBWixDQUEwQmYsUUFBMUIsRUFBb0NhLElBQXBDLFlBQTZDN0QsSUFBSSxDQUFDRSxRQUFMLENBQWMvQyxZQUFkLEVBQTdDLG9CQUEwRixhQUExRixFQUF5R2tHLElBQXpHO0FBQ0g7O0FBakVVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNQQSxJQUFJeEwsTUFBSjtBQUFXTixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxNQUFKLEVBQVdpQixZQUFYO0FBQXdCMUIsTUFBTSxDQUFDTyxJQUFQLENBQVksZ0JBQVosRUFBNkI7QUFBQ0UsUUFBTSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsVUFBTSxHQUFDRCxDQUFQO0FBQVMsR0FBcEI7O0FBQXFCa0IsY0FBWSxDQUFDbEIsQ0FBRCxFQUFHO0FBQUNrQixnQkFBWSxHQUFDbEIsQ0FBYjtBQUFlOztBQUFwRCxDQUE3QixFQUFtRixDQUFuRjtBQUFzRixJQUFJRSxPQUFKO0FBQVlWLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUNHLFNBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLFdBQU8sR0FBQ0YsQ0FBUjtBQUFVOztBQUF0QixDQUE3QixFQUFxRCxDQUFyRDtBQUF3RCxJQUFJdEIsU0FBSjtBQUFjYyxNQUFNLENBQUNPLElBQVAsQ0FBWSxrQkFBWixFQUErQjtBQUFDckIsV0FBUyxDQUFDc0IsQ0FBRCxFQUFHO0FBQUN0QixhQUFTLEdBQUNzQixDQUFWO0FBQVk7O0FBQTFCLENBQS9CLEVBQTJELENBQTNEO0FBQThELElBQUlOLE1BQUo7QUFBV0YsTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDTCxRQUFNLENBQUNNLENBQUQsRUFBRztBQUFDTixVQUFNLEdBQUNNLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXlHLFVBQUo7QUFBZWpILE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3lHLFNBQU8sQ0FBQ3hHLENBQUQsRUFBRztBQUFDeUcsY0FBVSxHQUFDekcsQ0FBWDtBQUFhOztBQUF6QixDQUEzQixFQUFzRCxDQUF0RDtBQU83WUYsTUFBTSxDQUFDSyxPQUFQLENBQWU7QUFFWDhMLG1CQUFpQixDQUFDN0ssUUFBRCxFQUFXa0MsS0FBWCxFQUFrQjtBQUMvQixVQUFNaEQsT0FBTyxHQUFHLEVBQWhCOztBQUVBLFFBQUksQ0FBQyxLQUFLQyxNQUFWLEVBQWtCO0FBQ2QsWUFBTSxJQUFJVCxNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0Msd0NBQWxDLENBQU47QUFDSDs7QUFFRCxVQUFNYSxNQUFNLEdBQUdILFlBQVksQ0FBQ1IsT0FBYixDQUFxQjtBQUFFSyxTQUFHLEVBQUVLLFFBQVA7QUFBaUJULGVBQVMsRUFBRSxLQUFLSjtBQUFqQyxLQUFyQixDQUFmOztBQUVBLFFBQUksQ0FBQ2MsTUFBTCxFQUFhO0FBQ1QsWUFBTSxJQUFJdkIsTUFBTSxDQUFDVSxLQUFYLENBQWlCLFdBQWpCLEVBQThCLHdCQUE5QixDQUFOO0FBQ0g7O0FBRUQsVUFBTXdKLFFBQVEsR0FBR3ZELFVBQVUsQ0FBQ25ELEtBQUQsQ0FBM0I7O0FBRUEsUUFBSTBHLFFBQVEsS0FBSzFHLEtBQWpCLEVBQXdCO0FBQ3BCLFlBQU0sSUFBSXhELE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixlQUFqQixFQUFrQyx3Q0FBbEMsQ0FBTjtBQUNIOztBQUVELFFBQUk7QUFDQVUsa0JBQVksQ0FBQ0osTUFBYixDQUNJO0FBQUVDLFdBQUcsRUFBRUs7QUFBUCxPQURKLEVBRUk7QUFDSUosWUFBSSxFQUNKO0FBQ0lzQyxlQUFLLEVBQUUwRztBQURYO0FBRkosT0FGSjtBQVNILEtBVkQsQ0FVRSxPQUFPL0ksR0FBUCxFQUFZO0FBQ1Z2QixZQUFNLENBQUNDLEdBQVAsQ0FBV3NCLEdBQVg7QUFDQSxZQUFNLElBQUluQixNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0MseURBQWxDLENBQU47QUFDSDtBQUNKOztBQW5DVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDUEEsSUFBSVYsTUFBSjtBQUFXTixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDs7QUFBcUQsSUFBSXVCLENBQUo7O0FBQU0vQixNQUFNLENBQUNPLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDd0IsR0FBQyxDQUFDdkIsQ0FBRCxFQUFHO0FBQUN1QixLQUFDLEdBQUN2QixDQUFGO0FBQUk7O0FBQVYsQ0FBaEMsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSUMsTUFBSjtBQUFXVCxNQUFNLENBQUNPLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDRSxRQUFNLENBQUNELENBQUQsRUFBRztBQUFDQyxVQUFNLEdBQUNELENBQVA7QUFBUzs7QUFBcEIsQ0FBN0IsRUFBbUQsQ0FBbkQ7QUFBc0QsSUFBSUUsT0FBSjtBQUFZVixNQUFNLENBQUNPLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDRyxTQUFPLENBQUNGLENBQUQsRUFBRztBQUFDRSxXQUFPLEdBQUNGLENBQVI7QUFBVTs7QUFBdEIsQ0FBN0IsRUFBcUQsQ0FBckQ7QUFBd0QsSUFBSXRCLFNBQUo7QUFBY2MsTUFBTSxDQUFDTyxJQUFQLENBQVksa0JBQVosRUFBK0I7QUFBQ3JCLFdBQVMsQ0FBQ3NCLENBQUQsRUFBRztBQUFDdEIsYUFBUyxHQUFDc0IsQ0FBVjtBQUFZOztBQUExQixDQUEvQixFQUEyRCxDQUEzRDtBQUE4RCxJQUFJTixNQUFKO0FBQVdGLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0wsUUFBTSxDQUFDTSxDQUFELEVBQUc7QUFBQ04sVUFBTSxHQUFDTSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl5RyxVQUFKO0FBQWVqSCxNQUFNLENBQUNPLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUN5RyxTQUFPLENBQUN4RyxDQUFELEVBQUc7QUFBQ3lHLGNBQVUsR0FBQ3pHLENBQVg7QUFBYTs7QUFBekIsQ0FBM0IsRUFBc0QsQ0FBdEQ7QUFRclpGLE1BQU0sQ0FBQ0ssT0FBUCxDQUFlO0FBRVgrTCxzQkFBb0IsQ0FBQzdMLE1BQUQsRUFBU2lELEtBQVQsRUFBZ0I7QUFDaEMsVUFBTWhELE9BQU8sR0FBRyxFQUFoQjs7QUFFQSxRQUFJLENBQUMsS0FBS0MsTUFBVixFQUFrQjtBQUNkLFlBQU0sSUFBSVQsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLHdDQUFsQyxDQUFOO0FBQ0g7O0FBRUQsVUFBTUMsS0FBSyxHQUFHUixNQUFNLENBQUNTLE9BQVAsQ0FBZTtBQUN6QkMsZUFBUyxFQUFFLEtBQUtKLE1BRFM7QUFFekJLLFNBQUcsRUFBRSxDQUNEO0FBQUVDLGNBQU0sRUFBRW5DLFNBQVMsQ0FBQ0MsYUFBVixDQUF3QkM7QUFBbEMsT0FEQyxFQUVEO0FBQUVpQyxjQUFNLEVBQUVuQyxTQUFTLENBQUNDLGFBQVYsQ0FBd0JHO0FBQWxDLE9BRkM7QUFGb0IsS0FBZixDQUFkLENBUGdDLENBZWhDOztBQUNBLFFBQUksQ0FBQzJCLEtBQUwsRUFBWTtBQUNSLFlBQU0sSUFBSVgsTUFBTSxDQUFDVSxLQUFYLENBQWlCLFdBQWpCLEVBQThCLGtCQUE5QixDQUFOO0FBQ0g7O0FBRUQsVUFBTWlCLFNBQVMsR0FBR0YsQ0FBQyxDQUFDRyxNQUFGLENBQVNqQixLQUFLLENBQUNrQixLQUFmLEVBQXNCLFVBQVVDLElBQVYsRUFBZ0I7QUFDcEQsYUFBT0EsSUFBSSxDQUFDdkIsTUFBTCxLQUFnQkEsTUFBdkI7QUFDSCxLQUZpQixDQUFsQjs7QUFJQSxRQUFJb0IsU0FBUyxDQUFDSSxNQUFWLEtBQXFCLENBQXpCLEVBQTRCO0FBQ3hCLFlBQU0sSUFBSS9CLE1BQU0sQ0FBQ1UsS0FBWCxDQUFpQixXQUFqQixFQUE4Qix1QkFBOUIsQ0FBTjtBQUNIOztBQUVELFFBQUltQyxTQUFTLEdBQUdsQixTQUFTLENBQUMsQ0FBRCxDQUFULENBQWFtQixLQUFiLElBQXNCLENBQXRDO0FBRUFELGFBQVMsSUFBSSxDQUFiO0FBRUEsVUFBTXFILFFBQVEsR0FBR3ZELFVBQVUsQ0FBQ25ELEtBQUQsQ0FBM0I7O0FBRUEsUUFBSTBHLFFBQVEsS0FBSyxFQUFqQixFQUFxQjtBQUNqQixZQUFNLElBQUlsSyxNQUFNLENBQUNVLEtBQVgsQ0FBaUIsZUFBakIsRUFBa0MsNENBQWxDLENBQU47QUFDSDs7QUFFRCxRQUFJO0FBQ0FQLFlBQU0sQ0FBQ2EsTUFBUCxDQUNJO0FBQ0lDLFdBQUcsRUFBRU4sS0FBSyxDQUFDTSxHQURmO0FBRUksd0JBQWdCVjtBQUZwQixPQURKLEVBS0k7QUFDSVcsWUFBSSxFQUFFO0FBQ0YsMkJBQWlCZ0o7QUFEZjtBQURWLE9BTEo7QUFXSCxLQVpELENBWUUsT0FBTy9JLEdBQVAsRUFBWTtBQUNWdkIsWUFBTSxDQUFDQyxHQUFQLENBQVdzQixHQUFYO0FBQ0EsWUFBTSxJQUFJbkIsTUFBTSxDQUFDVSxLQUFYLENBQWlCLGVBQWpCLEVBQWtDLDZEQUFsQyxDQUFOO0FBQ0g7QUFDSjs7QUF4RFUsQ0FBZixFOzs7Ozs7Ozs7OztBQ1JBLElBQUlWLE1BQUo7QUFBV04sTUFBTSxDQUFDTyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSTRJLEVBQUo7QUFBT3BKLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLElBQVosRUFBaUI7QUFBQ3lHLFNBQU8sQ0FBQ3hHLENBQUQsRUFBRztBQUFDNEksTUFBRSxHQUFDNUksQ0FBSDtBQUFLOztBQUFqQixDQUFqQixFQUFvQyxDQUFwQzs7QUFBdUMsSUFBSXVCLENBQUo7O0FBQU0vQixNQUFNLENBQUNPLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDd0IsR0FBQyxDQUFDdkIsQ0FBRCxFQUFHO0FBQUN1QixLQUFDLEdBQUN2QixDQUFGO0FBQUk7O0FBQVYsQ0FBaEMsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSTRGLFdBQUo7QUFBZ0JwRyxNQUFNLENBQUNPLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDNkYsYUFBVyxDQUFDNUYsQ0FBRCxFQUFHO0FBQUM0RixlQUFXLEdBQUM1RixDQUFaO0FBQWM7O0FBQTlCLENBQTdCLEVBQTZELENBQTdEO0FBS25MRixNQUFNLENBQUNxTSxPQUFQLENBQWUsYUFBZixFQUE4QixZQUFZO0FBQ3RDLFFBQU1DLElBQUksR0FBRyxJQUFiO0FBQ0EsUUFBTXJELFVBQVUsR0FBR0gsRUFBRSxDQUFDSSxZQUFILFdBQW1CQyxPQUFPLENBQUNDLEdBQVIsRUFBbkIsVUFBbkI7QUFDQSxRQUFNQyxVQUFVLGFBQU1KLFVBQU4sc0JBQWhCO0FBQ0EsUUFBTUssY0FBYyxhQUFNRCxVQUFOLGtCQUFwQjtBQUNBLFFBQU1FLEdBQUcsR0FBR1QsRUFBRSxDQUFDVSxXQUFILENBQWVGLGNBQWYsQ0FBWjs7QUFDQTdILEdBQUMsQ0FBQ21JLElBQUYsQ0FBT0wsR0FBUCxFQUFZLFVBQVVnRCxVQUFWLEVBQXNCO0FBQzlCLFVBQU1DLGNBQWMsR0FBR0QsVUFBVSxDQUFDRSxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLENBQXRCLEVBQXlCbkgsWUFBekIsRUFBdkI7QUFDQWdILFFBQUksQ0FBQ0ksS0FBTCxDQUFXLGFBQVgsRUFBMEJILFVBQTFCLEVBQXNDO0FBQUU3SCxVQUFJLEVBQUU4SCxjQUFSO0FBQXdCeEgsV0FBSyx5QkFBa0J1SCxVQUFsQjtBQUE3QixLQUF0QztBQUNILEdBSEQ7O0FBSUEsT0FBS0ksS0FBTDtBQUNILENBWEQsRTs7Ozs7Ozs7Ozs7QUNMQSxJQUFJM00sTUFBSjtBQUFXTixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJd0ssS0FBSjtBQUFVaEwsTUFBTSxDQUFDTyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDeUssT0FBSyxDQUFDeEssQ0FBRCxFQUFHO0FBQUN3SyxTQUFLLEdBQUN4SyxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUk4RixPQUFKLEVBQVk1RSxZQUFaO0FBQXlCMUIsTUFBTSxDQUFDTyxJQUFQLENBQVksZ0JBQVosRUFBNkI7QUFBQytGLFNBQU8sQ0FBQzlGLENBQUQsRUFBRztBQUFDOEYsV0FBTyxHQUFDOUYsQ0FBUjtBQUFVLEdBQXRCOztBQUF1QmtCLGNBQVksQ0FBQ2xCLENBQUQsRUFBRztBQUFDa0IsZ0JBQVksR0FBQ2xCLENBQWI7QUFBZTs7QUFBdEQsQ0FBN0IsRUFBcUYsQ0FBckY7QUFBd0YsSUFBSXRCLFNBQUo7QUFBY2MsTUFBTSxDQUFDTyxJQUFQLENBQVksa0JBQVosRUFBK0I7QUFBQ3JCLFdBQVMsQ0FBQ3NCLENBQUQsRUFBRztBQUFDdEIsYUFBUyxHQUFDc0IsQ0FBVjtBQUFZOztBQUExQixDQUEvQixFQUEyRCxDQUEzRDs7QUFLM1BrQixZQUFZLENBQUN3TCxZQUFiLENBQTBCLFdBQTFCLEVBQXVDLENBQXZDOztBQUNBeEwsWUFBWSxDQUFDd0wsWUFBYixDQUEwQixRQUExQixFQUFvQyxDQUFwQzs7QUFDQXhMLFlBQVksQ0FBQ3dMLFlBQWIsQ0FBMEIsV0FBMUIsRUFBdUMsQ0FBdkM7O0FBRUE1TSxNQUFNLENBQUNxTSxPQUFQLENBQWUsY0FBZixFQUErQixZQUFZO0FBQ3ZDLE1BQUksQ0FBQyxLQUFLNUwsTUFBVixFQUFrQjtBQUNkLFNBQUtvTSxJQUFMO0FBQ0EsV0FBTyxJQUFQO0FBQ0g7O0FBRUQsU0FBT3pMLFlBQVksQ0FBQ29HLElBQWIsQ0FBa0I7QUFDckIzRyxhQUFTLEVBQUUsS0FBS0osTUFESztBQUVyQk0sVUFBTSxFQUFFbkMsU0FBUyxDQUFDTSxpQkFBVixDQUE0QkM7QUFGZixHQUFsQixDQUFQO0FBSUgsQ0FWRDtBQVlBYSxNQUFNLENBQUNxTSxPQUFQLENBQWUsYUFBZixFQUE4QixVQUFVUyxNQUFWLEVBQWtCO0FBQzVDLE1BQUksQ0FBQyxLQUFLck0sTUFBVixFQUFrQjtBQUNkLFdBQU8sSUFBUDtBQUNIOztBQUVELE1BQUksQ0FBQ2lLLEtBQUssQ0FBQ3FDLElBQU4sQ0FBV0QsTUFBWCxFQUFtQjtBQUFFRSxTQUFLLEVBQUVwSixNQUFUO0FBQWlCcUosV0FBTyxFQUFFaEo7QUFBMUIsR0FBbkIsQ0FBTCxFQUE4RDtBQUMxRCxXQUFPLElBQVA7QUFDSDs7QUFFRCxRQUFNK0QsS0FBSyxHQUFHO0FBQ1ZuSCxhQUFTLEVBQUUsS0FBS0o7QUFETixHQUFkOztBQUlBLE1BQUksQ0FBQ3FNLE1BQU0sQ0FBQ0csT0FBWixFQUFxQjtBQUNqQmpGLFNBQUssQ0FBQ2pILE1BQU4sR0FBZW5DLFNBQVMsQ0FBQ00saUJBQVYsQ0FBNEJDLE9BQTNDO0FBQ0g7O0FBRUQsU0FBT2lDLFlBQVksQ0FBQ29HLElBQWIsQ0FBa0JRLEtBQWxCLEVBQXlCO0FBQUVrRixRQUFJLEVBQUU7QUFBRTVLLGlCQUFXLEVBQUU7QUFBZixLQUFSO0FBQTRCMEssU0FBSyxFQUFFRixNQUFNLENBQUNFO0FBQTFDLEdBQXpCLENBQVA7QUFDSCxDQWxCRDtBQW9CQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEU7Ozs7Ozs7Ozs7O0FDbkRBLElBQUloTixNQUFKO0FBQVdOLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLE1BQUo7QUFBV1QsTUFBTSxDQUFDTyxJQUFQLENBQVksZ0JBQVosRUFBNkI7QUFBQ0UsUUFBTSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsVUFBTSxHQUFDRCxDQUFQO0FBQVM7O0FBQXBCLENBQTdCLEVBQW1ELENBQW5EO0FBQXNELElBQUl0QixTQUFKO0FBQWNjLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGtCQUFaLEVBQStCO0FBQUNyQixXQUFTLENBQUNzQixDQUFELEVBQUc7QUFBQ3RCLGFBQVMsR0FBQ3NCLENBQVY7QUFBWTs7QUFBMUIsQ0FBL0IsRUFBMkQsQ0FBM0Q7O0FBSS9JQyxNQUFNLENBQUN5TSxZQUFQLENBQW9CLFdBQXBCLEVBQWlDLENBQWpDOztBQUNBek0sTUFBTSxDQUFDeU0sWUFBUCxDQUFvQixRQUFwQixFQUE4QixDQUE5Qjs7QUFFQTVNLE1BQU0sQ0FBQ3FNLE9BQVAsQ0FBZSxlQUFmLEVBQWdDLFlBQVk7QUFDeEMsTUFBSSxDQUFDLEtBQUs1TCxNQUFWLEVBQWtCO0FBQ2QsV0FBTyxJQUFQO0FBQ0g7O0FBRUQsU0FBT04sTUFBTSxDQUFDcUgsSUFBUCxDQUFZO0FBQ2YzRyxhQUFTLEVBQUUsS0FBS0osTUFERDtBQUVmTSxVQUFNLEVBQUU7QUFDSm9NLFNBQUcsRUFBRSxDQUFDdk8sU0FBUyxDQUFDQyxhQUFWLENBQXdCQyxNQUF6QixFQUFpQ0YsU0FBUyxDQUFDQyxhQUFWLENBQXdCRyxNQUF6RDtBQUREO0FBRk8sR0FBWixDQUFQO0FBTUgsQ0FYRDtBQWFBZ0IsTUFBTSxDQUFDcU0sT0FBUCxDQUFlLGlCQUFmLEVBQWtDLFlBQVk7QUFDMUMsTUFBSSxDQUFDLEtBQUs1TCxNQUFWLEVBQWtCO0FBQ2QsV0FBTyxJQUFQO0FBQ0g7O0FBRUQsU0FBT04sTUFBTSxDQUFDcUgsSUFBUCxDQUFZO0FBQUUzRyxhQUFTLEVBQUUsS0FBS0osTUFBbEI7QUFBMEJNLFVBQU0sRUFBRW5DLFNBQVMsQ0FBQ0MsYUFBVixDQUF3QkU7QUFBMUQsR0FBWixDQUFQO0FBQ0gsQ0FORDtBQVFBaUIsTUFBTSxDQUFDcU0sT0FBUCxDQUFlLHVCQUFmLEVBQXdDLFVBQVU3TCxPQUFWLEVBQW1CO0FBQ3ZELE1BQUksQ0FBQyxLQUFLQyxNQUFWLEVBQWtCO0FBQ2QsV0FBTyxJQUFQO0FBQ0g7O0FBRUQsU0FBT04sTUFBTSxDQUFDcUgsSUFBUCxDQUFZO0FBQUV2RyxPQUFHLEVBQUVULE9BQVA7QUFBZ0JLLGFBQVMsRUFBRSxLQUFLSixNQUFoQztBQUF3Q00sVUFBTSxFQUFFbkMsU0FBUyxDQUFDQyxhQUFWLENBQXdCRTtBQUF4RSxHQUFaLENBQVA7QUFDSCxDQU5ELEU7Ozs7Ozs7Ozs7O0FDNUJBLElBQUlpQixNQUFKO0FBQVdOLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0QsUUFBTSxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsVUFBTSxHQUFDRSxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlnRixRQUFKO0FBQWF4RixNQUFNLENBQUNPLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDaUYsVUFBUSxDQUFDaEYsQ0FBRCxFQUFHO0FBQUNnRixZQUFRLEdBQUNoRixDQUFUO0FBQVc7O0FBQXhCLENBQTdCLEVBQXVELENBQXZEOztBQUc3RWdGLFFBQVEsQ0FBQzBILFlBQVQsQ0FBc0IsV0FBdEIsRUFBbUMsQ0FBbkM7O0FBRUE1TSxNQUFNLENBQUNxTSxPQUFQLENBQWUsVUFBZixFQUEyQixZQUFZO0FBQ25DLE1BQUksQ0FBQ3JNLE1BQU0sQ0FBQ1MsTUFBUCxFQUFMLEVBQXNCO0FBQ2xCLFdBQU8sSUFBUDtBQUNIOztBQUVELFNBQU95RSxRQUFRLENBQUNzQyxJQUFULENBQWM7QUFBRTNHLGFBQVMsRUFBRWIsTUFBTSxDQUFDUyxNQUFQO0FBQWIsR0FBZCxDQUFQO0FBQ0gsQ0FORCxFOzs7Ozs7Ozs7Ozs7QUNMQSxNQUFJVCxNQUFKO0FBQVdnRCxTQUFPLENBQUMvQyxJQUFSLENBQWEsZUFBYixFQUE2QjtBQUFDRCxVQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixZQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsR0FBN0IsRUFBbUQsQ0FBbkQ7QUFBc0QsTUFBSWtOLEdBQUo7QUFBUXBLLFNBQU8sQ0FBQy9DLElBQVIsQ0FBYSx3QkFBYixFQUFzQztBQUFDbU4sT0FBRyxDQUFDbE4sQ0FBRCxFQUFHO0FBQUNrTixTQUFHLEdBQUNsTixDQUFKO0FBQU07O0FBQWQsR0FBdEMsRUFBc0QsQ0FBdEQ7QUFBeUQsTUFBSW1OLEtBQUo7QUFBVXJLLFNBQU8sQ0FBQy9DLElBQVIsQ0FBYSxjQUFiLEVBQTRCO0FBQUNvTixTQUFLLENBQUNuTixDQUFELEVBQUc7QUFBQ21OLFdBQUssR0FBQ25OLENBQU47QUFBUTs7QUFBbEIsR0FBNUIsRUFBZ0QsQ0FBaEQ7QUFBbUQsTUFBSW9OLEtBQUo7QUFBVXRLLFNBQU8sQ0FBQy9DLElBQVIsQ0FBYSxjQUFiLEVBQTRCO0FBQUN5RyxXQUFPLENBQUN4RyxDQUFELEVBQUc7QUFBQ29OLFdBQUssR0FBQ3BOLENBQU47QUFBUTs7QUFBcEIsR0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsTUFBSXRCLFNBQUo7QUFBY29FLFNBQU8sQ0FBQy9DLElBQVIsQ0FBYSxrQkFBYixFQUFnQztBQUFDckIsYUFBUyxDQUFDc0IsQ0FBRCxFQUFHO0FBQUN0QixlQUFTLEdBQUNzQixDQUFWO0FBQVk7O0FBQTFCLEdBQWhDLEVBQTRELENBQTVEOztBQU81USxNQUFJLENBQUNpRCxNQUFNLENBQUNrQyxTQUFQLENBQWlCQyxZQUF0QixFQUFvQztBQUNoQ25DLFVBQU0sQ0FBQ2tDLFNBQVAsQ0FBaUJDLFlBQWpCLEdBQWdDLFlBQVk7QUFDeEMsYUFBTyxLQUFLQyxPQUFMLENBQWEsUUFBYixFQUF1QixVQUFVQyxHQUFWLEVBQWU7QUFBRSxlQUFPQSxHQUFHLENBQUNDLE1BQUosQ0FBVyxDQUFYLEVBQWNDLFdBQWQsS0FBOEJGLEdBQUcsQ0FBQ0csTUFBSixDQUFXLENBQVgsRUFBY0MsV0FBZCxFQUFyQztBQUFtRSxPQUEzRyxDQUFQO0FBQ0gsS0FGRDtBQUdIOztBQUVEd0gsS0FBRyxDQUFDRyxlQUFKLENBQW9CLGFBQXBCLEVBQW1DQyxNQUFNLENBQUNDLE9BQVAsQ0FBZSxpQ0FBZixDQUFuQztBQUVBQyxVQUFRLENBQUNDLFdBQVQsQ0FBcUJDLE9BQXJCLENBQTZCO0FBQ3pCOUIsY0FBVSxFQUFFLFlBQVk7QUFDcEIsYUFBTyxLQUFLL0ssTUFBTCxLQUFnQm5DLFNBQVMsQ0FBQ00saUJBQVYsQ0FBNEJFLFFBQW5EO0FBQ0g7QUFId0IsR0FBN0I7QUFNQSxRQUFNMEwsV0FBVyxHQUFHLEVBQXBCOztBQUVBQSxhQUFXLENBQUMrQyxTQUFaLEdBQXdCLENBQUNDLEVBQUQsRUFBSzlCLElBQUwsRUFBVytCLE9BQVgsRUFBb0JDLElBQXBCLEtBQTZCO0FBQ2pEVixTQUFLLENBQUMsQ0FBQ1EsRUFBRCxFQUFLOUIsSUFBTCxFQUFXK0IsT0FBWCxFQUFvQkMsSUFBcEIsQ0FBRCxFQUE0QixDQUFDN0ssTUFBRCxDQUE1QixDQUFMO0FBRUFuRCxVQUFNLENBQUNpTyxLQUFQLENBQWEsWUFBWTtBQUNyQlosV0FBSyxDQUFDYSxJQUFOLENBQVc7QUFDUEosVUFBRSxFQUFFQSxFQURHO0FBRVA5QixZQUFJLEVBQUVBLElBQUksSUFBSSxzQkFGUDtBQUdQK0IsZUFBTyxFQUFFQSxPQUhGO0FBSVBDLFlBQUksRUFBRUE7QUFKQyxPQUFYO0FBTUgsS0FQRDtBQVFILEdBWEQ7O0FBYUFsRCxhQUFXLENBQUNvQixhQUFaLEdBQTRCLENBQUM0QixFQUFELEVBQUs5QixJQUFMLEVBQVcrQixPQUFYLEVBQW9CSSxZQUFwQixFQUFrQzNDLElBQWxDLEtBQTJDO0FBQ25FLFFBQUk0QyxJQUFJLEdBQUdoQixHQUFHLENBQUNpQixNQUFKLENBQVdGLFlBQVgsRUFBeUIzQyxJQUF6QixDQUFYO0FBRUF4TCxVQUFNLENBQUNpTyxLQUFQLENBQWEsWUFBWTtBQUNyQlosV0FBSyxDQUFDYSxJQUFOLENBQVc7QUFDUEosVUFBRSxFQUFFQSxFQURHO0FBRVA5QixZQUFJLEVBQUVBLElBQUksSUFBSSxzQkFGUDtBQUdQK0IsZUFBTyxFQUFFQSxPQUhGO0FBSVBPLFlBQUksRUFBRUY7QUFKQyxPQUFYO0FBTUgsS0FQRDtBQVFILEdBWEQ7O0FBYUExTyxRQUFNLENBQUNDLE9BQVAsR0FBaUI7QUFBRW1MO0FBQUYsR0FBakI7Ozs7Ozs7Ozs7OztBQ2pEQSxJQUFJOUssTUFBSjtBQUFXTixNQUFNLENBQUNPLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUVYRixNQUFNLENBQUN1TyxPQUFQLENBQWUsTUFBTSxDQUNuQjtBQUNELENBRkQsRTs7Ozs7Ozs7Ozs7QUNGQTdPLE1BQU0sQ0FBQzhPLE1BQVAsQ0FBYztBQUFDQyxzQkFBb0IsRUFBQyxNQUFJQTtBQUExQixDQUFkOztBQUErRCxJQUFJaE4sQ0FBSjs7QUFBTS9CLE1BQU0sQ0FBQ08sSUFBUCxDQUFZLG1CQUFaLEVBQWdDO0FBQUN3QixHQUFDLENBQUN2QixDQUFELEVBQUc7QUFBQ3VCLEtBQUMsR0FBQ3ZCLENBQUY7QUFBSTs7QUFBVixDQUFoQyxFQUE0QyxDQUE1QztBQUErQyxJQUFJd04sUUFBSjtBQUFhaE8sTUFBTSxDQUFDTyxJQUFQLENBQVksbUJBQVosRUFBZ0M7QUFBQ3lOLFVBQVEsQ0FBQ3hOLENBQUQsRUFBRztBQUFDd04sWUFBUSxHQUFDeE4sQ0FBVDtBQUFXOztBQUF4QixDQUFoQyxFQUEwRCxDQUExRDtBQUE2RCxJQUFJd08sS0FBSjtBQUFVaFAsTUFBTSxDQUFDTyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDeU8sT0FBSyxDQUFDeE8sQ0FBRCxFQUFHO0FBQUN3TyxTQUFLLEdBQUN4TyxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUl5TyxPQUFKO0FBQVlqUCxNQUFNLENBQUNPLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDME8sU0FBTyxDQUFDek8sQ0FBRCxFQUFHO0FBQUN5TyxXQUFPLEdBQUN6TyxDQUFSO0FBQVU7O0FBQXRCLENBQTdCLEVBQXFELENBQXJEOztBQU10USxNQUFNME8sT0FBTyxHQUFHLFNBQVNBLE9BQVQsQ0FBaUJDLFFBQWpCLEVBQTJCO0FBQ3ZDLFFBQU1DLEVBQUUsR0FBR0MsUUFBUSxDQUFDQyxhQUFULENBQXVCLEtBQXZCLENBQVg7QUFDQUQsVUFBUSxDQUFDWCxJQUFULENBQWNhLFdBQWQsQ0FBMEJILEVBQTFCOztBQUVBLE1BQUk7QUFDQUQsWUFBUSxDQUFDQyxFQUFELENBQVI7QUFDSCxHQUZELFNBRVU7QUFDTkMsWUFBUSxDQUFDWCxJQUFULENBQWNjLFdBQWQsQ0FBMEJKLEVBQTFCO0FBQ0g7QUFDSixDQVREOztBQVdPLE1BQU1MLG9CQUFvQixHQUFHLFNBQVNBLG9CQUFULENBQThCVSxRQUE5QixFQUF3QzNELElBQXhDLEVBQThDcUQsUUFBOUMsRUFBd0Q7QUFDeEZELFNBQU8sQ0FBRUUsRUFBRCxJQUFRO0FBQ1osVUFBTU0sV0FBVyxHQUFHM04sQ0FBQyxDQUFDNE4sUUFBRixDQUFXRixRQUFYLElBQXVCekIsUUFBUSxDQUFDeUIsUUFBRCxDQUEvQixHQUE0Q0EsUUFBaEU7QUFDQVQsU0FBSyxDQUFDWSxjQUFOLENBQXFCRixXQUFyQixFQUFrQzVELElBQWxDLEVBQXdDc0QsRUFBeEM7QUFDQUgsV0FBTyxDQUFDWSxLQUFSO0FBQ0FWLFlBQVEsQ0FBQ0MsRUFBRCxFQUFLTSxXQUFMLENBQVI7QUFDSCxHQUxNLENBQVA7QUFNSCxDQVBNLEM7Ozs7Ozs7Ozs7OztBQ2pCUCxNQUFJbk4sTUFBSjtBQUFXZSxTQUFPLENBQUMvQyxJQUFSLENBQWEsZUFBYixFQUE2QjtBQUFDZ0MsVUFBTSxDQUFDL0IsQ0FBRCxFQUFHO0FBQUMrQixZQUFNLEdBQUMvQixDQUFQO0FBQVM7O0FBQXBCLEdBQTdCLEVBQW1ELENBQW5EOztBQUFzRCxNQUFJdUIsQ0FBSjs7QUFBTXVCLFNBQU8sQ0FBQy9DLElBQVIsQ0FBYSxtQkFBYixFQUFpQztBQUFDd0IsS0FBQyxDQUFDdkIsQ0FBRCxFQUFHO0FBQUN1QixPQUFDLEdBQUN2QixDQUFGO0FBQUk7O0FBQVYsR0FBakMsRUFBNkMsQ0FBN0M7QUFBZ0QsTUFBSXRCLFNBQUo7QUFBY29FLFNBQU8sQ0FBQy9DLElBQVIsQ0FBYSxrQkFBYixFQUFnQztBQUFDckIsYUFBUyxDQUFDc0IsQ0FBRCxFQUFHO0FBQUN0QixlQUFTLEdBQUNzQixDQUFWO0FBQVk7O0FBQTFCLEdBQWhDLEVBQTRELENBQTVEO0FBS3JJLFFBQU1zUCxRQUFRLEdBQUc7QUFFYkMsZ0JBQVksQ0FBQ0MsVUFBRCxFQUFhO0FBQ3JCLFVBQUlDLEtBQUssR0FBRyxFQUFaOztBQUVBLFVBQUksQ0FBQ2xPLENBQUMsQ0FBQ29KLFdBQUYsQ0FBYzZFLFVBQWQsQ0FBTCxFQUFnQztBQUM1QkMsYUFBSyxHQUFHRCxVQUFSO0FBQ0g7O0FBRUQsWUFBTXhLLFFBQVEsR0FBRyxFQUFqQjtBQUNBQSxjQUFRLENBQUNDLGVBQVQsR0FBMkIsY0FBM0I7QUFDQUQsY0FBUSxDQUFDZCxnQkFBVCxHQUE0Qix3QkFBNUI7QUFDQWMsY0FBUSxDQUFDYixjQUFULEdBQTBCLHNCQUExQjtBQUNBYSxjQUFRLENBQUNaLGNBQVQsR0FBMEIsc0JBQTFCO0FBRUEsYUFBT1ksUUFBUDtBQUNILEtBaEJZOztBQWlCYjBLLHdCQUFvQixDQUFDRixVQUFELEVBQWE7QUFDN0IsVUFBSUMsS0FBSyxHQUFHLEVBQVo7O0FBRUEsVUFBSSxDQUFDbE8sQ0FBQyxDQUFDb0osV0FBRixDQUFjNkUsVUFBZCxDQUFMLEVBQWdDO0FBQzVCQyxhQUFLLEdBQUdELFVBQVI7QUFDSDs7QUFFRCxZQUFNNUosV0FBVyxHQUFHLEVBQXBCO0FBRUFBLGlCQUFXLENBQUNzQixJQUFaLENBQWlCO0FBQUUxQyxZQUFJLEVBQUUsU0FBUjtBQUFtQk0sYUFBSyxFQUFFO0FBQTFCLE9BQWpCO0FBQ0FjLGlCQUFXLENBQUNzQixJQUFaLENBQWlCO0FBQUUxQyxZQUFJLEVBQUUsU0FBUjtBQUFtQk0sYUFBSyxFQUFFO0FBQTFCLE9BQWpCO0FBQ0FjLGlCQUFXLENBQUNzQixJQUFaLENBQWlCO0FBQUUxQyxZQUFJLEVBQUUsV0FBUjtBQUFxQk0sYUFBSyxFQUFFO0FBQTVCLE9BQWpCO0FBQ0FjLGlCQUFXLENBQUNzQixJQUFaLENBQWlCO0FBQUUxQyxZQUFJLEVBQUUsVUFBUjtBQUFvQk0sYUFBSyxFQUFFO0FBQTNCLE9BQWpCO0FBQ0FjLGlCQUFXLENBQUNzQixJQUFaLENBQWlCO0FBQUUxQyxZQUFJLEVBQUUsVUFBUjtBQUFvQk0sYUFBSyxFQUFFO0FBQTNCLE9BQWpCO0FBRUEsYUFBT2MsV0FBUDtBQUNILEtBakNZOztBQW1DYitKLG1CQUFlLENBQUNILFVBQUQsRUFBYTtBQUN4QixVQUFJQyxLQUFLLEdBQUcsRUFBWjs7QUFFQSxVQUFJLENBQUNsTyxDQUFDLENBQUNvSixXQUFGLENBQWM2RSxVQUFkLENBQUwsRUFBZ0M7QUFDNUJDLGFBQUssR0FBR0QsVUFBUjtBQUNIOztBQUVELFlBQU1JLFdBQVcsR0FBRyxFQUFwQjtBQUVBQSxpQkFBVyxDQUFDN08sR0FBWixHQUFrQjBPLEtBQUssQ0FBQzFPLEdBQU4sSUFBYWdCLE1BQU0sQ0FBQzhGLEVBQVAsRUFBL0I7QUFDQStILGlCQUFXLENBQUNqUCxTQUFaLEdBQXdCOE8sS0FBSyxDQUFDOU8sU0FBTixJQUFtQm9CLE1BQU0sQ0FBQzhGLEVBQVAsRUFBM0M7QUFDQStILGlCQUFXLENBQUNqTSxTQUFaLEdBQXdCOEwsS0FBSyxDQUFDOUwsU0FBTixJQUFtQixJQUFJeEIsSUFBSixFQUEzQztBQUNBeU4saUJBQVcsQ0FBQ3RNLEtBQVosR0FBb0JtTSxLQUFLLENBQUNuTSxLQUFOLElBQWUsWUFBbkM7QUFDQXNNLGlCQUFXLENBQUMvTyxNQUFaLEdBQXFCNE8sS0FBSyxDQUFDNU8sTUFBTixJQUFnQm5DLFNBQVMsQ0FBQ00saUJBQVYsQ0FBNEJDLE9BQWpFO0FBQ0EyUSxpQkFBVyxDQUFDeE4sV0FBWixHQUEwQnFOLEtBQUssQ0FBQ3JOLFdBQU4sSUFBcUIsSUFBL0M7QUFFQSxhQUFPd04sV0FBUDtBQUNILEtBcERZOztBQXNEYkMsaUJBQWEsQ0FBQ0wsVUFBRCxFQUFhO0FBQ3RCLFVBQUlDLEtBQUssR0FBRyxFQUFaOztBQUVBLFVBQUksQ0FBQ2xPLENBQUMsQ0FBQ29KLFdBQUYsQ0FBYzZFLFVBQWQsQ0FBTCxFQUFnQztBQUM1QkMsYUFBSyxHQUFHRCxVQUFSO0FBQ0g7O0FBRUQsWUFBTXpNLFNBQVMsR0FBRyxFQUFsQjtBQUVBQSxlQUFTLENBQUMxQyxNQUFWLEdBQW1Cb1AsS0FBSyxDQUFDcFAsTUFBTixJQUFnQjBCLE1BQU0sQ0FBQzhGLEVBQVAsRUFBbkM7QUFDQTlFLGVBQVMsQ0FBQ08sS0FBVixHQUFrQm1NLEtBQUssQ0FBQ25NLEtBQU4sSUFBZSxZQUFqQztBQUNBUCxlQUFTLENBQUNsQyxNQUFWLEdBQW1CNE8sS0FBSyxDQUFDNU8sTUFBTixJQUFnQm5DLFNBQVMsQ0FBQ00saUJBQVYsQ0FBNEJDLE9BQS9EO0FBQ0E4RCxlQUFTLENBQUNVLFFBQVYsR0FBcUJnTSxLQUFLLENBQUNoTSxRQUFOLElBQWtCMUIsTUFBTSxDQUFDK04sTUFBUCxDQUFjLENBQUNwUixTQUFTLENBQUNTLGNBQVYsQ0FBeUJDLEtBQTFCLEVBQWlDVixTQUFTLENBQUNTLGNBQVYsQ0FBeUJFLEdBQTFELEVBQStEWCxTQUFTLENBQUNTLGNBQVYsQ0FBeUJHLEdBQXhGLENBQWQsQ0FBdkM7QUFDQXlELGVBQVMsQ0FBQ0gsS0FBVixHQUFrQjZNLEtBQUssQ0FBQzdNLEtBQU4sSUFBZSxDQUFqQztBQUNBRyxlQUFTLENBQUNZLFNBQVYsR0FBc0I4TCxLQUFLLENBQUM5TCxTQUFOLElBQW1CLElBQUl4QixJQUFKLEVBQXpDO0FBRUEsYUFBT1ksU0FBUDtBQUNILEtBdkVZOztBQXlFYmdOLGtCQUFjLENBQUNQLFVBQUQsRUFBYVEsS0FBYixFQUFvQjtBQUM5QixZQUFNck8sS0FBSyxHQUFHLEVBQWQ7QUFFQSxVQUFJLENBQUNxTyxLQUFMLEVBQVlBLEtBQUssR0FBRyxDQUFSOztBQUVaLFdBQUssSUFBSXpJLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUd5SSxLQUFwQixFQUEyQnpJLENBQUMsSUFBSSxDQUFoQyxFQUFtQztBQUMvQjVGLGFBQUssQ0FBQ3VGLElBQU4sQ0FBVyxLQUFLMkksYUFBTCxDQUFtQkwsVUFBbkIsQ0FBWCxFQUQrQixDQUNZO0FBQzlDOztBQUVELGFBQU83TixLQUFQO0FBQ0gsS0FuRlk7O0FBcUZic08sYUFBUyxDQUFDVCxVQUFELEVBQWE7QUFDbEIsVUFBSUMsS0FBSyxHQUFHLEVBQVo7O0FBRUEsVUFBSSxDQUFDbE8sQ0FBQyxDQUFDb0osV0FBRixDQUFjNkUsVUFBZCxDQUFMLEVBQWdDO0FBQzVCQyxhQUFLLEdBQUdELFVBQVI7QUFDSDs7QUFFRCxZQUFNVSxLQUFLLEdBQUcsRUFBZDtBQUVBQSxXQUFLLENBQUNuUCxHQUFOLEdBQVkwTyxLQUFLLENBQUMxTyxHQUFOLElBQWFnQixNQUFNLENBQUM4RixFQUFQLEVBQXpCO0FBQ0FxSSxXQUFLLENBQUN2TSxTQUFOLEdBQWtCLElBQUl4QixJQUFKLEVBQWxCO0FBQ0ErTixXQUFLLENBQUN2UCxTQUFOLEdBQWtCOE8sS0FBSyxDQUFDOU8sU0FBTixJQUFtQm9CLE1BQU0sQ0FBQzhGLEVBQVAsRUFBckM7QUFDQXFJLFdBQUssQ0FBQzVNLEtBQU4sR0FBY21NLEtBQUssQ0FBQ25NLEtBQU4sSUFBZSxZQUE3QjtBQUNBNE0sV0FBSyxDQUFDclAsTUFBTixHQUFlNE8sS0FBSyxDQUFDNU8sTUFBTixJQUFnQm5DLFNBQVMsQ0FBQ0MsYUFBVixDQUF3QkMsTUFBdkQ7QUFDQXNSLFdBQUssQ0FBQ3ZPLEtBQU4sR0FBYzhOLEtBQUssQ0FBQzlOLEtBQU4sSUFBZSxLQUFLb08sY0FBTCxDQUFvQixFQUFwQixFQUF3Qk4sS0FBSyxDQUFDTyxLQUFOLElBQWUsQ0FBdkMsQ0FBN0I7QUFDQUUsV0FBSyxDQUFDek4sYUFBTixHQUFzQmxCLENBQUMsQ0FBQ29KLFdBQUYsQ0FBYzhFLEtBQUssQ0FBQ2hOLGFBQXBCLElBQXFDLEtBQXJDLEdBQTZDZ04sS0FBSyxDQUFDaE4sYUFBekU7QUFDQXlOLFdBQUssQ0FBQ2pNLFVBQU4sR0FBbUJ3TCxLQUFLLENBQUN4TCxVQUFOLElBQW9CLElBQUk5QixJQUFKLEVBQXZDO0FBQ0ErTixXQUFLLENBQUNoTSxnQkFBTixHQUF5Qix3QkFBekI7QUFDQWdNLFdBQUssQ0FBQy9MLGNBQU4sR0FBdUIsc0JBQXZCO0FBQ0ErTCxXQUFLLENBQUM5TCxjQUFOLEdBQXVCLHNCQUF2Qjs7QUFDQSxVQUFJcUwsS0FBSyxDQUFDcEwsV0FBVixFQUF1QjtBQUNuQjZMLGFBQUssQ0FBQzdMLFdBQU4sR0FBb0JvTCxLQUFLLENBQUNwTCxXQUExQjtBQUNIOztBQUVELGFBQU82TCxLQUFQO0FBQ0gsS0E5R1k7O0FBZ0hiQyxjQUFVLENBQUNYLFVBQUQsRUFBYTtBQUNuQixVQUFJQyxLQUFLLEdBQUcsRUFBWjs7QUFFQSxVQUFJLENBQUNsTyxDQUFDLENBQUNvSixXQUFGLENBQWM2RSxVQUFkLENBQUwsRUFBZ0M7QUFDNUJDLGFBQUssR0FBR0QsVUFBUjtBQUNIOztBQUVELFlBQU1VLEtBQUssR0FBRyxFQUFkO0FBRUFBLFdBQUssQ0FBQ25QLEdBQU4sR0FBWTBPLEtBQUssQ0FBQzFPLEdBQU4sSUFBYWdCLE1BQU0sQ0FBQzhGLEVBQVAsRUFBekI7QUFDQXFJLFdBQUssQ0FBQ3ZNLFNBQU4sR0FBa0IsSUFBSXhCLElBQUosRUFBbEI7QUFDQStOLFdBQUssQ0FBQ3ZQLFNBQU4sR0FBa0I4TyxLQUFLLENBQUM5TyxTQUFOLElBQW1Cb0IsTUFBTSxDQUFDOEYsRUFBUCxFQUFyQztBQUNBcUksV0FBSyxDQUFDNU0sS0FBTixHQUFjbU0sS0FBSyxDQUFDbk0sS0FBTixJQUFlLFlBQTdCO0FBQ0E0TSxXQUFLLENBQUNyUCxNQUFOLEdBQWU0TyxLQUFLLENBQUM1TyxNQUFOLElBQWdCbkMsU0FBUyxDQUFDQyxhQUFWLENBQXdCQyxNQUF2RDtBQUNBc1IsV0FBSyxDQUFDdk8sS0FBTixHQUFjOE4sS0FBSyxDQUFDOU4sS0FBTixJQUFlLEtBQUtvTyxjQUFMLENBQW9CUCxVQUFwQixFQUFnQ0MsS0FBSyxDQUFDTyxLQUFOLElBQWUsQ0FBL0MsQ0FBN0I7QUFDQUUsV0FBSyxDQUFDek4sYUFBTixHQUFzQmxCLENBQUMsQ0FBQ29KLFdBQUYsQ0FBYzhFLEtBQUssQ0FBQ2hOLGFBQXBCLElBQXFDLEtBQXJDLEdBQTZDZ04sS0FBSyxDQUFDaE4sYUFBekU7QUFDQXlOLFdBQUssQ0FBQ2pNLFVBQU4sR0FBbUJ3TCxLQUFLLENBQUN4TCxVQUFOLElBQW9CLElBQUk5QixJQUFKLEVBQXZDO0FBQ0ErTixXQUFLLENBQUNoTSxnQkFBTixHQUF5Qix3QkFBekI7QUFDQWdNLFdBQUssQ0FBQy9MLGNBQU4sR0FBdUIsc0JBQXZCO0FBQ0ErTCxXQUFLLENBQUM5TCxjQUFOLEdBQXVCLHNCQUF2Qjs7QUFDQSxVQUFJcUwsS0FBSyxDQUFDcEwsV0FBVixFQUF1QjtBQUNuQjZMLGFBQUssQ0FBQzdMLFdBQU4sR0FBb0JvTCxLQUFLLENBQUNwTCxXQUExQjtBQUNIOztBQUVELGFBQU82TCxLQUFQO0FBQ0g7O0FBeklZLEdBQWpCO0FBNElBMVEsUUFBTSxDQUFDQyxPQUFQLEdBQWlCO0FBQUU2UDtBQUFGLEdBQWpCIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBDb25zdGFudHMgPSB7XG4gICAgUmV0cm9TdGF0dXNlczoge1xuICAgICAgICBBQ1RJVkU6ICdBY3RpdmUnLFxuICAgICAgICBBUkNISVZFRDogJ0FyY2hpdmVkJyxcbiAgICAgICAgRlJPWkVOOiAnRnJvemVuJyxcbiAgICAgICAgdmFsdWVzOiBbJ0FjdGl2ZScsICdBcmNoaXZlZCcsICdGcm96ZW4nXVxuICAgIH0sXG4gICAgUmV0cm9JdGVtU3RhdHVzZXM6IHtcbiAgICAgICAgUEVORElORzogJ1BlbmRpbmcnLFxuICAgICAgICBDT01QTEVURTogJ0NvbXBsZXRlJyxcbiAgICAgICAgdmFsdWVzOiBbJ1BlbmRpbmcnLCAnQ29tcGxldGUnXVxuICAgIH0sXG4gICAgUmV0cm9JdGVtVHlwZXM6IHtcbiAgICAgICAgSEFQUFk6ICdIYXBweScsXG4gICAgICAgIE1FSDogJ01laCcsXG4gICAgICAgIFNBRDogJ1NhZCcsXG4gICAgICAgIEFDVElPTjogJ0FjdGlvbicsXG4gICAgICAgIHZhbHVlczogWydIYXBweScsICdNZWgnLCAnU2FkJywgJ0FjdGlvbiddXG4gICAgfVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHsgQ29uc3RhbnRzIH1cbiIsImNvbnN0IExvZ2dlciA9IHtcbiAgICBsb2c6IChtZXNzYWdlKSA9PiB7XG4gICAgICAgIGNvbnNvbGUubG9nKG1lc3NhZ2UpXG4gICAgfVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHsgTG9nZ2VyIH1cbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBSZXRyb3MgfSBmcm9tICcuL3NlcXVlbnQnXG5pbXBvcnQgeyBTY2hlbWFzIH0gZnJvbSAnLi9zY2hlbWFzJ1xuaW1wb3J0IHsgQ29uc3RhbnRzIH0gZnJvbSAnLi9jb25zdGFudHMnXG5pbXBvcnQgeyBMb2dnZXIgfSBmcm9tICcuL2xvZ2dlcidcblxuTWV0ZW9yLm1ldGhvZHMoe1xuXG4gICAgY29tcGxldGVSZXRyb0l0ZW0oaXRlbUlkKSB7XG4gICAgICAgIGNvbnN0IHJldHJvSWQgPSAnJ1xuXG4gICAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1sb2dnZWQtaW4nLCAnWW91IG11c3QgYmUgbG9nZ2VkIGludG8gYSByZXRybyBib2FyZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gdmFsaWRhdGUgaXRlbSB0eXBlXG5cbiAgICAgICAgY29uc3QgcmV0cm8gPSBSZXRyb3MuZmluZE9uZSh7XG4gICAgICAgICAgICBjcmVhdGVkQnk6IHRoaXMudXNlcklkLFxuICAgICAgICAgICAgJG9yOiBbXG4gICAgICAgICAgICAgICAgeyBzdGF0dXM6IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkFDVElWRSB9LFxuICAgICAgICAgICAgICAgIHsgc3RhdHVzOiBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5GUk9aRU4gfVxuICAgICAgICAgICAgXVxuICAgICAgICB9KVxuXG4gICAgICAgIC8vIG5lZWQgdG8gc2VlIGlmIHRoZXJlIGlzXG4gICAgICAgIGlmICghcmV0cm8pIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1mb3VuZCcsICdSZXRybyBub3QgZm91bmQhJylcbiAgICAgICAgfVxuXG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIFJldHJvcy51cGRhdGUoXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBfaWQ6IHJldHJvLl9pZCxcbiAgICAgICAgICAgICAgICAgICAgJ2l0ZW1zLml0ZW1JZCc6IGl0ZW1JZFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAnaXRlbXMuJC5zdGF0dXMnOiBDb25zdGFudHMuUmV0cm9JdGVtU3RhdHVzZXMuQ09NUExFVEVcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIClcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBMb2dnZXIubG9nKGVycilcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ3VwZGF0ZS1mYWlsZWQnLCAnV2UgY291bGQgbm90IGNvbXBsZXRlIHRoZSByZXRybyBpdGVtIC0gcGxlYXNlIHRyeSBhZ2FpbiBsYXRlcicpXG4gICAgICAgIH1cbiAgICB9XG5cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgUmV0cm9zLCBSZXRyb0FjdGlvbnMgfSBmcm9tICcuL3NlcXVlbnQnXG5pbXBvcnQgeyBTY2hlbWFzIH0gZnJvbSAnLi9zY2hlbWFzJ1xuaW1wb3J0IHsgQ29uc3RhbnRzIH0gZnJvbSAnLi9jb25zdGFudHMnXG5pbXBvcnQgeyBMb2dnZXIgfSBmcm9tICcuL2xvZ2dlcidcblxuTWV0ZW9yLm1ldGhvZHMoe1xuXG4gICAgcmVtb3ZlQWN0aW9uKGFjdGlvbklkKSB7XG4gICAgICAgIGNvbnN0IHJldHJvSWQgPSAnJ1xuXG4gICAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1sb2dnZWQtaW4nLCAnWW91IG11c3QgYmUgbG9nZ2VkIGludG8gYSByZXRybyBib2FyZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgYWN0aW9uID0gUmV0cm9BY3Rpb25zLmZpbmRPbmUoeyBfaWQ6IGFjdGlvbklkLCBjcmVhdGVkQnk6IHRoaXMudXNlcklkIH0pXG5cbiAgICAgICAgaWYgKCFhY3Rpb24pIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1mb3VuZCcsICdBY3Rpb24gbm90IGZvdW5kIScpXG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIFJldHJvQWN0aW9ucy5yZW1vdmUoeyBfaWQ6IGFjdGlvbklkIH0pXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgTG9nZ2VyLmxvZyhlcnIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdkZWxldGUtZmFpbGVkJywgJ1dlIGNvdWxkIG5vdCBkZWxldGUgdGhlIGFjdGlvbiAtIHBsZWFzZSB0cnkgYWdhaW4gbGF0ZXInKVxuICAgICAgICB9XG4gICAgfVxuXG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IF8gfSBmcm9tICdtZXRlb3IvdW5kZXJzY29yZSdcbmltcG9ydCB7IFJldHJvcyB9IGZyb20gJy4vc2VxdWVudCdcbmltcG9ydCB7IFNjaGVtYXMgfSBmcm9tICcuL3NjaGVtYXMnXG5pbXBvcnQgeyBDb25zdGFudHMgfSBmcm9tICcuL2NvbnN0YW50cydcbmltcG9ydCB7IExvZ2dlciB9IGZyb20gJy4vbG9nZ2VyJ1xuXG5NZXRlb3IubWV0aG9kcyh7XG5cbiAgICByZW1vdmVSZXRyb0l0ZW0oaXRlbUlkKSB7XG4gICAgICAgIGNvbnN0IHJldHJvSWQgPSAnJ1xuXG4gICAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1sb2dnZWQtaW4nLCAnWW91IG11c3QgYmUgbG9nZ2VkIGludG8gYSByZXRybyBib2FyZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcmV0cm8gPSBSZXRyb3MuZmluZE9uZSh7XG4gICAgICAgICAgICBjcmVhdGVkQnk6IHRoaXMudXNlcklkLFxuICAgICAgICAgICAgJG9yOiBbXG4gICAgICAgICAgICAgICAgeyBzdGF0dXM6IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkFDVElWRSB9LFxuICAgICAgICAgICAgICAgIHsgc3RhdHVzOiBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5GUk9aRU4gfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgIH0pXG5cbiAgICAgICAgLy8gbmVlZCB0byBzZWUgaWYgdGhlcmUgaXNcbiAgICAgICAgaWYgKCFyZXRybykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWZvdW5kJywgJ1JldHJvIG5vdCBmb3VuZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcmV0cm9JdGVtID0gXy5maWx0ZXIocmV0cm8uaXRlbXMsIGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgICAgICByZXR1cm4gaXRlbS5pdGVtSWQgPT09IGl0ZW1JZFxuICAgICAgICB9KVxuXG4gICAgICAgIGlmIChyZXRyb0l0ZW0ubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtZm91bmQnLCAnUmV0cm8gSXRlbSBub3QgZm91bmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBSZXRyb3MudXBkYXRlKFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgX2lkOiByZXRyby5faWQsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICRwdWxsOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpdGVtczogeyBpdGVtSWQ6IGl0ZW1JZCB9LFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICApXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgTG9nZ2VyLmxvZyhlcnIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCd1cGRhdGUtZmFpbGVkJywgJ1dlIGNvdWxkIG5vdCByZW1vdmUgcmV0cm8gaXRlbSAtIHBsZWFzZSB0cnkgYWdhaW4gbGF0ZXInKVxuICAgICAgICB9XG4gICAgfSxcblxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBSYW5kb20gfSBmcm9tICdtZXRlb3IvcmFuZG9tJ1xuaW1wb3J0IHsgUmV0cm9zLCBSZXRyb0FjdGlvbnMgfSBmcm9tICcuLi9saWIvc2VxdWVudCdcbmltcG9ydCB7IFNjaGVtYXMgfSBmcm9tICcuL3NjaGVtYXMnXG5pbXBvcnQgeyBDb25zdGFudHMgfSBmcm9tICcuL2NvbnN0YW50cydcbmltcG9ydCB7IExvZ2dlciB9IGZyb20gJy4vbG9nZ2VyJ1xuXG5NZXRlb3IubWV0aG9kcyh7XG5cbiAgICB0b2dnbGVBY3Rpb24oYWN0aW9uSWQpIHtcbiAgICAgICAgY29uc3QgcmV0cm9JZCA9ICcnXG5cbiAgICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWxvZ2dlZC1pbicsICdZb3UgbXVzdCBiZSBsb2dnZWQgaW50byBhIHJldHJvIGJvYXJkIScpXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBhY3Rpb24gPSBSZXRyb0FjdGlvbnMuZmluZE9uZSh7IF9pZDogYWN0aW9uSWQsIGNyZWF0ZWRCeTogdGhpcy51c2VySWQgfSlcblxuICAgICAgICBpZiAoIWFjdGlvbikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWZvdW5kJywgJ1JldHJvQWN0aW9uIG5vdCBmb3VuZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgbmV3VmFsdWUgPSBhY3Rpb24uc3RhdHVzID09PSBDb25zdGFudHMuUmV0cm9JdGVtU3RhdHVzZXMuUEVORElORyA/IENvbnN0YW50cy5SZXRyb0l0ZW1TdGF0dXNlcy5DT01QTEVURSA6IENvbnN0YW50cy5SZXRyb0l0ZW1TdGF0dXNlcy5QRU5ESU5HXG5cbiAgICAgICAgbGV0IG5ld0RhdGVcblxuICAgICAgICBpZiAobmV3VmFsdWUgPT09IENvbnN0YW50cy5SZXRyb0l0ZW1TdGF0dXNlcy5DT01QTEVURSkge1xuICAgICAgICAgICAgbmV3RGF0ZSA9IG5ldyBEYXRlKClcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG5ld0RhdGUgPSBudWxsXG4gICAgICAgIH1cblxuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBSZXRyb0FjdGlvbnMudXBkYXRlKFxuICAgICAgICAgICAgICAgIHsgX2lkOiBhY3Rpb25JZCB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgJHNldDpcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBuZXdWYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbXBsZXRlZEF0OiBuZXdEYXRlXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgTG9nZ2VyLmxvZyhlcnIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdkZWxldGUtZmFpbGVkJywgJ1dlIGNvdWxkIG5vdCBkZWxldGUgdGhlIGFjdGlvbiAtIHBsZWFzZSB0cnkgYWdhaW4gbGF0ZXInKVxuICAgICAgICB9XG4gICAgfVxuXG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IFJldHJvcywgUmV0cm9BY3Rpb25zIH0gZnJvbSAnLi9zZXF1ZW50J1xuaW1wb3J0IHsgU2NoZW1hcyB9IGZyb20gJy4vc2NoZW1hcydcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4vY29uc3RhbnRzJ1xuaW1wb3J0IHsgTG9nZ2VyIH0gZnJvbSAnLi9sb2dnZXInXG5cbk1ldGVvci5tZXRob2RzKHtcblxuICAgIHRvZ2dsZVJldHJvRnJvemVuKCkge1xuICAgICAgICBjb25zdCByZXRyb0lkID0gJydcblxuICAgICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtbG9nZ2VkLWluJywgJ1lvdSBtdXN0IGJlIGxvZ2dlZCBpbnRvIGEgcmV0cm8gYm9hcmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHZhbGlkYXRlIGl0ZW0gdHlwZVxuXG4gICAgICAgIGNvbnN0IHJldHJvID0gUmV0cm9zLmZpbmRPbmUoe1xuICAgICAgICAgICAgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCxcbiAgICAgICAgICAgICRvcjpcbiAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICB7IHN0YXR1czogQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuQUNUSVZFIH0sXG4gICAgICAgICAgICAgICAgeyBzdGF0dXM6IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkZST1pFTiB9XG4gICAgICAgICAgICBdXG4gICAgICAgIH0pXG5cbiAgICAgICAgLy8gbmVlZCB0byBzZWUgaWYgdGhlcmUgaXNcbiAgICAgICAgaWYgKCFyZXRybykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWZvdW5kJywgJ1JldHJvIG5vdCBmb3VuZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHJldHJvLnN0YXR1cyA9PT0gQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuQVJDSElWRUQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ2ludmFsaWQtc3RhdGUnLCAnUmV0cm8gbXVzdCBub3QgYmUgYXJjaGl2ZWQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IG5ld1N0YXR1cyA9IHJldHJvLnN0YXR1cyA9PT0gQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuRlJPWkVOID8gQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuQUNUSVZFIDogQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuRlJPWkVOXG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIFJldHJvcy51cGRhdGUoXG4gICAgICAgICAgICAgICAgeyBfaWQ6IHJldHJvLl9pZCB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgJHNldDpcbiAgICAgICAgICAgICAgICAgICAgeyBzdGF0dXM6IG5ld1N0YXR1cyB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKVxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIExvZ2dlci5sb2coZXJyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcigndXBkYXRlLWZhaWxlZCcsICdXZSBjb3VsZCBub3QgZnJlZXplIHRoZSByZXRybyAtIHBsZWFzZSB0cnkgYWdhaW4gbGF0ZXInKVxuICAgICAgICB9XG4gICAgfVxuXG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IFJldHJvcywgUmV0cm9BY3Rpb25zIH0gZnJvbSAnLi9zZXF1ZW50J1xuaW1wb3J0IHsgU2NoZW1hcyB9IGZyb20gJy4vc2NoZW1hcydcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4vY29uc3RhbnRzJ1xuaW1wb3J0IHsgTG9nZ2VyIH0gZnJvbSAnLi9sb2dnZXInXG5cbk1ldGVvci5tZXRob2RzKHtcblxuICAgIHRvZ2dsZVNob3dDb21wbGV0ZWQoKSB7XG4gICAgICAgIGNvbnN0IHJldHJvSWQgPSAnJ1xuXG4gICAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1sb2dnZWQtaW4nLCAnWW91IG11c3QgYmUgbG9nZ2VkIGludG8gYSByZXRybyBib2FyZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcmV0cm8gPSBSZXRyb3MuZmluZE9uZSh7XG4gICAgICAgICAgICBjcmVhdGVkQnk6IHRoaXMudXNlcklkLFxuICAgICAgICAgICAgJG9yOlxuICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgIHsgc3RhdHVzOiBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5BQ1RJVkUgfSxcbiAgICAgICAgICAgICAgICB7IHN0YXR1czogQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuRlJPWkVOIH1cbiAgICAgICAgICAgIF1cbiAgICAgICAgfSlcblxuICAgICAgICAvLyBuZWVkIHRvIHNlZSBpZiB0aGVyZSBpc1xuICAgICAgICBpZiAoIXJldHJvKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtZm91bmQnLCAnUmV0cm8gbm90IGZvdW5kIScpXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBzaG93ID0gIXJldHJvLnNob3dDb21wbGV0ZWRcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgUmV0cm9zLnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIF9pZDogcmV0cm8uX2lkXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICRzZXQ6XG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3dDb21wbGV0ZWQ6IHNob3dcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIClcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBMb2dnZXIubG9nKGVycilcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ3VwZGF0ZS1mYWlsZWQnLCAnV2UgY291bGQgdG9nZ2xlIHJldHJvIHNob3cgY29tcGxldGVkIC0gcGxlYXNlIHRyeSBhZ2FpbiBsYXRlcicpXG4gICAgICAgIH1cbiAgICB9XG5cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgXyB9IGZyb20gJ21ldGVvci91bmRlcnNjb3JlJ1xuaW1wb3J0IHsgUmV0cm9zIH0gZnJvbSAnLi9zZXF1ZW50J1xuaW1wb3J0IHsgU2NoZW1hcyB9IGZyb20gJy4vc2NoZW1hcydcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4vY29uc3RhbnRzJ1xuaW1wb3J0IHsgTG9nZ2VyIH0gZnJvbSAnLi9sb2dnZXInXG5cbk1ldGVvci5tZXRob2RzKHtcblxuICAgIHVwVm90ZUl0ZW0oaXRlbUlkKSB7XG4gICAgICAgIGNvbnN0IHJldHJvSWQgPSAnJ1xuXG4gICAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1sb2dnZWQtaW4nLCAnWW91IG11c3QgYmUgbG9nZ2VkIGludG8gYSByZXRybyBib2FyZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gdmFsaWRhdGUgaXRlbSB0eXBlXG5cbiAgICAgICAgY29uc3QgcmV0cm8gPSBSZXRyb3MuZmluZE9uZSh7XG4gICAgICAgICAgICBjcmVhdGVkQnk6IHRoaXMudXNlcklkLFxuICAgICAgICAgICAgc3RhdHVzOiBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5BQ1RJVkVcbiAgICAgICAgfSlcblxuICAgICAgICAvLyBuZWVkIHRvIHNlZSBpZiB0aGVyZSBpc1xuICAgICAgICBpZiAoIXJldHJvKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtZm91bmQnLCAnUmV0cm8gbm90IGZvdW5kIScpXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCByZXRyb0l0ZW0gPSBfLmZpbHRlcihyZXRyby5pdGVtcywgZnVuY3Rpb24gKGl0ZW0pIHtcbiAgICAgICAgICAgIHJldHVybiBpdGVtLml0ZW1JZCA9PT0gaXRlbUlkXG4gICAgICAgIH0pXG5cbiAgICAgICAgaWYgKHJldHJvSXRlbS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1mb3VuZCcsICdSZXRybyBJdGVtIG5vdCBmb3VuZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgbGV0IHZvdGVDb3VudCA9IHJldHJvSXRlbVswXS52b3RlcyB8fCAwXG5cbiAgICAgICAgdm90ZUNvdW50ICs9IDFcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgUmV0cm9zLnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIF9pZDogcmV0cm8uX2lkLFxuICAgICAgICAgICAgICAgICAgICAnaXRlbXMuaXRlbUlkJzogaXRlbUlkXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICdpdGVtcy4kLnZvdGVzJzogdm90ZUNvdW50XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgTG9nZ2VyLmxvZyhlcnIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCd1cGRhdGUtZmFpbGVkJywgJ1dlIGNvdWxkIG5vdCB1cHZvdGUgdGhpcyBpdGVtIC0gcGxlYXNlIHRyeSBhZ2FpbiBsYXRlcicpXG4gICAgICAgIH1cbiAgICB9XG5cbn0pXG4iLCJcbmltcG9ydCB7IFNpbXBsZVNjaGVtYSB9IGZyb20gJ21ldGVvci9hbGRlZWQ6c2ltcGxlLXNjaGVtYSdcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4vY29uc3RhbnRzJ1xuXG5jb25zdCBTY2hlbWFzID0ge31cblxuU2NoZW1hcy5SZXRyb0l0ZW0gPSBuZXcgU2ltcGxlU2NoZW1hKHtcblxuICAgIGl0ZW1JZDoge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIHJlZ0V4OiBTaW1wbGVTY2hlbWEuUmVnRXguSWQsXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSxcbiAgICB0aXRsZToge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIG1heDogMjU1XG4gICAgfSxcbiAgICBzdGF0dXM6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBDb25zdGFudHMuUmV0cm9JdGVtU3RhdHVzZXMudmFsdWVzXG4gICAgfSxcbiAgICBpdGVtVHlwZToge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IENvbnN0YW50cy5SZXRyb0l0ZW1UeXBlcy52YWx1ZXNcbiAgICB9LFxuICAgIHZvdGVzOiB7XG4gICAgICAgIHR5cGU6IE51bWJlcixcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9LFxuICAgIGNyZWF0ZWRBdDoge1xuICAgICAgICB0eXBlOiBEYXRlXG4gICAgfVxuXG59KVxuXG5TY2hlbWFzLlJldHJvcyA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuXG4gICAgX2lkOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgcmVnRXg6IFNpbXBsZVNjaGVtYS5SZWdFeC5JZCxcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9LFxuICAgIGNyZWF0ZWRBdDoge1xuICAgICAgICB0eXBlOiBEYXRlLFxuICAgICAgICBhdXRvVmFsdWU6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLmlzSW5zZXJ0KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBEYXRlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLnVuc2V0KClcbiAgICAgICAgfVxuICAgIH0sXG4gICAgY3JlYXRlZEJ5OiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgcmVnRXg6IFNpbXBsZVNjaGVtYS5SZWdFeC5JZCxcbiAgICAgICAgYXV0b1ZhbHVlOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5pc0luc2VydCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnVzZXJJZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMudW5zZXQoKVxuICAgICAgICB9XG4gICAgfSxcbiAgICBzdGF0dXM6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy52YWx1ZXNcbiAgICB9LFxuICAgIGl0ZW1zOiB7XG4gICAgICAgIHR5cGU6IFtTY2hlbWFzLlJldHJvSXRlbV1cbiAgICB9LFxuICAgIHNob3dDb21wbGV0ZWQ6IHtcbiAgICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgICAgb3B0aW9uYWw6IHRydWUsXG4gICAgICAgIGRlZmF1bHRWYWx1ZTogZmFsc2VcbiAgICB9LFxuICAgIGFyY2hpdmVkQXQ6IHtcbiAgICAgICAgdHlwZTogRGF0ZSxcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9LFxuICAgIGhhcHB5UGxhY2Vob2xkZXI6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0sXG4gICAgbWVoUGxhY2Vob2xkZXI6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0sXG4gICAgc2FkUGxhY2Vob2xkZXI6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0sXG4gICAgYXJjaGl2ZU5hbWU6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH1cbn0pXG5cblNjaGVtYXMuQWN0aW9ucyA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgIF9pZDoge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIHJlZ0V4OiBTaW1wbGVTY2hlbWEuUmVnRXguSWQsXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSxcbiAgICBjcmVhdGVkQXQ6IHtcbiAgICAgICAgdHlwZTogRGF0ZSxcbiAgICAgICAgYXV0b1ZhbHVlOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5pc0luc2VydCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0aGlzLnVuc2V0KClcbiAgICAgICAgfVxuICAgIH0sXG4gICAgY3JlYXRlZEJ5OiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgcmVnRXg6IFNpbXBsZVNjaGVtYS5SZWdFeC5JZCxcbiAgICAgICAgYXV0b1ZhbHVlOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5pc0luc2VydCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnVzZXJJZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMudW5zZXQoKVxuICAgICAgICB9XG4gICAgfSxcbiAgICB0aXRsZToge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIG1heDogMjU1XG4gICAgfSxcbiAgICBzdGF0dXM6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBDb25zdGFudHMuUmV0cm9JdGVtU3RhdHVzZXMudmFsdWVzXG4gICAgfSxcbiAgICBjb21wbGV0ZWRBdDoge1xuICAgICAgICB0eXBlOiBEYXRlLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH1cbn0pXG5cblNjaGVtYXMuTmV3VGVhbSA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgIG5hbWU6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBtYXg6IDYwLFxuICAgICAgICBtaW46IDVcbiAgICB9LFxuICAgIGRlc2NyaXB0aW9uOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgb3B0aW9uYWw6IHRydWUsXG4gICAgICAgIG1heDogMjU1XG4gICAgfSxcbiAgICBwYXNzd29yZDoge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIHJlZ0V4OiAvXig/PS4qW2Etel0pKD89LipbQS1aXSkoPz0uKlxcZClbYS16QS1aXFxkXXs4LH0kLyxcbiAgICAgICAgbWluOiA4LFxuICAgIH0sXG4gICAgY29uZmlybVBhc3N3b3JkOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgbWluOiA4LFxuICAgICAgICBjdXN0b20oKSB7XG4gICAgICAgICAgICBpZiAodGhpcy52YWx1ZSAhPT0gdGhpcy5maWVsZCgncGFzc3dvcmQnKS52YWx1ZSkge1xuICAgICAgICAgICAgICAgIHJldHVybiAncGFzc3dvcmRNaXNtYXRjaCc7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59KVxuXG5TY2hlbWFzLlNldHRpbmdzID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgX2lkOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgcmVnRXg6IFNpbXBsZVNjaGVtYS5SZWdFeC5JZCxcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9LFxuICAgIGNyZWF0ZWRCeToge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIHJlZ0V4OiBTaW1wbGVTY2hlbWEuUmVnRXguSWQsXG4gICAgICAgIGF1dG9WYWx1ZTogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaWYgKHRoaXMuaXNJbnNlcnQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy51c2VySWQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLnVuc2V0KClcbiAgICAgICAgfSxcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9LFxuICAgIGJhY2tncm91bmRJbWFnZToge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIGRlZmF1bHRWYWx1ZTogJy9iYWNrZ3JvdW5kcy90cmlhbmdsZXMucG5nJyxcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9LFxuICAgIGhhcHB5UGxhY2Vob2xkZXI6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBkZWZhdWx0VmFsdWU6ICc6KScsXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSxcbiAgICBtZWhQbGFjZWhvbGRlcjoge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIGRlZmF1bHRWYWx1ZTogJzp8JyxcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9LFxuICAgIHNhZFBsYWNlaG9sZGVyOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgZGVmYXVsdFZhbHVlOiAnOignLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH1cblxufSlcblxubW9kdWxlLmV4cG9ydHMgPSB7IFNjaGVtYXMgfVxuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nXG5pbXBvcnQgeyBTY2hlbWFzIH0gZnJvbSAnLi9zY2hlbWFzJ1xuXG5pZiAoIVN0cmluZy5wcm90b3R5cGUudG9Qcm9wZXJDYXNlKSB7XG4gICAgU3RyaW5nLnByb3RvdHlwZS50b1Byb3BlckNhc2UgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJlcGxhY2UoL1xcd1xcUyovZywgZnVuY3Rpb24gKHR4dCkgeyByZXR1cm4gdHh0LmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgdHh0LnN1YnN0cigxKS50b0xvd2VyQ2FzZSgpOyB9KTtcbiAgICB9O1xufVxuXG5jb25zdCBSZXRyb3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncmV0cm9zJylcbmNvbnN0IFJldHJvQWN0aW9ucyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdyZXRyby1hY3Rpb25zJylcbmNvbnN0IEJhY2tncm91bmRzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2JhY2tncm91bmRzJylcbmNvbnN0IFNldHRpbmdzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3NldHRpbmdzJylcblxuUmV0cm9zLmF0dGFjaFNjaGVtYShTY2hlbWFzLlJldHJvcylcblJldHJvQWN0aW9ucy5hdHRhY2hTY2hlbWEoU2NoZW1hcy5BY3Rpb25zKVxuU2V0dGluZ3MuYXR0YWNoU2NoZW1hKFNjaGVtYXMuU2V0dGluZ3MpXG5cbmNvbnN0IFNlcXVlbnQgPSB7XG4gICAgYXJjaGl2ZVJvdXRlTmFtZTogJ2FyY2hpdmVzJyxcbiAgICBkZWZhdWx0QmFja2dyb3VuZDogJy9iYWNrZ3JvdW5kcy90cmlhbmdsZXMucG5nJyxcbiAgICBkZWZhdWx0Q29uZmlybU1zZzogJ0FyZSB5b3Ugc3VyZT8nLFxuICAgIFRvYXN0VGltZU91dDogMzAwMCxcbiAgICBFTUFJTF9UQVJHRVQ6ICdlbWFpbFRhcmdldCcsXG4gICAgcGFnZVNpemUoKSB7XG4gICAgICAgIHJldHVybiAyNVxuICAgIH0sXG4gICAgZ2V0U2V0dGluZ3MoKSB7XG4gICAgICAgIGxldCBzZXR0aW5ncyA9IFNldHRpbmdzLmZpbmRPbmUoKVxuXG4gICAgICAgIGlmICghc2V0dGluZ3MpIHtcbiAgICAgICAgICAgIHNldHRpbmdzID0ge31cbiAgICAgICAgICAgIHNldHRpbmdzLmJhY2tncm91bmRJbWFnZSA9IFNlcXVlbnQuZGVmYXVsdEJhY2tncm91bmRcbiAgICAgICAgICAgIHNldHRpbmdzLmhhcHB5UGxhY2Vob2xkZXIgPSAnOiknXG4gICAgICAgICAgICBzZXR0aW5ncy5tZWhQbGFjZWhvbGRlciA9ICc6fCdcbiAgICAgICAgICAgIHNldHRpbmdzLnNhZFBsYWNlaG9sZGVyID0gJzooJ1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHNldHRpbmdzXG4gICAgfVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgICBTZXF1ZW50LCBSZXRyb3MsIFJldHJvQWN0aW9ucywgQmFja2dyb3VuZHMsIFNldHRpbmdzXG59XG4iLCJpbXBvcnQgc2FuaXRpemVIdG1sIGZyb20gJ3Nhbml0aXplLWh0bWwnXG5cbmNvbnN0IGNsZWFuSW5wdXQgPSAoaW5wdXQsIGRlZmF1bHRWYWwgPSAnJykgPT4ge1xuICAgIGNvbnN0IHZhbHVlID0gc2FuaXRpemVIdG1sKGlucHV0LCB7XG4gICAgICAgIGFsbG93ZWRUYWdzOiBbXVxuICAgIH0pXG4gICAgcmV0dXJuIHZhbHVlIHx8IGRlZmF1bHRWYWxcbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xlYW5JbnB1dFxuIiwiaW1wb3J0IHsgXyB9IGZyb20gJ21ldGVvci91bmRlcnNjb3JlJ1xuXG5jb25zdCBDb252ZXJ0UmV0cm8gPSAoc2V0dGluZ3MsIHJldHJvKSA9PiB7XG4gICAgY29uc3QgaXRlbXMgPSBbXVxuXG4gICAgbGV0IGRvYyA9ICcnXG5cbiAgICBkb2MgKz0gYFwiJHtzZXR0aW5ncy5oYXBweVBsYWNlaG9sZGVyfVwiLFwiJHtzZXR0aW5ncy5tZWhQbGFjZWhvbGRlcn1cIixcIiR7c2V0dGluZ3Muc2FkUGxhY2Vob2xkZXJ9XCJcXG5gXG5cbiAgICBjb25zdCBoYXBweSA9IF8uZmlsdGVyKHJldHJvLml0ZW1zLCBpdGVtID0+IGl0ZW0uaXRlbVR5cGUudG9Mb3dlckNhc2UoKSA9PT0gJ2hhcHB5JylcbiAgICBoYXBweS5mb3JFYWNoKChpdGVtKSA9PiB7XG4gICAgICAgIGl0ZW1zLnB1c2goe1xuICAgICAgICAgICAgaGFwcHk6IGl0ZW0udGl0bGUsXG4gICAgICAgICAgICBtZWg6ICcnLFxuICAgICAgICAgICAgc2FkOiAnJ1xuICAgICAgICB9KVxuICAgIH0pXG5cbiAgICBjb25zdCBtZWggPSBfLmZpbHRlcihyZXRyby5pdGVtcywgaXRlbSA9PiBpdGVtLml0ZW1UeXBlLnRvTG93ZXJDYXNlKCkgPT09ICdtZWgnKVxuICAgIG1laC5mb3JFYWNoKChpdGVtKSA9PiB7XG4gICAgICAgIGNvbnN0IG5leHQgPSBfLmZpbmQoaXRlbXMsIGkgPT4gaS5tZWggPT09ICcnKVxuICAgICAgICBpZiAobmV4dCkge1xuICAgICAgICAgICAgbmV4dC5tZWggPSBpdGVtLnRpdGxlXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBpdGVtcy5wdXNoKHtcbiAgICAgICAgICAgICAgICBoYXBweTogJycsXG4gICAgICAgICAgICAgICAgbWVoOiBpdGVtLnRpdGxlLFxuICAgICAgICAgICAgICAgIHNhZDogJydcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH1cbiAgICB9KVxuXG4gICAgY29uc3Qgc2FkID0gXy5maWx0ZXIocmV0cm8uaXRlbXMsIGl0ZW0gPT4gaXRlbS5pdGVtVHlwZS50b0xvd2VyQ2FzZSgpID09PSAnc2FkJylcbiAgICBzYWQuZm9yRWFjaCgoaXRlbSkgPT4ge1xuICAgICAgICBjb25zdCBuZXh0ID0gXy5maW5kKGl0ZW1zLCBpID0+IGkuc2FkID09PSAnJylcbiAgICAgICAgaWYgKG5leHQpIHtcbiAgICAgICAgICAgIG5leHQuc2FkID0gaXRlbS50aXRsZVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaXRlbXMucHVzaCh7XG4gICAgICAgICAgICAgICAgaGFwcHk6ICcnLFxuICAgICAgICAgICAgICAgIG1laDogJycsXG4gICAgICAgICAgICAgICAgc2FkOiBpdGVtLnRpdGxlXG4gICAgICAgICAgICB9KVxuICAgICAgICB9XG4gICAgfSlcblxuICAgIGl0ZW1zLmZvckVhY2goKGl0ZW0pID0+IHtcbiAgICAgICAgZG9jICs9IGBcIiR7aXRlbS5oYXBweX1cIixcIiR7aXRlbS5tZWh9XCIsXCIke2l0ZW0uc2FkfVwiXFxuYFxuICAgIH0pXG5cbiAgICByZXR1cm4gZG9jXG59XG5cbm1vZHVsZS5leHBvcnRzID0geyBDb252ZXJ0UmV0cm8gfVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IFdlYkFwcCB9IGZyb20gJ21ldGVvci93ZWJhcHAnXG5pbXBvcnQgeyBTZXR0aW5ncywgUmV0cm9zIH0gZnJvbSAnLi4vbGliL3NlcXVlbnQnXG5pbXBvcnQgeyBDb252ZXJ0UmV0cm8gfSBmcm9tICcuL2NvbnZlcnRSZXRybydcblxuXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZSgnL2V4cG9ydC9yZXRybycsIChyZXEsIHJlcywgbmV4dCkgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHJlcS5xdWVyeVxuXG4gICAgY29uc3QgcmV0cm8gPSBSZXRyb3MuZmluZE9uZShpZClcbiAgICBpZiAoIXJldHJvKSB7XG4gICAgICAgIHJlcy53cml0ZUhlYWQoNDAwKTtcbiAgICAgICAgcmVzLmVuZCgnUmV0cm8gbm90IGZvdW5kIScpO1xuICAgIH1cblxuICAgIGxldCBzZXR0aW5ncyA9IFNldHRpbmdzLmZpbmRPbmUoeyBjcmVhdGVkQnk6IHJldHJvLmNyZWF0ZWRCeSB9KVxuICAgIGlmICghc2V0dGluZ3MpIHtcbiAgICAgICAgc2V0dGluZ3MgPSB7XG4gICAgICAgICAgICBoYXBweVBsYWNlaG9sZGVyOiAnOiknLFxuICAgICAgICAgICAgbWVoUGxhY2Vob2xkZXI6ICc6fCcsXG4gICAgICAgICAgICBzYWRQbGFjZWhvbGRlcjogJzooJ1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgdXNlciA9IE1ldGVvci51c2Vycy5maW5kT25lKHsgX2lkOiByZXRyby5jcmVhdGVkQnkgfSlcbiAgICBpZiAoIXVzZXIpIHtcbiAgICAgICAgdXNlci51c2VybmFtZSA9ICdzZXF1ZW50J1xuICAgIH1cblxuICAgIGNvbnN0IGRvYyA9IENvbnZlcnRSZXRybyhzZXR0aW5ncywgcmV0cm8pXG5cbiAgICByZXMuc2V0SGVhZGVyKCdDb250ZW50LVR5cGUnLCAndGV4dC9jc3YnKTtcbiAgICByZXMuc2V0SGVhZGVyKCdDb250ZW50LURpc3Bvc2l0aW9uJywgYGF0dGFjaG1lbnQ7IGZpbGVuYW1lPSR7dXNlci51c2VybmFtZX0tZXhwb3J0LmNzdmApXG5cbiAgICByZXMuZW5kKGRvYyk7XG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgbW9tZW50IGZyb20gJ21vbWVudCdcbmltcG9ydCB7IFNldHRpbmdzLCBSZXRyb3MgfSBmcm9tICcuLi9saWIvc2VxdWVudCdcbmltcG9ydCB7IFNjaGVtYXMgfSBmcm9tICcuLi9saWIvc2NoZW1hcydcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4uL2xpYi9jb25zdGFudHMnXG5pbXBvcnQgeyBMb2dnZXIgfSBmcm9tICcuLi9saWIvbG9nZ2VyJ1xuaW1wb3J0IGNsZWFuSW5wdXQgZnJvbSAnLi9jbGVhbklucHV0J1xuXG5jb25zdCBpbnB1dE5hbWUgPSAobmFtZSwgZGF0ZVZhbCkgPT4ge1xuICAgIGNvbnN0IG5ld05hbWUgPSBjbGVhbklucHV0KG5hbWUpXG4gICAgaWYgKCFuZXdOYW1lKSByZXR1cm4gYCR7ZGF0ZVZhbH1gXG4gICAgaWYgKG5ld05hbWUgPT09ICcnKSByZXR1cm4gYCR7ZGF0ZVZhbH1gXG4gICAgcmV0dXJuIG5ld05hbWVcbn1cblxuXG5NZXRlb3IubWV0aG9kcyh7XG5cbiAgICBhcmNoaXZlUmV0cm8ocmV0cm9JZCwgbmFtZSkge1xuICAgICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtbG9nZ2VkLWluJywgJ1lvdSBtdXN0IGJlIGxvZ2dlZCBpbnRvIGEgcmV0cm8gYm9hcmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHJldHJvID0gUmV0cm9zLmZpbmRPbmUoe1xuICAgICAgICAgICAgX2lkOiByZXRyb0lkLFxuICAgICAgICAgICAgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZFxuICAgICAgICB9KVxuXG4gICAgICAgIGlmICghcmV0cm8pIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1mb3VuZCcsICdSZXRybyBjb3VsZCBub3QgYmUgZm91bmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChyZXRyby5zdGF0dXMgPT09IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkFSQ0hJVkVEKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdhbHJlYWR5LWFyY2hpdmVkJywgJ1JldHJvIHdhcyBhbHJlYWR5IGFyY2hpdmVkIScpXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBhcmNoaXZlZEF0ID0gbmV3IERhdGUoKVxuXG4gICAgICAgIGNvbnN0IGRhdGVWYWwgPSBtb21lbnQoYXJjaGl2ZWRBdCkuZm9ybWF0KCdNTS1ERC1ZWVlZIC0gTFQnKVxuXG4gICAgICAgIGNvbnN0IGFyY2hpdmVOYW1lID0gaW5wdXROYW1lKG5hbWUsIGRhdGVWYWwpXG5cbiAgICAgICAgaWYgKGFyY2hpdmVOYW1lICE9PSBuYW1lICYmIG5hbWUgIT09ICcnKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdpbnZhbGlkLW5hbWUnLCAnSW52YWxpZCBBcmNoaXZlIG5hbWUuIEhUTUwgdGFncyBub3QgYWxsb3dlZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgbGV0IHNldHRpbmdzID0gU2V0dGluZ3MuZmluZE9uZSh7IGNyZWF0ZWRCeTogdGhpcy51c2VySWQgfSlcblxuICAgICAgICBpZiAoIXNldHRpbmdzKSB7XG4gICAgICAgICAgICBzZXR0aW5ncyA9IHtcbiAgICAgICAgICAgICAgICBoYXBweVBsYWNlaG9sZGVyOiAnOiknLFxuICAgICAgICAgICAgICAgIG1laFBsYWNlaG9sZGVyOiAnOnwnLFxuICAgICAgICAgICAgICAgIHNhZFBsYWNlaG9sZGVyOiAnOignXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgUmV0cm9zLnVwZGF0ZShcbiAgICAgICAgICAgICAgICB7IF9pZDogcmV0cm8uX2lkIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAkc2V0OlxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkFSQ0hJVkVELFxuICAgICAgICAgICAgICAgICAgICAgICAgYXJjaGl2ZWRBdCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFyY2hpdmVOYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgaGFwcHlQbGFjZWhvbGRlcjogc2V0dGluZ3MuaGFwcHlQbGFjZWhvbGRlcixcbiAgICAgICAgICAgICAgICAgICAgICAgIG1laFBsYWNlaG9sZGVyOiBzZXR0aW5ncy5tZWhQbGFjZWhvbGRlcixcbiAgICAgICAgICAgICAgICAgICAgICAgIHNhZFBsYWNlaG9sZGVyOiBzZXR0aW5ncy5zYWRQbGFjZWhvbGRlclxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKVxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIExvZ2dlci5sb2coZXJyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcigndXBkYXRlLWZhaWxlZCcsICdXZSBjb3VsZCBub3QgYXJjaGl2ZSB0aGUgcmV0cm8gLSBwbGVhc2UgdHJ5IGFnYWluIGxhdGVyJylcbiAgICAgICAgfVxuICAgIH1cblxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBSZXRyb3MgfSBmcm9tICcuLi9saWIvc2VxdWVudCdcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4uL2xpYi9jb25zdGFudHMnXG5pbXBvcnQgeyBMb2dnZXIgfSBmcm9tICcuLi9saWIvbG9nZ2VyJ1xuXG5NZXRlb3IubWV0aG9kcyh7XG5cbiAgICBjbGVhclJldHJvQm9hcmQocmV0cm9JZCwgbmFtZSkge1xuICAgICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtbG9nZ2VkLWluJywgJ1lvdSBtdXN0IGJlIGxvZ2dlZCBpbnRvIGEgcmV0cm8gYm9hcmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHJldHJvID0gUmV0cm9zLmZpbmRPbmUoe1xuICAgICAgICAgICAgX2lkOiByZXRyb0lkLFxuICAgICAgICAgICAgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZFxuICAgICAgICB9KVxuXG4gICAgICAgIGlmICghcmV0cm8pIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1mb3VuZCcsICdSZXRybyBjb3VsZCBub3QgYmUgZm91bmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChyZXRyby5zdGF0dXMgPT09IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkFSQ0hJVkVEKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdhbHJlYWR5LWFyY2hpdmVkJywgJ1JldHJvIGlzIGFyY2hpdmVkIGFuZCBjYW5ub3QgYmUgY2xlYXJlZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIFJldHJvcy51cGRhdGUoXG4gICAgICAgICAgICAgICAgeyBfaWQ6IHJldHJvLl9pZCB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgJHNldDpcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgaXRlbXM6IFtdXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgTG9nZ2VyLmxvZyhlcnIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCd1cGRhdGUtZmFpbGVkJywgJ1dlIGNvdWxkIG5vdCBjbGVhciB0aGlzIHJldHJvIGJvYXJkIC0gcGxlYXNlIHRyeSBhZ2FpbiBsYXRlci4nKVxuICAgICAgICB9XG4gICAgfVxuXG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCB7IF8gfSBmcm9tICdtZXRlb3IvdW5kZXJzY29yZSdcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgIGNvbXBvbmVudEltYWdlcygpIHtcbiAgICAgICAgY29uc3QgaW1hZ2VzID0gW11cblxuICAgICAgICBjb25zdCBtZXRlb3JSb290ID0gZnMucmVhbHBhdGhTeW5jKGAke3Byb2Nlc3MuY3dkKCl9Ly4uL2ApO1xuICAgICAgICBjb25zdCBwdWJsaWNQYXRoID0gYCR7bWV0ZW9yUm9vdH0vd2ViLmJyb3dzZXIvYXBwL2A7XG4gICAgICAgIGNvbnN0IGJhY2tncm91bmRQYXRoID0gYCR7cHVibGljUGF0aH0vYDtcbiAgICAgICAgY29uc3QgYmdzID0gZnMucmVhZGRpclN5bmMoYmFja2dyb3VuZFBhdGgpO1xuICAgICAgICBjb25zdCBmaWxlcyA9IGJncy5maWx0ZXIoZnVuY3Rpb24gKGVsbSkgeyByZXR1cm4gZWxtLm1hdGNoKC8uKlxcLihwbmcpL2lnKTsgfSlcblxuICAgICAgICBfLmVhY2goZmlsZXMsIGZ1bmN0aW9uIChpbWcpIHtcbiAgICAgICAgICAgIGltYWdlcy5wdXNoKHsgZmlsZU5hbWU6IGAvJHtpbWd9YCB9KVxuICAgICAgICB9KVxuXG4gICAgICAgIHJldHVybiBpbWFnZXNcbiAgICB9XG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IFJldHJvcywgUmV0cm9BY3Rpb25zIH0gZnJvbSAnLi4vbGliL3NlcXVlbnQnXG5pbXBvcnQgeyBTY2hlbWFzIH0gZnJvbSAnLi4vbGliL3NjaGVtYXMnXG5pbXBvcnQgeyBDb25zdGFudHMgfSBmcm9tICcuLi9saWIvY29uc3RhbnRzJ1xuaW1wb3J0IHsgTG9nZ2VyIH0gZnJvbSAnLi4vbGliL2xvZ2dlcidcbmltcG9ydCBjbGVhbklucHV0IGZyb20gJy4vY2xlYW5JbnB1dCdcblxuTWV0ZW9yLm1ldGhvZHMoe1xuXG4gICAgY3JlYXRlUmV0cm9BY3Rpb24odGl0bGUpIHtcbiAgICAgICAgY29uc3QgcmV0cm9JZCA9ICcnXG5cbiAgICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWxvZ2dlZC1pbicsICdZb3UgbXVzdCBiZSBsb2dnZWQgaW50byBhIHJldHJvIGJvYXJkIScpXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBhY3Rpb24gPSB7fVxuICAgICAgICBhY3Rpb24udGl0bGUgPSBjbGVhbklucHV0KHRpdGxlKVxuXG4gICAgICAgIGFjdGlvbi5zdGF0dXMgPSBDb25zdGFudHMuUmV0cm9JdGVtU3RhdHVzZXMuUEVORElOR1xuXG4gICAgICAgIGlmIChhY3Rpb24udGl0bGUgPT09ICcnKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCd0aXRsZS1yZXF1aXJlZCcsICdJbnZhbGlkIGFjdGlvbiBpdGVtISBIVE1MIFRhZ3Mgbm90IGFsbG93ZWQuJylcbiAgICAgICAgfVxuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBhY3Rpb25JZCA9IFJldHJvQWN0aW9ucy5pbnNlcnQoYWN0aW9uKVxuICAgICAgICAgICAgcmV0dXJuIGFjdGlvbklkXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgTG9nZ2VyLmxvZyhlcnIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdpbnNlcnQtZmFpbGVkJywgJ1dlIGNvdWxkIG5vdCBhZGQgcmV0cm8gaXRlbSB0byB0aGUgcmV0cm8gLSBwbGVhc2UgdHJ5IGFnYWluIGxhdGVyJylcbiAgICAgICAgfVxuICAgIH1cblxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBSYW5kb20gfSBmcm9tICdtZXRlb3IvcmFuZG9tJ1xuaW1wb3J0IHsgXyB9IGZyb20gJ21ldGVvci91bmRlcnNjb3JlJ1xuaW1wb3J0IHsgUmV0cm9zIH0gZnJvbSAnLi4vbGliL3NlcXVlbnQnXG5pbXBvcnQgeyBTY2hlbWFzIH0gZnJvbSAnLi4vbGliL3NjaGVtYXMnXG5pbXBvcnQgeyBDb25zdGFudHMgfSBmcm9tICcuLi9saWIvY29uc3RhbnRzJ1xuaW1wb3J0IHsgTG9nZ2VyIH0gZnJvbSAnLi4vbGliL2xvZ2dlcidcbmltcG9ydCBjbGVhbklucHV0IGZyb20gJy4vY2xlYW5JbnB1dCdcblxuTWV0ZW9yLm1ldGhvZHMoe1xuXG4gICAgY3JlYXRlUmV0cm9JdGVtKHRpdGxlLCBpdGVtVHlwZSkge1xuICAgICAgICBsZXQgcmV0cm9JZCA9ICcnXG5cbiAgICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWxvZ2dlZC1pbicsICdZb3UgbXVzdCBiZSBsb2dnZWQgaW50byBhIHJldHJvIGJvYXJkIScpXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBuZXdUaXRsZSA9IGNsZWFuSW5wdXQodGl0bGUpXG5cbiAgICAgICAgaWYgKG5ld1RpdGxlID09PSAnJykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcigndGl0bGUtcmVxdWlyZWQnLCAnSW52YWxpZCByZXRybyBpdGVtISBIVE1MIFRhZ3Mgbm90IGFsbG93ZWQuJylcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIGlmIHRoZXJlIGFyZSBubyBhY3RpdmUgcmV0cm9zIGZvciB0aGlzIHVzZXIgY3JlYXRlIG9uZVxuICAgICAgICBsZXQgcmV0cm8gPSBSZXRyb3MuZmluZE9uZSh7XG4gICAgICAgICAgICBjcmVhdGVkQnk6IHRoaXMudXNlcklkLFxuICAgICAgICAgICAgc3RhdHVzOiBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5BQ1RJVkVcbiAgICAgICAgfSlcblxuICAgICAgICBpZiAoIXJldHJvKSB7XG4gICAgICAgICAgICBjb25zdCByZXRyb0RvYyA9IHt9XG4gICAgICAgICAgICByZXRyb0RvYy5zdGF0dXMgPSBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5BQ1RJVkVcbiAgICAgICAgICAgIHJldHJvRG9jLml0ZW1zID0gW11cblxuICAgICAgICAgICAgcmV0cm9JZCA9IFJldHJvcy5pbnNlcnQocmV0cm9Eb2MpXG5cbiAgICAgICAgICAgIHJldHJvID0gUmV0cm9zLmZpbmRPbmUoeyBfaWQ6IHJldHJvSWQgfSlcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHJvSWQgPSByZXRyby5faWRcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGRvYyA9IHt9XG4gICAgICAgIGRvYy5pdGVtSWQgPSBSYW5kb20uaWQoKVxuICAgICAgICBkb2MudGl0bGUgPSBuZXdUaXRsZVxuICAgICAgICBkb2MuaXRlbVR5cGUgPSBpdGVtVHlwZVxuICAgICAgICBkb2Muc3RhdHVzID0gQ29uc3RhbnRzLlJldHJvSXRlbVN0YXR1c2VzLlBFTkRJTkdcbiAgICAgICAgZG9jLnZvdGVzID0gMFxuICAgICAgICBkb2MuY3JlYXRlZEF0ID0gbmV3IERhdGUoKVxuXG4gICAgICAgIGlmICghXy5pc0FycmF5KHJldHJvLml0ZW1zKSkge1xuICAgICAgICAgICAgcmV0cm8uaXRlbXMgPSBbXVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gcmV0cm8uaXRlbXMucHVzaChkb2MpXG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIFJldHJvcy51cGRhdGUoXG4gICAgICAgICAgICAgICAgeyBfaWQ6IHJldHJvSWQgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICRwdXNoOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpdGVtczogZG9jXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApXG4gICAgICAgICAgICByZXR1cm4gcmV0cm9JZFxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIExvZ2dlci5sb2coZXJyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignaW5zZXJ0LWZhaWxlZCcsICdXZSBjb3VsZCBub3QgYWRkIHJldHJvIGl0ZW0gdG8gdGhlIHJldHJvIC0gcGxlYXNlIHRyeSBhZ2FpbiBsYXRlcicpXG4gICAgICAgIH1cbiAgICB9XG5cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgZ2V0Q2hhcnRVcmwoKSB7XG4gICAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1sb2dnZWQtaW4nLCAnWW91IG11c3QgYmUgbG9nZ2VkIGludG8gYSByZXRybyBib2FyZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcmV0dmFsID0gcHJvY2Vzcy5lbnYuVVNBR0VfVVJMIHx8ICcnXG5cbiAgICAgICAgcmV0dXJuIHJldHZhbFxuICAgIH1cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgUmFuZG9tIH0gZnJvbSAnbWV0ZW9yL3JhbmRvbSdcbmltcG9ydCB7IE1hdGNoIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJ1xuaW1wb3J0IHsgU2ltcGxlU2NoZW1hIH0gZnJvbSAnbWV0ZW9yL2FsZGVlZDpzaW1wbGUtc2NoZW1hJ1xuaW1wb3J0IHsgXyB9IGZyb20gJ21ldGVvci91bmRlcnNjb3JlJ1xuaW1wb3J0IHsgU2V0dGluZ3MgfSBmcm9tICcuLi9saWIvc2VxdWVudCdcbmltcG9ydCB7IFNjaGVtYXMgfSBmcm9tICcuLi9saWIvc2NoZW1hcydcbmltcG9ydCB7IExvZ2dlciB9IGZyb20gJy4uL2xpYi9sb2dnZXInXG5pbXBvcnQgY2xlYW5JbnB1dCBmcm9tICcuL2NsZWFuSW5wdXQnXG5cbk1ldGVvci5tZXRob2RzKHtcblxuICAgIHNhdmVTZXR0aW5ncyhkb2MpIHtcbiAgICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWxvZ2dlZC1pbicsICdZb3UgbXVzdCBiZSBsb2dnZWQgaW50byBhIHJldHJvIGJvYXJkIScpXG4gICAgICAgIH1cblxuICAgICAgICBTY2hlbWFzLlNldHRpbmdzLnZhbGlkYXRlKGRvYylcblxuICAgICAgICBjb25zdCBzZXR0aW5ncyA9IFNldHRpbmdzLmZpbmRPbmUoeyBjcmVhdGVkQnk6IHRoaXMudXNlcklkIH0pXG5cbiAgICAgICAgY29uc3QgaGFwcHkgPSBjbGVhbklucHV0KGRvYy5oYXBweVBsYWNlaG9sZGVyLCAnOiknKVxuICAgICAgICBjb25zdCBtZWggPSBjbGVhbklucHV0KGRvYy5tZWhQbGFjZWhvbGRlciwgJzp8JylcbiAgICAgICAgY29uc3Qgc2FkID0gY2xlYW5JbnB1dChkb2Muc2FkUGxhY2Vob2xkZXIsICc6KCcpXG5cbiAgICAgICAgaWYgKGhhcHB5ICE9PSBkb2MuaGFwcHlQbGFjZWhvbGRlciB8fCBtZWggIT09IGRvYy5tZWhQbGFjZWhvbGRlciB8fCBzYWQgIT09IGRvYy5zYWRQbGFjZWhvbGRlcikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignaW52YWxpZC1wcm9tcHQnLCAnSW52YWxpZCBwcm9tcHQhIEhUTUwgVGFncyBub3QgYWxsb3dlZC4nKVxuICAgICAgICB9XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGlmIChfLmlzVW5kZWZpbmVkKHNldHRpbmdzKSkge1xuICAgICAgICAgICAgICAgIFNldHRpbmdzLmluc2VydChkb2MpXG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIFNldHRpbmdzLnVwZGF0ZShcbiAgICAgICAgICAgICAgICAgICAgeyBfaWQ6IHNldHRpbmdzLl9pZCB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZEltYWdlOiBkb2MuYmFja2dyb3VuZEltYWdlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhcHB5UGxhY2Vob2xkZXI6IGhhcHB5LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1laFBsYWNlaG9sZGVyOiBtZWgsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2FkUGxhY2Vob2xkZXI6IHNhZFxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIExvZ2dlci5sb2coZXJyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcigndXBkYXRlLWZhaWxlZCcsICdXZSBjb3VsZCBub3QgdXBkYXRlIHNldHRpbmdzIC0gcGxlYXNlIHRyeSBhZ2FpbiBsYXRlcicpXG4gICAgICAgIH1cbiAgICB9XG5cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgXyB9IGZyb20gJ21ldGVvci91bmRlcnNjb3JlJ1xuaW1wb3J0IHsgUmV0cm9zLCBSZXRyb0FjdGlvbnMgfSBmcm9tICcuLi9saWIvc2VxdWVudCdcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4uL2xpYi9jb25zdGFudHMnXG5pbXBvcnQgeyBTZXJ2ZXJVdGlscyB9IGZyb20gJy4vc2VydmVyVXRpbHMnXG5pbXBvcnQgY2xlYW5JbnB1dCBmcm9tICcuL2NsZWFuSW5wdXQnXG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICBzZW5kQWN0aW9uc0J5RW1haWwoY3VycmVudFJldHJvLCB0YXJnZXRFbWFpbCkge1xuICAgICAgICAvLyBjb25zb2xlLmxvZygnaGkgdGhlcmUnKVxuICAgICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtbG9nZ2VkLWluJywgJ1lvdSBtdXN0IGJlIGxvZ2dlZCBpbiB0byBwZXJmb3JtIHRoaXMgYWN0aW9uIScpXG4gICAgICAgIH1cblxuICAgICAgICAvLyBjb25zdCByZXRybyA9IFJldHJvcy5maW5kT25lKHsgX2lkOiBjdXJyZW50UmV0cm8gfSlcblxuICAgICAgICAvLyBpZiAoIXJldHJvKSB7XG4gICAgICAgIC8vICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtZm91bmQnLCAnUmV0cm8gbm90IGZvdW5kIScpXG4gICAgICAgIC8vIH1cblxuICAgICAgICAvLyBpZiAocmV0cm8uY3JlYXRlZEJ5ICE9PSB0aGlzLnVzZXJJZCkge1xuICAgICAgICAvLyAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LXRoZS1vd25lcicsICdZb3UgYXJlIG5vdCB0aGUgb3duZXIgb2YgdGhpcyByZXRybyEnKVxuICAgICAgICAvLyB9XG5cbiAgICAgICAgY29uc3QgZW1haWxUb1VzZSA9IHRhcmdldEVtYWlsIHx8ICcnXG5cbiAgICAgICAgaWYgKGVtYWlsVG9Vc2UgPT09ICcnKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdlbWFpbC1hZGRyZXNzLXJlcXVpcmVkJywgJ0FuIGVtYWlsIGFkZHJlc3MgaXMgcmVxdWlyZWQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IG5ld0VtYWlsID0gY2xlYW5JbnB1dChlbWFpbFRvVXNlKVxuXG4gICAgICAgIGlmIChuZXdFbWFpbCA9PT0gJycpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ2NvbnRhaW5zLWh0bWwnLCAnSW52YWxpZCBlbWFpbCBhZGRyZXNzIScpXG4gICAgICAgIH1cblxuICAgICAgICAvLyBjb25zb2xlLmxvZygnZW1haWwnLCBuZXdFbWFpbClcblxuICAgICAgICBjb25zdCBhY3Rpb25zID0gUmV0cm9BY3Rpb25zLmZpbmQoe1xuICAgICAgICAgICAgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCxcbiAgICAgICAgICAgICRvcjogW1xuICAgICAgICAgICAgICAgIHsgc3RhdHVzOiBDb25zdGFudHMuUmV0cm9JdGVtU3RhdHVzZXMuUEVORElORyB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBDb25zdGFudHMuUmV0cm9JdGVtU3RhdHVzZXMuQ09NUExFVEUsXG4gICAgICAgICAgICAgICAgICAgIGNvbXBsZXRlZEF0OiB7ICRndDogbmV3IERhdGUoRGF0ZS5ub3coKSAtICgyNCAqIDYwICogNjAgKiAxMDAwKSkgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIF1cbiAgICAgICAgfSkuZmV0Y2goKVxuXG4gICAgICAgIGlmIChhY3Rpb25zLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm8tYWN0aW9ucycsICdUaGVyZSBhcmUgbm8gYWN0aXZlIG9yIHJlY2VudGx5IGNvbXBsZXRlZCBhY3Rpb25zIHRvIHNlbmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGRhdGEgPSB7fVxuXG4gICAgICAgIGNvbnN0IHVzZXIgPSBNZXRlb3IudXNlcnMuZmluZE9uZSh0aGlzLnVzZXJJZClcblxuICAgICAgICBkYXRhLnJldHJvTmFtZSA9IHVzZXIudXNlcm5hbWUudG9Qcm9wZXJDYXNlKClcbiAgICAgICAgZGF0YS5jdXJyZW50WWVhciA9IG5ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKVxuICAgICAgICAvLyB0dXJuIGludG8gaHRtbCBsaXN0XG4gICAgICAgIGxldCBpdGVtcyA9ICc8dHI+PHRoPkFjdGlvbiBJdGVtPC90aD48dGggY2xhc3M9XCJ0ZXh0LWNlbnRlclwiIHN0eWxlPVwid2lkdGg6IDI1JTtcIj5TdGF0dXM8L3RoPjwvdHI+J1xuICAgICAgICBkYXRhLnJldHJvSXRlbXMgPSBfLnNvcnRCeShhY3Rpb25zLCAnc3RhdHVzJykuZm9yRWFjaCgoaXRlbSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgaXNDb21wbGV0ZSA9IChpdGVtLnN0YXR1cyA9PT0gQ29uc3RhbnRzLlJldHJvSXRlbVN0YXR1c2VzLkNPTVBMRVRFKSA/ICdDb21wbGV0ZScgOiAnQWN0aXZlJ1xuICAgICAgICAgICAgY29uc3QgaXRlbVN0eWxlID0gKGl0ZW0uc3RhdHVzID09PSBDb25zdGFudHMuUmV0cm9JdGVtU3RhdHVzZXMuQ09NUExFVEUpID8gJ2NvbG9yOiAjOTk5OyBwYWRkaW5nOiA0cHggNHB4IDRweCAwcHg7IHZlcnRpY2FsLWFsaWduOiB0b3A7JyA6ICdwYWRkaW5nOiA0cHggNHB4IDRweCAwcHg7IHZlcnRpY2FsLWFsaWduOiB0b3A7J1xuICAgICAgICAgICAgaXRlbXMgKz0gYDx0cj48L3RyPjx0ZCBzdHlsZT1cIiR7aXRlbVN0eWxlfVwiPiR7aXRlbS50aXRsZX08L3RkPjx0ZCBzdHlsZT1cIiR7aXRlbVN0eWxlfVwiPiR7aXNDb21wbGV0ZX08L3RkPjwvdHI+YFxuICAgICAgICB9KVxuXG4gICAgICAgIGRhdGEucmV0cm9JdGVtcyA9IGl0ZW1zXG5cbiAgICAgICAgY29uc3QgZnJvbSA9IHByb2Nlc3MuZW52LkZST01fRU1BSUxfQUREUkVTUyB8fCAnc2VxdWVudEA2dGhjZW50cy5jb20nXG5cbiAgICAgICAgU2VydmVyVXRpbHMuc2VuZEh0bWxFbWFpbChuZXdFbWFpbCwgZnJvbSwgYCR7dXNlci51c2VybmFtZS50b1Byb3BlckNhc2UoKX0gQWN0aW9uIEl0ZW1zYCwgJ2FjdGlvbkl0ZW1zJywgZGF0YSlcbiAgICB9XG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IFJldHJvcywgUmV0cm9BY3Rpb25zIH0gZnJvbSAnLi4vbGliL3NlcXVlbnQnXG5pbXBvcnQgeyBTY2hlbWFzIH0gZnJvbSAnLi4vbGliL3NjaGVtYXMnXG5pbXBvcnQgeyBDb25zdGFudHMgfSBmcm9tICcuLi9saWIvY29uc3RhbnRzJ1xuaW1wb3J0IHsgTG9nZ2VyIH0gZnJvbSAnLi4vbGliL2xvZ2dlcidcbmltcG9ydCBjbGVhbklucHV0IGZyb20gJy4vY2xlYW5JbnB1dCdcblxuTWV0ZW9yLm1ldGhvZHMoe1xuXG4gICAgdXBkYXRlQWN0aW9uVGl0bGUoYWN0aW9uSWQsIHRpdGxlKSB7XG4gICAgICAgIGNvbnN0IHJldHJvSWQgPSAnJ1xuXG4gICAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1sb2dnZWQtaW4nLCAnWW91IG11c3QgYmUgbG9nZ2VkIGludG8gYSByZXRybyBib2FyZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgYWN0aW9uID0gUmV0cm9BY3Rpb25zLmZpbmRPbmUoeyBfaWQ6IGFjdGlvbklkLCBjcmVhdGVkQnk6IHRoaXMudXNlcklkIH0pXG5cbiAgICAgICAgaWYgKCFhY3Rpb24pIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1mb3VuZCcsICdSZXRyb0FjdGlvbiBub3QgZm91bmQhJylcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IG5ld1RpdGxlID0gY2xlYW5JbnB1dCh0aXRsZSlcblxuICAgICAgICBpZiAobmV3VGl0bGUgIT09IHRpdGxlKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdpbnZhbGlkLXRpdGxlJywgJ0ludmFsaWQgYWN0aW9uISBIVE1MIHRhZ3Mgbm90IGFsbG93ZWQuJylcbiAgICAgICAgfVxuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBSZXRyb0FjdGlvbnMudXBkYXRlKFxuICAgICAgICAgICAgICAgIHsgX2lkOiBhY3Rpb25JZCB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgJHNldDpcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IG5ld1RpdGxlXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgTG9nZ2VyLmxvZyhlcnIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdkZWxldGUtZmFpbGVkJywgJ1dlIGNvdWxkIG5vdCBkZWxldGUgdGhlIGFjdGlvbiAtIHBsZWFzZSB0cnkgYWdhaW4gbGF0ZXInKVxuICAgICAgICB9XG4gICAgfVxuXG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IF8gfSBmcm9tICdtZXRlb3IvdW5kZXJzY29yZSdcbmltcG9ydCB7IFJldHJvcyB9IGZyb20gJy4uL2xpYi9zZXF1ZW50J1xuaW1wb3J0IHsgU2NoZW1hcyB9IGZyb20gJy4uL2xpYi9zY2hlbWFzJ1xuaW1wb3J0IHsgQ29uc3RhbnRzIH0gZnJvbSAnLi4vbGliL2NvbnN0YW50cydcbmltcG9ydCB7IExvZ2dlciB9IGZyb20gJy4uL2xpYi9sb2dnZXInXG5pbXBvcnQgY2xlYW5JbnB1dCBmcm9tICcuL2NsZWFuSW5wdXQnXG5cbk1ldGVvci5tZXRob2RzKHtcblxuICAgIHVwZGF0ZVJldHJvSXRlbVRpdGxlKGl0ZW1JZCwgdGl0bGUpIHtcbiAgICAgICAgY29uc3QgcmV0cm9JZCA9ICcnXG5cbiAgICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWxvZ2dlZC1pbicsICdZb3UgbXVzdCBiZSBsb2dnZWQgaW50byBhIHJldHJvIGJvYXJkIScpXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCByZXRybyA9IFJldHJvcy5maW5kT25lKHtcbiAgICAgICAgICAgIGNyZWF0ZWRCeTogdGhpcy51c2VySWQsXG4gICAgICAgICAgICAkb3I6IFtcbiAgICAgICAgICAgICAgICB7IHN0YXR1czogQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuQUNUSVZFIH0sXG4gICAgICAgICAgICAgICAgeyBzdGF0dXM6IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkZST1pFTiB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgfSlcblxuICAgICAgICAvLyBuZWVkIHRvIHNlZSBpZiB0aGVyZSBpc1xuICAgICAgICBpZiAoIXJldHJvKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtZm91bmQnLCAnUmV0cm8gbm90IGZvdW5kIScpXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCByZXRyb0l0ZW0gPSBfLmZpbHRlcihyZXRyby5pdGVtcywgZnVuY3Rpb24gKGl0ZW0pIHtcbiAgICAgICAgICAgIHJldHVybiBpdGVtLml0ZW1JZCA9PT0gaXRlbUlkXG4gICAgICAgIH0pXG5cbiAgICAgICAgaWYgKHJldHJvSXRlbS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1mb3VuZCcsICdSZXRybyBJdGVtIG5vdCBmb3VuZCEnKVxuICAgICAgICB9XG5cbiAgICAgICAgbGV0IHZvdGVDb3VudCA9IHJldHJvSXRlbVswXS52b3RlcyB8fCAwXG5cbiAgICAgICAgdm90ZUNvdW50ICs9IDFcblxuICAgICAgICBjb25zdCBuZXdUaXRsZSA9IGNsZWFuSW5wdXQodGl0bGUpXG5cbiAgICAgICAgaWYgKG5ld1RpdGxlID09PSAnJykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignaW52YWxpZC10aXRsZScsICdJbnZhbGlkIFJldHJvIEl0ZW0uIEhUTUwgdGFncyBub3QgYWxsb3dlZC4nKVxuICAgICAgICB9XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIFJldHJvcy51cGRhdGUoXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBfaWQ6IHJldHJvLl9pZCxcbiAgICAgICAgICAgICAgICAgICAgJ2l0ZW1zLml0ZW1JZCc6IGl0ZW1JZFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAnaXRlbXMuJC50aXRsZSc6IG5ld1RpdGxlXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgTG9nZ2VyLmxvZyhlcnIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCd1cGRhdGUtZmFpbGVkJywgJ1dlIGNvdWxkIG5vdCB1cGRhdGUgdGhlIHJldHJvIGl0ZW0gLSBwbGVhc2UgdHJ5IGFnYWluIGxhdGVyJylcbiAgICAgICAgfVxuICAgIH1cblxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgZnMgZnJvbSAnZnMnXG5pbXBvcnQgeyBfIH0gZnJvbSAnbWV0ZW9yL3VuZGVyc2NvcmUnXG5pbXBvcnQgeyBCYWNrZ3JvdW5kcyB9IGZyb20gJy4uL2xpYi9zZXF1ZW50J1xuXG5NZXRlb3IucHVibGlzaCgnYmFja2dyb3VuZHMnLCBmdW5jdGlvbiAoKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgY29uc3QgbWV0ZW9yUm9vdCA9IGZzLnJlYWxwYXRoU3luYyhgJHtwcm9jZXNzLmN3ZCgpfS8uLi9gKTtcbiAgICBjb25zdCBwdWJsaWNQYXRoID0gYCR7bWV0ZW9yUm9vdH0vd2ViLmJyb3dzZXIvYXBwL2A7XG4gICAgY29uc3QgYmFja2dyb3VuZFBhdGggPSBgJHtwdWJsaWNQYXRofS9iYWNrZ3JvdW5kcy9gO1xuICAgIGNvbnN0IGJncyA9IGZzLnJlYWRkaXJTeW5jKGJhY2tncm91bmRQYXRoKTtcbiAgICBfLmVhY2goYmdzLCBmdW5jdGlvbiAoYmFja2dyb3VuZCkge1xuICAgICAgICBjb25zdCBiYWNrZ3JvdW5kTmFtZSA9IGJhY2tncm91bmQuc3BsaXQoJy4nKVswXS50b1Byb3BlckNhc2UoKVxuICAgICAgICBzZWxmLmFkZGVkKCdiYWNrZ3JvdW5kcycsIGJhY2tncm91bmQsIHsgbmFtZTogYmFja2dyb3VuZE5hbWUsIHZhbHVlOiBgL2JhY2tncm91bmRzLyR7YmFja2dyb3VuZH1gIH0pO1xuICAgIH0pXG4gICAgdGhpcy5yZWFkeSgpO1xufSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgTWF0Y2ggfSBmcm9tICdtZXRlb3IvY2hlY2snXG5pbXBvcnQgeyBTZXF1ZW50LCBSZXRyb0FjdGlvbnMgfSBmcm9tICcuLi9saWIvc2VxdWVudCdcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4uL2xpYi9jb25zdGFudHMnXG5cblJldHJvQWN0aW9ucy5fZW5zdXJlSW5kZXgoJ2NyZWF0ZWRCeScsIDEpXG5SZXRyb0FjdGlvbnMuX2Vuc3VyZUluZGV4KCdzdGF0dXMnLCAxKVxuUmV0cm9BY3Rpb25zLl9lbnN1cmVJbmRleCgnY3JlYXRlZEF0JywgMSlcblxuTWV0ZW9yLnB1Ymxpc2goJ29wZW4tYWN0aW9ucycsIGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgIHRoaXMuc3RvcCgpXG4gICAgICAgIHJldHVybiBudWxsXG4gICAgfVxuXG4gICAgcmV0dXJuIFJldHJvQWN0aW9ucy5maW5kKHtcbiAgICAgICAgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCxcbiAgICAgICAgc3RhdHVzOiBDb25zdGFudHMuUmV0cm9JdGVtU3RhdHVzZXMuUEVORElOR1xuICAgIH0pXG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goJ2FsbC1hY3Rpb25zJywgZnVuY3Rpb24gKHNlYXJjaCkge1xuICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG5cbiAgICBpZiAoIU1hdGNoLnRlc3Qoc2VhcmNoLCB7IGxpbWl0OiBOdW1iZXIsIHNob3dBbGw6IEJvb2xlYW4gfSkpIHtcbiAgICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG5cbiAgICBjb25zdCBxdWVyeSA9IHtcbiAgICAgICAgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZFxuICAgIH1cblxuICAgIGlmICghc2VhcmNoLnNob3dBbGwpIHtcbiAgICAgICAgcXVlcnkuc3RhdHVzID0gQ29uc3RhbnRzLlJldHJvSXRlbVN0YXR1c2VzLlBFTkRJTkdcbiAgICB9XG5cbiAgICByZXR1cm4gUmV0cm9BY3Rpb25zLmZpbmQocXVlcnksIHsgc29ydDogeyBjb21wbGV0ZWRBdDogMSB9LCBsaW1pdDogc2VhcmNoLmxpbWl0IH0pXG59KTtcblxuLypcbm1lc3NhZ2VzLmZpbmQoeydtZXRhZGF0YS50aHJlYWQnOiB0aHJlYWRJZH0sXG4gIHtcbiAgICBzb3J0OiB7J2RhdGUnIDogc29ydH0sXG4gICAgbGltaXQ6IGxpbWl0LFxuICAgIGRpc2FibGVPcGxvZzogdHJ1ZSxcbiAgICBwb2xsaW5nVGhyb3R0bGVNczogMTIwMDAsXG4gICAgcG9sbGluZ0ludGVydmFsTXM6IDEyMDAwXG4gIH1cbik7XG4qL1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IFJldHJvcyB9IGZyb20gJy4uL2xpYi9zZXF1ZW50J1xuaW1wb3J0IHsgQ29uc3RhbnRzIH0gZnJvbSAnLi4vbGliL2NvbnN0YW50cydcblxuUmV0cm9zLl9lbnN1cmVJbmRleCgnY3JlYXRlZEJ5JywgMSlcblJldHJvcy5fZW5zdXJlSW5kZXgoJ3N0YXR1cycsIDEpXG5cbk1ldGVvci5wdWJsaXNoKCdhY3RpdmUtcmV0cm9zJywgZnVuY3Rpb24gKCkge1xuICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG5cbiAgICByZXR1cm4gUmV0cm9zLmZpbmQoe1xuICAgICAgICBjcmVhdGVkQnk6IHRoaXMudXNlcklkLFxuICAgICAgICBzdGF0dXM6IHtcbiAgICAgICAgICAgICRpbjogW0NvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkFDVElWRSwgQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuRlJPWkVOXVxuICAgICAgICB9XG4gICAgfSlcbn0pO1xuXG5NZXRlb3IucHVibGlzaCgnYXJjaGl2ZWQtcmV0cm9zJywgZnVuY3Rpb24gKCkge1xuICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG5cbiAgICByZXR1cm4gUmV0cm9zLmZpbmQoeyBjcmVhdGVkQnk6IHRoaXMudXNlcklkLCBzdGF0dXM6IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkFSQ0hJVkVEIH0pXG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goJ3NpbmdsZS1hcmNoaXZlZC1yZXRybycsIGZ1bmN0aW9uIChyZXRyb0lkKSB7XG4gICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICByZXR1cm4gbnVsbFxuICAgIH1cblxuICAgIHJldHVybiBSZXRyb3MuZmluZCh7IF9pZDogcmV0cm9JZCwgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZCwgc3RhdHVzOiBDb25zdGFudHMuUmV0cm9TdGF0dXNlcy5BUkNISVZFRCB9KVxufSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgU2V0dGluZ3MgfSBmcm9tICcuLi9saWIvc2VxdWVudCdcblxuU2V0dGluZ3MuX2Vuc3VyZUluZGV4KCdjcmVhdGVkQnknLCAxKVxuXG5NZXRlb3IucHVibGlzaCgnc2V0dGluZ3MnLCBmdW5jdGlvbiAoKSB7XG4gICAgaWYgKCFNZXRlb3IudXNlcklkKCkpIHtcbiAgICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG5cbiAgICByZXR1cm4gU2V0dGluZ3MuZmluZCh7IGNyZWF0ZWRCeTogTWV0ZW9yLnVzZXJJZCgpIH0pXG59KTtcblxuIiwiLyogZ2xvYmFsIEFzc2V0cyBUZW1wbGF0ZSAqL1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IFNTUiB9IGZyb20gJ21ldGVvci9tZXRlb3JoYWNrczpzc3InXG5pbXBvcnQgeyBFbWFpbCB9IGZyb20gJ21ldGVvci9lbWFpbCdcbmltcG9ydCBjaGVjayBmcm9tICdtZXRlb3IvY2hlY2snXG5pbXBvcnQgeyBDb25zdGFudHMgfSBmcm9tICcuLi9saWIvY29uc3RhbnRzJ1xuXG5pZiAoIVN0cmluZy5wcm90b3R5cGUudG9Qcm9wZXJDYXNlKSB7XG4gICAgU3RyaW5nLnByb3RvdHlwZS50b1Byb3BlckNhc2UgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJlcGxhY2UoL1xcd1xcUyovZywgZnVuY3Rpb24gKHR4dCkgeyByZXR1cm4gdHh0LmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgdHh0LnN1YnN0cigxKS50b0xvd2VyQ2FzZSgpOyB9KTtcbiAgICB9O1xufVxuXG5TU1IuY29tcGlsZVRlbXBsYXRlKCdhY3Rpb25JdGVtcycsIEFzc2V0cy5nZXRUZXh0KCdlbWFpbFRlbXBsYXRlcy9hY3Rpb25JdGVtcy5odG1sJykpO1xuXG5UZW1wbGF0ZS5hY3Rpb25JdGVtcy5oZWxwZXJzKHtcbiAgICBpc0NvbXBsZXRlOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnN0YXR1cyA9PT0gQ29uc3RhbnRzLlJldHJvSXRlbVN0YXR1c2VzLkNPTVBMRVRFXG4gICAgfVxufSlcblxuY29uc3QgU2VydmVyVXRpbHMgPSB7fVxuXG5TZXJ2ZXJVdGlscy5zZW5kRW1haWwgPSAodG8sIGZyb20sIHN1YmplY3QsIHRleHQpID0+IHtcbiAgICBjaGVjayhbdG8sIGZyb20sIHN1YmplY3QsIHRleHRdLCBbU3RyaW5nXSk7XG5cbiAgICBNZXRlb3IuZGVmZXIoZnVuY3Rpb24gKCkge1xuICAgICAgICBFbWFpbC5zZW5kKHtcbiAgICAgICAgICAgIHRvOiB0byxcbiAgICAgICAgICAgIGZyb206IGZyb20gfHwgJ25vcmVwbHlANnRoY2VudHMuY29tJyxcbiAgICAgICAgICAgIHN1YmplY3Q6IHN1YmplY3QsXG4gICAgICAgICAgICB0ZXh0OiB0ZXh0XG4gICAgICAgIH0pO1xuICAgIH0pO1xufVxuXG5TZXJ2ZXJVdGlscy5zZW5kSHRtbEVtYWlsID0gKHRvLCBmcm9tLCBzdWJqZWN0LCB0ZW1wbGF0ZU5hbWUsIGRhdGEpID0+IHtcbiAgICB2YXIgYm9keSA9IFNTUi5yZW5kZXIodGVtcGxhdGVOYW1lLCBkYXRhKTtcblxuICAgIE1ldGVvci5kZWZlcihmdW5jdGlvbiAoKSB7XG4gICAgICAgIEVtYWlsLnNlbmQoe1xuICAgICAgICAgICAgdG86IHRvLFxuICAgICAgICAgICAgZnJvbTogZnJvbSB8fCAnc2VxdWVudEA2dGhjZW50cy5jb20nLFxuICAgICAgICAgICAgc3ViamVjdDogc3ViamVjdCxcbiAgICAgICAgICAgIGh0bWw6IGJvZHlcbiAgICAgICAgfSlcbiAgICB9KTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSB7IFNlcnZlclV0aWxzIH1cbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gIC8vIGNvZGUgdG8gcnVuIG9uIHNlcnZlciBhdCBzdGFydHVwXG59KTtcbiIsIi8qIGdsb2JhbCBkb2N1bWVudCAqL1xuaW1wb3J0IHsgXyB9IGZyb20gJ21ldGVvci91bmRlcnNjb3JlJztcbmltcG9ydCB7IFRlbXBsYXRlIH0gZnJvbSAnbWV0ZW9yL3RlbXBsYXRpbmcnO1xuaW1wb3J0IHsgQmxhemUgfSBmcm9tICdtZXRlb3IvYmxhemUnO1xuaW1wb3J0IHsgVHJhY2tlciB9IGZyb20gJ21ldGVvci90cmFja2VyJztcblxuY29uc3Qgd2l0aERpdiA9IGZ1bmN0aW9uIHdpdGhEaXYoY2FsbGJhY2spIHtcbiAgICBjb25zdCBlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZWwpO1xuXG4gICAgdHJ5IHtcbiAgICAgICAgY2FsbGJhY2soZWwpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQoZWwpO1xuICAgIH1cbn07XG5cbmV4cG9ydCBjb25zdCB3aXRoUmVuZGVyZWRUZW1wbGF0ZSA9IGZ1bmN0aW9uIHdpdGhSZW5kZXJlZFRlbXBsYXRlKHRlbXBsYXRlLCBkYXRhLCBjYWxsYmFjaykge1xuICAgIHdpdGhEaXYoKGVsKSA9PiB7XG4gICAgICAgIGNvbnN0IHRoZVRlbXBsYXRlID0gXy5pc1N0cmluZyh0ZW1wbGF0ZSkgPyBUZW1wbGF0ZVt0ZW1wbGF0ZV0gOiB0ZW1wbGF0ZTtcbiAgICAgICAgQmxhemUucmVuZGVyV2l0aERhdGEodGhlVGVtcGxhdGUsIGRhdGEsIGVsKTtcbiAgICAgICAgVHJhY2tlci5mbHVzaCgpO1xuICAgICAgICBjYWxsYmFjayhlbCwgdGhlVGVtcGxhdGUpO1xuICAgIH0pO1xufTtcbiIsIi8qIGdsb2JhbCBtb21lbnQgKi9cbmltcG9ydCB7IFJhbmRvbSB9IGZyb20gJ21ldGVvci9yYW5kb20nXG5pbXBvcnQgeyBfIH0gZnJvbSAnbWV0ZW9yL3VuZGVyc2NvcmUnXG5pbXBvcnQgeyBDb25zdGFudHMgfSBmcm9tICcuLi9saWIvY29uc3RhbnRzJ1xuXG5jb25zdCBUZXN0RGF0YSA9IHtcblxuICAgIGZha2VTZXR0aW5ncyhwYXJhbWV0ZXJzKSB7XG4gICAgICAgIGxldCBwYXJtcyA9IHt9XG5cbiAgICAgICAgaWYgKCFfLmlzVW5kZWZpbmVkKHBhcmFtZXRlcnMpKSB7XG4gICAgICAgICAgICBwYXJtcyA9IHBhcmFtZXRlcnM7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBTZXR0aW5ncyA9IHt9XG4gICAgICAgIFNldHRpbmdzLmJhY2tncm91bmRJbWFnZSA9ICcvZmFrZU9uZS5qcGcnXG4gICAgICAgIFNldHRpbmdzLmhhcHB5UGxhY2Vob2xkZXIgPSAnRmFrZSBoYXBweSBwbGFjZWhvbGRlcidcbiAgICAgICAgU2V0dGluZ3MubWVoUGxhY2Vob2xkZXIgPSAnRmFrZSBtZWggcGxhY2Vob2xkZXInXG4gICAgICAgIFNldHRpbmdzLnNhZFBsYWNlaG9sZGVyID0gJ0Zha2Ugc2FkIHBsYWNlaG9sZGVyJ1xuXG4gICAgICAgIHJldHVybiBTZXR0aW5nc1xuICAgIH0sXG4gICAgZmFrZUJhY2tncm91bmRzQXJyYXkocGFyYW1ldGVycykge1xuICAgICAgICBsZXQgcGFybXMgPSB7fVxuXG4gICAgICAgIGlmICghXy5pc1VuZGVmaW5lZChwYXJhbWV0ZXJzKSkge1xuICAgICAgICAgICAgcGFybXMgPSBwYXJhbWV0ZXJzO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgQmFja2dyb3VuZHMgPSBbXVxuXG4gICAgICAgIEJhY2tncm91bmRzLnB1c2goeyBuYW1lOiAnZmFrZU9uZScsIHZhbHVlOiAnL2Zha2VPbmUuanBnJyB9KVxuICAgICAgICBCYWNrZ3JvdW5kcy5wdXNoKHsgbmFtZTogJ2Zha2VUd28nLCB2YWx1ZTogJy9mYWtlVHdvLmpwZycgfSlcbiAgICAgICAgQmFja2dyb3VuZHMucHVzaCh7IG5hbWU6ICdmYWtlVGhyZWUnLCB2YWx1ZTogJy9mYWtlVGhyZWUuanBnJyB9KVxuICAgICAgICBCYWNrZ3JvdW5kcy5wdXNoKHsgbmFtZTogJ2Zha2VGb3VyJywgdmFsdWU6ICcvZmFrZUZvdXIuanBnJyB9KVxuICAgICAgICBCYWNrZ3JvdW5kcy5wdXNoKHsgbmFtZTogJ2Zha2VGaXZlJywgdmFsdWU6ICcvZmFrZUZpdmUuanBnJyB9KVxuXG4gICAgICAgIHJldHVybiBCYWNrZ3JvdW5kc1xuICAgIH0sXG5cbiAgICBmYWtlUmV0cm9BY3Rpb24ocGFyYW1ldGVycykge1xuICAgICAgICBsZXQgcGFybXMgPSB7fVxuXG4gICAgICAgIGlmICghXy5pc1VuZGVmaW5lZChwYXJhbWV0ZXJzKSkge1xuICAgICAgICAgICAgcGFybXMgPSBwYXJhbWV0ZXJzO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgUmV0cm9BY3Rpb24gPSB7fVxuXG4gICAgICAgIFJldHJvQWN0aW9uLl9pZCA9IHBhcm1zLl9pZCB8fCBSYW5kb20uaWQoKVxuICAgICAgICBSZXRyb0FjdGlvbi5jcmVhdGVkQnkgPSBwYXJtcy5jcmVhdGVkQnkgfHwgUmFuZG9tLmlkKClcbiAgICAgICAgUmV0cm9BY3Rpb24uY3JlYXRlZEF0ID0gcGFybXMuY3JlYXRlZEF0IHx8IG5ldyBEYXRlKClcbiAgICAgICAgUmV0cm9BY3Rpb24udGl0bGUgPSBwYXJtcy50aXRsZSB8fCAnZmFrZSB0aXRsZSdcbiAgICAgICAgUmV0cm9BY3Rpb24uc3RhdHVzID0gcGFybXMuc3RhdHVzIHx8IENvbnN0YW50cy5SZXRyb0l0ZW1TdGF0dXNlcy5QRU5ESU5HXG4gICAgICAgIFJldHJvQWN0aW9uLmNvbXBsZXRlZEF0ID0gcGFybXMuY29tcGxldGVkQXQgfHwgbnVsbFxuXG4gICAgICAgIHJldHVybiBSZXRyb0FjdGlvblxuICAgIH0sXG5cbiAgICBmYWtlUmV0cm9JdGVtKHBhcmFtZXRlcnMpIHtcbiAgICAgICAgbGV0IHBhcm1zID0ge31cblxuICAgICAgICBpZiAoIV8uaXNVbmRlZmluZWQocGFyYW1ldGVycykpIHtcbiAgICAgICAgICAgIHBhcm1zID0gcGFyYW1ldGVycztcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IFJldHJvSXRlbSA9IHt9XG5cbiAgICAgICAgUmV0cm9JdGVtLml0ZW1JZCA9IHBhcm1zLml0ZW1JZCB8fCBSYW5kb20uaWQoKVxuICAgICAgICBSZXRyb0l0ZW0udGl0bGUgPSBwYXJtcy50aXRsZSB8fCAnZmFrZSB0aXRsZSdcbiAgICAgICAgUmV0cm9JdGVtLnN0YXR1cyA9IHBhcm1zLnN0YXR1cyB8fCBDb25zdGFudHMuUmV0cm9JdGVtU3RhdHVzZXMuUEVORElOR1xuICAgICAgICBSZXRyb0l0ZW0uaXRlbVR5cGUgPSBwYXJtcy5pdGVtVHlwZSB8fCBSYW5kb20uY2hvaWNlKFtDb25zdGFudHMuUmV0cm9JdGVtVHlwZXMuSEFQUFksIENvbnN0YW50cy5SZXRyb0l0ZW1UeXBlcy5NRUgsIENvbnN0YW50cy5SZXRyb0l0ZW1UeXBlcy5TQURdKVxuICAgICAgICBSZXRyb0l0ZW0udm90ZXMgPSBwYXJtcy52b3RlcyB8fCAwXG4gICAgICAgIFJldHJvSXRlbS5jcmVhdGVkQXQgPSBwYXJtcy5jcmVhdGVkQXQgfHwgbmV3IERhdGUoKVxuXG4gICAgICAgIHJldHVybiBSZXRyb0l0ZW1cbiAgICB9LFxuXG4gICAgZmFrZVJldHJvSXRlbXMocGFyYW1ldGVycywgY291bnQpIHtcbiAgICAgICAgY29uc3QgaXRlbXMgPSBbXVxuXG4gICAgICAgIGlmICghY291bnQpIGNvdW50ID0gMVxuXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY291bnQ7IGkgKz0gMSkge1xuICAgICAgICAgICAgaXRlbXMucHVzaCh0aGlzLmZha2VSZXRyb0l0ZW0ocGFyYW1ldGVycykpIC8vICBlc2xpbnQtZGlzYWJsZS1saW5lXG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gaXRlbXNcbiAgICB9LFxuXG4gICAgZmFrZVJldHJvKHBhcmFtZXRlcnMpIHtcbiAgICAgICAgbGV0IHBhcm1zID0ge31cblxuICAgICAgICBpZiAoIV8uaXNVbmRlZmluZWQocGFyYW1ldGVycykpIHtcbiAgICAgICAgICAgIHBhcm1zID0gcGFyYW1ldGVycztcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IFJldHJvID0ge31cblxuICAgICAgICBSZXRyby5faWQgPSBwYXJtcy5faWQgfHwgUmFuZG9tLmlkKClcbiAgICAgICAgUmV0cm8uY3JlYXRlZEF0ID0gbmV3IERhdGUoKVxuICAgICAgICBSZXRyby5jcmVhdGVkQnkgPSBwYXJtcy5jcmVhdGVkQnkgfHwgUmFuZG9tLmlkKClcbiAgICAgICAgUmV0cm8udGl0bGUgPSBwYXJtcy50aXRsZSB8fCAnZmFrZSB0aXRsZSdcbiAgICAgICAgUmV0cm8uc3RhdHVzID0gcGFybXMuc3RhdHVzIHx8IENvbnN0YW50cy5SZXRyb1N0YXR1c2VzLkFDVElWRVxuICAgICAgICBSZXRyby5pdGVtcyA9IHBhcm1zLml0ZW1zIHx8IHRoaXMuZmFrZVJldHJvSXRlbXMoe30sIHBhcm1zLmNvdW50IHx8IDMpXG4gICAgICAgIFJldHJvLnNob3dDb21wbGV0ZWQgPSBfLmlzVW5kZWZpbmVkKHBhcm1zLnNob3dDb21wbGV0ZWQpID8gZmFsc2UgOiBwYXJtcy5zaG93Q29tcGxldGVkXG4gICAgICAgIFJldHJvLmFyY2hpdmVkQXQgPSBwYXJtcy5hcmNoaXZlZEF0IHx8IG5ldyBEYXRlKClcbiAgICAgICAgUmV0cm8uaGFwcHlQbGFjZWhvbGRlciA9ICdGYWtlIGhhcHB5IHBsYWNlaG9sZGVyJ1xuICAgICAgICBSZXRyby5tZWhQbGFjZWhvbGRlciA9ICdGYWtlIG1laCBwbGFjZWhvbGRlcidcbiAgICAgICAgUmV0cm8uc2FkUGxhY2Vob2xkZXIgPSAnRmFrZSBzYWQgcGxhY2Vob2xkZXInXG4gICAgICAgIGlmIChwYXJtcy5hcmNoaXZlTmFtZSkge1xuICAgICAgICAgICAgUmV0cm8uYXJjaGl2ZU5hbWUgPSBwYXJtcy5hcmNoaXZlTmFtZVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIFJldHJvXG4gICAgfSxcblxuICAgIGZha2VSZXRybzIocGFyYW1ldGVycykge1xuICAgICAgICBsZXQgcGFybXMgPSB7fVxuXG4gICAgICAgIGlmICghXy5pc1VuZGVmaW5lZChwYXJhbWV0ZXJzKSkge1xuICAgICAgICAgICAgcGFybXMgPSBwYXJhbWV0ZXJzO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgUmV0cm8gPSB7fVxuXG4gICAgICAgIFJldHJvLl9pZCA9IHBhcm1zLl9pZCB8fCBSYW5kb20uaWQoKVxuICAgICAgICBSZXRyby5jcmVhdGVkQXQgPSBuZXcgRGF0ZSgpXG4gICAgICAgIFJldHJvLmNyZWF0ZWRCeSA9IHBhcm1zLmNyZWF0ZWRCeSB8fCBSYW5kb20uaWQoKVxuICAgICAgICBSZXRyby50aXRsZSA9IHBhcm1zLnRpdGxlIHx8ICdmYWtlIHRpdGxlJ1xuICAgICAgICBSZXRyby5zdGF0dXMgPSBwYXJtcy5zdGF0dXMgfHwgQ29uc3RhbnRzLlJldHJvU3RhdHVzZXMuQUNUSVZFXG4gICAgICAgIFJldHJvLml0ZW1zID0gcGFybXMuaXRlbXMgfHwgdGhpcy5mYWtlUmV0cm9JdGVtcyhwYXJhbWV0ZXJzLCBwYXJtcy5jb3VudCB8fCAzKVxuICAgICAgICBSZXRyby5zaG93Q29tcGxldGVkID0gXy5pc1VuZGVmaW5lZChwYXJtcy5zaG93Q29tcGxldGVkKSA/IGZhbHNlIDogcGFybXMuc2hvd0NvbXBsZXRlZFxuICAgICAgICBSZXRyby5hcmNoaXZlZEF0ID0gcGFybXMuYXJjaGl2ZWRBdCB8fCBuZXcgRGF0ZSgpXG4gICAgICAgIFJldHJvLmhhcHB5UGxhY2Vob2xkZXIgPSAnRmFrZSBoYXBweSBwbGFjZWhvbGRlcidcbiAgICAgICAgUmV0cm8ubWVoUGxhY2Vob2xkZXIgPSAnRmFrZSBtZWggcGxhY2Vob2xkZXInXG4gICAgICAgIFJldHJvLnNhZFBsYWNlaG9sZGVyID0gJ0Zha2Ugc2FkIHBsYWNlaG9sZGVyJ1xuICAgICAgICBpZiAocGFybXMuYXJjaGl2ZU5hbWUpIHtcbiAgICAgICAgICAgIFJldHJvLmFyY2hpdmVOYW1lID0gcGFybXMuYXJjaGl2ZU5hbWVcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBSZXRyb1xuICAgIH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSB7IFRlc3REYXRhIH1cblxuIl19
