(function () {



/* Exports */
Package._define("cultofcoders:persistent-session");

})();
